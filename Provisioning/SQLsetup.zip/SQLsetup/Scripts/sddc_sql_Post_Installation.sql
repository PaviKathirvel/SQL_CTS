/**********************************************************************************************
Script Name: SQL_Post_Installation
Description: SQL Script to customize SQL Server installation for SDDC
**********************************************************************************************
Version			Date			Author			Reason For Change
1.0				05/20/2014		Bruno Campos	New Script
**********************************************************************************************/

/*Grant access to server specific DBA groups*/


SET NOCOUNT ON

declare @machinName nvarchar(1000)
declare @grpName nvarchar(1000)
declare @grpName1 nvarchar(1000)
declare @sql nvarchar(4000)
set @machinName = cast(SERVERPROPERTY('machinename') as nvarchar)


set @grpName = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA'
set @grpName1 = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA-Temp'


if not exists (select * from sys.syslogins where loginname in (@grpName,@grpName1))
begin
set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
PRINT @SQL
exec sp_executesql @sql

set @sql = ''
set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName,'''') + ', @rolename = ' + quotename('sysadmin','''')
PRINT @SQL
exec sp_executesql @sql

set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName1) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
exec sp_executesql @sql

set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName1,'''') + ', @rolename = ' + quotename('sysadmin','''')
exec sp_executesql @sql
end

/**********************************************/
/*Create Job for DataIntegrity And Optimization Maintenance Plan*/
/**********************************************/
USE [msdb]
GO

/****** Object:  Job [DataIntegrityAndOptimizationMaintenance.Subplan_1]    Script Date: 5/20/2014 8:19:57 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 5/20/2014 8:19:57 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DataIntegrityAndOptimizationMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 5/20/2014 8:19:57 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\DataIntegrityAndOptimizationMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DataIntegrityAndOptimizationMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=120000, 
		@active_end_time=235959, 
		@schedule_uid=N'8e230b2c-f3f0-49bb-b17d-dac479f08b19'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{2BF14C47-FEB2-43D5-B357-A53794FC42C5}',
@plan_id = '{4D91B031-E7D0-46A8-BF10-A8E1162D081D}',
@name = 'DataIntegrityAndOptimizationMaintenance',
@description = 'DataIntegrityAndOptimizationMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/**********************************************/
/*Create Job for Differential Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [DiffDatabaseBackupMaintenance.Subplan_1]    Script Date: 5/20/2014 8:30:38 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 5/20/2014 8:30:38 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DiffDatabaseBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 5/20/2014 8:30:38 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\DiffDatabaseBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DiffDatabaseBackupMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=95, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'7d608cea-62e9-4d6c-8a19-0d5f7a04c544'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{344CEB6C-8F11-44B8-A5DE-1DEE4F159C14}',
@plan_id = '{8FDBE6A9-4F8D-40C3-A456-4B69B9B22116}',
@name = 'DiffDatabaseBackupMaintenance',
@description = 'DiffDatabaseBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/**********************************************/
/*Create Job for Full Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [FullDatabaseBackupMaintenance.Subplan_1]    Script Date: 5/20/2014 8:32:46 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 5/20/2014 8:32:46 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FullDatabaseBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 5/20/2014 8:32:46 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\FullDatabaseBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'FullDatabaseBackupMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'54c59be2-5a91-4c61-ac0e-7a25a7f2c87b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{3F0A8222-1C00-430A-929B-37C2316E54AD}',
@plan_id = '{328EE8BA-1A10-41D6-A072-85E994A891FA}',
@name = 'FullDatabaseBackupMaintenance',
@description = 'FullDatabaseBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/**********************************************/
/*Create Job for Transaction Log Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [TransactionLogBackupMaintenance.Subplan_1]    Script Date: 5/20/2014 8:35:06 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 5/20/2014 8:35:06 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'TransactionLogBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 5/20/2014 8:35:06 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\TransactionLogBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'TransactionLogBackupMaintenance', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'578d5b23-3839-4ff3-95c3-2d10f8843baf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{0609D009-D85D-4939-BB13-258F82B91378}',
@plan_id = '{882A742D-277B-4006-9FBA-29B79320AACD}',
@name = 'TransactionLogBackupMaintenance',
@description = 'TransactionLogBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



USE MASTER
GO
sp_configure 'show advanced options', 1;
GO
reconfigure
GO
/**********************************************/
/*Enable Backup Compression*/
USE master
GO
sp_configure 'backup compression default',1
GO
reconfigure
GO
/**********************************************/
/*Configure to use 75% of Server Memory*/
DECLARE @S_Mem INT
SELECT @S_Mem = (SELECT total_physical_memory_kb/1024 FROM sys.dm_os_sys_memory) * 0.75
BEGIN
EXEC sp_configure 'max server memory (MB)',@S_Mem
reconfigure
END
GO
/**********************************************/
/*Configure Remote Query Timeout*/
sp_configure 'remote query timeout (s)',0
GO
reconfigure
GO
/**********************************************/
/*Configure Remote admin connection*/
sp_configure 'remote admin connections', 1
GO
reconfigure
GO

/**********************************************/
/*Configure MAXDOP based on # of processors*/
DECLARE @T_CPU INT 
DECLARE @S_CPU INT
SELECT @T_CPU = (SELECT cpu_count FROM sys.dm_os_sys_info)


IF @T_CPU > 4
BEGIN
	SET @S_CPU = @T_CPU / 2
	IF @S_CPU <= 8
		EXEC sp_configure 'max degree of parallelism', @S_CPU
	ELSE
		EXEC sp_configure 'max degree of parallelism', 8
END



/*Configure xp_cmdshell*/
USE master
GO
sp_configure 'xp_cmdshell',1
GO
reconfigure
GO
/**********************************************/
/*Grant access to CMDB auto discovery account*/
/***************Atl**************/
IF NOT Exists (select * from sys.syslogins where loginname = 'JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe')
BEGIN
CREATE LOGIN [JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe] FROM WINDOWS 
END
GO

/**********************************************/


/*Configure Error Log to 45 files*/
EXEC master.sys.xp_instance_regwrite
    N'HKEY_LOCAL_MACHINE',
    N'Software\Microsoft\MSSQLServer\MSSQLServer',
    N'NumErrorLogs',
	N'REG_DWORD',
    45
GO
/**********************************************/





/**********************************************/
/*Configure TempDB Data and LogFiles*/
DECLARE @TDB_Size_Source INT,@TDB_Size INT,@STDB_Size INT, @CMD NVARCHAR(4000), @CMD_2 NVARCHAR(4000), @CMD_3 NVARCHAR(4000), @i INT, @Loc VARCHAR(1000), @T_CPU INT
SELECT @Loc = (SELECT SUBSTRING(physical_name,0,CHARINDEX('\tempdb.mdf',physical_name)+1) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' AND FILE_ID = 1)
SELECT @TDB_Size_Source = (SELECT 
						(((total_bytes/1024)/1024)/1024)
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
SELECT @T_CPU = (SELECT cpu_count FROM sys.dm_os_sys_info)
IF @TDB_Size_Source < 10
BEGIN
SELECT @TDB_Size = (SELECT 
						(total_bytes/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
SET @STDB_Size = @TDB_size * 0.10

IF @T_CPU = 1
BEGIN

	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + ''',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
END
IF @TDB_Size_Source >= 10
BEGIN
SELECT @TDB_Size = (SELECT 
						((total_bytes/1024)/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
IF (@TDB_size * 0.10) <= 10
	SET @STDB_Size = @TDB_size * 0.10
ELSE
	SET @STDB_Size = 10

IF @T_CPU = 1
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	print @CMD
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
END

/*********End TempDB*************************************/




