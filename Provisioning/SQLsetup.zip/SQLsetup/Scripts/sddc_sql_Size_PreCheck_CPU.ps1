###################################################################################################
$ScriptName = "sddc_sql_Size_PreCheck_CPU.PS1"
$Scriptver = "1.0"
#Description: Script used to verify CPU values prior to re-size.
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			10/07/2016	Bruno Campos	New Script
###################################################################################################
####
#*********** Lab DML************* 
#$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML' 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\SDDC' 
$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl


#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
#####

#Number of CPUs passed by VRA
$ErrorActionPreference = "SilentlyContinue"
$error.clear()
$N_CPU = $args[0]


#*********************************** Start of Post installation function ***********************************#

FUNCTION sddc_sql_Size_Modification($IDMLLOC)  
{

$Time = get-date -Uformat "%Y%m%d%H%M"
$Log = "C:\SQLInstall_Logs\sddc_sql_Size_PreCheck_CPU_$Time.txt"
$M_Plans_sql = $IDMLLOC + "\Scripts"

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Inst_Status = $svr.status
IF ($Inst_Status -ne "OnLine")
{
$Final_Status_Error = 1
}
ELSE
{
$Final_Status_Error = 0

$conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
$conn.Open()

#--------------------------------- Checking MAXDOP Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$CPU = $N_CPU

$cmdDD_6 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_6.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max degree of parallelism'"
$cmdDD_6.Connection = $conn
$DOP = $cmdDD_6.ExecuteScalar()
if ($CPU -le 4)
{
IF ($DOP -eq 0)
{
	Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 0"
	Write-Host "Current value in use for Max DOP allocation: $DOP"
	"For $CPU CPU(s), expected value in use for Max DOP allocation: 0" >> $Log
	"Current value in use for Max DOP allocation: $DOP" >> $Log
}
ELSE
{
	Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 0"
	Write-Host "Current value in use for Max DOP allocation: $DOP"
	"For $CPU CPU(s), expected value in use for Max DOP allocation: 0" >> $Log
	"Current value in use for Max DOP allocation: $DOP" >> $Log
}
}
IF ($CPU -gt 4)
{
	$C_CPU = $CPU / 2
	IF ($CPU -gt 8)
	{
	IF ($DOP -eq 8)
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 8"
		Write-Host "Current value in use for Max DOP allocation: $DOP"
		"For $CPU CPU(s), expected value in use for Max DOP allocation: 8" >> $Log
		"Current value in use for Max DOP allocation: $DOP" >> $Log
	}
	ELSE
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 8"
		Write-Host "Current value in use for Max DOP allocation: $DOP"
		"For $CPU CPU(s), expected value in use for Max DOP allocation: 8" >> $Log
		"Current value in use for Max DOP allocation: $DOP" >> $Log
	}
	}
	IF ($DOP -eq $C_CPU)
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU"
		Write-Host "Current value in use for Max DOP allocation: $DOP"
		"For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU" >> $Log
		"Current value in use for Max DOP allocation: $DOP" >> $Log
	}
	ELSE
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU"
		Write-Host "Current value in use for Max DOP allocation: $DOP"
		"For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU" >> $Log
		"Current value in use for Max DOP allocation: $DOP" >> $Log
	}
}

#--------------------------------- Checking TEMPDB Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_x = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_x.CommandText = "SELECT (((total_bytes/1024)/1024)/1024) AS Value FROM sys.master_files AS f CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID) WHERE DB_NAME(f.database_id) = 'tempdb' AND f.FILE_ID = 1"
$cmdDD_x.Connection = $conn
$TempDrive_T_Size = $cmdDD_x.ExecuteScalar()
$cmdDD_x2 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_x2.CommandText = "SELECT CONVERT(INT,$TempDrive_T_Size * 0.10)"
$cmdDD_x2.Connection = $conn
$TempDB_Size = $cmdDD_x2.ExecuteScalar()

If ($TempDB_Size -gt 10)
{
$TempDB_Size = 10
}

$cmdDD_7 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_7.CommandText = "SELECT COUNT(*) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and type_desc = 'ROWS'"
$cmdDD_7.Connection = $conn
$Temp_Count = $cmdDD_7.ExecuteScalar()
if ($Temp_Count -eq $CPU)
{
	Write-Host "For $CPU CPU(s), expected number of TempDB files : $CPU"
	Write-Host "Current number of TempDB files : $Temp_Count"
	Write-Host ""
	"For $CPU CPU(s), expected number of TempDB files : $CPU" >> $Log
	"Current number of TempDB files : $Temp_Count" >> $Log
	"-------" >> $Log
	$T = 0
}
ELSE
{
	Write-Host "For $CPU CPU(s), expected number of TempDB files : $CPU"
	Write-Host "Current number of TempDB files : $Temp_Count"
	Write-Host ""
	"For $CPU CPU(s), expected number of TempDB files : $CPU" >> $Log
	"Current number of TempDB files : $Temp_Count" >> $Log
	"-------" >> $Log
	$T = 1
}
$cmdDD_8 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_8.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'tempdev'"
$cmdDD_8.Connection = $conn
$Temp_Files = $cmdDD_8.ExecuteScalar()
if ($Temp_Files -eq $TempDB_Size)
{
	Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
	Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
	Write-Host ""
	"Expected TempDB size for the given drive size : $TempDB_Size GB" >> $Log
	"Current TempDB size for the given drive size : $Temp_Files GB" >> $Log
	"-------" >> $Log
	$TF = 0
}
ELSE
{
	Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
	Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
	Write-Host ""
	"Expected TempDB size for the given drive size : $TempDB_Size GB" >> $Log
	"Current TempDB size for the given drive size : $Temp_Files GB" >> $Log
	"-------" >> $Log
	$TF = 1
}

$cmdDD_9 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_9.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'templog'"
$cmdDD_9.Connection = $conn
$Temp_Log = $cmdDD_9.ExecuteScalar()
if ($Temp_Log -eq $TempDB_Size)
{
	Write-Host "Expected size of Temp log file : $TempDB_Size"
	Write-Host "Current size of Temp log file : $Temp_Log"
	Write-Host ""
	"Expected size of Temp log file : $TempDB_Size" >> $Log
	"Current size of Temp log file : $Temp_Log" >> $Log
	"-------" >> $Log
	$TLF = 0
}
ELSE
{
	Write-Host "Expected size of Temp log file : $TempDB_Size"
	Write-Host "Current size of Temp log file : $Temp_Log"
	Write-Host ""
	"Expected size of Temp log file : $TempDB_Size" >> $Log
	"Current size of Temp log file : $Temp_Log" >> $Log
	"-------" >> $Log
	$TLF = 1
}
}
IF ($Final_Status_Error -eq 1)
{
Write-Host "STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"STATUS = FAILED" >> $Log
Write-Host "SQL Server instance not on-line"
"SQL Server instance not on-line" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Exit 0
}
}

#*********************************** End of Post installation function ***********************************#


#--------- Start POST install configuration ---------#

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1
$ipAddressParts = $GetIp.Split('.') 

$IpPartsIdentifier1 = $ipAddressParts[0]
$IpPartsIdentifier2 = $ipAddressParts[1]
$IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	sddc_sql_Size_Modification $LabSQLDML

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

	sddc_sql_Size_Modification $NASQLDML
 }
}

#--------- End POST install configuration ---------#

