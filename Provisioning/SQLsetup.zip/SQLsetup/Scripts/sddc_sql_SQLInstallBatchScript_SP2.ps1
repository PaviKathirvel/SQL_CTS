###################################################################################################
$ScriptName = "sddc_sql_SQLInstallBatchScript.PS1"
$Scriptver = "2.0"
#Description: Description: Execute all the scripts related to SQL provisioning in one batch 
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			09/10/2014	Atul Patil	New Script
#2.0			11/24/2014	Jay Sangam	Provision for named instance installs

###################################################################################################


#*********** Lab DML************* 
$LabSQLDML= "\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\Scripts\"

#*********** NA DML*************

$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\'

#******************Identify server location based on IP address *****************

$Process = $args[0]
$Tier = $args[1]
$Env = $args[2]
$sqlversion = $args[3]
$Edition = $args[4]



#$InstanceName = $args[5]	Un-Comment later for named instance installations
$InstanceName = "MSSQLSERVER"	# Delete this line later for named instance installs.


#--------------------------------- Checking Parameters Values ---------------------------------#

IF (($Process -ne "SDDC") -and ($Process -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
EXIT 0
}

IF (($Tier -ne "Small") -and ($Tier -ne "Medium") -and ($Tier -ne "Large"))
{
Write-Host ""
Write-Host "Size not Valid. Please pass SMALL or MEDIUM or LARGE as 2nd parameter" -f red
Write-Host ""
EXIT 0
}

IF (($Env -ne "DEV") -and ($Env -ne "QA") -and ($Env -ne "PROD"))
{
Write-Host ""
Write-Host "Environment not Valid. Please pass DEV or QA or PROD as 3rd parameter" -f red
Write-Host ""
EXIT 0
}

IF (($sqlversion -ne "SQL2005") -and ($sqlversion -ne "SQL2008") -and ($sqlversion -ne "SQL2012"))
{
Write-Host ""
Write-Host "Invalid SQLServer version. Please pass SQL2005 or SQL2008 or SQL2012 as 4th parameter" -f red
Write-Host ""
EXIT 0
}

IF (($Edition -ne "E") -and ($Edition -ne "S"))
{
Write-Host ""
Write-Host "Edition not Valid. Please pass either E or S as 5th parameter" -f red
Write-Host ""
EXIT 0
}

#	Un-comment later for named instance installs.
# IF($InstanceName -eq $null)
# {

#        Write-Host ""
#        Write-Host "Please pass instance name as 6th parameter" -f red
#        Write-Host ""

#	Exit 0
# }

IF (Test-Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')

{

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -ne $null)
{
 foreach ($inst in $instances)
 {
 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst

	IF($inst -eq 'MSSQLSERVER')
	{
		Write-Host ""
#		Write-host "Instance $InstanceName already exists. Please pass a different instance name"	Un-comment later for named instance installs.
		Write-host "Default instance $InstanceName already exists."					# Delete this line later for named instance installs.
		Write-Host ""  
        	Exit 0    
	}
 }
}

}
ELSE
{

#Fresh build

}

#-------------------------------- Install function ----------------------------------

FUNCTION Executeallscripts
{
Param(
       [string] $dmllocation,
       [string] $prc,
       [string] $tr,
       [string] $envr,
       [string] $sqlver,
       [string] $edtn,
       [string] $instnc	
     )


$Time = get-date -Uformat "%Y%m%d%H%M"

IF (!(Test-Path C:\SQLInstall_Logs))
{
mkdir "C:\SQLInstall_Logs"
}
$BatchLog = "C:\SQLInstall_Logs\sddc_sql_SQLInstallBatchScript_$Time.txt"

Write-Host "###################################################################################################"
"###################################################################################################" > $BatchLog
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $BatchLog
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $BatchLog
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $BatchLog
Write-Host "Server Host: $ENV:computername"
"Server Host: $ENV:computername" >> $BatchLog
"Execution string: $ScriptName $prc $tr $envr $sqlver $edtn $instnc" >> $BatchLog
Write-Host "###################################################################################################"
"###################################################################################################" >> $BatchLog
"" >> $BatchLog


#----------------Execute O/S Verification------------------# 
$OSVerification = "$dmllocation" + 'sddc_sql_Pre-Req_OS_Verification.ps1'

powershell.exe -ExecutionPolicy Bypass $OSVerification $prc $tr $envr $sqlver

   $Script1 = (Get-Content "C:\IQOQ\Status.txt")

    If ($Script1 -ne "FAILED")
    {
    #----------------Execute SQL Installation------------------#
       "Script sddc_sql_Pre-Req_OS_Verification.ps1 : Executed successfully" >> $BatchLog
       $SQLInstallation = "$dmllocation" + 'sddc_sql_InstallSQLServer.ps1'

       powershell.exe -ExecutionPolicy Bypass $SQLInstallation $prc $sqlver $edtn $instnc
      
       $Script2 = (Get-Content "C:\IQOQ\Status.txt")

      If ($Script2 -ne "FAILED")
        {
        #----------------Execute Post Installation------------------# 
          "Script sddc_sql_InstallSQLServer.ps1 : Executed successfully" >> $BatchLog
           $SQLPostInstallation = "$dmllocation" + 'sddc_sql_Post_Installation.ps1'

           powershell.exe -ExecutionPolicy Bypass $SQLPostInstallation $prc $sqlver $instnc
        
	    
	    $Script3 = (Get-Content "C:\IQOQ\Status.txt")
            If ($Script3 -ne "FAILED")
            {
                #----------------Execute Post Verification------------------# 
                "Script sddc_sql_Post_Installation.ps1 : Executed successfully" >> $BatchLog                  
		If ($Process -eq "NON_SDDC")
		 {
		   $SQLInstallVerification = "$dmllocation" + 'sddc_sql_Post_Installation_Verification.ps1'

                   powershell.exe -ExecutionPolicy Bypass $SQLInstallVerification $sqlver $instnc
		 	If ($Script2 -eq "REBOOT")
			{
			Write-Host "Please reboot the server"
			}
				$Script4 = (Get-Content "C:\IQOQ\Status.txt")
				If ($Script4 -ne "FAILED")
				 {
				    "Script sddc_sql_Post_Installation_Verification.ps1 : Executed successfully" >> $BatchLog
				 }
				 else
				 {
				    "Script sddc_sql_Post_Installation_Verification.ps1 : FAILED. View the log files and address the failed steps" >> $BatchLog
				 }
		 }
		Elseif ($Process -eq "SDDC")
		 {
		   $SQLInstallVerification = "$dmllocation" + 'sddc_sql_Post_Installation_Verification_SDDC.ps1'

                   powershell.exe -ExecutionPolicy Bypass $SQLInstallVerification $sqlver $envr $instnc
		 	If ($Script2 -eq "REBOOT")
			{
			Write-Host "Please reboot the server"
			}
				$Script4 = (Get-Content "C:\IQOQ\Status.txt")
				If ($Script4 -ne "FAILED")
				 {
				    "Script sddc_sql_Post_Installation_Verification_SDDC.ps1 : Executed successfully" >> $BatchLog
				 }
				 else
				 {
				    "Script sddc_sql_Post_Installation_Verification_SDDC.ps1 : FAILED. View the log files and address the failed steps" >> $BatchLog
				 }
		 }
            }       
            Else 
            {
                Write-host "Error during Post Installation script sddc_sql_Post_Installation"
		"Script sddc_sql_Post_Installation.ps1 : Error during Post Installation script sddc_sql_Post_Installation" >> $BatchLog
            } 

	}              
       Else 
       {
        Write-host "Reboot required OR Error during SQL Installation"
	"Script sddc_sql_InstallSQLServer.ps1 : Reboot required OR Error during SQL Installation" >> $BatchLog
       }

    }
       Else 
       {
        #Write-host "Error during SQL Installation"
	Write-Host ""
        Write-host "Resolve the failed tasks and then run the script."
	Write-Host ""
	"Script sddc_sql_Pre-Req_OS_Verification.ps1 : Resolve the failed tasks and then run the script." >> $BatchLog 
       }
    
}

#------------------------------------- End of function -------------------------------------

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]  

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	$location = "on LAB Server"
	Executeallscripts $LabSQLDML $Process $Tier $Env $sqlversion $Edition $InstanceName
 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 223)
 { 
	$location =  "on NA Server"
    	Executeallscripts $NASQLDML $Process $Tier $Env $sqlversion $Edition $InstanceName
	
 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
 }
}

