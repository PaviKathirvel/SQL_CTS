###################################################################################################
$ScriptName = "sddc_sql_InstallSQLServer_SP2.PS1"
$Scriptver = "1.0"
#Description: Description: Install SQL Server, use DML based on Server Location 
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			07/24/2014	Atul Patil	New Script
#2.0			11/17/2014	Jay Sangam	Named instance coding

###################################################################################################


#*********** Install Parameters*************
$Process = $args[0]
$Edition = $args[1]
$InstName = $args[2]
$InstName = "MSSQLSERVER"	#Delete this line later for named instance installs.

$EPIDNumber = '/PID="FH666-Y346V-7XFQ3-V69JM-RHW28"'
$SPIDNumber = '/PID="YFC4R-BRRWB-TVP9Y-6WJQ9-MCJQ7"' 
$Noupdate ='/UpdateEnabled=False'
$Action ='/Action=Install'
$InstParam = '/INSTANCENAME=' + $InstName
$InstParamID = '/INSTANCEID=' + $InstName

IF ($InstName -eq 'MSSQLSERVER')
{
$SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
$AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
}
ELSE
{
$SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
$AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
}

IF (($Process -ne "SDDC") -and ($Process -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
"Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" >> $Log
Exit 0
}

$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2012'

IF ($Process -eq "SDDC") 
{

$cnfgfl = '\ConfigFiles\SDDC_DefaultConfigurationFile.ini"'

#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\SDDC_DefaultConfigurationFile.ini"'	#Personal Config file

$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\MSSQL\Backup'
$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\Data'
$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2012\MSSQL11.' + $InstName + '\Log'
$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2012\MSSQL11.' + $InstName + '\Tempdb'

}

IF ($Process -eq "NON_SDDC")
{
 
$cnfgfl = '\ConfigFiles\DefaultConfigurationFile.ini"'

#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\DefaultConfigurationFile.ini"'	#Personal Config file

$BkpDir = '/SQLBACKUPDIR=G:\MSSQL2012\MSSQL11.' + $InstName + '\MSSQL\Backup'
$UserDBDir = '/SQLUSERDBDIR=E:\MSSQL2012\MSSQL11.' + $InstName + '\Data'
$UserDBLogDir = '/SQLUSERDBLOGDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\Log'
$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2012\MSSQL11.' + $InstName + '\Tempdb'

}

$cnfgfl_lab = '\ConfigFiles\NonSDDCDefaultConfigurationFile.ini"'  #Non SDDC config
$BatchOutput2 = "C:\IQOQ\Status.txt"

#*********** Lab DML************* 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML' 
$LabSetup =  $LabSQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"
$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl_lab

#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
$NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl

#*********** EMEA DML*************
$EMEASQLDML = '\\itsbebevsnap01.jnj.com\msqldml'
$EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"
$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

#*********** ASPAC DML*************
$ASPACSQLDML = '\\itssgsgw00009\MSQLDML'
$ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"
$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

#*********** LA DML*************
$LASQLDML = '\\itsbrsjvsnap01.jnj.com\msqldml'
$LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"
$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl


#*********** Select Edition************* 
IF($Edition -eq 'S')
{
 	$PIDNumber = $SPIDNumber 
	$SelectedEdition = 'Standard Edition....'
}
ELSEIF($Edition -eq 'E')
{
	$PIDNumber = $EPIDNumber 
	$SelectedEdition = 'Enterprise Edition....'
}
ELSE 
{
        Write-Host ""
        Write-Host "Pass S for Standard or E for Enterprise edition as 2nd parameter" -f red
        Write-Host ""

	Exit 0
}


#*********** Get Instance name ************* 

IF($InstName -eq $null)
{

        Write-Host ""
        Write-Host "Please pass instance name as 3rd parameter" -f red
        Write-Host ""

	Exit 0
}


#*********** Get Domain*************
#$FQDN_hostname = HKLM:\SYSTEM\ ControlSet001\Services\Tcpip\Parameters" Domain
#$FQDN_hostname = Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\services\Tcpip\Parameters" -Name domain

#*************************** Function Verify SQL Install ***************************
Function verifySQLInstall()
{


	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"

    	$Path = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\' + $LatestFolder


	$SummaryFile = Get-ChildItem $Path -Filter "Summary*GlobalRules.txt"
	# Write-Host "Summary file is $SummaryFile"

	$ResultFile = $Path + "\" + $SummaryFile
	$exitmsg = (Get-Content $ResultFile)[2].Trim()

	If ($exitmsg -eq "Exit code (Decimal):           -2067919934")
	{
    	  Write-Host ""
    	  Write-Host "A Computer restart is required. Installation of SQL 2012 instance $($InstName) : " -f white -nonewline; Write-Host "FAILED" -f red
    	  Write-Host ""
    	  "" >> $Log
    	  "A Computer restart is required. Installation of SQL 2012 instance $InstName : FAILED" >> $Log
	  "FAILED" > $BatchOutput2
	  EXIT 0
	}

    $Time = get-date -Uformat "%Y%m%d%H%M"
    $file_txt = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\Summary.txt'
    $s1 = (Get-Content $file_txt)[1]
    $s2 = (Get-Content $file_txt)[3]
    $s3 = (Get-Content $file_txt)[4]
    $s4 = (Get-Content $file_txt)[2].Trim()
    #$exitcode = "  Final result:                  Passed"
    $exitPass  = "Exit code (Decimal):           0"
    $exitPassReboot  = "Exit code (Decimal):           3010"


    ################External Files##########################
    $Log = "C:\SQLInstall_Logs\sddc_sql_Installation_Verification_$Time.txt"

    Write-host ""
    Write-Host "#######################################################################"
    "#######################################################################" > $Log
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >> $Log
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >> $Log
    Write-Host "Executed On: $Exec_Time"
    "Execute On: $Exec_Time" >> $Log
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >> $Log
    "Execution string: $ScriptName $Process $Edition $InstName" >> $Log

    Write-Host "#######################################################################"
    "#######################################################################" >> $Log


    if ($s4 -eq $exitPass)  
    {
    	Write-Host ""
    	Write-Host "Installation of SQL 2012 instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL" -f green
    	Write-Host ""
    	"" >> $Log
    	"Installation of SQL 2012 instance $InstName : SUCCESSFUL" >> $Log
	"SUCCESS" > $BatchOutput2
    }
    ELSEIF ($s4 -eq $exitPassReboot)
    {
    	Write-Host ""
    	Write-Host "Installation of SQL 2012 instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL, but reboot the server before proceeding to next step" -f red
    	Write-Host ""
    	"" >> $Log
    	"SUCCESSFUL, but reboot the server before proceeding to next step" >> $Log
	"REBOOT" > $BatchOutput2
    }
    ELSE
    {
    	Write-Host ""
    	Write-Host "Installation of SQL 2012 instance $InstName : " -f white -nonewline; Write-Host "FAILED" -f red
    	Write-Host ""
    	"" >> $Log
    	"Installation of SQL 2012 instance $InstName : FAILED" >> $Log
	"FAILED" > $BatchOutput2
    }

        Write-Host ""
        Write-Host "------------------------ Installation Summary -------------------------"  
        Write-Host ""
        Write-Host "$s1"
        Write-Host "$s2"
        Write-Host "$s3"
        Write-Host ""

        "" >> $Log
        "------------------------ Installation Summary -------------------------"  >> $log
        "" >> $Log
        "$s1" >> $log
        "$s2" >> $log
        "$s3" >> $log

        $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances


        # Verify SQL instances
        foreach ($inst in $instances)
        {
        $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	
	IF ($p -eq 'MSSQL11.' + $InstName)
	 {
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"
	}
    }

} 

#*************************** End of Verify SQL Install Function ***************************

#*************************** InstallSQLInstance Function ***************************

Function InstallSQLInstance
{
Param(
	[string] $setp,
    	[string] $ConfigFile,
	[string] $Dlocation
     )
        Write-Host ""
        Write-Host "------Installing SQL2012 instance $InstName"  $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""

	        
	& $setp $Action $ConfigFile $InstParam $InstParamID $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Noupdate

    	WRITE-HOST "Installation completed..."
        VerifySQLInstall
}
#*************************** End InstallSQLInstance Function ***************************

#*************************** Verify if the instance already exists ***************************

IF (Test-Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')

{

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -ne $null)
{
 foreach ($inst in $instances)
 {
 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
 	IF($dinst -eq 'MSSQL11.' + $InstName)
	{
		Write-Host ""
#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
		Write-host "Default instance $InstName already exists."					#Delete this line later for named instance installs.
		Write-Host ""
		"FAILED" > $BatchOutput2  
        	Exit 0    
	}
 }
}

}
ELSE
{

#Fresh build

}

#*********** End of Verifying if the instance already existis*************


#******************Identify server location based on IP address *****************
 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	$location = "on LAB Server"
	InstallSQLInstance $LabSetup $LabConfig $location
 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 
	$location =  "on NA Server"
    	InstallSQLInstance $NASetup $NAConfig $location
	
 }
 ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 { 	
	$location = "on LA Server"
	InstallSQLInstance $LASetup $LAConfig $location
    	
 }
 ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 { 	
	$location = "on EMEA Server"
    	InstallSQLInstance $EMEASetup $EMEAConfig $location

 }
 ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 { 	
	$location = "on ASPAC Server"
    	InstallSQLInstance $ASPACSetup $ASPACConfig $location

 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
	
 }

}


#******************End of identifying server location based on IP address *****************


