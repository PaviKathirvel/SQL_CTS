################################################################################################### ############needs 1 change#############
$ScriptName = "sddc_sql_Post_Installation_Verification.PS1"
$Scriptver = "7.0"
#Description: Description: SQL Post Installation Steps for SDDC
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			05/07/2014	Bruno Campos	          New Script
#2.0			07/24/2014	Jay Sangam	          	  Added Default DBA groups to CMDB section
#3.0			08/04/2014	Bruno Campos	          Fix issues checking MAXDOP and TempDB files
#4.0            Jan/19/2017	Saketh Valluripalli       Provisioning of SQL 2014 and additional parameter SP3CU11.0.6567 for SQL2012 builds
#5.0 			Sept/2/2019	Sanjiv					  Adding 2017 Installation logic	and Baseline Performance framework 
#6.0 			FEB/26/2020	Sanjiv				 	  Adding 2019 Installation logic	
#7.0 			FEB/26/2024	Shubham				 	  Adding 2022 Installation logic
###################################################################################################

#*********** Lab DML************* 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML' 
$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
#####

$Time = get-date -Uformat "%Y%m%d%H%M"
################External Files##########################
$Log = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_Verification_$Time.txt"
$BatchOutput4 = "C:\IQOQ\Status.txt"
########################################################

$sqlver2 = $args[0]
$spver2 = $args[1]
$InstName = $args[2]
$InstName = "MSSQLSERVER"	#Delete this line later for named instance installs.

###################shubh
IF (($sqlver2 -ne "SQL2005") -and ($sqlver2 -ne "SQL2008") -and ($sqlver2 -ne "SQL2012") -and ($sqlver2 -ne "SQL2014") -and ($sqlver2 -ne "SQL2016") -and ($sqlver2 -ne "SQL2017") -and ($sqlver2 -ne "SQL2019") -and ($sqlver2 -ne "SQL2022"))
{
Write-Host ""
Write-Host "SQL build version not Valid. Please pass SQL2005 or SQL2008 or SQL2012 or SQL2014 or SQL2016 or SQL2017 or SQL2019 or SQL2022 as 1st parameter" -f red
Write-Host ""
Exit 0
}

IF ($InstName -eq $null)
{
Write-Host ""
Write-Host "Pass a valid instance name as 2nd parameter" -f red
Write-Host ""
Exit 0
}

#------------------------ Check if valid instance name is being passed --------------------------------------

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -notcontains $InstName)
{
Write-Host ""
#Write-Host "Instance $InstName not found. Pass a valid instance name" -f red	Un-comment later for named instance installs.
Write-Host "Instance $InstName not found." -f red		#Delete this line later for named instance installs.
Write-Host ""
Exit 0
}

#*********** Accept valid SP for the SQL version passed *************

IF ($sqlver2 -eq "SQL2005")
{
 IF (($spver2 -ne "SP3") -and ($spver2 -ne "SP4"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2005. Please pass SP3 or SP4 as 3rd parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlver2 -eq "SQL2008")
{
 IF (($spver2 -ne "SP3") -and ($spver2 -ne "SP4") -and ($spver2 -ne "SP4_10.00.6556"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2008. Please pass SP3 or SP4 or SP4_10.00.6556 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlver2 -eq "SQL2012")
{
 IF (($spver2 -ne "SP2") -and ($spver2 -ne "SP3") -and ($spver2 -ne "SP3CU11.0.6567") -and ($spver2 -ne "SP4") -and ($spver2 -ne "SP4_11.0.7462"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2012. Please pass SP2 or SP3 or SP3CU11.0.6567 or SP4 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlver2 -eq "SQL2014")
{
 IF (($spver2 -ne "SP2") -and ($spver2 -ne "SP2_12.0.5557") -and ($spver2 -ne "SP2_12.0.5589")-and ($spver2 -ne "SP3_12.0.6329"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2014. Please pass SP2 or SP2_12.0.5557 or SP2_12.0.5589 or SP3_12.0.6329 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlver2 -eq "SQL2016")
{
 IF (($spver2 -ne "SP1") -and ($spver2 -ne "SP2") -and ($spver2 -ne "SP2_13.0.5426") -and ($spver2 -ne "SP2_13.0.5201") -and ($spver2 -ne "SP2_13.0.5830") -and ($spver2 -ne "CU17") -and ($spver2 -ne "SP3") -and ($spver2 -ne "SP3_13.0.6419"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2016. Please pass SP1 or SP2 as 3rd parameter" -f red
    Write-Host ""
    EXIT 0
  }
}

ELSEIF ($sqlver2 -eq "SQL2017")
{
 IF (($spver2 -ne "RTM") -and ($spver2 -ne "CU16"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2017. Please pass RTM or CU16 as 3rd parameter" -f red
    Write-Host ""
    EXIT 0
  }
}

ELSEIF ($sqlver2 -eq "SQL2019")
{
 IF (($spver2 -ne "RTM")-and ($spver2 -ne "CU9") -and ($spver2 -ne "CU12")-and ($spver2 -ne "CU17"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2019. Please pass RTM or CU9 as 3rd parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlver2 -eq "SQL2022")
{
 IF (($spver2 -ne "RTM")) #Shubham
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2022. Please pass RTM as 3rd parameter" -f red
    Write-Host ""
    EXIT 0
  }
}

#------------------- Check if instance name really belongs to the SQLVersion passed as parameter ---------------------------

   $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName

   $ver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version
   $Edtn = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition

   $build = $ver.substring(0,2)

If (($build -eq "13") -and ($sqlver2 -ne "SQL2016"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "14") -and ($sqlver2 -ne "SQL2017"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}


If (($build -eq "15") -and ($sqlver2 -ne "SQL2019"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "16") -and ($sqlver2 -ne "SQL2022")) #Shubham
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "12") -and ($sqlver2 -ne "SQL2014"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "11") -and ($sqlver2 -ne "SQL2012"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "10") -and ($sqlver2 -ne "SQL2008"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "9") -and ($sqlver2 -ne "SQL2005"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlver2. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log
"Execution string: $ScriptName $sqlver2 $InstName" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')

IF ($InstName -eq "MSSQLSERVER")
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Final_Status_Error = 0
}
ELSE
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name + "\" + $InstName
$Final_Status_Error = 0
}

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName

Write-Host "--------------------------------- IQOQ verification results ---------------------------------"
"--------------------------------- IQOQ verification results ---------------------------------" >> $Log

$conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
$conn.Open()

#--------------------------------- Checking SQL Server build version --------------------------------#
Write-Host "-------"
"-------" >> $Log

IF ($sqlver2 -eq "SQL2014")

{

  IF ($spver2 -eq "SP2")
   {

       $SQL2014Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2014Version -eq "12.0.5000.0")
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "Current value of SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "SQL 2014 version 12.0.5000.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "Current value of SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "SQL 2014 version 12.0.5000.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "Current value of SQL 2014 version installed : $SQL2014Version"
	  Write-Host "SQL 2014 version 12.0.5000.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "Current value of SQL 2014 version installed : $SQL2012Version" >> $Log
	  "SQL 2014 version 12.0.5000.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
 ELSEIF ($spver2 -eq "SP4CU12.0.5557.0")
   {

       $SQL2014Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2014Version -eq "12.0.5000.0")
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "Current value of SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "SQL 2014 version 12.0.5000.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "Current value of SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "SQL 2014 version 12.0.5000.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.5000.0"
	  Write-Host "Current value of SQL 2014 version installed : $SQL2014Version"
	  Write-Host "SQL 2014 version 12.0.5000.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 version installed : 12.0.5000.0" >> $Log
	  "Current value of SQL 2014 version installed : $SQL2012Version" >> $Log
	  "SQL 2014 version 12.0.5000.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
  
  ELSEIF ($spver2 -eq "SP1")

    {

       $SQL2014Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2014Version -eq "12.0.4100.0")
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.4100.0"
	  Write-Host "Current value of SQL 2014 version installed : 12.0.4100.0"
	  Write-Host "SQL 2014 version 12.0.4100.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 version installed : 12.0.4100.0" >> $Log
	  "Current value of SQL 2014 version installed : 12.0.4100.0" >> $Log
	  "SQL 2014 version 12.0.4100.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.4100.0"
	  Write-Host "Current value of SQL 2014 version installed : $SQL2014Version"
	  Write-Host "SQL 2014 version 12.0.4100.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 version installed : 12.0.4100.0" >> $Log
	  "Current value of SQL 2014 version installed : $SQL2012Version" >> $Log
	  "SQL 2014 version 12.0.4100.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
ELSEIF ($spver2 -eq "SP3_12.0.6329")
   {

       $SQL2014Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2014Version -eq "12.0.6024.0")
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.6024.0"
	  Write-Host "Current value of SQL 2014 version installed : 12.0.6024.0"
	  Write-Host "SQL 2014 version 12.0.6024.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 version installed : 12.0.6024.0" >> $Log
	  "Current value of SQL 2014 version installed : 12.0.6024.0" >> $Log
	  "SQL 2014 version 12.0.6024.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2014 version installed : 12.0.6024.0"
	  Write-Host "Current value of SQL 2014 version installed : $SQL2014Version"
	  Write-Host "SQL 2014 version 12.0.6024.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 version installed : 12.0.6024.0" >> $Log
	  "Current value of SQL 2014 version installed : $SQL2012Version" >> $Log
	  "SQL 2014 version 12.0.6024.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
  
}

ELSEIF ($sqlver2 -eq "SQL2012")

{

  IF ($spver2 -eq "SP3CU11.0.6567")
   {

       $SQL2012Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2012Version -eq "11.0.6020.0")
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "Current value of SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "SQL 2012 version 11.0.6020.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "Current value of SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "SQL 2012 version 11.0.6020.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "Current value of SQL 2012 version installed : $SQL2012Version"
	  Write-Host "SQL 2012 version 11.0.6020.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "Current value of SQL 2012 version installed : $SQL2012Version" >> $Log
	  "SQL 2012 version 11.0.6020.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
ELSEIF ($spver2 -eq "SP4")
   {

       $SQL2012Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2012Version -eq "11.0.7001.0")
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.7001.0"
	  Write-Host "Current value of SQL 2012 version installed : 11.0.7001.0"
	  Write-Host "SQL 2012 version 11.0.7001.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 version installed : 11.0.7001.0" >> $Log
	  "Current value of SQL 2012 version installed : 11.0.7001.0" >> $Log
	  "SQL 2012 version 11.4.7001.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.7001.0"
	  Write-Host "Current value of SQL 2012 version installed : $SQL2012Version"
	  Write-Host "SQL 2012 version 11.0.7001.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 version installed : 11.0.7001.0" >> $Log
	  "Current value of SQL 2012 version installed : $SQL2012Version" >> $Log
	  "SQL 2012 version 11.0.7001.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
  ELSEIF ($spver2 -eq "SP3")
   {

       $SQL2012Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2012Version -eq "11.0.6020.0")
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "Current value of SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "SQL 2012 version 11.0.6020.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "Current value of SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "SQL 2012 version 11.0.6020.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.6020.0"
	  Write-Host "Current value of SQL 2012 version installed : $SQL2012Version"
	  Write-Host "SQL 2012 version 11.0.6020.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 version installed : 11.0.6020.0" >> $Log
	  "Current value of SQL 2012 version installed : $SQL2012Version" >> $Log
	  "SQL 2012 version 11.0.6020.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
   ELSEIF ($spver2 -eq "SP2")

    {

       $SQL2012Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2012Version -eq "11.0.5058.0")
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.5058.0"
	  Write-Host "Current value of SQL 2012 version installed : 11.0.5058.0"
	  Write-Host "SQL 2012 version 11.0.5058.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 version installed : 11.0.5058.0" >> $Log
	  "Current value of SQL 2012 version installed : 11.0.5058.0" >> $Log
	  "SQL 2012 version 11.0.5058.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2012 version installed : 11.0.5058.0"
	  Write-Host "Current value of SQL 2012 version installed : $SQL2012Version"
	  Write-Host "SQL 2012 version 11.0.5058.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 version installed : 11.0.5058.0" >> $Log
	  "Current value of SQL 2012 version installed : $SQL2012Version" >> $Log
	  "SQL 2012 version 11.0.5058.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }

}

ELSEIF ($sqlver2 -eq "SQL2008")

{

  IF ($spver2 -eq "SP4")
   {

       $SQL2008Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2008Version -eq "10.0.6000.29")
        {
	  Write-Host "Expected value for SQL 2008 version installed : 10.0.6000.29"
	  Write-Host "Current value of SQL 2008 version installed : 10.0.6000.29"
	  Write-Host "SQL 2008 version 10.0.6000.29 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 version installed : 10.0.6000.29" >> $Log
	  "Current value of SQL 2008 version installed : 10.0.6000.29" >> $Log
	  "SQL 2008 version 10.0.6000.29 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2008 version installed : 10.0.6000.29"
	  Write-Host "Current value of SQL 2008 version installed : $SQL2008Version"
	  Write-Host "SQL 2008 version 10.0.6000.29 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2008 version installed : 10.0.6000.29" >> $Log
	  "Current value of SQL 2008 version installed : $SQL2008Version" >> $Log
	  "SQL 2008 version 10.0.6000.29 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

   }

  ELSEIF ($spver2 -eq "SP3")

   {

       $SQL2008Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2008Version -eq "10.0.5500.0")
        {
	  Write-Host "Expected value for SQL 2008 version installed : 10.0.5500.0"
	  Write-Host "Current value of SQL 2008 version installed : 10.0.5500.0"
	  Write-Host "SQL 2008 version 10.0.5500.0installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 version installed : 10.0.5500.0" >> $Log
	  "Current value of SQL 2008 version installed : 10.0.5500.0" >> $Log
	  "SQL 2008 version 10.0.5500.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2008 version installed : 10.0.5500.0"
	  Write-Host "Current value of SQL 2008 version installed : $SQL2008Version"
	  Write-Host "SQL 2008 version 10.0.5500.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2008 version installed : 10.0.5500.0" >> $Log
	  "Current value of SQL 2008 version installed : $SQL2008Version" >> $Log
	  "SQL 2008 version 10.0.5500.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

   }

}

ELSEIF ($sqlver2 -eq "SQL2005")

{

  IF ($spver2 -eq "SP4")
   {

       $SQL2005Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       If ($SQL2005Version -eq "9.00.5000.00")
        {
	  Write-Host "Expected value for SQL 2005 version installed : 9.00.5000.00"
	  Write-Host "Current value of SQL 2005 version installed : 9.00.5000.00"
	  Write-Host "SQL 2005 version 9.00.5000.00 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 version installed : 9.00.5000.00" >> $Log
	  "Current value of SQL 2005 version installed : 9.00.5000.00" >> $Log
	  "SQL 2005 version 9.00.5000.00 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2005 version installed : 9.00.5000.00"
	  Write-Host "Current value of SQL 2005 version installed : $SQL2005Version"
	  Write-Host "SQL 2005 version 9.00.5000.00 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2005 version installed : 9.00.5000.00" >> $Log
	  "Current value of SQL 2005 version installed : $SQL2005Version" >> $Log
	  "SQL 2005 version 9.00.5000.00 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

   }

  ELSEIF ($spver2 -eq "SP3")

   {

       $SQL2005Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       If ($SQL2005Version -eq "9.0.4035")
        {
	  Write-Host "Expected value for SQL 2005 version installed : 9.0.4035"
	  Write-Host "Current value of SQL 2005 version installed : 9.0.4035"
	  Write-Host "SQL 2005 version 9.0.4035 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 version installed : 9.0.4035" >> $Log
	  "Current value of SQL 2005 version installed : 9.0.4035" >> $Log
	  "SQL 2005 version 9.0.4035 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2005 version installed : 9.0.4035"
	  Write-Host "Current value of SQL 2005 version installed : $SQL2005Version"
	  Write-Host "SQL 2005 version 9.0.4035 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2005 version installed : 9.0.4035" >> $Log
	  "Current value of SQL 2005 version installed : $SQL2005Version" >> $Log
	  "SQL 2005 version 9.0.4035 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

   }


}

ELSEIF ($sqlver2 -eq "SQL2016")

{

  IF ($spver2 -eq "SP1")
   {

       $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.1601.5")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.1601.5"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.1601.5"
	  Write-Host "SQL 2016 version 13.0.1601.5 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.1601.5" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.1601.5" >> $Log
	  "SQL 2016 version 13.0.1601.5 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.1601.5"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.0.1601.5 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.1601.5" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.1601.5 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
ELSEIF ($spver2 -eq "SP2")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.2.5026.0")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     }
   
ELSEIF ($spver2 -eq "SP2_13.0.5426")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.5026.0")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.5026.0"
	  Write-Host "SQL 2016 version 13.0.5026.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.5026.0" >> $Log
	  "SQL 2016 version 13.0.5026.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     } 

ELSEIF ($spver2 -eq "SP2_13.0.5830")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.5026.0")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.5026.0"
	  Write-Host "SQL 2016 version 13.0.5026.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.5026.0" >> $Log
	  "SQL 2016 version 13.0.5026.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     } 

ELSEIF ($spver2 -eq "CU17")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.5888.11")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.5888.11"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.5888.11"
	  Write-Host "SQL 2016 version 13.0.5888.11 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.5888.11" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.5888.11" >> $Log
	  "SQL 2016 version 13.0.5888.11 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.5888.11"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.0.5888.11 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.5888.11" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.5888.11 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

}

ELSEIF ($spver2 -eq "SP3")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.6300.2")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6300.2"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.6300.2"
	  Write-Host "SQL 2016 version 13.0.6300.2 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.6300.2" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.6300.2" >> $Log
	  "SQL 2016 version 13.0.6300.2 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.5888.11"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.0.5888.11 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.5888.11" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.5888.11 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

}

ELSEIF ($spver2 -eq "SP3_13.0.6419.1")
   {

      $SQL2016Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2016Version -eq "13.0.6419.1")
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "SQL 2016 version 13.0.6419.1 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "SQL 2016 version 13.0.6419.1 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016Version"
	  Write-Host "SQL 2016 version 13.0.6419.1 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.6419.1 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

}

}

ELSEIF ($sqlver2 -eq "SQL2017")

{

  IF ($spver2 -eq "RTM")
   {

       $SQL2017Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2017Version -eq "14.0.1000.169")
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.1000.169"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.1000.169"
	  Write-Host "SQL 2017 version 14.0.1000 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.1000.169" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.1000.169" >> $Log
	  "SQL 2017 version 14.0.1000 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.1000"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017Version"
	  Write-Host "SQL 2017 version 14.0.1000 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.1000" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.1000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
ELSEIF ($spver2 -eq "CU16")
   {

      $SQL2017Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
       IF ($SQL2017Version -eq "14.0.3223.3")
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "SQL 2017 version 14.0.3223.3 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "SQL 2017 version 14.0.3223.3 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017Version"
	  Write-Host "SQL 2017 version 14.0.3223.3 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3076 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     }
 
ELSEIF ($spver2 -eq "CU25")
   {

      $SQL2017Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
       IF ($SQL2017Version -eq "14.0.3401.7")
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3401.7"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3401.7"
	  Write-Host "SQL 2017 version 14.0.3401.7 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3401.7" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3401.7" >> $Log
	  "SQL 2017 version 14.0.3401.7 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3401.3"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017Version"
	  Write-Host "SQL 2017 version 14.0.3401.3 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3401.3" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3401 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     }

     ELSEIF ($spver2 -eq "CU29")
   {

      $SQL2017Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
       IF ($SQL2017Version -eq "14.0.3445.2")
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "SQL 2017 version 14.0.3445.2 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "SQL 2017 version 14.0.3445.2 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017Version"
	  Write-Host "SQL 2017 version 14.0.3445.2 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3445.2 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
     }
  
}

ELSEIF ($sqlver2 -eq "SQL2019")

{

  IF ($spver2 -eq "RTM")
   {

       $SQL2019Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2019Version -eq "15.0.2000.5")
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "SQL 2019 version 15.0.2000.5 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "Current value of SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "SQL 2019 version $SQL2019Version installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 version installed : $SQL2019Version"
	  Write-Host "SQL 2019 version 15.0.2000 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "Current value of SQL 2019 version installed : $SQL2017Version" >> $Log
	  "SQL 2019 version 15.0.2000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }


	ELSEIF ($spver2 -eq "CU9")
   {

       $SQL2019Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2019Version -eq "15.0.2000.5")
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "SQL 2019 version 15.0.2000 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "Current value of SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "SQL 2019 version 15.0.2000.5 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 version installed : $SQL2019Version"
	  Write-Host "SQL 2019 version 15.0.2000 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 version installed : 15.0.2000.5" >> $Log
	  "Current value of SQL 2019 version installed : $SQL2019Version" >> $Log
	  "SQL 2019 version 15.0.2000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }
ELSEIF ($spver2 -eq "CU12")
   {

       $SQL2019Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2019Version -eq "15.0.4153.5")
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.4153.5"
	  Write-Host "Current value of SQL 2019 version installed : 15.0.4153.5"
	  Write-Host "SQL 2019 version 15.0.4153 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 version installed : 15.0.4153.5" >> $Log
	  "Current value of SQL 2019 version installed : 15.0.4153.5" >> $Log
	  "SQL 2019 version 15.0.4153.5 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.4153.5"
	  Write-Host "Current value of SQL 2019 version installed : $SQL2019Version"
	  Write-Host "SQL 2019 version 15.0.4153 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 version installed : 15.0.4153.5" >> $Log
	  "Current value of SQL 2019 version installed : $SQL2019Version" >> $Log
	  "SQL 2019 version 15.0.4153 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }

    ELSEIF ($spver2 -eq "CU17")

   {

       $SQL2019Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2019Version -eq "15.0.4249.2")
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.4249.2"
	  Write-Host "Current value of SQL 2019 version installed : 15.0.4249.2"
	  Write-Host "SQL 2019 version 15.0.4249.2 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 version installed : 15.0.4249.2" >> $Log
	  "Current value of SQL 2019 version installed : 15.0.4249.2" >> $Log
	  "SQL 2019 version 15.0.4249.2 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2019 version installed : 15.0.4249.2"
	  Write-Host "Current value of SQL 2019 version installed : $SQL2019Version"
	  Write-Host "SQL 2019 version 15.0.4249.2 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 version installed : 15.0.4249.2" >> $Log
	  "Current value of SQL 2019 version installed : $SQL2019Version" >> $Log
	  "SQL 2019 version 15.0.4249.2 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }

}



ELSEIF ($sqlver2 -eq "SQL2022") #Shubham

{

  IF ($spver2 -eq "RTM")
   {

       $SQL2022Version=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
       IF ($SQL2022Version -eq "16.0.1000.6")
        {
	  Write-Host "Expected value for SQL 2022 version installed : 16.0.1000.6"
	  Write-Host "Current value of SQL 2022 version installed : 16.0.1000.6"
	  Write-Host "SQL 2022 version 16.0.1000 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2022 version installed : 16.0.1000.6" >> $Log
	  "Current value of SQL 2022 version installed : 16.0.1000.6" >> $Log
	  "SQL 2022 version $SQL2019Version installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2022 version installed : 16.0.1000.6"
	  Write-Host "Current value of SQL 2022 version installed : $SQL2022Version"
	  Write-Host "SQL 2022 version 16.0.1000.6 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2022 version installed : 16.0.1000.6" >> $Log
	  "Current value of SQL 2022 version installed : $SQL2022Version" >> $Log
	  "SQL 2022 version 16.0.1000.6 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }

    }

}


#--------------------------------- Checking SQL Server patch version --------------------------------#
Write-Host "-------"
"-------" >> $Log

IF ($sqlver2 -eq "SQL2014")

{

  IF ($spver2 -eq "SP2")
   {

   	$SQL2014PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2014PatchVersion -eq "12.2.5532.0")
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.2.5532.0"
	  Write-Host "Current value of SQL 2014 patch version installed : 12.2.5532.0"
	  Write-Host "SQL 2014 installation with patch version 12.2.5532.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 patch version installed : 12.2.5532.0" >> $Log
	  "Current value of SQL 2014 patch version installed : 12.2.5532.0" >> $Log
	  "SQL 2014 patch version 12.2.5532.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.2.5532.0"
	  Write-Host "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion"
	  Write-Host "SQL 2014 installation with patch version 12.2.5532.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 patch version installed : 12.2.5532.0" >> $Log
	  "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion" >> $Log
	  "SQL 2014 patch version 12.2.5532.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
 ELSEIF ($spver2 -eq "SP4CU12.0.5557.0")
   {

   	$SQL2014PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2014PatchVersion -eq "12.2.5557.0")
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.2.5557.0"
	  Write-Host "Current value of SQL 2014 patch version installed : 12.2.5557.0"
	  Write-Host "SQL 2014 installation with patch version 12.2.5557.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 patch version installed : 12.2.5557.0" >> $Log
	  "Current value of SQL 2014 patch version installed : 12.2.5557.0" >> $Log
	  "SQL 2014 patch version 12.2.5557.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.2.5557.0"
	  Write-Host "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion"
	  Write-Host "SQL 2014 installation with patch version 12.2.5557.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 patch version installed : 12.2.5557.0" >> $Log
	  "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion" >> $Log
	  "SQL 2014 patch version 12.2.5557.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
  ELSEIF ($spver2 -eq "SP1")
   {

   	$SQL2014PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2014PatchVersion -eq "12.0.4100.0")
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.1.4100.0"
	  Write-Host "Current value of SQL 2014 patch version installed : 12.1.4100.0"
	  Write-Host "SQL 2014 installation with patch version 12.1.4100.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 patch version installed : 12.1.4100.0" >> $Log
	  "Current value of SQL 2014 patch version installed : 12.1.4100.0" >> $Log
	  "SQL 2014 patch version 12.1.4100.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.1.4100.0"
	  Write-Host "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion"
	  Write-Host "SQL 2014 installation with patch version 12.1.4100.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 patch version installed : 12.1.4100.0" >> $Log
	  "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion" >> $Log
	  "SQL 2014 patch version 12.1.4100.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

  ELSEIF ($spver2 -eq "SP3_12.0.6329")
   {

   	$SQL2014PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2014PatchVersion -eq "12.3.6329.1")
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.3.6329.1"
	  Write-Host "Current value of SQL 2014 patch version installed : 12.3.6329.1"
	  Write-Host "SQL 2014 installation with patch version 12.3.6329.1 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2014 patch version installed : 12.3.6329.1" >> $Log
	  "Current value of SQL 2014 patch version installed : 12.3.6329.1" >> $Log
	  "SQL 2014 patch version 12.3.6329.1 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2014 patch version installed : 12.3.6329.1"
	  Write-Host "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion"
	  Write-Host "SQL 2014 installation with patch version 12.3.6329.1 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2014 patch version installed : 12.3.6329.1" >> $Log
	  "Current value of SQL 2014 patch version installed : $SQL2014PatchVersion" >> $Log
	  "SQL 2014 patch version 12.3.6329.1 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

}

ELSEIF ($sqlver2 -eq "SQL2012")

{

  IF ($spver2 -eq "SP3CU11.0.6567")
   {

   	$SQL2012PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2012PatchVersion -eq "11.3.6567.0")
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.3.6567.0"
	  Write-Host "Current value of SQL 2012 patch version installed : 11.3.6567.0"
	  Write-Host "SQL 2012 installation with patch version 11.3.6567.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 patch version installed : 11.3.6567.0" >> $Log
	  "Current value of SQL 2012 patch version installed : 11.3.6567.0" >> $Log
	  "SQL 2012 patch version 11.3.6567.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.3.6567.0"
	  Write-Host "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion"
	  Write-Host "SQL 2012 installation with patch version 11.3.6567.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 patch version installed : 11.3.6567.0" >> $Log
	  "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion" >> $Log
	  "SQL 2012 patch version 11.3.6567.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
ELSEIF ($spver2 -eq "SP4")
   {

   	$SQL2012PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2012PatchVersion -eq "11.4.7001.0")
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.4.7001.0"
	  Write-Host "Current value of SQL 2012 patch version installed : 11.4.7001.0"
	  Write-Host "SQL 2012 installation with patch version 11.4.7001.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 patch version installed : 11.4.7001.0" >> $Log
	  "Current value of SQL 2012 patch version installed : 11.4.7001.0" >> $Log
	  "SQL 2012 patch version 11.4.7001.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.4.7001.0"
	  Write-Host "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion"
	  Write-Host "SQL 2012 installation with patch version 11.4.7001.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 patch version installed : 11.4.7001.0" >> $Log
	  "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion" >> $Log
	  "SQL 2012 patch version 11.4.7001.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
  ELSEIF ($spver2 -eq "SP3")
   {

   	$SQL2012PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2012PatchVersion -eq "11.3.6020.0")
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.3.6020.0"
	  Write-Host "Current value of SQL 2012 patch version installed : 11.3.6020.0"
	  Write-Host "SQL 2012 installation with patch version 11.3.6020.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 patch version installed : 11.3.6020.0" >> $Log
	  "Current value of SQL 2012 patch version installed : 11.3.6020.0" >> $Log
	  "SQL 2012 patch version 11.3.6020.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.3.6020.0"
	  Write-Host "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion"
	  Write-Host "SQL 2012 installation with patch version 11.3.6020.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 patch version installed : 11.3.6020.0" >> $Log
	  "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion" >> $Log
	  "SQL 2012 patch version 11.3.6020.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
  ELSEIF ($spver2 -eq "SP2")
   {

   	$SQL2012PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2012PatchVersion -eq "11.2.5058.0")
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.2.5058.0"
	  Write-Host "Current value of SQL 2012 patch version installed : 11.2.5058.0"
	  Write-Host "SQL 2012 installation with patch version 11.2.5058.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2012 patch version installed : 11.2.5058.0" >> $Log
	  "Current value of SQL 2012 patch version installed : 11.2.5058.0" >> $Log
	  "SQL 2012 patch version 11.2.5058.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2012 patch version installed : 11.2.5058.0"
	  Write-Host "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion"
	  Write-Host "SQL 2012 installation with patch version 11.2.5058.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2012 patch version installed : 11.2.5058.0" >> $Log
	  "Current value of SQL 2012 patch version installed : $SQL2012PatchVersion" >> $Log
	  "SQL 2012 patch version 11.2.5058.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

}

ELSEIF ($sqlver2 -eq "SQL2008")

{

   IF ($spver2 -eq "SP4")
   {

   	$SQL2008PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2008PatchVersion -eq "10.4.6535.0")
   	{
	  Write-Host "Expected value for SQL 2008 patch version installed : 10.4.6535.0"
	  Write-Host "Current value of SQL 2008 patch version installed : 10.4.6535.0"
	  Write-Host "SQL 2008 installation with patch version 10.4.6535.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 patch version installed : 10.4.6535.0" >> $Log
	  "Current value of SQL 2008 patch version installed : 10.4.6535.0" >> $Log
	  "SQL 2008 patch version 10.4.6535.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2008 patch version installed : 10.4.6535.0"
	  Write-Host "Current value of SQL 2008 patch version installed : $SQL2008PatchVersion"
	  Write-Host "SQL 2008 installation with patch version 10.4.6535.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2008 patch version installed : 10.4.6535.0" >> $Log
	  "Current value of SQL 2008 patch version installed : $SQL2008PatchVersion" >> $Log
	  "SQL 2008 patch version 10.4.6535.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
  ELSEIF ($spver2 -eq "SP3")
   {

   	$SQL2008PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2008PatchVersion -eq "10.3.5500.0")
   	{
	  Write-Host "Expected value for SQL 2008 patch version installed : 10.3.5500.0"
	  Write-Host "Current value of SQL 2008 patch version installed : 10.3.5500.0"
	  Write-Host "SQL 2008 installation with patch version 10.3.5500.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2008 patch version installed : 10.3.5500.0" >> $Log
	  "Current value of SQL 2008 patch version installed : 10.3.5500.0" >> $Log
	  "SQL 2008 patch version 10.3.5500.0 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2008 patch version installed : 10.3.5500.0"
	  Write-Host "Current value of SQL 2008 patch version installed : $SQL2008PatchVersion"
	  Write-Host "SQL 2008 installation with patch version 10.3.5500.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2008 patch version installed : 10.3.5500.0" >> $Log
	  "Current value of SQL 2008 patch version installed : $SQL2008PatchVersion" >> $Log
	  "SQL 2008 patch version 10.3.5500.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }


}

ELSEIF ($sqlver2 -eq "SQL2005")

{

  IF ($spver2 -eq "SP4")
   {

   	$SQL2005PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2005PatchVersion -eq "9.4.5000")
   	{
	  Write-Host "Expected value for SQL 2005 patch version installed : 9.4.5000"
	  Write-Host "Current value of SQL 2005 patch version installed : 9.4.5000"
	  Write-Host "SQL 2005 installation with patch version 9.4.5000 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2005 patch version installed : 9.4.5000" >> $Log
	  "Current value of SQL 2005 patch version installed : 9.4.5000" >> $Log
	  "SQL 2005 patch version 9.4.5000 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2005 patch version installed : 9.4.5000"
	  Write-Host "Current value of SQL 2005 patch version installed : $SQL2005PatchVersion"
	  Write-Host "SQL 2005 installation with patch version 9.4.5000 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2005 patch version installed : 9.4.5000" >> $Log
	  "Current value of SQL 2005 patch version installed : $SQL2005PatchVersion" >> $Log
	  "SQL 2005 patch version 9.4.5000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
  ELSEIF ($spver2 -eq "SP3")
   {

   	$SQL2005PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	IF ($SQL2005PatchVersion -eq "9.0.4035")
   	{
	  Write-Host "Expected value for SQL 2005 patch version installed : 9.0.4035"
	  Write-Host "Current value of SQL 2005 patch version installed : 9.0.4035"
	  Write-Host "SQL 2005 installation with patch version 9.0.4035 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2005 patch version installed : 9.0.4035" >> $Log
	  "Current value of SQL 2005 patch version installed : 9.0.4035" >> $Log
	  "SQL 2005 patch version 9.0.4035 installation : SUCCESS" >> $Log
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2005 patch version installed : 9.0.4035"
	  Write-Host "Current value of SQL 2005 patch version installed : $SQL2005PatchVersion"
	  Write-Host "SQL 2005 installation with patch version 9.0.4035 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2005 patch version installed : 9.0.4035" >> $Log
	  "Current value of SQL 2005 patch version installed : $SQL2005PatchVersion" >> $Log
	  "SQL 2005 patch version 9.0.4035 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

}

ELSEIF ($sqlver2 -eq "SQL2016")

{

  IF ($spver2 -eq "SP1")
   {

   	$SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2016PatchVersion -eq "13.1.4001.0")
   	{
	  Write-Host "Expected value for SQL 2016 patch version installed : 13.1.4001.0"
	  Write-Host "Current value of SQL 2016 patch version installed : 13.1.4001.0"
	  Write-Host "SQL 2016 installation with patch version 13.1.4001.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 patch version installed : 13.1.4001.0" >> $Log
	  "Current value of SQL 2016 patch version installed : 13.1.4001.0" >> $Log
	  "SQL 2016 patch version 13.1.4001.0 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2016 patch version installed : 13.1.4001.0"
	  Write-Host "Current value of SQL 2016 patch version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 installation with patch version 13.1.4001.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 patch version installed : 13.1.4001.0" >> $Log
	  "Current value of SQL 2016 patch version installed : $SQL2016PatchVersion" >> $Log
	  "SQL 2016 patch version 13.1.4001.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
ELSEIF ($spver2 -eq "SP2")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.2.5026.0")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5026.0"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.2.5026.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5026.0" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5026.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
    
ELSEIF ($spver2 -eq "SP2_13.0.5426")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.2.5426.0")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5426.0"
	  Write-Host "Current value of SQL 2016 version installed : 13.2.5426.0"
	  Write-Host "SQL 2016 version 13.2.5426.0 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.2.5426.0" >> $Log
	  "Current value of SQL 2016 version installed : 13.2.5426.0" >> $Log
	  "SQL 2016 version 13.2.5426.0 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5426.0"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.2.5426.0 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5426.0" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5426.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
    
ELSEIF ($spver2 -eq "SP2_13.0.5830")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.2.5830.85")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5830.85"
	  Write-Host "Current value of SQL 2016 version installed : 13.2.5830.85"
	  Write-Host "SQL 2016 version 13.2.5830.85 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.2.5830.85" >> $Log
	  "Current value of SQL 2016 version installed : 13.2.5830.85" >> $Log
	  "SQL 2016 version 13.2.5830.85 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5830.85"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.2.5830.85 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5830.85" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5830.85 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
    
ELSEIF ($spver2 -eq "CU17")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.2.5888.11")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5888.11"
	  Write-Host "Current value of SQL 2016 version installed : 13.2.5888.11"
	  Write-Host "SQL 2016 version 13.2.5888.11 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.2.5888.11" >> $Log
	  "Current value of SQL 2016 version installed : 13.2.5888.11" >> $Log
	  "SQL 2016 version 13.2.5888.11 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.2.5888.11"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.2.5888.11 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.2.5888.11" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.2.5888.11 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
 ELSEIF ($spver2 -eq "SP3")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.0.6300.2")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6300.2"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.6300.2"
	  Write-Host "SQL 2016 version 13.0.6300.2 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.6300.2" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.6300.2" >> $Log
	  "SQL 2016 version 13.0.6300.2 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6300.2"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.0.6300.2 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.6300.2" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.6300.2 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }

ELSEIF ($spver2 -eq "SP3_13.0.6419.1")
   {

       $SQL2016PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2016PatchVersion -eq "13.0.6419.1")
       {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "Current value of SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "SQL 2016 version 13.0.6419.1 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "Current value of SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "SQL 2016 version 13.0.6419.1installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2016 version installed : 13.0.6419.1"
	  Write-Host "Current value of SQL 2016 version installed : $SQL2016PatchVersion"
	  Write-Host "SQL 2016 version 13.0.6419.1 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2016 version installed : 13.0.6419.1" >> $Log
	  "Current value of SQL 2016 version installed : $SQL2016Version" >> $Log
	  "SQL 2016 version 13.0.6419.1 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }

   }
   
ELSEIF ($sqlver2 -eq "SQL2017")

{

  IF ($spver2 -eq "RTM")
   {

   	$SQL2017PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2017PatchVersion -eq "14.0.1000.0")
   	{
	  Write-Host "Expected value for SQL 2017 patch version installed : 14.0.1000.0"
	  Write-Host "Current value of SQL 2017 patch version installed : 14.0.1000.0"
	  Write-Host "SQL 2017 installation with patch version 14.0.1000.0 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 patch version installed : 14.0.1000.0" >> $Log
	  "Current value of SQL 2017 patch version installed : 14.0.1000.0" >> $Log
	  "SQL 2017 patch version 14.0.1000.0 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2017 patch version installed : 14.0.1000.0"
	  Write-Host "Current value of SQL 2017 patch version installed : $SQL2017PatchVersion"
	  Write-Host "SQL 2017 installation with patch version 14.0.1000.0 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 patch version installed : 14.0.1000.0" >> $Log
	  "Current value of SQL 2017 patch version installed : $SQL2017PatchVersion" >> $Log
	  "SQL 2017 patch version 14.0.1000.0 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
ELSEIF ($spver2 -eq "CU16")
   {

       $SQL2017PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2017PatchVersion -eq "14.0.3223.3")
       {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "SQL 2017 version 14.0.3076 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "SQL 2017 version 14.0.3223.3 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3223.3"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017PatchVersion"
	  Write-Host "SQL 2017 version 14.0.3223.3 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3223.3" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3223.3 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
    
ELSEIF ($spver2 -eq "CU25")
   {

       $SQL2017PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2017PatchVersion -eq "14.0.3401.7")
       {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3401.7"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3401.7"
	  Write-Host "SQL 2017 version 14.0.3401 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3401.7" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3401.7" >> $Log
	  "SQL 2017 version 14.0.3401.7 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3401.7"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017PatchVersion"
	  Write-Host "SQL 2017 version 14.0.3401.7 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3401.7" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3401.7 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }

      ELSEIF ($spver2 -eq "CU29")
   {

       $SQL2017PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
      IF ($SQL2017PatchVersion -eq "14.0.3445.2")
       {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "Current value of SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "SQL 2017 version 14.0.3445.2 installation: " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "Current value of SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "SQL 2017 version 14.0.3445.2 installation : SUCCESS" >> $Log
        }
       ELSE
        {
	  Write-Host "Expected value for SQL 2017 version installed : 14.0.3445.2"
	  Write-Host "Current value of SQL 2017 version installed : $SQL2017PatchVersion"
	  Write-Host "SQL 2017 version 14.0.3445.2 installation: " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2017 version installed : 14.0.3445.2" >> $Log
	  "Current value of SQL 2017 version installed : $SQL2017Version" >> $Log
	  "SQL 2017 version 14.0.3445.2 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
        }
      }
  
   }

   
ELSEIF ($sqlver2 -eq "SQL2019")

{

  IF ($spver2 -eq "RTM")
   {

   	$SQL2019PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2019PatchVersion -eq "15.0.2000.5")
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 patch version installed : 15.0.2000.5"
	  Write-Host "SQL 2019 installation with patch version 15.0.2000 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 patch version installed : 15.0.2000.5" >> $Log
	  "Current value of SQL 2019 patch version installed : 15.0.2000.5" >> $Log
	  "SQL 2019 patch version 15.0.2000 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.2000.5"
	  Write-Host "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion"
	  Write-Host "SQL 2019 installation with patch version 15.0.2000 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 patch version installed : 15.0.2000" >> $Log
	  "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion" >> $Log
	  "SQL 2019 patch version 15.0.2000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

 ELSEIF ($spver2 -eq "CU9")
   {

   	$SQL2019PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2019PatchVersion -eq "15.0.4102.2")
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4102.2"
	  Write-Host "Current value of SQL 2019 patch version installed : 15.0.4102.2"
	  Write-Host "SQL 2019 installation with patch version 15.0.4102.2 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 patch version installed : 15.0.4102.2" >> $Log
	  "Current value of SQL 2019 patch version installed : 15.0.4102.2" >> $Log
	  "SQL 2019 patch version 15.0.4102.2 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4102.2"
	  Write-Host "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion"
	  Write-Host "SQL 2019 installation with patch version 15.0.4102.2 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 patch version installed : 15.0.4102.2" >> $Log
	  "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion" >> $Log
	  "SQL 2019 patch version 15.0.4102.2 : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }
ELSEIF ($spver2 -eq "CU12")
   {

   	$SQL2019PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2019PatchVersion -eq "15.0.4153.1")
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4153.1"
	  Write-Host "Current value of SQL 2019 patch version installed : 15.0.4153.1"
	  Write-Host "SQL 2019 installation with patch version 15.0.4153.1 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 patch version installed : 15.0.4153.1" >> $Log
	  "Current value of SQL 2019 patch version installed : 15.0.4153.1" >> $Log
	  "SQL 2019 patch version 15.0.4153.1 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4153.1"
	  Write-Host "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion"
	  Write-Host "SQL 2019 installation with patch version 15.0.4153.1 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 patch version installed : 15.0.4153.1" >> $Log
	  "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion" >> $Log
	  "SQL 2019 patch version 15.0.4153.1 : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

   ELSEIF ($spver2 -eq "CU17")
   {

   	$SQL2019PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2019PatchVersion -eq "15.0.4249.2")
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4249.2"
	  Write-Host "Current value of SQL 2019 patch version installed : 15.0.4249.2"
	  Write-Host "SQL 2019 installation with patch version 15.0.4249.2 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2019 patch version installed : 15.0.4249.2" >> $Log
	  "Current value of SQL 2019 patch version installed : 15.0.4249.2" >> $Log
	  "SQL 2019 patch version 15.0.4249.2 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2019 patch version installed : 15.0.4249.2"
	  Write-Host "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion"
	  Write-Host "SQL 2019 installation with patch version 15.0.4249.2 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2019 patch version installed : 15.0.4249.2" >> $Log
	  "Current value of SQL 2019 patch version installed : $SQL2019PatchVersion" >> $Log
	  "SQL 2019 patch version 15.0.4249.2 : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }


}

ELSEIF ($sqlver2 -eq "SQL2022") #Shubham 

{

  IF ($spver2 -eq "RTM")
   {

   	$SQL2022PatchVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
   	If ($SQL2022PatchVersion -eq "16.0.1000.6")
   	{
	  Write-Host "Expected value for SQL 2022 patch version installed : 16.0.1000.6"
	  Write-Host "Current value of SQL 2022 patch version installed : 16.0.1000.6"
	  Write-Host "SQL 2022 installation with patch version 16.0.1000 : " -f white -nonewline; Write-Host "Success" -f green
	  "Expected value for SQL 2022 patch version installed : 16.0.1000.6" >> $Log
	  "Current value of SQL 2022 patch version installed : 16.0.1000.6" >> $Log
	  "SQL 2022 patch version 16.0.1000 installation : SUCCESS" >> $Log
          
   	}
   	ELSE
   	{
	  Write-Host "Expected value for SQL 2022 patch version installed : 16.0.1000.6"
	  Write-Host "Current value of SQL 2022 patch version installed : $SQL2022PatchVersion"
	  Write-Host "SQL 2022 installation with patch version 16.0.1000 : " -f white -nonewline; Write-Host "Failed" -f red
	  "Expected value for SQL 2022 patch version installed : 16.0.1000" >> $Log
	  "Current value of SQL 2022 patch version installed : $SQL2022PatchVersion" >> $Log
	  "SQL 2022 patch version 16.0.1000 installation : FAILED" >> $Log
	  $Final_Status_Error = 1
   	}

   }

}

#--------------------------------- Checking SQL Services ----------------------------------# 

# ******** MSSQL SERVER ******** #
Write-Host ""
"" >> $Log


   Write-Host "Expected status  of MSSQL Server service : Running"
   "Expected status of MSSQL Server service : Running" >> $Log

   IF (Get-Service | where-object {$_.name -like 'MSSQLSERVER' -and $_.Status -eq 'Running' } -ErrorAction SilentlyContinue)
   {
    Write-Host "Current status for MSSQL Server service : " -f white -nonewline; Write-Host "Running" -f green
    "Current status for installation of MSSQL Server service : Running" >> $Log
    
   }

   ELSE

   {
    Write-Host "Current status for MSSQL Server services : Stopped"
    Write-Host "Status of MSSQL Server services : " -f white -nonewline; Write-Host "Stopped" -f red
    "Current status for MSSQL Server services : Stopped" >> $Log
    $Final_Status_Error = 1
    
   }

Write-Host ""
"" >> $Log

# ******** SQL SERVER Agent ******** #

   Write-Host "Expected status of SQLSERVERAGENT service : Running"
   "Expected status of SQLSERVERAGENT service : Running" >> $Log

   IF (Get-Service | where-object {$_.name -like 'SQLSERVERAGENT' -and $_.Status -eq 'Running' } -ErrorAction SilentlyContinue)
   {
    
    Write-Host "Current status for SQLSERVERAGENT service : "-f white -nonewline; Write-Host "Running" -f green
    "Current status for installation of SQLSERVERAGENT service : Running" >> $Log
    
   }

   ELSE

   {
    Write-Host "Current status of SQLSERVERAGENT services : Stopped"
    Write-Host "Status of SQLSERVERAGENT services : " -f white -nonewline; Write-Host "Stopped" -f red
    "Current status for SQLSERVERAGENT services : Stopped" >> $Log
    $Final_Status_Error = 1
    
   }

Write-Host ""
"" >> $Log

# ******** SQLBrowser ******** #

   Write-Host "Expected status for installation of SQLBrowser service : Running"
   "Expected status for installation of SQLBrowser service : Running" >> $Log

   IF (Get-Service | where-object {$_.name -like 'SQLBrowser' -and $_.Status -eq 'Running' } -ErrorAction SilentlyContinue)
   {
    
    Write-Host "Current status for SQLBrowser service :" -f white -nonewline; Write-Host "Running" -f green
    "Current status forSQLBrowser service : Running" >> $Log
       
   }

   ELSE

   {
    Write-Host "Current status for SQLBrowser services : Stopped"
    Write-Host "Status of SQLBrowser services : " -f white -nonewline; Write-Host "Stopped" -f red
    "Current status for SQLBrowser services : Stopped" >> $Log
    $Final_Status_Error = 1
    
   }

Write-Host ""
"" >> $Log



###############################################################################################################################
#--------------------------------- Checking BI Components ---------------------------------#

Write-Host "-------"
"-------" >> $Log

# ******** IS ********

   Write-Host "Expected status for installation of Integration services : Success"
   "Expected status for installation of Integration services : Success" >> $Log

   IF (Get-Service | where-object {$_.name -like 'MSDTS*'} -ErrorAction SilentlyContinue)
   {
    Write-Host "Current status for installation of Integration services : Success"
    Write-Host "Installation of Integration services : " -f white -nonewline; Write-Host "Success" -f green
    "Current status for installation of Integration services : Success" >> $Log
    "Installation of Integration services : Success" >> $Log
   }

   ELSE

   {
    Write-Host "Current status for installation of Integration services : Failed"
    Write-Host "Installation of Integration services : " -f white -nonewline; Write-Host "Failed" -f red
    "Current status for installation of Integration services : Failed" >> $Log
    "Installation of Integration services : Failed" >> $Log
    $Final_Status_Error = 1
    
   }

Write-Host ""
"" >> $Log

# ******** AS ********

   Write-Host "Expected status for installation of Analysis services : Success"
   "Expected status for installation of Analysis services : Success" >> $Log

   IF (Get-Service | where-object {$_.name -like '*OLAP*'} -ErrorAction SilentlyContinue)
   {
    Write-Host "Current status for installation of Anaysis services : Success"
    Write-Host "Installation of Analysis services : " -f white -nonewline; Write-Host "Success" -f green
    "Current status for installation of Anaysis services : Success" >> $Log
    "Installation of Analysis services : Success" >> $Log
   }

   ELSE

   {
    Write-Host "Current status for installation of Analysis services : Failed"
    Write-Host "Installation of Analysis services : " -f white -nonewline; Write-Host "Failed" -f red
    "Current status for installation of Analysis services : Failed" >> $Log
     "Installation of Analysis services : Failed" >> $Log
    $Final_Status_Error = 1
   }

Write-Host ""
"" >> $Log

# ******** RS ********

   Write-Host "Expected status for installation of Reporting services : Success"
   "Expected status for installation of Reporting services : Success" >> $Log

   IF (Get-Service | where-object {$_.name -like '*Report*Serv*'} -ErrorAction SilentlyContinue)
   {
    Write-Host "Current status for installation of Reporting services : Success"
    Write-Host "Installation of Reporting services : " -f white -nonewline; Write-Host "Success" -f green
    "Current status for installation of Reporting services : Success" >> $Log
    "Installation of Reporting services : Success" >> $Log
   }

   ELSE

   {
    Write-Host "Current status for installation of Reporting services : Failed"
    Write-Host "Installation of Reporting services : " -f white -nonewline; Write-Host "Failed" -f red
    "Current status for installation of Reporting services : Failed" >> $Log
    "Installation of Reporting services : Failed" >> $Log
    $Final_Status_Error = 1
   }

 Write-Host "-------"
"-------" >> $Log
Write-Host ""
"" >> $Log

#####################################System DB Drive Verification ####################################################################

 Write-Host "System DB and the Drive Letter on the Server"
   "System DB and the Drive Letter on the Server" >> $Log
   
Write-Host "--------------------------------"
"------------------------------" >> $Log
$SQuery = "select distinct db_name(dbid) as systemDBName,substring(filename,1,3) as drivename from master..sysaltfiles where dbid <= 4 "
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery -As DataSet
$QueryResult.Tables[0].Rows | %{ echo "{ $($_['systemDBName']), $($_['drivename']) }" }
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery -As DataTable
$QueryResult.ItemArray  | Add-Content -Path $Log 

Write-Host ""
"" >> $Log
###################################################################################################################################

#####################################Password Policy Check  ###########################################################################

 Write-Host "Password Policy Check for Logins"
   "Password Policy Check for Logins" >> $Log
   
Write-Host "------------------------"
"-----------------------" >> $Log
$SQuery1 = "USE [master]
GO
SELECT name,
case is_policy_checked 
when '0' then 'Password Policy Not Checked'
when '1' then 'Password Policy Checked'
end  as 'is_policy_checked'
FROM sys.sql_logins where name not like '%#%'"
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery1 -As DataSet
$QueryResult.Tables[0].Rows | %{ echo "{ $($_['name']), $($_['is_policy_checked']) }" }
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery1 -As DataTable
$QueryResult.ItemArray  | Add-Content -Path $Log 

Write-Host ""
"" >> $Log
###################################################################################################################################



#=========================Login Auditing Configuration  ========================= #


 Write-Host "Login Auditing Configuration "
   "Login Auditing Configuration " >> $Log
   
Write-Host "------------------------"
"-----------------------" >> $Log
$SQuery3 = "declare @SQLServerAuditLevel int
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
                                    ,N'Software\Microsoft\MSSQLServer\MSSQLServer'
                                    ,N'AuditLevel', 
                            @SQLServerAuditLevel OUTPUT
select (CASE 
        WHEN @SQLServerAuditLevel = 0 THEN 'None.'
        WHEN @SQLServerAuditLevel = 1 THEN 'Successful Logins Only'
        WHEN @SQLServerAuditLevel = 2 THEN 'Failed Logins Only'
        WHEN @SQLServerAuditLevel = 3 THEN 'Both Failed and Successful Logins Only'
        ELSE 'N/A' END) AS [AuditLevel]
Go"
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery3 -As DataSet
$QueryResult.Tables[0].Rows | %{ echo "{ $($_['AuditLevel'])}" }
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery3 -As DataTable
$QueryResult.ItemArray  | Add-Content -Path $Log 


Write-Host "-------"
"-------" >> $Log
Write-Host ""
"" >> $Log

#--------------------------------- Checking Remote Access---------------------------------#
Write-Host "-------"
"-------" >> $Log

$cmdDD_1 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_1.CommandText = "SELECT CONVERT(INT,value) AS VALUE FROM sys.configurations WHERE name = 'remote access'"
$cmdDD_1.Connection = $conn
$Rmt_Comp = $cmdDD_1.ExecuteScalar()
IF ($Rmt_Comp -ne 1)
{
	Write-Host "Expected value for Remote Access : 1"
	Write-Host "Current value of Remote Access : $BKP_Comp"
	Write-Host "Remote Access: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value for Remote Access : 1" >> $Log
	"Current value of Remote Access : $BKP_Comp" >> $Log
	"Remote Access setting : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value for Remote Access : 1"
	Write-Host "Current value of Remote Access : 1"
	Write-Host "Remote Access: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value for Remote Access : 1" >> $Log
	"Current value of Remote Access : 1" >> $Log
	"Remote Access setting : SUCCESS" >> $Log
}

Write-Host "-------"
"-------" >> $Log
Write-Host ""
"" >> $Log
#------------------------------------------------------------------------------------------------#
 <#
#####################################System DB Drive Verification ################################################################
 Write-Host "System DB and the Drive Letter on the Server"
   "System DB and the Drive Letter on the Server" >> $Log
$SQuery = "select distinct db_name(dbid) as systemDBName,substring(filename,1,3) as drivename from master..sysaltfiles where dbid <= 4 "
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery -As DataSet
$QueryResult.Tables[0].Rows | %{ echo "{ $($_['systemDBName']), $($_['drivename']) }" }
$QueryResult = Invoke-Sqlcmd  -Database 'Master' -Query $SQuery -As DataTable
$QueryResult.ItemArray  | Add-Content -Path $Log 
###################################################################################################################################

#>
#--------------------------------- Checking Backup Compression---------------------------------#
Write-Host "-------"
"-------" >> $Log

IF ($sqlver2 -eq "SQL2005")
{
#Write-Host "Backup compression not supported in SQL Server 2005"
}

ELSEIF (($sqlver2 -eq "SQL2008") -and ($Edtn -eq "Standard Edition"))
{
#Write-Host "Backup compression not supported in SQL2008 Std edition"
}

ELSE

{
$cmdDD_1 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_1.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'backup compression default'"
$cmdDD_1.Connection = $conn
$BKP_Comp = $cmdDD_1.ExecuteScalar()
IF ($BKP_Comp -ne 1)
{
	Write-Host "Expected value for Backup Compression : 1"
	Write-Host "Current value of Backup Compression : $BKP_Comp"
	Write-Host "Backup Compression: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value for Backup Compression : 1" >> $Log
	"Current value of Backup Compression : $BKP_Comp" >> $Log
	"Backup Compression setting : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value for Backup Compression : 1"
	Write-Host "Current value of Backup Compression : 1"
	Write-Host "Backup Compression: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value for Backup Compression : 1" >> $Log
	"Current value of Backup Compression : 1" >> $Log
	"Backup Compression setting : SUCCESS" >> $Log
}

}

#--------------------------------- Checking Remote Query Time Out---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_2 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_2.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'remote query timeout (s)'"
$cmdDD_2.Connection = $conn
$Remo_Query = $cmdDD_2.ExecuteScalar()
if ($Remo_Query -ne 0)
{
	Write-Host "Expected value for Remote Query Timeout : 0"
	Write-Host "Current value for Remote Query Timeout : $Remo_Query"
	Write-Host "Remote Query Timeout: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value for Remote Query Timeout : 0" >> $Log
	"Current value for Remote Query Timeout : $Remo_Query" >> $Log
	"Remote Query Timeout setting : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value for Remote Query Timeout : 0"
	Write-Host "Current value for Remote Query Timeout : 0"
	Write-Host "Remote Query Timeout: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value for Remote Query Timeout : 0" >> $Log
	"Current value for Remote Query Timeout : 0" >> $Log
	"Remote Query Timeout setting : SUCCESS" >> $Log
}

#--------------------------------- Checking Memory Allocation ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_3 = New-Object System.Data.SqlClient.SqlCommand

IF (($sqlver2 -eq "SQL2012") -or ($sqlver2 -eq "SQL2014") -or ($sqlver2 -eq "SQL2016") -or ($sqlver2 -eq "SQL2017") -or ($sqlver2 -eq "SQL2019") -or ($sqlver2 -eq "SQL2022"))
 {
  $cmdDD_3.CommandText = "SELECT CONVERT(INT,(total_physical_memory_kb/1024)*0.75) FROM sys.dm_os_sys_memory"
 }
ELSE
 {
  $cmdDD_3.CommandText = "SELECT CONVERT(INT,(physical_memory_in_bytes/1024/1024)*0.75) FROM [master].[sys].[dm_os_sys_info]"
 }

$cmdDD_3.Connection = $conn
$Max_Mem = $cmdDD_3.ExecuteScalar()
$cmdDD_4 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_4.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max server memory (MB)'"
$cmdDD_4.Connection = $conn
$SQL_Mem = $cmdDD_4.ExecuteScalar()
if ($Max_Mem -ne $SQL_Mem)
{
	Write-Host "Expected value for memory allocation to SQL Server : 75% of total memory"
	Write-Host "Current value of memory allocated to SQL Server : $SQL_Mem"
	Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value for memory allocation to SQL Server : 75% of total memory" >> $Log
	"Current value of memory allocated to SQL Server : $SQL_Mem" >> $Log
	"Memory allocation setting : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value for memory allocation to SQL Server : 75% of total memory"
	Write-Host "Current value of memory allocated to SQL Server :  75% of total memory"
	Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value for memory allocation to SQL Server : 75% of total memory" >> $Log
	"Current value of memory allocated to SQL Server : 75% of total memory" >> $Log
	"Memory allocation setting : SUCCESS" >> $Log
}

#--------------------------------- Checking MAXDOP Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_5 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_5.CommandText = "SELECT cpu_count FROM sys.dm_os_sys_info"
$cmdDD_5.Connection = $conn
$CPU = $cmdDD_5.ExecuteScalar()
$cmdDD_6 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_6.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max degree of parallelism'"
$cmdDD_6.Connection = $conn
$DOP = $cmdDD_6.ExecuteScalar()
if ($CPU -le 4)
{
IF ($DOP -eq 0)
{
	Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 0"
	Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
	Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
	"For $CPU CPU(s), expected value in use for Max DOP allocation: 0" >> $Log
	"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
	"Max DOP Allocation status : SUCCESS" >> $Log
}
ELSE
{
	Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 0"
	Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
	Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
	"For $CPU CPU(s), expected value in use for Max DOP allocation: 0" >> $Log
	"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
	"Max DOP Allocation status : FAILED" >> $Log
	$Final_Status_Error = 1
}
}
IF ($CPU -gt 4)
{
	$C_CPU = $CPU / 2
	IF ($CPU -gt 8)
	{
	IF ($DOP -eq 8)
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 8"
		Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
		Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
		"For $CPU CPU(s), expected value in use for Max DOP allocation: 8" >> $Log
		"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
		"Max DOP Allocation status : SUCCESS" >> $Log
	}
	ELSE
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: 8"
		Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
		Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
		"For $CPU CPU(s), expected value in use for Max DOP allocation: 8" >> $Log
		"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
		"Max DOP Allocation status : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	}
	IF ($DOP -eq $C_CPU)
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU"
		Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
		Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
		"For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU" >> $Log
		"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
		"Max DOP Allocation status : SUCCESS" >> $Log
	}
	ELSE
	{
		Write-Host "For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU"
		Write-Host "For $CPU CPU(s), current value in use for Max DOP allocation: $DOP"
		Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
		"For $CPU CPU(s), expected value in use for Max DOP allocation: $C_CPU" >> $Log
		"For $CPU CPU(s), current value in use for Max DOP allocation: $DOP" >> $Log
		"Max DOP Allocation status : Failed" >> $Log
		$Final_Status_Error = 1
	}
}

#--------------------------------- Checking TEMPDB Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log

IF (($sqlver2 -eq "SQL2012") -or ($sqlver2 -eq "SQL2014") -or ($sqlver2 -eq "SQL2016") -or ($sqlver2 -eq "SQL2017") -or ($sqlver2 -eq "SQL2019") -or ($sqlver2 -eq "SQL2022"))
{
 $cmdDD_x = New-Object System.Data.SqlClient.SqlCommand
 $cmdDD_x.CommandText = "SELECT (((total_bytes/1024)/1024)/1024) AS Value FROM sys.master_files AS f CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID) WHERE DB_NAME(f.database_id) = 'tempdb' AND f.FILE_ID = 1"
 $cmdDD_x.Connection = $conn
 $TempDrive_T_Size = $cmdDD_x.ExecuteScalar()
}

ELSEIF (($sqlver2 -eq "SQL2008") -or ($sqlver2 -eq "SQL2005"))

{
 $tdisk = Get-WmiObject Win32_LogicalDisk -ComputerName $env:COMPUTERNAME -Filter "DeviceID='H:'" | Foreach-Object {((($_.Size/1024)/1024)/1024)}
 $TempDrive_T_Size = [math]::Floor($tdisk)
# Write-Host "TempDriveTsize is $TempDrive_T_Size"
}

$cmdDD_x2 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_x2.CommandText = "SELECT CONVERT(INT,$TempDrive_T_Size * 0.10)"
$cmdDD_x2.Connection = $conn
$TempDB_Size = $cmdDD_x2.ExecuteScalar()

If ($TempDB_Size -gt 10)
{
$TempDB_Size = 10
}

$cmdDD_7 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_7.CommandText = "SELECT COUNT(*) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and type_desc = 'ROWS'"
$cmdDD_7.Connection = $conn
$Temp_Count = $cmdDD_7.ExecuteScalar()

If ($CPU -lt 9)
	{
		if ($Temp_Count -eq $CPU)
		{
			Write-Host "For $CPU CPU(s), expected number of TempDB files : $CPU"
			Write-Host "For $CPU CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"For $CPU CPU(s), expected number of TempDB files : $CPU" >> $Log
			"For $CPU CPU(s), current number of TempDB files : $Temp_Count" >> $Log
			"TempDB # files based on # of CPUs: SUCCESS" >> $Log
			"" >> $Log
			$T = 0
		}
		ELSE
		{
			#Write-Host "For $CPU CPU(s), expected number of TempDB files : $CPU"
			#Write-Host "For $CPU CPU(s), current number of TempDB files : $Temp_Count"
			#Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Failed" -f red
			#Write-Host ""
			"For $CPU CPU(s), expected number of TempDB files : $CPU" >> $Log
			"For $CPU CPU(s), current number of TempDB files : $Temp_Count" >> $Log
			"TempDB # files based on # of CPUs: FAILED" >> $Log
			"" >> $Log
			$T = 1
			$Final_Status_Error = 1
		}
	}
ELSE
	{
	
			if ($Temp_Count -eq 8)
		{
			Write-Host "For $CPU CPU(s), expected number of TempDB files : 8"
			Write-Host "For $CPU CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"For $CPU CPU(s), expected number of TempDB files : 8" >> $Log
			"For $CPU CPU(s), current number of TempDB files : $Temp_Count" >> $Log
			"TempDB # files based on # of CPUs: SUCCESS" >> $Log
			"" >> $Log
			$T = 0
		}
		ELSE
		{
			#Write-Host "For $CPU CPU(s), expected number of TempDB files : 8"
			#Write-Host "For $CPU CPU(s), current number of TempDB files : $Temp_Count"
			#Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Failed" -f red
			#Write-Host ""
			"For $CPU CPU(s), expected number of TempDB files : 8" >> $Log
			"For $CPU CPU(s), current number of TempDB files : $Temp_Count" >> $Log
			"TempDB # files based on # of CPUs: FAILED" >> $Log
			"" >> $Log
			$T = 1
			$Final_Status_Error = 1
		}
	
	
	}

$cmdDD_8 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_8.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'tempdev'"
$cmdDD_8.Connection = $conn
$Temp_Files = $cmdDD_8.ExecuteScalar()
if ($Temp_Files -eq $TempDB_Size)
{
	Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
	Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
	Write-Host "TempDB File Size (Initial File): " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected TempDB size for the given drive size : $TempDB_Size GB" >> $Log
	"Current TempDB size for the given drive size : $Temp_Files GB" >> $Log
	"TempDB File Size (Initial File): SUCCESS" >> $Log
	"" >> $Log
	$TF = 0
}
ELSE
{
	Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
	Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
	Write-Host "TempDB File Size (Initial File): " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected TempDB size for the given drive size : $TempDB_Size GB" >> $Log
	"Current TempDB size for the given drive size : $Temp_Files GB" >> $Log
	"TempDB File Size (Initial File): FAILED" >> $Log
	"" >> $Log
	$TF = 1
	$Final_Status_Error = 1
}

if ($Temp_Count -gt 1)
{
	$i = 2
	$y = 0
	while ($i -le $Temp_Count)
	{
		$cmdDD_x3 = New-Object System.Data.SqlClient.SqlCommand
		$cmdDD_x3.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'tempdev_$i'"
		$cmdDD_x3.Connection = $conn
		$Temp_Files2 = $cmdDD_x3.ExecuteScalar()
		if ($Temp_Files2 -ne $TempDB_Size)
		{
			$y = $y + 1
		}
		$i = $i + 1
	}
	if (($T -eq 0) -and ($TF -eq 0 ) -and ($y -eq 0))
	{

		Write-Host "Expected size of each additional TempDB files : $TempDB_Size GB"
		Write-Host "Current size of each additional TempDB files : $TempDB_Size GB"
		Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected size of each additional TempDB files : $TempDB_Size GB" >> $Log 
		"Current size of each additional TempDB files : $TempDB_Size GB" >> $Log
		"TempDB File Size (Additional Files): SUCCESS" >> $Log
		"" >> $Log 
		$Temp_DB_Final = 0
	}
	ELSE
	{

		#Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Failed" -f red
		#Write-Host ""
		"TempDB File Size (Additional Files): FAILED" >> $Log
		"" >> $Log
		$Temp_DB_Final = 1
		$Final_Status_Error = 1 
	}
}
ELSE
{
	if (($T -eq 0) -and ($TF -eq 0 ))
	{
		Write-Host "Expected number of additional TempDB files required : 0"
		Write-Host "Current number of additional TempDB files : 0"
		Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected number of additional TempDB files required : 0" >> $Log
		"Current number of additional TempDB files : 0" >> $Log
		"TempDB File Size (Additional Files): SUCCESS" >> $Log
		"" >> $Log
		$Temp_DB_Final = 0
	}
	ELSE
	{
		#Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Failed" -f red
		#Write-Host ""
		"TempDB File Size (Additional Files): FAILED" >> $Log
		"" >> $Log
		$Temp_DB_Final = 1
		$Final_Status_Error = 1
	}
}
$cmdDD_9 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_9.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'templog'"
$cmdDD_9.Connection = $conn
$Temp_Log = $cmdDD_9.ExecuteScalar()
if ($Temp_Log -eq $TempDB_Size)
{
	Write-Host "Expected size of Temp log file : $TempDB_Size"
	Write-Host "Current size of Temp log file : $Temp_Log"
	Write-Host "TempDB Log File Size: " -f white -nonewline; Write-Host "Success" -f green
	"Expected size of Temp log file : $TempDB_Size" >> $Log
	"Current size of Temp log file : $Temp_Log" >> $Log
	"TempDB Log File Size: SUCCESS" >> $Log
	Write-Host "-------"
	"-------" >> $Log
	$TLF = 0
}
ELSE
{
	Write-Host "Expected size of Temp log file : $TempDB_Size"
	Write-Host "Current size of Temp log file : $Temp_Log"
	Write-Host "TempDB Log File Size: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected size of Temp log file : $TempDB_Size" >> $Log
	"Current size of Temp log file : $Temp_Log" >> $Log
	"TempDB Log File Size: FAILED" >> $Log
	Write-Host "-------"
	"-------" >> $Log
	$TLF = 1
	$Final_Status_Error = 1
}

IF (($sqlver2 -eq "SQL2005") -and ($sqlver2 -eq "SQL2008") -and ($sqlver2 -eq "SQL2012") -and ($sqlver2 -eq "SQL2014"))
{
$regkey = Get-ItemProperty �HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\Parameters�
$regkey3 = $regkey.SQLArg3
$regkey4 = $regkey.SQLArg4
IF ($regkey3 -eq "-T1118") 
{
	Write-Host "Expected value of trace parameter SQLArg3 in registry : -T1118"
	Write-Host "Current value of trace parameter SQLArg3 in registry : -T1118"
	Write-Host "TempDB T1118 Parameter: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected value of trace parameter SQLArg3 in registry : -T1118" >> $Log
	"Current value of trace parameter SQLArg3 in registry : -T1118" >> $Log
	"TempDB T1118 Parameter: SUCCESS" >> $Log
	"-------" >> $Log
	$S_Param3 = 0
} 
ELSE 
{
	Write-Host "Expected value of trace parameter SQLArg3 in registry : -T1118"
	Write-Host "Current value of trace parameter SQLArg3 in registry : $regkey3"
	Write-Host "TempDB T1118 Parameter: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected value of trace parameter SQLArg3 in registry : -T1118" >> $Log
	"Current value of trace parameter SQLArg3 in registry : $regkey3" >> $Log
	"TempDB T1118 Parameter: FAILED" >> $Log
	"-------" >> $Log
	$S_Param3 = 1
	$Final_Status_Error = 1
}
IF ($regkey4 -eq "-T1117") 
{
	Write-Host "Expected value of trace parameter SQLArg4 in registry : -T1117"
	Write-Host "Current value of trace parameter SQLArg4 in registry : -T1117"
	Write-Host "TempDB T1117 Parameter: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value of trace parameter SQLArg4 in registry : -T1117" >> $Log
	"Current value of trace parameter SQLArg4 in registry : -T1117" >> $Log
	"TempDB T1117 Parameter: SUCCESS" >> $Log
	"-------" >> $Log

	$S_Param4 = 0
} 
ELSE 
{
	Write-Host "Expected value of trace parameter SQLArg4 in registry : -T1117"
	Write-Host "Current value of trace parameter SQLArg4 in registry : $regkey4"
	Write-Host "TempDB T117 Parameter: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value of trace parameter SQLArg4 in registry: -T1117" >> $Log
	"Current value of trace parameter SQLArg4 in registry : $regkey4" >> $Log
	"TempDB T1117 Parameter: FAILED" >> $Log
	"-------" >> $Log

	$S_Param4 = 1
	$Final_Status_Error = 1
}
}
#---------------------------------Checking # of Error Logs ---------------------------------#
Write-Host "-------"
IF ($sqlver2 -eq "SQL2005")
 {
   [int]$NLogFiles=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
 }
ELSE
 {
   $server = New-Object 'Microsoft.SqlServer.Management.SMO.Server' ($Inst_Name)  
   $NLogFiles = $server.NumberOfLogFiles
 }


if ($NLogFiles -ne 45)
{
	#Write-Host "Expected number of error logs : 45"
	#Write-Host "Current number of error logs : $NLogFiles"
	#Write-Host "Setup number of error logs to 45: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected number of error logs : 45" >> $Log
	"Current number of error logs : $NLogFiles" >> $Log
	"Setup number of error logs to 45: FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected number of error logs : 45"
	Write-Host "Current number of error logs : 45"
	Write-Host "Setup number of error logs to 45: " -f white -nonewline; Write-Host "Success" -f green
	"Expected number of error logs : 45" >> $Log
	"Current number of error logs : 45" >> $Log
	"Setup number of error logs to 45: SUCCESS" >> $Log
}


#--------------------------------- checking xp_cmdshell ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_10 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_10.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'xp_cmdshell'"
$cmdDD_10.Connection = $conn
$xp_cmd = $cmdDD_10.ExecuteScalar()
if ($xp_cmd -ne 1)
{
	Write-Host "Expected value of xp_cmdshell : 1"
	Write-Host "Current value of xp_cmdshell : $xp_cmd"
	Write-Host "Enable xp_cmdshell: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value of xp_cmdshell : 1" >> $Log
	"Current value of xp_cmdshell : $xp_cmd" >> $Log
	"Enable xp_cmdshell: FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value of xp_cmdshell : 1"
	Write-Host "Current value of xp_cmdshell : 1"
	Write-Host "Enable xp_cmdshell: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value of xp_cmdshell : 1" >> $Log
	"Current value of xp_cmdshell : 1" >> $Log
	"Enable xp_cmdshell: SUCCESS" >> $Log
}

#--------------------------------- Checking CMDB account ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_11 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_11.CommandText = "SELECT 1 FROM sys.syslogins WHERE name = 'JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe'"
$cmdDD_11.Connection = $conn
$cmdb = $cmdDD_11.ExecuteScalar()
if ($cmdb -ne 1)
{
	Write-Host ""
	Write-Host "Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe"
	Write-Host "Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe" >> $Log
	"Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host ""
	Write-Host "Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe"
	Write-Host "Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe" >> $Log
	"Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: SUCCESS" >> $Log
	"" >> $Log
}

<#
$dba = 'JNJ\ITS-EP-SQL-' + $env:COMPUTERNAME + '-DEFAULT-DBA'
$dbatemp = 'JNJ\ITS-EP-SQL-' + $env:COMPUTERNAME + '-DEFAULT-DBA-Temp'

$cmdDD_12 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_12.CommandText = "SELECT 1 FROM sys.syslogins WHERE name = '$dba'"
$cmdDD_12.Connection = $conn
$cmdb = $cmdDD_12.ExecuteScalar()
if ($cmdb -ne 1)
{
	Write-Host "Expected AD group to  be provisioned : $($dba)"
	Write-Host "Provision account $($dba) : " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected AD group to  be provisioned : $($dba)" >> $Log
	"Provision account $($dba) : FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected AD group to  be provisioned : $($dba)"
	Write-Host "Provision account $($dba) : " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected AD group to  be provisioned : $($dba)" >> $Log
	"Provision account $($dba) : SUCCESS" >> $Log
	"" >> $Log
}


$cmdDD_13 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_13.CommandText = "SELECT IS_SRVROLEMEMBER('sysadmin', '$dba')"
$cmdDD_13.Connection = $conn
$cmdb = $cmdDD_13.ExecuteScalar()
if ($cmdb -ne 1)
{
	Write-Host "Expected role to be provisioned to $($dba) group : SYSADMIN"
	Write-Host "Provision SYSADMIN role to account $($dba) : " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected role to be provisioned to $($dba) group : SYSADMIN" >> $Log
	"Provision SYSADMIN role to account $($dba) : FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected role to be provisioned to $($dba) group : SYSADMIN"
	Write-Host "Provision SYSADMIN role to account $($dba) : " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected role to be provisioned to $($dba) group : SYSADMIN" >> $Log
	"Provision SYSADMIN role to account $($dba) : SUCCESS" >> $Log
	"" >> $Log
}

$cmdDD_14 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_14.CommandText = "SELECT 1 FROM sys.syslogins WHERE name = '$dbatemp'"
$cmdDD_14.Connection = $conn
$cmdb = $cmdDD_14.ExecuteScalar()
if ($cmdb -ne 1)
{
	Write-Host "Expected AD group to  be provisioned : $($dbatemp)"
	Write-Host "Provision account $($dbatemp) : " -f white -nonewline; Write-Host "Failed" -f red
	Write-host ""
	"Expected AD group to  be provisioned : $($dbatemp)" >> $Log
	"Provision account $($dbatemp) : FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected AD group to  be provisioned : $($dbatemp)"
	Write-Host "Provision account $($dbatemp) : " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected AD group to  be provisioned : $($dbatemp)" >> $Log
	"Provision account $($dbatemp) : SUCCESS" >> $Log
	"" >> $Log
}


$cmdDD_15 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_15.CommandText = "SELECT IS_SRVROLEMEMBER('sysadmin', '$dbatemp')"
$cmdDD_15.Connection = $conn
$cmdb = $cmdDD_15.ExecuteScalar()
if ($cmdb -ne 1)
{
	Write-Host "Expected role to be provisioned to $($dbatemp) group : SYSADMIN"
	Write-Host "Provision SYSADMIN role to account $($dbatemp) : " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected role to be provisioned to $($dbatemp) group : SYSADMIN" >> $Log
	"Provision SYSADMIN role to account $($dbatemp) : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected role to be provisioned to $($dbatemp) group : SYSADMIN"
	Write-Host "Provision SYSADMIN role to account $($dbatemp) : " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected role to be provisioned to $($dbatemp) group : SYSADMIN" >> $Log
	"Provision SYSADMIN role to account $($dbatemp) : SUCCESS" >> $Log
}
#>
#--------------------------------- Checking Native Auditing status ---------------------------------#
Write-Host "-------"
"-------" >> $Log

$NA = (Get-Content 'C:\IQOQ\IQOQ_2.txt')[0]

If ($NA -eq "Native Auditing:1")

{
	Write-Host "Expected setting for Native Auditing : Enabled"
	Write-Host "Current setting for Native Auditing : Disabled"
	Write-Host "Native Auditing enabled : " -f white -nonewline; Write-Host "Failed" -f red
	"Expected setting for Native Auditing : Enabled" >> $Log
	"Current setting for Native Auditing : Disabled" >> $Log
	"Native Auditing setting enabled : FAILED" >> $Log
	$Final_Status_Error = 1
}

If ($NA -eq "Native Auditing:0")
{
	Write-Host "Expected setting for Native Auditing : Enabled"
	Write-Host "Current setting for Native Auditing : Enabled"
	Write-Host "Native Auditing enabled: " -f white -nonewline; Write-Host "Success" -f green
	"Expected setting for Native Auditing : Enabled" >> $Log
	"Current setting for Native Auditing : Enabled" >> $Log
	"Native Auditing setting enabled : SUCCESS" >> $Log
}

If ($NA -eq "Native Auditing:D")
{
	Write-Host "Expected setting for Native Auditing : Disabled"
	Write-Host "Current setting for Native Auditing : Disabled"
	Write-Host "Native Auditing Disabled: " -f white -nonewline; Write-Host "Success" -f green
	"Expected setting for Native Auditing : Disabled" >> $Log
	"Current setting for Native Auditing : Disabled" >> $Log
	"Native Auditing setting disabled: SUCCESS" >> $Log
}

#--------------------------------- Checking Cold Backup status ---------------------------------#
Write-Host "-------"
"-------" >> $Log

$ColdBackup = (Get-Content 'C:\IQOQ\IQOQ_2.txt')[1]

If ($ColdBackup -eq "Cold Backup:1")

{
	Write-Host "Expected status of cold backup of system databases : Success"
	Write-Host "Current status of cold backup of system databases : Failed"
	Write-Host "Cold backups of system databases performed : " -f white -nonewline; Write-Host "Failed" -f red
	"Expected status of cold backup of system databases : Success" >> $Log
	"Current status of cold backup of system databases : Failed" >> $Log
	"Cold backup of system databases : FAILED" >> $Log
	$Final_Status_Error = 1
}

ELSE

{
	Write-Host "Expected status of cold backup of system databases : Success"
	Write-Host "Current status of cold backup of system databases : Success"
	Write-Host "Cold backups of system databases performed: " -f white -nonewline; Write-Host "Success" -f green
	"Expected status of cold backup of system databases : Success" >> $Log
	"Current status of cold backup of system databases : Success" >> $Log
	"Native Auditing setting enabled : SUCCESS" >> $Log
}


#--------------------------------- Checking Data Integrity and Optimization Plan Deployment ----------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_16 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_16.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name in ( 'DatabaseIntegrityCheck - All Databases' ,'IndexOptimize - All Databases')AND enabled = 1"
$cmdDD_16.Connection = $conn
$DataInt = $cmdDD_16.ExecuteScalar()
if ($DataInt -eq 2)
{
	Write-Host "Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success"
	Write-Host "Current status of Data Integrity and Optimization Maintenance Jobs creation: Success"
	Write-Host "Creation of job for Data Integrity and Optimization Maintenance Jobs: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success" >> $Log
	"Current status of Data Integrity and Optimization Maintenance Jobs creation: Success" >> $Log
	"Creation of job for Data Integrity and Optimization Maintenance Jobs: SUCCESS" >> $Log
	"" >> $Log	
}
ELSE
{
	Write-Host "Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success"
	Write-Host "Current status of Data Integrity and Optimization Maintenance Jobs creation: Failed"
	Write-Host "Creation of job for Data Integrity and Optimization Maintenance Jobs: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success" >> $Log
	"Current status of Data Integrity and Optimization Maintenance Jobs creation: Failed" >> $Log
	"Creation of job for Data Integrity and Optimization Maintenance Jobs: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}

#####################################################################################################################################
#####################################################################################################################################
#####################################################################################################################################

$cmdDD_99 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_99.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name like 'ITSSQL_%' AND enabled = 1"
$cmdDD_99.Connection = $conn
$BackupInt = $cmdDD_99.ExecuteScalar()

If ($BackupInt -ne 0)
{
#--------------------------------- Checking Backup jobs Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log
If ($BackupInt -ge 3)
{


$cmdDD_17 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_17.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_FULL' AND enabled = 1"
$cmdDD_17.Connection = $conn
$DataInt = $cmdDD_17.ExecuteScalar()
if ($DataInt -ne 1)
{

	Write-Host "Expected status of ITSSQL_DirectTape_FULL job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_FULL job creation: Failed"
	Write-Host "Creation of ITSSQL_DirectTape_FULL job: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_FULL job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_FULL job creation: Failed" >> $Log
	"Creation of ITSSQL_DirectTape_FULL job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of ITSSQL_DirectTape_FULL job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_FULL job creation: Success"
	Write-Host "Creation of ITSSQL_DirectTape_FULL job: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_FULL job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_FULL job creation: Success" >> $Log
	"Creation of ITSSQL_DirectTape_FULL job: SUCCESS" >> $Log
	"" >> $Log
}



$cmdDD_18 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_18.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_DIFF' AND enabled = 1"
$cmdDD_18.Connection = $conn
$DataInt = $cmdDD_18.ExecuteScalar()
if ($DataInt -ne 1)
{

	Write-Host "Expected status of ITSSQL_DirectTape_DIFF job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_DIFF job creation: Failed"
	Write-Host "Creation of ITSSQL_DirectTape_DIFF job : " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_DIFF job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_DIFF job creation: Failed" >> $Log
	"Creation of ITSSQL_DirectTape_DIFF job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of ITSSQL_DirectTape_DIFF job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_DIFF job creation: Success"
	Write-Host "Creation of ITSSQL_DirectTape_DIFF job: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_DIFF job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_DIFF job creation: Success" >> $Log
	"Creation of ITSSQL_DirectTape_DIFF job: SUCCESS" >> $Log
	"" >> $Log
}



$cmdDD_19 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_19.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_LOG' AND enabled = 1"
$cmdDD_19.Connection = $conn
$DataInt = $cmdDD_19.ExecuteScalar()
if ($DataInt -ne 1)
{

	Write-Host "Expected status of ITSSQL_DirectTape_Log job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_Log job creation: Failed"
	Write-Host "Creation of ITSSQL_DirectTape_Log job: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_Log job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_Log job creation: Failed" >> $Log
	"Creation of ITSSQL_DirectTape_Log job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of ITSSQL_DirectTape_Log job creation: Success"
	Write-Host "Current status of ITSSQL_DirectTape_Log job creation: Success"
	Write-Host "Creation of ITSSQL_DirectTape_Log job: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of ITSSQL_DirectTape_Log job creation: Success" >> $Log
	"Current status of ITSSQL_DirectTape_Log job creation: Success" >> $Log
	"Creation of ITSSQL_DirectTape_Log job: SUCCESS" >> $Log
	"" >> $Log
}


}
Else 
{


$cmdDD_20 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_20.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_MetaData' AND enabled = 1"
$cmdDD_20.Connection = $conn
$DataInt = $cmdDD_20.ExecuteScalar()
if ($DataInt -ne 1)
{

	Write-Host "Expected status of ITSSQL_MetaData job creation: Success"
	Write-Host "Current status of ITSSQL_MetaData job creation: Failed"
	Write-Host "Creation of ITSSQL_MetaData job: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of ITSSQL_MetaData job creation: Success" >> $Log
	"Current status of ITSSQL_MetaData job creation: Failed" >> $Log
	"Creation of ITSSQL_MetaData job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of ITSSQL_MetaData job creation: Success"
	Write-Host "Current status of ITSSQL_MetaData job creation: Success"
	Write-Host "Creation of ITSSQL_MetaData job: " -f white -nonewline; Write-Host "Success" -f green
	"Expected status of ITSSQL_MetaData job creation: Success" >> $Log
	"Current status of ITSSQL_MetaData job creation: Success" >> $Log
	"Creation of ITSSQL_MetaData job: SUCCESS" >> $Log
	"" >> $Log
}


}
}


Else 
{
#--------------------------------- Checking Full Backup Plan Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_18 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_18.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'FullDatabaseBackupMaintenance.Subplan_1' AND enabled = 1"
$cmdDD_18.Connection = $conn
$FullBKP = $cmdDD_18.ExecuteScalar()
if ($FullBKP -ne 1)
{
	Write-Host "Expected status of Full Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Full Backup Maintenance Plan creation: Failed"
	Write-Host "Creation of job for Full Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Full Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Full Backup Maintenance Plan creation: Failed" >> $Log
	"Creation of job for Full Backup Maintenance Plan: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of Full Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Full Backup Maintenance Plan creation: Success"
	Write-Host "Creation of job for Full Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Full Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Full Backup Maintenance Plan creation: Success" >> $Log
	"Creation of job for Full Backup Maintenance Plan: SUCCESS" >> $Log
	"" >> $Log
}

#--------------------------------- Checking Differential Backup Plan Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_17 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_17.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'DiffDatabaseBackupMaintenance.Subplan_1' AND enabled = 1"
$cmdDD_17.Connection = $conn
$DiffBKP = $cmdDD_17.ExecuteScalar()
if ($DiffBKP -ne 1)
{
	Write-Host "Expected status of Differential Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Differential Backup Maintenance Plan creation: Failed"
	Write-Host "Creation of job for Differential Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Differential Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Differential Backup Maintenance Plan creation: Failed" >> $Log
	"Creation of job for Differential Backup Maintenance Plan: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of Differential Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Differential Backup Maintenance Plan creation: Success"
	Write-Host "Creation of job for Differential Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Differential Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Differential Backup Maintenance Plan creation: Success" >> $Log
	"Creation of job for Differential Backup Maintenance Plan: SUCCESS" >> $Log
	"" >> $Log
}

#--------------------------------- Checking Transaction Log Backup Plan Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_19 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_19.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'TransactionLogBackupMaintenance.Subplan_1' AND enabled = 1"
$cmdDD_19.Connection = $conn
$TLOGBKP = $cmdDD_19.ExecuteScalar()
if ($TLOGBKP -ne 1)
{
	Write-Host "Expected status of Transaction Log Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Transaction Log Backup Maintenance Plan creation: Failed"
	Write-Host "Creation of job for Transaction Log Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Transaction Log Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Transaction Log Backup Maintenance Plan creation: Failed" >> $Log
	"Creation of job for Transaction Log Backup Maintenance Plan: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of Transaction Log Backup Maintenance Plan creation: Success"
	Write-Host "Current status of Transaction Log Backup Maintenance Plan creation: Success"
	Write-Host "Creation of job for Transaction Log Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Transaction Log Backup Maintenance Plan creation: Success" >> $Log
	"Current status of Transaction Log Backup Maintenance Plan creation: Success" >> $Log
	"Creation of job for Transaction Log Backup Maintenance Plan: SUCCESS" >> $Log
	"" >> $Log
}
#############################################################################################################
}
#############################################Baseline Framework Validation Log #########################################
Write-Host "-------"
"-------" >> $Log

Write-Host "Baseline Framework Validation"
"Baseline Framework Validation" >> $Log

Write-Host "-------"
"-------" >> $Log

$cmdDD_21 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_21.CommandText = "select count(*) from master.sys.databases where name = 'Baseline' and state_desc = 'ONLINE'
"
$cmdDD_21.Connection = $conn
$DataInt = $cmdDD_21.ExecuteScalar()
if ($DataInt -ne 1)
{

	Write-Host "Expected status of Baseline Framework Database and Job creation: Success"
	Write-Host "Current status of Baseline Framework  Database and Jobcreation: Failed"
	Write-Host "Creation of Baseline Framework  Database and Job: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Baseline Framework Database and Jobcreation: Success" >> $Log
	"Current status of Baseline Framework Database and Jobcreation: Failed" >> $Log
	"Creation of Baseline Framework Database and Job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of Baseline Framework Database creation: Success"
	Write-Host "Current status of Baseline Framework Database: Success"
	Write-Host "Creation of Baseline Framework Database: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Baseline Framework Database creation: Success" >> $Log
	"Current status of Baseline Framework Database creation: Success" >> $Log
	"Creation of Baseline Framework Database: SUCCESS" >> $Log
	"" >> $Log
$DataInt = "null"
Echo $DataInt
$cmdDD_22 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_22.CommandText = "SELECT COUNT(*) FROM msdb..sysjobs WHERE name in ('DBA - Capture Who is Active','DBA - Collect Index_Stats Info',
'DBA - DB Space Utilization','DBA - Load Session Status','DBA - Load SystemHealthSession', 'DBA - PerfMon Counter Collection', 'DBA - Server Config Changes' ) AND enabled = 1"
$cmdDD_22.Connection = $conn
$DataInt = $cmdDD_22.ExecuteScalar()
Echo $DataInt
if ($DataInt -ne 7)
{

	Write-Host "Expected status of Baseline Framework Job creation: Success"
	Write-Host "Current status of Baseline Framework  job creation: Failed"
	Write-Host "Creation of Baseline Framework  job: " -f white -nonewline; Write-Host "Failed" -f red
	Write-Host ""
	"Expected status of Baseline Framework Job creation: Success" >> $Log
	"Current status of Baseline Framework Job creation: Failed" >> $Log
	"Creation of Baseline Framework Job: FAILED" >> $Log
	"" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected status of Baseline Framework Job creation: Success"
	Write-Host "Current status of Baseline Framework Job: Success"
	Write-Host "Creation of Baseline Framework Job: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	"Expected status of Baseline Framework Job creation: Success" >> $Log
	"Current status of Baseline Framework Job creation: Success" >> $Log
	"Creation of Baseline Framework Job: SUCCESS" >> $Log
	"" >> $Log
}
}
###############################################END OF BASELINE FRAMEWORK VALIDATION ###################################


Write-Host "########################## SQL INSTALLATION OPERATIONAL VERIFICATION ##########################"
"########################## SQL INSTALLATION OPERATIONAL VERIFICATION ##########################" >> $Log

IF ($Final_Status_Error -eq 1)
{
Write-Host ""
Write-Host "SQL IQOQ verification FAILED. Return code is 1"
Write-Host "Please review the verification steps and address the failed step"
Write-Host ""
"" >> $Log
"SQL IQOQ verification FAILED. Return code is 1" >> $Log
"Please review the verification steps and address the failed step" >> $Log
"" >> $Log
"FAILED" > $BatchOutput4
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Write-Host ""
Write-Host "SQL IQOQ verification PASSED. Return code is 0"
Write-Host ""
"" >> $Log
"SQL IQOQ verification PASSED. Return code is 0" >> $Log
"" >> $Log
"SUCCESS" > $BatchOutput4
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}

<#
Write-Host ""
Write-Host "SQL IQOQ verification PASSED. Return code is 0"
Write-Host ""
"" >> $Log
"SQL IQOQ verification PASSED. Return code is 0" >> $Log
"" >> $Log
"SUCCESS" > $BatchOutput4
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
#>
#*********************************** End of Post installation Verification ***********************************#


