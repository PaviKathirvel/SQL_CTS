 #########################################################################
###################################################################################################
$ScriptName = "Instance_Decommission.ps1"
$Scriptver = "1.0"
#Description: Pre-implementation script for Instance Decommission.
#Example:-  Instance_Decommission.ps1 ChangeNumber ServerName InstanceName DatabaseName CoolDownPeriod 
#Sample:- 
###################################################################################################
#Version Author		Reason for Change
###################################################################################################
#1.0	Darshana	New Script

###################################################################################################
$ChangeNumber = $args[0]
$ServerName = $args[1]
$InstanceName = $args[2]
$DatabaseName = $args[3]
$CTaskOrder = $args[4]

if(($ChangeNumber -eq $null) -or ($ServerName -eq $null) -or ($InstanceName -eq $null) -or ($CTaskOrder -eq $null))
{
 write-host "Please pass the valid parameters!"
 write-host "Sample: ChangeNumber as first Parameter, ServerName as second Parameter,InstanceName as third Parameter and CTaskOrder as fourth Parameter"
 EXIT 1
}

 
 
$timenow = (Get-Date -uformat "%m%d%Y%H%M%S")


[array]$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
#Write-Host "Following are the instances running on the server $ServerName : $instances"

                 #write-host "Success.."
                  if($InstanceName -eq "MSSQLSERVER")
                 {
                    $DBServerInstanceName = $ServerName
                    write-host "InstanceName is:$DBServerInstanceName"
		    "InstanceName is:$DBServerInstanceName">>$LogFolder2
                 }elseif($InstanceName -ne "MSSQLSERVER")
                 {
                  $DBServerInstanceName = $ServerName+'\'+$InstanceName
                  write-host "InstanceName is:$DBServerInstanceName"
		  "InstanceName is:$DBServerInstanceName">>$LogFolder2
                 }
		


############Get the Version details of an Instance##################

$p2= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName
 $version = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").Version



$Hostname = hostname

#############################################Log Folder#########################################
$LogFolder0 = 'C:\' + "$ChangeNumber"


if(!(test-path $LogFolder0))
{
  New-Item $LogFolder0 -type directory
}else
{
  #Write-host " the log folder exist "
}

$LogFolder = $LogFolder0 + "\"+"ITS_Instance_Decommission"

                  
if(!(test-path $LogFolder))
{
  New-Item $LogFolder -type directory
}else
{
  #Write-host " the log folder exist "
}

$LogFolder1 = $LogFolder + "\$DBServerInstanceName"

if(!(test-path $LogFolder1))
{
  New-Item $LogFolder1 -type directory
}else
{
 #write-host " the log folder exist "
}

if($CTaskOrder -eq "1")
{
 $LogFolder2 = $LogFolder1 + "\"+"$Hostname"+"_AUTOMATION_TASK300_VRO_"+"PreCoolDownPeriod"+"_"+"$timenow"+".log"
 #write-host $LogFolder2
}
elseif($CTaskOrder -eq "2")
{
 $LogFolder2 = $LogFolder1 + "\"+"$Hostname"+"_AUTOMATION_TASK320_VRO_"+"PostCoolDownPeriod"+"_"+"$timenow"+".log"
 #write-host $LogFolder2
}
elseif($CTaskOrder -eq "3")
{
 $LogFolder2 = $LogFolder1 + "\"+"$Hostname_AUTOMATION_TASK400_VRO_"+"PostImplementationVerification"+"_"+"$timenow"+".log"
}
$ESTime = Get-date
#write-host "Execution Start Time is: $ESTime"
#"Execution Start Time is: $ESTime">>$LogFolder2




    Write-host
    Write-Host "#######################################################################"
    "#######################################################################">>$LogFolder2
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >>$LogFolder2
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >>$LogFolder2
    Write-Host "Execution Start Time: $ESTime"
    "Execution Start Time: $ESTime" >>$LogFolder2
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >>$LogFolder2
    "Execution string: $ScriptName $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder " >>$LogFolder2

    Write-Host "#######################################################################"
    "#######################################################################" >>$LogFolder2

 $cs = Get-WmiObject -Class Win32_SystemServices -ComputerName $env:computername
 IF ($cs | select PartComponent | where {$_ -like "*ClusSvc*"}) 
 { 
  $IsClus = "YES" 
  write-host "Clustered Server!"
  #EXIT 1
 }ELSE
 { 
   $IsClus = "NO"
   write-host "Not a Clustered Server!"
  "Not a Clustered Server!">>$LogFolder2
 " ">>$LogFolder2
 }
 
#########################################################################################
IF(($ServerName -eq $null))
{
 write-host "Please pass the valid ServerName" -f red
 EXIT 1
}elseif($ServerName -ne "$Hostname")
{
  write-host "Invalid ServerName!!Please pass the valid ServerName." -f red
	EXIT 1
}
else{
#########################################################################################
###########################Server Validation Check###################################
######################################################################################
#write-host "Success"


Function getLocation()
{
 
foreach($serv in $ServerName)
{
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]

	IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
	 {
	   IF ($IpPartsIdentifier2 -eq 0) 

 	    { 
		$ServerLocation	= "LAB"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder2
	        " ">>$LogFolder2
		"ServerName:$ServerName">>$LogFolder2
	        write-output "Location:$ServerName belongs to $ServerLocation">>$LogFolder2
		"############################################################################################################################################">>$LogFolder2
		" ">>$LogFolder2

 	    }
	    ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 	    { 
		$ServerLocation	= "NA"
		write-host "$ServerName belongs to $ServerLocation"
		write-output "ServerName:$ServerName">>$LogFolder2
	        write-output "Location:$ServerName belongs to $ServerLocation">>$LogFolder2
		"#####################################################################################################################################">>$LogFolder2
		" ">>$LogFolder2

 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 	    {
		$ServerLocation	= "LA"	
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder2
	        " ">>$LogFolder2
		"ServerName:$ServerName">>$LogFolder2
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder2
		"#################################################################################################################################">>$LogFolder2
		" ">>$LogFolder2

	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 	    {
		$ServerLocation	= "EMEA"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder2
	        " ">>$LogFolder2
		"ServerName:$ServerName">>$LogFolder2
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder2
		"##############################################################################################################################################">>$LogFolder2
		" ">>$LogFolder2

 	    }ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 	    {
		$ServerLocation	= "ASPAC"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder2
	        " ">>$LogFolder2
		"ServerName:$ServerName">>$LogFolder2
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder2
		"##############################################################################################################################################">>$LogFolder2
		" ">>$LogFolder2

 	    }
	   ELSE 
 	    {
		Write-Host "Server location is unknown, exiting now.." -f red
		" ">>$LogFolder2
	        " ">>$LogFolder2
	        "Server location is unknown, exiting now..">>$LogFolder2
	        "Exit 1">>$LogFolder2
		Exit 1
 	    }

	 }			
}

}
getLocation
}

###########################################################################
############Get the specific InstanceName if Server contains more than one Instance###################
###########################################################################

[array]$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
#Write-Host "Following are the instances running on the server $ServerName : $instances"

                 #write-host "Success.."
                  if($InstanceName -eq "MSSQLSERVER")
                 {
                    $DBServerInstanceName = $ServerName
                    write-host "InstanceName is:$DBServerInstanceName"
		    "InstanceName is:$DBServerInstanceName">>$LogFolder2
                 }elseif($InstanceName -ne "MSSQLSERVER")
                 {
                  $DBServerInstanceName = $ServerName+'\'+$InstanceName
                  write-host "InstanceName is:$DBServerInstanceName"
		  "InstanceName is:$DBServerInstanceName">>$LogFolder2
                 }
		




<#
 Function ClusteredServer()
 {
#######################Clustered Information#############################


   $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances

    FOREACH ($inst in $instances)
    {
         $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName
        
          IF ($inst -eq 'MSSQLServer')
           {

                IF ($IsClus -eq "YES")
                  {
                       $ClusterInstanceName = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName
			write-host $ClusterInstanceName
                       $DBServerInstanceName = $ClusterInstanceName
                  }
                 ELSE
                  {
                       $DBServerInstanceName = $env:computername
                  }

           }

          ELSE

           {
                IF ($IsClus -eq "YES")
                  {
                     $ClusterInstanceName = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName
                      $DBServerInstanceName = $ClusterInstanceName+'\'+$inst
                  }
                 ELSE
                  {
                       $DBServerInstanceName = $env:computername+'\'+$inst
                  }

           }

      }
}
#>
############################Sql Uninstall########################
Function Uninstall()
{
 $IQOQOutput = "C:\IQOQ"


if(!(test-path $IQOQOutput))
{
  New-Item $IQOQOutput -type directory
}else
{
  #Write-host "  log folder exist "
}
write-host "Inside Uninstall Block"
 $IQOQOutput = "C:\IQOQ\Decommission_Status.txt"
 $Time = get-date -Uformat "%Y%m%d%H%M"
IF ($Build -eq "12")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\Summary.txt'	
        Write-Host "Detailed log files are available inside -- $file_txt." -f Green
        "Detailed log files are available inside -- $file_txt." >> $LogFolder2
}

ELSEIF ($Build -eq "11")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\Summary.txt'	
	Write-Host "Detailed log files are available inside -- $file_txt." -f Green
         "Detailed log files are available inside -- $file_txt." >> $LogFolder2
}
ELSEIF ($Build -eq "10")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log\Summary.txt'
	Write-Host "Detailed log files are available inside -- $file_txt. " -f Green
        "Detailed log files are available inside -- $file_txt. ">>$LogFolder2
}
ELSEIF ($Build -eq "9")
{
	$file_txt = 'C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\LOG\Summary.txt'
	Write-Host "Detailed log files are available inside -- $file_txt." -f Green
       "Detailed log files are available inside -- $file_txt.">>$LogFolder2
}

ELSEIF ($Build -eq "13")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log\Summary.txt'
	Write-Host "Detailed log files are available inside -- $file_txt. " -f Green
      "Detailed log files are available inside -- $file_txt. ">>$LogFolder2
}

IF (($Build -eq "11") -or ($Build -eq "10"))
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*GlobalRules.txt"
}
ELSEIF ($Build -eq "12")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}
ELSEIF ($Build -eq "13")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}

IF (($Build -eq "12") -or ($Build -eq "11") -or ($Build -eq "10") -or ($Build -eq "13"))
{
	$ResultFile = $Path + "\" + $SummaryFile
	$exitmsg = (Get-Content $ResultFile)[2].Trim()

	If ($exitmsg -eq "Exit code (Decimal):           -2067919934")
	{
    	  Write-Host ""
    	  Write-Host "A Computer restart is required. Uninstallation of instance "$InstanceName" : " -f white -nonewline; Write-Host "FAILED" -f red
    	  Write-Host ""
    	  "" >> $LogFolder2
    	  "A Computer restart is required. Uninstallation of  instance $InstanceName : FAILED" >> $LogFolder2
	  "FAILED" >$IQOQOutput
	  EXIT 0
	}

    $Time = get-date -Uformat "%Y%m%d%H%M"

    $s1 = (Get-Content $file_txt)[1]
    $s2 = (Get-Content $file_txt)[3]
    $s3 = (Get-Content $file_txt)[4]
    $s4 = (Get-Content $file_txt)[2].Trim()
    #$exitcode = "  Final result: Passed"
    $exitPass  = "Exit code (Decimal):           0"
    #$exitPassReboot  = "Exit code (Decimal):           3010"


    

    if ($s4 -eq $exitPass)  
    {
    	Write-Host ""
    	Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "SUCCESSFUL" -f green
    	Write-Host ""
    	"" >> $LogFolder2
    	"UnInstallation of $ver instance $InstanceName : SUCCESSFUL" >> $LogFolder2
	"SUCCESS" > $IQOQOutput
    }
    
    ELSE
    {
    	Write-Host ""
    	Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "FAILED" -f red
    	Write-Host ""
    	"" >> $LogFolder2
    	"UnInstallation of  instance $InstanceName : FAILED" >> $LogFolder2
	"FAILED" > $IQOQOutput
    }

        Write-Host ""
        Write-Host "------------------------ Uninstallation Summary -------------------------"  
        Write-Host ""
        Write-Host "$s1"
        Write-Host "$s2"
        Write-Host "$s3"
        Write-Host ""

        "" >> $LogFolder2
        "------------------------ Uninstallation Summary -------------------------"  >> $LogFolder2
        "" >> $LogFolder2
        "$s1" >> $LogFolder2
        "$s2" >> $LogFolder2
        "$s3" >> $LogFolder2


}
}

#*************************** End of Verify SQL Uninstall Function ***************************

##################################################################End Cluster Information##############################
if($CTaskOrder -eq $null)
{
 write-host "Please pass the valid CDPeriod"
 EXIT 1
}elseif($CTaskOrder -eq '1')
{
 Function PreCoolDownImplementation()
{

#----------------------- Blackout Script ----------------------------
$Blackout_StartTime = get-date (get-date).AddMinutes(6) -format "MM/dd/yyyy hh:mm:ss"
$Blackout_EndTime = get-date (get-date).AddHours(2) -format "MM/dd/yyyy hh:mm:ss"
$Blackout_Hostname = Hostname
$Blackout_Exec = "\\itsusrawsp03355\Blackout_Prod\bin\blackout.bat $Blackout_Hostname cmdb_ci_win_server $Blackout_StartTime $Blackout_EndTime Change ""Blackout Windows created for patching through Automation"" N"
Write-Host "Blackout Window"
Write-Host $Blackout_Exec

& \\itsusrawsp03355\Blackout_Prod\bin\blackout.bat $Blackout_Hostname cmdb_ci_win_server "$Blackout_StartTime" "$Blackout_EndTime" Change "Blackout Windows created for patching through Automation" N

Write-Host ""
Write-Host "Delay of 2 Minutes for Blackout Window"
Start-Sleep -s 120
write-host "Server is been succesfully added to Blackout Window"

###########################################################################
############Check if this is Last Instance on the server###################
###########################################################################

[int]$instlen = $instances.length


IF($instlen -gt 1)
{
  $instCount = "$instlen"
  write-host "Number of Instances present are: $instlen"
  "Number of Instances present are: $instlen">>$LogFolder2
  Write-Host "Following are the instances running on the server $ServerName : $instances"
  "Following are the instances running on the server $ServerName : $instances">>$LogFolder2
  Write-Host "This machine has more than 1 instance running"
  "This machine has more than 1 instance running " >> $LogFolder2
  "" >> $LogFolder2
 Write-Host "Follow the Manual Decommission process" -F RED
 "Follow the Manual Decommission process" >> $LogFolder2
write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 0 "
"EXIT 0 ">>$LogFolder2
EXIT 0

} ELSEIF($instlen -eq 1)
{
 write-host "Number of Instances present are:$instlen"
  "Number of Instances present are:$instlen">>$LogFolder2
  Write-Host "Following are the instances running on the server $ServerName : $instances"
  "Following are the instances running on the server $ServerName : $instances">>$LogFolder2




 Write-Host "Continuing with AutoDecommission process" -F RED
 "Continuing with AutoDecommission process" >> $LogFolder2



}


 $connectionString = "Data Source=$ServerName; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog = 'master'"

###########################Database Validation Check######################################
 $connectionString = "Data Source=$ServerName; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog = 'master'"
###############################################################################################################
 
$result = invoke-sqlcmd -query "select name from sys.databases where state_desc = 'OFFLINE'"-serverinstance $DBServerInstanceName -database master 
foreach($res in $result)
{
 try
{
 $State = $res.name
 $query = "Use Master Alter Database $State Set Online With Rollback Immediate;"
 $result = Invoke-Sqlcmd -ServerInstance $DBServerInstanceName -Database master -Query $query
 write-host "$State is now in Online state"
 "$State is now in Online state">>$LogFolder2
}catch
{
 $ex = "Database is in offline state,Please check if there are any active transactions on database $State."
 #$ErrorActionPreference = "SilentlyContinue"
	   $ex = "Database is in offline state,Please check if there are any active transactions on database $State"
	
	   "Database is in offline state,Please check if there are any active transactions on database $State">>$LogFolder2
  write-host "Instance can't be decommissioned!" -f RED     
 write-host "$ex"
write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 1"
 "EXIT 1">>$LogFolder2

 EXIT 1


}

}
################################################Restoring part##############################################################
$query1 = "select name from sys.databases where  state = '1'"
$result1 = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database master -Query $query1
foreach($res in $result1)
{
 $query = " use $State  Restore  database $State WITH RECOVERY "
try
{
 $State	= $res.name
 $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
    	    $command = new-object system.data.sqlclient.sqlcommand($query,$connection)
 $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
    	    $command.commandtimeout = 0
    	    $dataset = New-Object System.Data.DataSet
    	    $adapter.Fill($dataSet) | Out-Null
    	    $dataSet.Tables
}
catch
{
 $ex = "Database is in Restoring state,Please check if there are any active transactions on database $State."
 $ErrorActionPreference = "SilentlyContinue"
	   $ex = "Database $State is in Restoring state,Please check if there are any active transactions on database $State"
	
	   "Database $State is in Restoring state,Please check if there are any active transactions on database $State">>$LogFolder2
  write-host "Instance can't be decommissioned!" -f RED     
 write-host $ex
write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 1"
 "EXIT 1">>$LogFolder2

 EXIT 1


}
  
}
#######################################################State##################################################################
$query = " select name from sys.databases where state ='2' or state='3' or state ='4' or state ='5' "
$result = Invoke-Sqlcmd -ServerInstance $DBServerInstanceName -Database master -Query $query

$da22 = New-Object System.Data.SqlClient.SqlDataAdapter ($query,$connectionString)
$dt22 = New-Object System.Data.DataTable
$da22.fill($dt22)
if($dt22.Rows.Count -ne 0)
{
 $query = " select name from sys.databases where state ='2' or state='3' or state ='4' or state ='5'"
 $result = Invoke-Sqlcmd -ServerInstance $DBServerInstanceName -Database master -Query $query
 foreach($res in $result)
{
  $name = $res.name
  write-host "Database $name is in one of the state that is either 2 = RECOVERING , 3 = RECOVERY_PENDING , 4 = SUSPECT ,5 = EMERGENCY"
  write-host "Hence cannot proceed with Instance Decommission" -f red
  "Database $name is in one of the state that is either in 2 = RECOVERING , 3 = RECOVERY_PENDING , 4 = SUSPECT ,5 = EMERGENCY">>$LogFolder2
  "Hence cannot proceed with Instance Decommission">>$LogFolder2

write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 1"
 "EXIT 1">>$LogFolder2

 EXIT 1
}
}

#####################################################################
          try
     	     {  	
		$computername = hostname
		Get-WmiObject win32_logicaldisk -ComputerName $ComputerName -Filter "Drivetype=3"  |`
		select  DeviceID,@{Label="Free Size";Expression={$_.freespace / (1024*1024) -as [int]}} |ConvertTo-Xml -as String -NoTypeInformation|`
		Set-Content -path C:\users\public\diskspace.xml
		$query = "if exists(select * from tempdb.dbo.sysobjects where ID = object_id(N'tempdb..#tbl_XMLDisk'))
			   BEGIN
			   DROP TABLE #tbl_XMLDisk
			   END
			   CREATE TABLE #tbl_XMLDisk
			  (
				XMLData XML,
			  )

 
			  INSERT INTO #tbl_XMLDisk(XMLData)
			  SELECT 
			  CONVERT(XML, BulkColumn) AS BulkColumn
			  FROM 
			  OPENROWSET(BULK 'C:\users\public\diskspace.xml', SINGLE_BLOB) AS x;

		
 			  if exists(select * from tempdb.dbo.sysobjects where ID = object_id(N'tempdb..#ITS_DiskSpace'))
			  BEGIN
			  DROP TABLE #ITS_DiskSpace
			  END
			  create table #ITS_DiskSpace
			 (
	  		   DeviceID nvarchar(128),
	 		   Free_space int
			 )


 			 insert into #ITS_DiskSpace
			 SELECT 

			 p.value('(./Property)[1]', 'VARCHAR(30)') AS DeviceID,
	
			 p.value('(./Property)[2]', 'decimal') AS [Free Size]
	 		 FROM #tbl_XMLDisk 
    			 CROSS APPLY XMLData.nodes('/Objects/Object') t(p)
			 select DeviceID,Free_space from #ITS_DiskSpace where Free_space in(select MAX(Free_space) from #ITS_DiskSpace)"
			$result = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database tempdb -Query $query
		
	}
          catch
	  {
	    $ErrorActionPreference = "SilentlyContinue"
	    $exception = "Could not fetch the details of the disk with maximum free diskspace"
	    "Could not fetch the details of the disk with maximum Free Diskspace">>$LogFolder2
           write-host "$exception"
	  }
          
           foreach($res in $result)
	{
	   $resw = $result.DeviceID
	   $resx = $result.Free_space
	   write-host "Maximum disk-space is on $resw Drive..."
		write-host $resw
	   "Disk Drive $resw is found with maximum FreeDiskSpace...">>$LogFolder2
	}
###############Database Count#################
$query0 = "SELECT COUNT(*) as dbcount FROM sys.databases" 
$result0 = Invoke-Sqlcmd -ServerInstance $DBServerInstanceName -Database master -query $query0
 foreach($res in $result0)
 {
  $DbCount = $result0.dbcount
  write-host "Database Count is:$DbCount"
 }
###################Total User Database Size##################        
$query1 = "select
'server' = @@servername
, 'Totaldbsize'= convert(decimal(10,2),(sum(size * 8.00) / 1024.00 )) 
 from
sys.master_files where database_id > 4"
$result1 = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database master -Query $query1
	
if($DbCount -eq "4")
  {
   $Totaldb_size = "0"
   write-host "Total user database size is: $Totaldb_size"
   Services
 #write-host "EXIT 0"
 #"EXIT 0" >>$LogFolder2
  }
else
{	
foreach($res in $result1)
{

    $Totaldb_size = $result1.Totaldbsize
   write-host "Total user database size is: $Totaldb_size"
 }
}
    
	
if($resx -gt $Totaldb_size)
{
   write-host "Disk Space size is: $resx"
   "Disk Space size is: $resx">>$LogFolder2
	"  ">>$LogFolder2
   write-host "Total User Db Size is: $Totaldb_size"
   "Total User Db Size is: $Totaldb_size">>$LogFolder2
   "$resw Drive has got maximum diskspace size and size of this disk is greater than Total userdb size!!">>$LogFolder2
	"  ">>$LogFolder2


  write-host "Success"
  write-host "Success:"
 [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
 [System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null

 $s = New-Object ('Microsoft.SqlServer.Management.Smo.Server') 

 $connectionString ="Data Source=$s;Integrated Security=true;Initial Catalog=master;Connect Timeout=3;"
 $sqlConn = new-object ("Data.SqlClient.SqlConnection") $connectionString
 $query = "select name as DatabaseName from sys.databases where database_id>4"

  
   $connectionString = "Data Source=$ServerName; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog = 'master'"
  	   try
           {    
		 foreach($inst in $instances)
                {
                 write-host "Success.."
                  if($InstanceName -eq "MSSQLSERVER")
                 {
                    $DBServerInstanceName = $ServerName
                    write-host "InstanceName is:$DBServerInstanceName"
                 }elseif($InstanceName -ne "MSSQLSERVER")
                 {
                  $DBServerInstanceName = $ServerName+'\'+$InstanceName
                  write-host "InstanceName is:$DBServerInstanceName"
                 }
               }
                Function UnEncrypted()
		{
		  write-host "Success"
	     	 $query = "select name as DatabaseName from sys.databases where state_desc <>'OFFLINE' and name not in('tempdb','master','model','msdb')"
		 $da1 = New-Object System.Data.SqlClient.SqlDataAdapter ($query, $connectionString)
		 $dt1 = New-Object System.Data.DataTable
		 $da1.fill($dt1)
		 foreach($Row in $dt1.Rows)
		 {
		  $db = $Row[0]
		  write-host $db
	          $query = "select name, is_encrypted FROM SYS.DATABASES where name = '$db' and is_encrypted = '0' and state_desc <>'OFFLINE' "
		  $result = invoke-sqlcmd -ServerInstance $DBServerInstanceName  -Database  "master" -query $query
		   foreach($res in $result)
		   {
		     
			  $BackupDir = "$resw"+"\BackupUserDb"
		           if(!(test-path $BackupDir))
	                   {
		            New-Item -ItemType Directory -Force -Path  $BackupDir
	                   }
			   $Bkp = $BackupDir + "\" + $DBServerInstanceName
			   if(!(test-path $Bkp))
	                   {
		            New-Item -ItemType Directory -Force -Path  $Bkp
	                   }
			    $Bkp = $BackupDir + "\" + $DBServerInstanceName + "\" + "ALLDB_Backup_BeforeInstanceDecommission"
			   
			    if(!(test-path $Bkp))
	                    {
		             New-Item -ItemType Directory -Force -Path  $Bkp
	                    }
			    $Bkp = $BackupDir + "\" + $DBServerInstanceName + "\" + "ALLDB_Backup_BeforeInstanceDecommission"+"\"+"UnEncrypted"
			    if(!(test-path $Bkp))
	                    {
		              New-Item -ItemType Directory -Force -Path  $Bkp
	                    }
	
	
         		 "######################################################################################################################">>$LogFolder2
         		      write-host "Default Source Backup Folder is: $Bkp" 
			      "$db is UnEncrypted Database">>$LogFolder2
			   "  ">>$LogFolder2
			     "Backup to the Backup Directory is in Progress">>$LogFolder2
                             "Please find the Backup of $db at the path:$Bkp">>$LogFolder2
			    "  ">>$LogFolder2
			    $ErrorActionPreference = "SilentlyContinue"
	 		    $BackupSql = "backup database "+$db+" to disk = '"+$Bkp+"\"+"$db"+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK' with copy_only"
				$ErrorActionPreference = "SilentlyContinue"
			    Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database $Db -Query $BackupSql
		     }
		  }
		}
				Function Encrypted()
				{
		  		   write-host "Success"
	     	 		   $query = "select name as DatabaseName from sys.databases where state_desc <>'OFFLINE' and name not in('tempdb')"
		 		   $da1 = New-Object System.Data.SqlClient.SqlDataAdapter ($query,$connectionString)
		 		   $dt1 = New-Object System.Data.DataTable
		 		   $da1.fill($dt1)
				   foreach($Row in $dt1.Rows)
				   {
		  		    $db = $Row[0]
		  		    write-host $db
	          		    $query = "select name, is_encrypted FROM SYS.DATABASES where name = '$db' and is_encrypted = '1' and state_desc <>'OFFLINE'and name not in('tempdb')"
		  		    $result = invoke-sqlcmd -ServerInstance $DBServerInstanceName  -Database  "master" -query $query
		                    foreach($res in $result)
		                    {
				   $BackupDir = "$resw"+"\BackupUserDb"
		           	   if(!(test-path $BackupDir))
	                   	   {
		            	    New-Item -ItemType Directory -Force -Path  $BackupDir
	                   	   }
			            
			              $Bkp = $BackupDir + "\" + $DBServerInstanceName + "\" + "ALLDB_Backup_BeforeInstanceDecommission"
			             if(!(test-path $Bkp))
	                             {
		                     New-Item -ItemType Directory -Force -Path  $Bkp
	                             }
			             
			            $Bkp = $BackupDir + "\" + $DBServerInstanceName + "\" + "ALLDB_Backup_BeforeInstanceDecommission"+"\"+"Encrypted"
			            if(!(test-path $Bkp))
	                            {
		                      New-Item -ItemType Directory -Force -Path  $Bkp
	                            }
				    $Bkp = $BackupDir + "\" + $DBServerInstanceName + "\" + "ALLDB_Backup_BeforeInstanceDecommission"+"\"+"Encrypted"+"\$db"
			            if(!(test-path $Bkp))
	                            {
		                      New-Item -ItemType Directory -Force -Path  $Bkp
	                            }
	
	
         		  
         		           "######################################################################################################################">>$LogFolder2
         		      write-host "Backup Folder is: $Bkp" 
			      "$db is Encrypted Database">>$LogFolder2
			   "  ">>$LogFolder2
			     "Backup to the Backup Directory is in Progress">>$LogFolder2
                             "Please find the Backup of $db at the path:$Bkp">>$LogFolder2
			    "  ">>$LogFolder2
			  
			            $ErrorActionPreference = "SilentlyContinue"
	 		            $BackupSql = "backup database "+$db+" to disk = '"+$Bkp+"\"+"$db"+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK' with copy_only"				  
				    $ErrorActionPreference = "SilentlyContinue"
			            $result = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database "master" -Query $BackupSql
				    
				    $query1 = "select database_name = d.name,dek.encryptor_type,cert_name = c.name from sys.dm_database_encryption_keys dek
                                              left join sys.certificates c
                                              on dek.encryptor_thumbprint = c.thumbprint
                                              inner join sys.databases d
                                              on dek.database_id = d.database_id where dek.database_id > '4';"
					$ErrorActionPreference = "SilentlyContinue"						  
				    $result1 = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database "master" -Query $query1
				    foreach($res in $result1)
				    {  
					write-host "success"
					$db_name = $res.database_name
	    				write-host $db_name
			                write-host $db
					$Certificate = $res.cert_name
					write-host "Certificate name is:$Certificate"
				        if($Certificate -ne $null)
				     	{
        				 write-host "Success"
					   "Backup of $db_name Certificate to the default Backup Directory is in Progress">>$LogFolder2
					 $ErrorActionPreference = "SilentlyContinue"
				         $query = "BACKUP CERTIFICATE "+$Certificate+" TO FILE = '"+$Bkp+"\"+"$db_name"+"_"+(Get-Date -Format "yyyyMMdd")+".certbak'"
				         $result = Invoke-SqlCmd -ServerInstance $DBServerInstanceName -Database "master" -Query $query
					}
				      
				  }
			     }
			   }
			}
		
		UnEncrypted
		Encrypted 
      
           }
            catch
            {
             $ex = $_.Exception
             write-host "Exception is:$ex!"
               write-host "  "
		write-host "  "

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		$EETime = Get-date
		write-host "Execution End Time is: $EETime"
		"Execution End Time is: $EETime">>$LogFolder2

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		write-host "  "
		write-host "  "
		write-host "EXIT 1"
 		"EXIT 1">>$LogFolder2

 		EXIT 1
            }

}
if($resx -lt $Totaldb_size)
{
 write-host "Disk-space is not sufficient for backup of user databases to $resw Drive!"
"Disk-space is not sufficient for backup of user databases to $resw Drive!">>$LogFolder2
"EXIT 1">>$LogFolder2
 EXIT 1
}

write-host "################################################################################################"
"##################################################################################################">>$LogFolder2
$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -notcontains $InstanceName)
{
Write-Host ""
Write-Host "Instance $InstanceName not found. Pass a valid instance name" -f red
Write-Host ""
Exit 1
}
   $p2= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName

   $ver2 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").Version
   $build2 = $ver2.substring(0,2)

Function BackupDBs
{

    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | Out-Null

    $Time2 = get-date -Uformat "%Y%m%d%H%M"


#--------- First backup System DBs (master, Model, MSDB, SystemResource) ------------

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName
$BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
$SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot

$SysBkp = $BackupDir + "\"
$SysBkp = $SysBkp + "$DBServerInstanceName"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
  
 }

$SysBkp = $SysBkp+ "\System_Backup"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
 }

$SysBkp = $SysBkp + "\BeforeInstance_Decommission" + "_"+"$Time2"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
 }
<#
$SysBkp = $SysBkp + "_"+"$Time2"
#>

IF ($InstanceName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

ELSEIF($InstanceName -ne "MSSQLSERVER")

{
 $SQLSvcAcct = 'MSSQL$' + $InstanceName
 $SQLAgtAcct = 'SQLAgent$' + $InstanceName
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

$error.clear()

if ($error[0])
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host "Cold backup of System DBs failed. Cannot proceed with Decommission. Exiting..." -f red
    "Cold backup of System DBs failed. Cannot proceed with Decommission. Exiting...">>$LogFolder2

	write-host "  "
	write-host "  "

	"  ">>$LogFolder2
	"  ">>$LogFolder2
	$EETime = Get-date
	write-host "Execution End Time is: $EETime"
	"Execution End Time is: $EETime">>$LogFolder2

	"  ">>$LogFolder2
	"  ">>$LogFolder2
	write-host "  "
	write-host "  "
	write-host "EXIT 1"
 	"EXIT 1">>$LogFolder2

 	EXIT 1
}
ELSE
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Success" -f green


	
	$ArchiveFolder = $SysBkp + "\ArchivedBeforeDecommission_$Time2"

	If (Test-Path $ArchiveFolder)
	{
	Remove-Item $ArchiveFolder + "BeforeInstance_Decommission\*" -recurse
	}

	mkdir $ArchiveFolder
 
}
IF ($build2 -eq "13")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL13.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($build2 -eq "12")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($build2 -eq "11")
{

	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL11.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}
ELSEIF ($build2 -eq "10")
{

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

}
ELSEIF ($build2 -eq "9")
{

	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
}

	Rename-Item $ArchiveFolder\master.mdf master.mmm
	Rename-Item $ArchiveFolder\model.mdf model.mmm
	Rename-Item $ArchiveFolder\MSDBData.mdf MSDBData.mmm
	Rename-Item $ArchiveFolder\mastlog.ldf mastlog.lll
	Rename-Item $ArchiveFolder\modellog.ldf modellog.lll
	Rename-Item $ArchiveFolder\MSDBLog.ldf MSDBLog.lll


if ($error[0])
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host ""
	Write-Host "Cannot proceed further with Decommission. Exiting out... " -f red
    "Cold backup of system databases to $ArchiveFolder : ">>$LogFolder2
    "Cannot proceed further with Decommission. Exiting out... ">>$LogFolder2
	
	write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 1"
 "EXIT 1">>$LogFolder2

 EXIT 1

}
ELSE
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Success" -f green
	"Cold backup of system databases to ArchiveFolder is Successfull ">>$LogFolder2
	"Please find the Cold backup of System DBs at the location:$ArchiveFolder">>$LogFolder2 
	
}
<#

Write-Host "-------"
#"-------" >> $Log_Bkp
$error.clear()
IF ($InstanceName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $InstanceName
 $SQLAgtAcct = 'SQLAgent$' + $InstanceName
}
"Starting the SQL Server Services and AGENT">>$LogFolder2
 write-host "Starting the SQL Server Services and AGENT" -F GREEN
 net start $SQLSvcAcct
 net start $SQLAgtAcct
 Start-Service -Name $SQLAgtAcct
 Start-Service -Name $SQLSvcAcct
"####################################################################################################">>$LogFolder2
 "Sql Server Agent Account is been started...">>$LogFolder2
 "Sql Server Service Account is been started...">>$LogFolder2
"$EXIT 0">>$LogFolder2

if ($error[0])
{
	Write-Host ""
	#Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "FAILED" -f red -nonewline; Write-Host " Try again." >> $LogFolder2
	$error.clear()
	EXIT 0
}
ELSE
{
	Write-Host ""
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	#"Start SQL Server Services: Success" >> $LogFolder2
}

#>
}

#-------------------------------- PERFORM A COLD BACKUP of SYSTEM DATABASES --------------------------------

BackupDBs




               Function Services()
               {
		$stop = 'Y'
		IF ($InstanceName -eq "MSSQLSERVER")
		{
		  #Read-Host "Do you want the services to be stopped?("Enter ''Y'' if 'Yes' else ''N'' if 'No'")"
                  if($stop -eq 'Y')
	         {

		  try
		  {
		  "Stopping the Services and SQLAGENT...">>$LogFolder2
		   write-host "Stopping the Services and SQLAGENT..."
 		   $SQLSvcAcct = 'MSSQLSERVER'
 		   $SQLAgtAcct = 'SQLSERVERAGENT'
 		   Stop-Service -Name $SQLAgtAcct
 		   Stop-Service -Name $SQLSvcAcct -force
	"###########################################################################################################################">>$LogFolder2
        "SQL Server service account is been stopped">>$LogFolder2
        "SQL Server agent account is been stopped">>$LogFolder2
         write-host "SQL Server service account is been stopped" -F Green
	 write-host "SQL Server agent account is been stopped" -F Green

        write-host "#################################################################################"
	write-host
	write-host
        write-host "cTaskname : Pre-CoolDown Implementation,"
        write-host "status :success,"
        write-host "message:  Added database to blackout and shut down complete for database $DatabaseName on host $ServerName,"
        write-host "cTaskorder:300" 
		
	"cTaskname : Pre-CoolDown Implementation,
         status :  success,
         message:  Added database to blackout and shut down complete for database $DatabaseName on host $ServerName ,
         cTaskorder: 300" >> $LogFolder2
              EXIT 0
		}
		catch
		{
                  $ex = $_.Exception
		  write-host "Exception is:$ex"
		 write-host "  "
		write-host "  "

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		$EETime = Get-date
		write-host "Execution End Time is: $EETime"
		"Execution End Time is: $EETime">>$LogFolder2

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		write-host "  "
		write-host "  "
		write-host "EXIT 1"
 		"EXIT 1">>$LogFolder2

 		EXIT 1
		}
                  
		
		}elseif($stop -eq 'N')
		{
                  "SQL Service and Agent are not stopped.">>$LogFolder2
		 write-host "SQL Service and Agent are not stopped."
	          EXIT  0
		}

		
	       }

		ELSE

		{
	         #$stop = Read-Host "Do you want the services to be stopped?("Enter ''Y'' if 'Yes' else ''N'' if 'No'")"
                  if($stop = 'Y')
	         {
 		  $SQLSvcAcct = 'MSSQL$' + $InstanceName
 		  $SQLAgtAcct = 'SQLAgent$' + $InstanceName
 		  Stop-Service -Name $SQLAgtAcct
 		  Stop-Service -Name $SQLSvcAcct -force
	"###########################################################################################################################">>$LogFolder2
         "SQL Server service account is been stopped">>$LogFolder2
         "SQL Server agent account is been stopped">>$LogFolder2
          "EXIT 0">>$LogFolder2
	 write-host "EXIT 0"

        write-host "#################################################################################"
	write-host
	write-host
        write-host "cTaskname : Pre-CoolDown Implementation,"
        write-host "status :success,"
        write-host "message:  Added database to blackout and shut down complete for database $DatabaseName on host $ServerName,"
        write-host "cTaskorder:300" 
	
	"cTaskname : Pre-CoolDown Implementation,
         status :  success,
         message:  Added database to blackout and shut down complete for database $DatabaseName on host $ServerName ,
         cTaskorder: 300" >> $LogFolder2
	         EXIT 0
		}elseif($stop -eq 'N')
		{
                  "SQL Service and Agent are not stopped.">>$LogFolder2
		 write-host "SQL Service and Agent are not stopped."
	       EXIT 0
		}
		}
}
Services

<#
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2
#>	 
}


PreCoolDownImplementation
}elseif($CTaskOrder -eq '2')
{
 Function PostCoolDownImplementation()
{
 $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -notcontains $InstanceName)
{
Write-Host ""
Write-Host "Instance $InstanceName not found. $InstanceName decommissioned successfully" -f red
Write-Host ""
"Instance $InstanceName not found. $InstanceName decommissioned successfully" >>$LogFolder2
Exit 0
}
   $p2= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName

   $ver2 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").Version
   $build2 = $ver2.substring(0,2)

Function BackupDBs
{

    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | Out-Null

    $Time2 = get-date -Uformat "%Y%m%d%H%M"


#--------- First backup System DBs (master, Model, MSDB, SystemResource) ------------

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName
$BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
$SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot

$SysBkp = $BackupDir + "\"
$SysBkp = $SysBkp + "$DBServerInstanceName"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
  
 }

$SysBkp = $SysBkp+ "\System_Backup"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
 }

$SysBkp = $SysBkp + "\BeforeInstance_Decommission" + "_"+"$Time2"
 if(!(test-path $SysBkp))
 {
  New-Item -ItemType Directory -Force -Path  $SysBkp
 }
<#
$SysBkp = $SysBkp + "_"+"$Time2"
#>

IF ($InstanceName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

ELSEIF($InstanceName -ne "MSSQLSERVER")

{
 $SQLSvcAcct = 'MSSQL$' + $InstanceName
 $SQLAgtAcct = 'SQLAgent$' + $InstanceName
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

$error.clear()

if ($error[0])
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host "Cold backup of System DBs failed. Cannot proceed with Decommission. Exiting..." -f red
    "Cold backup of System DBs failed. Cannot proceed with Decommission. Exiting...">>$LogFolder2

	write-host "  "
	write-host "  "

	"  ">>$LogFolder2
	"  ">>$LogFolder2
	$EETime = Get-date
	write-host "Execution End Time is: $EETime"
	"Execution End Time is: $EETime">>$LogFolder2

	"  ">>$LogFolder2
	"  ">>$LogFolder2
	write-host "  "
	write-host "  "
	write-host "EXIT 1"
 	"EXIT 1">>$LogFolder2

 	EXIT 1
}
ELSE
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Success" -f green


	
	$ArchiveFolder = $SysBkp + "\ArchivedBeforeDecommission_$Time2"

	If (Test-Path $ArchiveFolder)
	{
	Remove-Item $ArchiveFolder + "BeforeInstance_Decommission\*" -recurse
	}

	mkdir $ArchiveFolder
 
}
IF ($build2 -eq "13")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL13.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($build2 -eq "12")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($build2 -eq "11")
{

	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL11.$InstanceName\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}
ELSEIF ($build2 -eq "10")
{

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

}
ELSEIF ($build2 -eq "9")
{

	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
}

	Rename-Item $ArchiveFolder\master.mdf master.mmm
	Rename-Item $ArchiveFolder\model.mdf model.mmm
	Rename-Item $ArchiveFolder\MSDBData.mdf MSDBData.mmm
	Rename-Item $ArchiveFolder\mastlog.ldf mastlog.lll
	Rename-Item $ArchiveFolder\modellog.ldf modellog.lll
	Rename-Item $ArchiveFolder\MSDBLog.ldf MSDBLog.lll


if ($error[0])
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host ""
	Write-Host "Cannot proceed further with Decommission. Exiting out... " -f red
    "Cold backup of system databases to $ArchiveFolder : ">>$LogFolder2
    "Cannot proceed further with Decommission. Exiting out... ">>$LogFolder2
	
	write-host "  "
write-host "  "

"  ">>$LogFolder2
"  ">>$LogFolder2
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

"  ">>$LogFolder2
"  ">>$LogFolder2
write-host "  "
write-host "  "
write-host "EXIT 1"
 "EXIT 1">>$LogFolder2

 EXIT 1

}
ELSE
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Success" -f green
	"Cold backup of system databases to ArchiveFolder is Successfull ">>$LogFolder2
	"Please find the Cold backup of System DBs at the location:$ArchiveFolder">>$LogFolder2 
	
}


Write-Host "-------"
#"-------" >> $Log_Bkp
$error.clear()
IF ($InstanceName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $InstanceName
 $SQLAgtAcct = 'SQLAgent$' + $InstanceName
}
"Starting the SQL Server Services and AGENT">>$LogFolder2
 write-host "Starting the SQL Server Services and AGENT" -F GREEN
 net start $SQLSvcAcct
 net start $SQLAgtAcct
 Start-Service -Name $SQLAgtAcct
 Start-Service -Name $SQLSvcAcct
"####################################################################################################">>$LogFolder2
 "Sql Server Agent Account is been started...">>$LogFolder2
 "Sql Server Service Account is been started...">>$LogFolder2
"$EXIT 0">>$LogFolder2

if ($error[0])
{
	Write-Host ""
	#Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "FAILED" -f red -nonewline; Write-Host " Try again." >> $LogFolder2
	$error.clear()
	EXIT 0
}
ELSE
{
	Write-Host ""
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	#"Start SQL Server Services: Success" >> $LogFolder2
}


}

#-------------------------------- PERFORM A COLD BACKUP of SYSTEM DATABASES --------------------------------

#BackupDBs

IF ($InstanceName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
}

ELSE

{
a $SQLSvcAcct = 'MSSQL$' + $InstanceName
 $SQLAgtAcct = 'SQLAgent$' + $InstanceName
}
"Starting the SQL Server Services and AGENT">>$LogFolder2
 write-host "Starting the SQL Server Services and AGENT" -F GREEN
 net start $SQLSvcAcct
 net start $SQLAgtAcct
 Start-Service -Name $SQLAgtAcct
 Start-Service -Name $SQLSvcAcct
"####################################################################################################">>$LogFolder2
 "Sql Server Agent Account is been started...">>$LogFolder2
 "Sql Server Service Account is been started...">>$LogFolder2
"$EXIT 0">>$LogFolder2

if ($error[0])
{
	Write-Host ""
	#Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "FAILED" -f red -nonewline; Write-Host " Try again." >> $LogFolder2
	$error.clear()
	EXIT 0
}
ELSE
{
	Write-Host ""
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	#"Start SQL Server Services: Success" >> $LogFolder2
}



"Instance is Ready for Decommission">>$LogFolder2

write-host "Instance is Ready for Decommission..." -f Red

#$Decommission = Read-host "Would you like to proceed?("Enter 'Y' if yes or 'N' if no")"
$p2= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstanceName
 $version = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").Version
write-host $version
$Decommission = "Y"
$Build = $version.substring(0,2)
write-host $Build
 $Action = '/ACTION="unInstall"'
write-host "$Action" -f green
 $Ind = '/INDICATEPROGRESS="TRUE"'
 $Features = '/FEATURES=SQLENGINE,REPLICATION'
 $InstParam = '/INSTANCENAME='+"$InstanceName"
 write-host " $InstParam" -F Green
 $Quiet = '/Quiet'
if($Decommission -eq 'Y')
{ 

try
{
 if($Build -eq "9")
 {
    #$ver = "SQL2005"
    & "C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\SQLServer2005\Setup.exe" $Action $Ind $Features $InstParam $Quiet | out-null
 }
 elseif($Build -eq "10")
 {
   	
    & "C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\SQLServer2008\Setup.exe" $Action $Ind $Features $InstParam $Quiet | out-null
 }
 elseif($Build -eq "11")
 {
  #$ver = "SQL2012"
  & "C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\SQLServer2012\Setup.exe" $Action $Ind $Features $InstParam $Quiet | out-null

 }
 elseif($Build -eq "12")
 { 
   #$ver = "$SQL2014"
   & "C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\SQLServer2014\Setup.exe" $Action $Ind $Features $InstParam $Quiet | out-null
  
 }
 elseif($Build -eq "13")
 { 
   #$ver = "$SQL2016"
   & "C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\SQLServer2016\Setup.exe" $Action $Ind $Features $InstParam $Quiet | out-null
  
 }
 "Instance $InstanceName is decommissioned!">>$LogFolder2
 Uninstall


}
catch
{
 $ex = "Uninstallation Failed"
 write-host "Could not Uninstall Successfully" -f red
 $ex = $_.Exception
		  write-host "Exception is:$ex"
		 write-host "  "
		write-host "  "

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		$EETime = Get-date
		write-host "Execution End Time is: $EETime"
		"Execution End Time is: $EETime">>$LogFolder2

		"  ">>$LogFolder2
		"  ">>$LogFolder2
		write-host "  "
		write-host "  "
		write-host "EXIT 1"
 		"EXIT 1">>$LogFolder2

 		EXIT 1
 
}

}
if($Decommission -eq 'N')
{
 EXIT 0
}
##################PostImplementation Verification started##################
write-host
write-host
"  ">>$LogFolder2
"  ">>$LogFolder2
$serviceName = 'mssqlserver'
$IQOQOutput = "C:\IQOQ\Decommission_Status.txt"
write-host "Scanning the service name $serviceName from the list of Services..." -f Green
write-host
write-host "Please wait until the process is complete.." -f Yellow

Start-Sleep -s 15

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

        write-host

	"  ">>$LogFolder2
	"  ">>$LogFolder2
        Write-Host "Service $serviceName is present and is running." -f Green
	write-host
        "Service $serviceName is present and is running.">>$LogFolder2
	write-host
	"  ">>$LogFolder2
        Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "FAILED" -f red
	"  ">>$LogFolder2
	"UnInstallation of instance $InstanceName :FAILED ">>$LogFolder2
	EXIT 1
	EXIT $LastExitCode
    } Else {

             Write-Host "$serviceName found, but it is not running."
		 "$serviceName found, but it is not running." >>$LogFolder2
		EXIT 1
		EXIT $LastExitCode

    }

} Else {
	

    write-host
    "  ">>$LogFolder2
    Write-Host "$serviceName not found"
    "$serviceName not found" >> $LogFolder2
    Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "SUCCESS" -f red
    write-host
    "  ">>$LogFolder2
   "UnInstallation of instance $InstanceName :SUCCESS " >> $LogFolder2
    "UnInstallation of instance $InstanceName :SUCCESS " >>$IQOQOutput
EXIT 0 
EXIT $LastExitCode
}


}
PostCoolDownImplementation
}
<#elseif($CDPeriod -eq '3')
{
##################PostImplementation Verification started##################
write-host
write-host
"  ">>$LogFolder2
"  ">>$LogFolder2
$serviceName = 'mssqlserver'
$IQOQOutput = "C:\IQOQ\Decommission_Status.txt"
write-host "Scanning the service name $serviceName from the list of Services..." -f Green
write-host
write-host "Please wait until the process is complete.." -f Yellow

Start-Sleep -s 15

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

        write-host

	"  ">>$LogFolder2
	"  ">>$LogFolder2
        Write-Host "Service $serviceName is present and is running." -f Green
	write-host
        "Service $serviceName is present and is running.">>$LogFolder2
	write-host
	"  ">>$LogFolder2
        Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "FAILED" -f red
	"  ">>$LogFolder2
	"UnInstallation of instance $InstanceName :FAILED ">>$LogFolder2
    } Else {

             Write-Host "$serviceName found, but it is not running."
		 "$serviceName found, but it is not running." >>$LogFolder2

    }

} Else {
	

    write-host
    "  ">>$LogFolder2
    Write-Host "$serviceName not found"
    "$serviceName not found" >> $LogFolder2
    Write-Host "UnInstallation of instance $InstanceName : " -f white -nonewline; Write-Host "SUCCESS" -f red
    write-host
    "  ">>$LogFolder2
   "UnInstallation of instance $InstanceName :SUCCESS " >> $LogFolder2
    "UnInstallation of instance $InstanceName :SUCCESS " >>$IQOQOutput
}

}
#>




write-host
write-host
$EETime = Get-date
write-host "Execution End Time is: $EETime"
"Execution End Time is: $EETime">>$LogFolder2

  "EXIT 0">>$LogFolder2
                  EXIT 0
		write-host "EXIT 0"










