###################################################################################################
$ScriptName = "sddc_sql_SQLInstallBatchScript.PS1"
$Scriptver = "10.0"
#Description: Description: Execute all the scripts related to SQL provisioning in one batch 
###################################################################################################
#Version		Date		Author		             Reason for Change
###################################################################################################
#1.0			09/10/2014	Atul Patil	             New Script
#2.0			11/24/2014	Jay Sangam	             Provision for named instance installs
#3.0			Feb/10/2016	Jay Sangam	             Provision for SP aware installs
#4.0                    Jan/19/2017	Saketh Valluripalli          Provisioning of SQL 2014 and additional parameter SP3CU11.0.6567 for SQL2012 builds
#5.0                    Dec/02/2017	Kishore Kumar          Provisioning of SQL 2014 SP2 with security patch with additional parameter SP4CU12.0.5557.0 and SQL2012
#SP4 
#6.0                    Jun/25/2018     Kavya/Kishore          Added new license key for MSSQL2012 and MSSQL2014
                                                               #Added logic to exclude creating registry setting for TF1117 & TF1118 for SQL 2016 
                                                               #Added logic to include disabling CEIP in SQL 2016
                                                               #Added SP2 for SQL2016
                                                               #If STANDARD edition, if it is seen more than 4 SOCKETS raise an error(Commented out)   
#7.0 					Sept/2/2019		Sanjiv				#Adding 2017 Installation logic	and Baseline Performance framework 
#8.0 					FEB/26/2020		Sanjiv				#Adding 2019 Installation logic	
#9.0					APR/15/2021		Sanjiv				#Promoting SQL2019
#10.0					Feb/17/2023		Priyanka/Sunil			#Promotig TLM 2023
###################################################################################################


#*********** Lab DML************* 
$LabSQLDML= "\\na.jnj.com\nadfsroot\ncsus\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\"

#*********** NA DML*************

#$NASQLDML ='\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSDevelopment\new_one\'

$NASQLDML = "\\na.jnj.com\nadfsroot\ncsus\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\"	


#******************Identify server location based on IP address *****************

$Process = $args[0]
$Tier = $args[1]
$Env = $args[2]
$sqlversion = $args[3]
$SPVersion = $args[4]
$Edition = $args[5]
$strCollation = $args[6]
#$InstanceName = $args[7]Un-Comment later for named instance installations
$InstanceName = "MSSQLSERVER"	# Delete this line later for named instance installs.



#--------------------------------- Checking Parameters Values ---------------------------------#

IF (($Process -ne "SDDC") -and ($Process -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
EXIT 0
}

IF (($Tier -ne "Small") -and ($Tier -ne "Medium") -and ($Tier -ne "Large"))
{
Write-Host ""
Write-Host "Size not Valid. Please pass SMALL or MEDIUM or LARGE as 2nd parameter" -f red
Write-Host ""
EXIT 0
}

IF (($Env -ne "DEV") -and ($Env -ne "QA") -and ($Env -ne "PROD"))
{
Write-Host ""
Write-Host "Environment not Valid. Please pass DEV or QA or PROD as 3rd parameter" -f red
Write-Host ""
EXIT 0
}

IF (($sqlversion -ne "SQL2005") -and ($sqlversion -ne "SQL2008") -and ($sqlversion -ne "SQL2012") -and ($sqlversion -ne "SQL2014") -and ($sqlversion -ne "SQL2016") -and ($sqlversion -ne "SQL2017") -and ($sqlversion -ne "SQL2019") -and ($sqlversion -ne "SQL2022"))
{
Write-Host ""
Write-Host "Invalid SQLServer version. Please pass SQL2005 or SQL2008 or SQL2012 or SQL2014 or SQL2016 or SQL2017 or SQL2019 or SQL2022 as 4th parameter" -f red
Write-Host ""
EXIT 0
}

IF ($sqlversion -eq "SQL2005")
{
 IF (($SPVersion -ne "SP3") -and ($SPVersion -ne "SP4"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2005. Please pass SP3 or SP4 as 5th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2008")
{
 IF (($SPackVer -ne "SP3") -and ($SPackVer -ne "SP4") -and ($SPackVer -ne "SP4_10.00.6556"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2008. Please pass SP3 or SP4 or SP4_10.00.6556 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2012")
{
 IF (($SPackVer -ne "SP2") -and ($SPackVer -ne "SP3") -and ($SPackVer -ne "SP3CU11.0.6567") -and ($SPackVer -ne "SP4") -and ($SPackVer -ne "SP4_11.0.7462"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2012. Please pass SP2 or SP3 or SP3CU11.0.6567 or SP4 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2014")
{
 IF (($SPackVer -ne "SP2") -and ($SPackVer -ne "SP2_12.0.5557") -and ($SPackVer -ne "SP2_12.0.5589") -and ($SPackVer -ne "SP3_12.0.6329"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2014. Please pass SP2 or SP2_12.0.5557 or SP2_12.0.5589 or SP3_12.0.6329 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlversion -eq "SQL2016")
{
 IF (($SPVersion -ne "SP1") -and ($SPVersion -ne "SP2") -and ($SPVersion -ne "SP2_13.0.5201") -and ($SPVersion -ne "SP2_13.0.5426") -and ($SPVersion -ne "SP2_13.0.5830") -and ($SPVersion -ne "CU17") -and ($SPVersion -ne "SP3") -and ($SPVersion -ne "SP3_13.0.6419"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2016. Please pass SP1 or SP2 or SP3 or SP3_13.0.6419 as 5th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
 ELSEIF ($sqlversion -eq "SQL2017")
{
 IF (($SPVersion -ne "RTM") -and ($SPVersion -ne "CU16") -and ($SPVersion -ne "CU21")-and ($SPVersion -ne "CU25") -and ($SPVersion -ne "CU29"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2017. Please pass RTM or CU16 or CU21 or CU25 or CU29 as 5th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlversion -eq "SQL2019")
{
 IF (($SPVersion -ne "RTM") -and ($SPVersion -ne "CU12") -and ($SPVersion -ne "CU17"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2019. Please pass RTM or CU12 or CU17 as 5th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($sqlversion -eq "SQL2022")
{
 IF (($SPVersion -ne "RTM"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2022. Please pass RTM as 5th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}

IF (($Edition -ne "E") -and ($Edition -ne "S"))
{
Write-Host ""
Write-Host "Edition not Valid. Please pass either E or S as 6th parameter" -f red
Write-Host ""
EXIT 0
}

#------------------ Check if valid collation is being passed ------------------

$arrCollation = @("SQL_Latin1_General_CP1_CI_AS",
"Latin1_General_CI_AI",
"Latin1_General_CI_AS",
"Latin1_General_CI_AS_KS_WS",
"SQL_Latin1_General_CP850_CI_AI",
"Chinese_PRC_CI_AS",
"SQL_Latin1_General_CP1_CI_AI",
"SQL_Latin1_General_CP850_BIN2",
"Chinese_Taiwan_Stroke_CI_AS",
"SQL_Latin1_General_CP1_CS_AS",
"Cyrillic_General_CI_AS",
"Finnish_Swedish_CI_AS",
"Japanese_CI_AS",
"SQL_Czech_CP1250_CI_AS",
"Arabic_BIN",
"Czech_BIN",
"French_BIN",
"Latin1_General_CS_AS",
"SQL_Latin1_General_CP850_BIN",
"Thai_CI_AS",
"Finnish_Swedish_CS_AI",
"Hebrew_CI_AS",
"Japanese_CI_AI",
"Korean_Wansung_CI_AS",
"Latin1_General_CS_AI",
"Polish_CI_AS",
"SQL_1xCompat_CP850_CI_AS",
"SQL_Hungarian_CP1250_CS_AS",
"SQL_Slovak_CP1250_CI_AS" )

If ($arrCollation -notcontains $strCollation)

{
    Write-Host ""
    Write-Host "Please pass a valid collation name as 7th parameter" -f red
    Write-Host ""
    EXIT 0
}

#-----------------------------------------------------------------------




#	Un-comment later for named instance installs.
# IF($InstanceName -eq $null)
# {

#        Write-Host ""
#        Write-Host "Please pass instance name as 7th parameter" -f red
#        Write-Host ""

#	Exit 0
# }

IF (Test-Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')

{

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -ne $null)
{
 foreach ($inst in $instances)
 {
 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst

	IF($inst -eq 'MSSQLSERVER')
	{
		Write-Host ""
#		Write-host "Instance $InstanceName already exists. Please pass a different instance name"	Un-comment later for named instance installs.
		Write-host "Default instance $InstanceName already exists."					# Delete this line later for named instance installs.
		Write-Host ""  
        	Exit 0    
	}
 }
}

}
ELSE
{

#Fresh build

}

#-------------------------------- Install function ----------------------------------

FUNCTION Executeallscripts
{
Param(
       [string] $dmllocation,
       [string] $prc,
       [string] $tr,
       [string] $envr,
       [string] $sqlver,
       [string] $edtn,
       [string] $instnc,
       [string] $spver,
       [string] $collation
     )


$Time = get-date -Uformat "%Y%m%d%H%M"

IF (!(Test-Path C:\SQLInstall_Logs))
{
mkdir "C:\SQLInstall_Logs"
}
$BatchLog = "C:\SQLInstall_Logs\sddc_sql_SQLInstallBatchScript_$Time.txt"

Write-Host "###################################################################################################"
"###################################################################################################" > $BatchLog
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $BatchLog
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $BatchLog
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $BatchLog
Write-Host "Server Host: $ENV:computername"
"Server Host: $ENV:computername" >> $BatchLog
"Execution string: $ScriptName $prc $tr $envr $sqlver $spver $edtn $instnc $collation" >> $BatchLog
Write-Host "###################################################################################################"
"###################################################################################################" >> $BatchLog
"" >> $BatchLog


#----------------Execute O/S Verification------------------# 
$OSVerification = "$dmllocation" + 'sddc_sql_Pre-Req_OS_Verification.ps1'

powershell.exe -ExecutionPolicy Bypass $OSVerification $prc $tr $envr $sqlver

   $Script1 = (Get-Content "C:\IQOQ\Status.txt")

    If ($Script1 -ne "FAILED")
    {
    #----------------Execute SQL Installation------------------#
       "Script sddc_sql_Pre-Req_OS_Verification.ps1 : Executed successfully" >> $BatchLog
        $SQLInstallation = "$dmllocation" + 'SDDC_sql_InstallSQLServer.ps1'

       powershell.exe -ExecutionPolicy Bypass $SQLInstallation $prc $sqlver $edtn $spver $collation $instnc
      
       $Script2 = (Get-Content "C:\IQOQ\Status.txt")

      If ($Script2 -ne "FAILED")
        {
        #----------------Execute Post Installation------------------# 
          "Script SDDC_sql_InstallSQLServer.ps1 : Executed successfully" >> $BatchLog
           $SQLPostInstallation = "$dmllocation" + 'sddc_sql_Post_Installation.ps1'

           powershell.exe -ExecutionPolicy Bypass $SQLPostInstallation $prc $sqlver $instnc
        
	    
	    $Script3 = (Get-Content "C:\IQOQ\Status.txt")
            If ($Script3 -ne "FAILED")
            {
                #----------------Execute Post Verification------------------# 
                "Script sddc_sql_Post_Installation.ps1 : Executed successfully" >> $BatchLog                  
		If ($Process -eq "NON_SDDC")
		 {
		   $SQLInstallVerification = "$dmllocation" + 'sddc_sql_Post_Installation_Verification.ps1'

                   powershell.exe -ExecutionPolicy Bypass $SQLInstallVerification $sqlver $spver $instnc
		 	If ($Script2 -eq "REBOOT")
			{
			Write-Host "Please reboot the server"
			}
				$Script4 = (Get-Content "C:\IQOQ\Status.txt")
				If ($Script4 -ne "FAILED")
				 {
				    "Script sddc_sql_Post_Installation_Verification.ps1 : Executed successfully" >> $BatchLog
				 }
				 else
				 {
				    "Script sddc_sql_Post_Installation_Verification.ps1 : FAILED. View the log files and address the failed steps" >> $BatchLog
				 }
		 }
		Elseif ($Process -eq "SDDC")
		 {
		   $SQLInstallVerification = "$dmllocation" + 'sddc_sql_Post_Installation_Verification_SDDC.ps1'

                   powershell.exe -ExecutionPolicy Bypass $SQLInstallVerification $sqlver $envr $spver $instnc
		 	If ($Script2 -eq "REBOOT")
			{
			Write-Host "Please reboot the server"
			}
				$Script4 = (Get-Content "C:\IQOQ\Status.txt")
				If ($Script4 -ne "FAILED")
				 {
				    "Script sddc_sql_Post_Installation_Verification_SDDC.ps1 : Executed successfully" >> $BatchLog
				 }
				 else
				 {
				    "Script sddc_sql_Post_Installation_Verification_SDDC.ps1 : FAILED. View the log files and address the failed steps" >> $BatchLog
				 }
		 }
            }       
            Else 
            {
                Write-host "Error during Post Installation script sddc_sql_Post_Installation"
		"Script sddc_sql_Post_Installation.ps1 : Error during Post Installation script sddc_sql_Post_Installation" >> $BatchLog
            } 

	}              
       Else 
       {
        Write-host "Reboot required OR Error during SQL Installation"
	"Script sddc_sql_InstallSQLServer.ps1 : Reboot required OR Error during SQL Installation" >> $BatchLog
       }

    }
       Else 
       {
        #Write-host "Error during SQL Installation"
	Write-Host ""
        Write-host "Resolve the failed tasks and then run the script."
	Write-Host ""
	"Script sddc_sql_Pre-Req_OS_Verification.ps1 : Resolve the failed tasks and then run the script." >> $BatchLog 
       }
    
}

#------------------------------------- End of function -------------------------------------

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]  

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	$location = "on LAB Server"
	Executeallscripts $LabSQLDML $Process $Tier $Env $sqlversion $Edition $InstanceName $SPVersion $strCollation
 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 223)
 { 
	$location =  "on NA Server"
    	Executeallscripts $NASQLDML $Process $Tier $Env $sqlversion $Edition $InstanceName $SPVersion $strCollation
	
 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
 }
}

