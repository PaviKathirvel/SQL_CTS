#################################################################################################################################################################
# File                           : SQLServerAlwaysOnScript.ps1
# Description                    : This script will create SQL Server AG group based on the inputs provided by user and enroll the databses to newly created AG group.
# Logs                           : Defualt path C:\SQLInstallLogs_2012\AlwaysOn_<TimeStamp>.txt
# Example                        : C:\sqlalwayson\alwaysonsetup.ps1 -LnrName "ITSUSRASLSNR002" -LnrIP �10.38.70.218� -LnrSubnet �255.255.252.0� -MODE "SYNC" -DatabaseList "ALL"

#################################################################################################################################################################
#Version		Date		Author		Reason for Change
#################################################################################################################################################################
#1.0			23-Dec-2015	Jay Natarajan	          New Script
#2.0			14-Nov-2016	Jayasimha Sangam	  User to pass SYNC or ASYNC for the MODE parameter
#3.0			14-Apr-2017	Jayasimha Sangam          Added steps for Backup job validation and ReadOnly routing configuration

#################################################################################################################################################################

Param(
[string] $BackupPath,
[String] $AGName,
[String] $LnrName,
[String] $LnrIP,
[String] $LnrSubnet,
[String[]]$DatabaseList,
[string] $mode
)


IF (($mode -ne "SYNC") -and ($mode -ne "ASYNC"))
{
Write-Host ""
Write-Host "Pass SYNC or ASYNC as value for 'Mode' parameter"
Write-Host ""
EXIT
}



# Local Variables
#
[String]$ModuleLogFile = "C:\\SQLInstall_Logs\\AlwaysOn_Log_" + [System.DateTime]::Now.ToString("ddMMyyyyHHmm") + ".txt"
             if ((Test-Path $ModuleLogFile) -eq $false)
    {
                                New-Item $ModuleLogFile -type file | Out-Null
    }
   # else
   # {
   # Write-Output "The log file location is invalid. Please make sure the log file location exists" 
    #Write-Output "FINAL STATUS = FAILURE" -f red
    #break
    #}



# Function to log all activities to a text file.
# <para>$log</para> - Contains text that needs to be logged in file
#
function LogActivity([String]$log)
{
   
                
                 Add-Content $ModuleLogFile "`r`n$log" 
                
                 if ($log -match 'FAIL')
                 {
                   
                    $log | Write-Host -fore red  
                 }
                 elseif   ($log -match 'SUCCESS')
                 {
                    $log | Write-Host -fore  green  
                 }
                 else
                 {
                    $log | Write-Host 
                 }
}



function GetIpDetails([string[]]$ComputerName)
{
              
       
begin {}            
process {            
 foreach ($Computer in $ComputerName) {   
  if(Test-Connection -ComputerName $Computer -Count 1 -ea 0) {            
   try {            
    $Networks = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $Computer -EA Stop | ? {$_.IPEnabled}            
   } catch {            
        Write-Warning "Error occurred while querying $computer."            
        Continue            
   }      
   foreach ($Network in $Networks) {      
   
    $IPAddress  = $Network.IpAddress[0]            
    $SubnetMask  = $Network.IPSubnet[0]            
    $DefaultGateway = $Network.DefaultIPGateway            
    $DNSServers  = $Network.DNSServerSearchOrder            
    $IsDHCPEnabled = $false            
    If($network.DHCPEnabled) {            
     $IsDHCPEnabled = $true            
    }   
  
 
    if ($DNSServers)
    {
    $MACAddress  = $Network.MACAddress            
    $OutputObj  = New-Object -Type PSObject            
    $OutputObj | Add-Member -MemberType NoteProperty -Name ComputerName -Value $Computer.ToUpper()            
    $OutputObj | Add-Member -MemberType NoteProperty -Name IPAddress -Value $IPAddress            
    $OutputObj | Add-Member -MemberType NoteProperty -Name SubnetMask -Value $SubnetMask            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name Gateway -Value $DefaultGateway            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name IsDHCPEnabled -Value $IsDHCPEnabled            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name DNSServers -Value $DNSServers            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name MACAddress -Value $MACAddress            
    $OutputObj 
    }           
   }            
  }            
 }            
}            
            
end {}

}



if (!$DatabaseList)
{
    $DatabaseList = "ALL"
}




if (!$BackupPath)
{
    $BackupPath = $null
}


# Parameters
$clustername = get-cluster
#$PrimaryReplica = get-wmiobject -class win32_computersystem | select-object name
$PrimaryReplica = get-clustergroup -cluster $clustername -name "cluster Group"|select ownernode
$allnodes = get-clusternode | select-object name
$PrimaryReplica = $PrimaryReplica.ownernode.tostring()
[String]$SecondaryReplica = ($allnodes -notmatch $PrimaryReplica) | select-object -Expandproperty name

$PrimaryReplica1 = $PrimaryReplica
$SecondaryReplica1 = $SecondaryReplica

$PrimaryReplica = "tcp:$primaryreplica"
$SecondaryReplica = "tcp:$Secondaryreplica"


if (!$AGName)
{
    [String]$AGGroupName = $clustername.Name + "GRP"
}
else
{
    [String]$AGGroupName = $AGName
}



if (($LnrIP -and !$LnrSubnet) )
{

    LogActivity "Listener subnet is a required parameter when Listener IP is specified" 
    LogActivity "FINAL STATUS = FAILURE"
    break

}
if ((!$LnrIP -and $LnrSubnet) )
{

    LogActivity "Listener IP is a required parameter when Listener Subnet is specified" 
    LogActivity "FINAL STATUS = FAILURE"
    break

}

if (($LnrIP -or $LnrSubnet) -and (!$LnrName))
{

    LogActivity "Listener name is a required parameter when Listener IP and Listener Subnet is specified." 
    LogActivity "FINAL STATUS = FAILURE"
    break



}


if (!$LnrName)
{
    [String]$ListernerName = $clustername.Name + "LSNR"
}
else
{
    [String]$ListernerName = $LnrName
}


if (!$LnrIP -and !$LnrSubnet)
{
$lnrdetails = GetIpDetails $ListernerName

[String]$IpAddress = $lnrdetails.IPAddress
[String]$Subnet = $lnrdetails.Subnetmask
}
else
{
[String]$IpAddress = $LnrIp
[String]$Subnet = $LnrSubnet

}

if (!$IpAddress)
{

    LogActivity "The Listener name is invalid. Please validate that the DNS entry and make sure the Listener exists before proceeding." 
    LogActivity "FINAL STATUS = FAILURE"
    break


}



[String]$ListenerPort = "1433"
[String]$Port = "5022"
[string]$ReturnStatus = $false

   IF ($mode -eq "SYNC")
    {
	[string]$AsyncSecondary = $false
    }
   ELSE
    {
	[string]$AsyncSecondary = $true
    }


if (!$PrimaryReplica -or !$SecondaryReplica) 
{
    LogActivity "Invalid Cluster nodes. Please check the Cluster name" 
    LogActivity "FINAL STATUS = FAILURE"
    break
}



   if ($DatabaseList -eq "ALL")
   {
    $DBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
    }
    
   
     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name

    

       if (($DBList) -and ($DBinAG))
       {
        
        $errdb = Compare-Object -ReferenceObject $DBList  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }

    if ($DatabaseList -ne "ALL")
    {

    $PrimaryDBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name

    if ($PrimaryDBlist)
    {
        $errdbexists = Compare-Object -ReferenceObject $PrimaryDBlist  -DifferenceObject $DatabaseList -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject
        if ($errdbexists)
    {
        $errdb1 = $errdbexists.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }
     }  
     else
             
     {
        
                $errdb1 = $DatabaseList.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }

    }

#backup and restore databases


    if ($BackupPath)
    {
  
    $bkuppathexist = [System.IO.Directory]::Exists($backuppath)
   
    if (!$bkuppathexist)
    {
        LogActivity "Invalid Backup Path specified, please specifcy valid path and run the script again."
        break
    }
    else
    {   
        if ($DatabaseList -match "ALL")
        { 
             $dblists =  (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4 and name not in (select db_name(database_id) from sys.dm_hadr_database_replica_states)" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
             
            if ( !$dblists) 
            {
                 LogActivity "No valid databases found to be added to the Availability Group. Please check the input variables" 
                 LogActivity "FINAL STATUS = FAILURE"
                 break
            }
        }


        $dt = get-date -format yyyyMMddHHmmss
        $dblists = $DatabaseList.split(",")
        foreach ($db in $dblists)
        {

            $dbbkpath = "$BackupPath\$db$dt.bak"

            $backupsrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $PrimaryReplica
            $backupsrvrconn.ConnectionContext.StatementTimeout = 0

            $restoresrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $SecondaryReplica
            $restoresrvrconn.ConnectionContext.StatementTimeout = 0


            # Backup my database and its log on the primary
            Backup-SqlDatabase -Database $db -BackupFile "$dbbkpath" -InputObject $backupsrvrconn


            # Restore the database and log on the 1st secondary (using NO RECOVERY)
            Restore-SqlDatabase -Database $db -BackupFile "$dbbkpath"  -InputObject $restoresrvrconn -ReplaceDatabase -NoRecovery
           
            
        }
    }
       LogActivity "Backup and restore the databases for AlwaysOn:SUCCESS" 
    }   



# Check if database exist


    $Primarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
        
    $Secondarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 1 and database_id > 4 " -ServerInstance $SecondaryReplica -QueryTimeout 120).name
    
     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
  
     if (!$Secondarysrvdatabaselist)
     {

        LogActivity "Validating the databases for AlwaysOn:FAILURE. All the databases must be available on both nodes." 
        LogActivity "FINAL STATUS = FAILURE"
        break

     }
      
  if ($DatabaseList -match "ALL")
   {
  
    $DBListCompare = Compare-Object -ReferenceObject $Primarysrvdatabaselist -DifferenceObject $Secondarysrvdatabaselist -PassThru

    if ($DBListCompare)
    {
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases in either server must exist in all."
        LogActivity "FINAL STATUS = FAILURE"
        break
    }
    else
    {
        $DBList = $Primarysrvdatabaselist -join ","
        $DatabaseList = $Primarysrvdatabaselist

        
    
  
        $dblists = $DatabaseList.split(",")
         
       if ($dbinAG)
       {
        
        $errdb = Compare-Object -ReferenceObject $Primarysrvdatabaselist  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }
     

           if ($Secondarysrvdatabaselist)
           {
            $errdb = Compare-Object -ReferenceObject $Secondarysrvdatabaselist  -DifferenceObject $Primarysrvdatabaselist -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject


            if ($errdb)
            {
            
                $exists = $false
                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
            }
            else
            {
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $databaselist is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }



    }
    }
    else
    {
      
  
        $dblists = $DatabaseList.split(",")
        
# Check if database exist
       if ($dbinAG)
       {

      $errdb = Compare-Object -ReferenceObject $dblists  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
        }

      $errdb = Compare-Object -ReferenceObject $Primarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject

   



              if ($errdb)
            {
            
                $exists = $false
                $PrimarysrvdatabaselistOtherRecoveryModel = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model <> 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                $errdbrecmodel = Compare-Object -ReferenceObject $dblists  -DifferenceObject $PrimarysrvdatabaselistOtherRecoveryModel -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject
                $PrimarysrvdatabaselistExists = (invoke-sqlcmd -query "select name from sys.databases where state = 0  and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                
                $errdbexists = Compare-Object -ReferenceObject $PrimarysrvdatabaselistExists  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject
                if ($errdbrecmodel)
                {
                $errdbrecmodel1 = $errdbrecmodel.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbrecmodel1 has to be in full recovery model in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                if ($errdbexists)
                {
                $errdbexists1 = $errdbexists.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbexists1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
                exit
                }
                else
                {
                 $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
            }


           if ($Secondarysrvdatabaselist)
           {
            $errdb = Compare-Object -ReferenceObject $Secondarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject


            if ($errdb)
            {
            
                $exists = $false
                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
            }
            else
            {
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $databaselist is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }



      
    }


# Function to enable "AlwaysOn" for specific sql instance.
#
function EnableAlwayOn([String]$Server) 
{
                try
                {
                                # Importing SQLPS module to execute TSQL statements
                                Import-Module SQLPS -DisableNameChecking
                                
                                LogActivity "Enabling SQL Server AlwaysOn on $Server server."
                                
                                # Calling Enable-SqlAlwaysOn cmdlet

				$InstName = 'MSSQLSERVER'
				$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName

				$ver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version
				$build = $ver.substring(0,2)

				If ($build -eq "11")
				{
                                  Enable-SqlAlwaysOn -Path SQL\$Server\DEFAULT -force
				}

                                LogActivity "Enabling SQL Server AlwaysOn on $Server server: SUCCESS"
                }
                catch
                {
                                LogActivity "Enabling SQL Server AlwaysOn on $Server server: FAILURE"
                                LogActivity "FINAL STATUS = FAILURE"
                                break
                }
}

# Function to disable "AlwaysOn" for specific sql instance.
#
function DisableAlwayOn([String]$Server) 
{
                try
                {
                                # Importing SQLPS module to execute TSQL statements
                                Import-Module SQLPS -DisableNameChecking
                                
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server."
                                
                                # Calling Disable-SqlAlwaysOn cmdlet
                                Disable-SqlAlwaysOn -Path SQL\$Server\DEFAULT -force
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server: SUCCESS"
                }
                catch
                {
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server: FAILURE"
                                LogActivity "FINAL STATUS = FAILURE"
                                break
                }
}

# Enable Always-On for Primary and Secondary replica
EnableAlwayOn $PrimaryReplica1
EnableAlwayOn $SecondaryReplica1


# Function to configure AlwaysOn Availability Groups for user selected databases.
#
function CofigureAG
{

                                $PrimaryServer = $PrimaryReplica1
                                $SecondaryServer = $SecondaryReplica1
                                

                                $Domain = (gwmi WIN32_ComputerSystem).Domain

                                $PrimaryEndPointUrl = "TCP://" + ($PrimaryReplica1) + "." + $Domain + ":$Port"
                                $SecondaryEndPointUrl = "TCP://" + ($SecondaryReplica1) + "." + $Domain + ":$Port"
                               

                                # Creating Availability Group on Primary
                                if ($DatabaseList -match "ALL")
                                {
                                $DbList = $DbList
                                }
                                else
                                {
                                $DBlist = $databaselist -join ","
                                }

                                

                                if($AsyncSecondary -eq $false)
                                {
                                                $sqlquery1 =   "CREATE AVAILABILITY GROUP [$AGGroupName]
                                                                                                WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
                                                                                                FOR DATABASE $DBList
                                                                                                REPLICA ON N'$SecondaryServer' WITH (ENDPOINT_URL = N'$SecondaryEndPointUrl', 
                                                                                                FAILOVER_MODE = AUTOMATIC, 
                                                                                                AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL)),
                                                                                                N'$PrimaryServer' WITH (ENDPOINT_URL = N'$PrimaryEndPointUrl', 
                                                                                                FAILOVER_MODE = AUTOMATIC, 
                                                                                                AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL))"

                                }
                                else
                                {                                                                              
                                                $sqlquery1 =              "CREATE AVAILABILITY GROUP [$AGGroupName]
                                                                                                WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
                                                                                                FOR DATABASE $DBList
                                                                                                REPLICA ON N'$SecondaryServer' WITH (ENDPOINT_URL = N'$SecondaryEndPointUrl', 
                                                                                                FAILOVER_MODE = MANUAL , 
                                                                                                AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL )),
                                                                                                N'$PrimaryServer' WITH (ENDPOINT_URL = N'$PrimaryEndPointUrl', 
                                                                                                FAILOVER_MODE = MANUAL, 
                                                                                                AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT , 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL ));
                                                                                                GO"
                                }
                                
                                 $sqlquery2 =   "ALTER AVAILABILITY GROUP [$AGGroupName]
                                                                                ADD LISTENER N'$ListernerName' (
                                                                                WITH IP
                                                                                ((N'$IpAddress', N'$Subnet')
                                                                                ), PORT=$ListenerPort)"

                                $sqlquery3 = "ALTER AVAILABILITY GROUP $AGGroupName JOIN"


                                try
                                {
                                   # $scope = New-Object -TypeName System.Transactions.TransactionScope
                                
                                    LogActivity "Creating Availability Group"                                                                                                                               
                                    Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery1 -QueryTimeout 200 -ea 'Stop' 
                                    Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery2 -QueryTimeout 200 -ea 'Stop' 
                                    Invoke-Sqlcmd -ServerInstance $SecondaryReplica1 -Query $sqlquery3 -QueryTimeout 200 -ea 'Stop' 

                                    $dblists = $DatabaseList.split(",")
                                    foreach ($db in $dblists)
                                    {
                                   
                                               # $dbbkpath = "$BackupPath\$db$dt.bak"
                   
                                                 # Backup my database and its log on the primary
                                                # invoke-sqlcmd -query "backup log $db to disk ='$dbbkpath'" -ServerInstance $PrimaryReplica -QueryTimeout 120

                
                                                 # Restore the database and log on the 1st secondary (using NO RECOVERY)
                                                 #invoke-sqlcmd -query "restore log $db from disk = '$dbbkpath' with norecovery,replace" -ServerInstance $SecondaryReplica -QueryTimeout 120
            
                                   
                                        $sqlquery5 = "ALTER DATABASE $db SET HADR AVAILABILITY GROUP =  $AGGroupName"

                                        Invoke-Sqlcmd -ServerInstance $SecondaryReplica1 -Query $sqlquery5 -QueryTimeout 200 -ea 'Stop'

                                    }

                                    LogActivity "SQL Server AlwaysON has been enabled on server $PrimaryReplica"
                                    # LogActivity "SQL IQOQ verification PASSSED"
                                    Return $true
                                }
                                catch
                                {
                                    Logactivity $_.exception.message
                                    
                                    # Disable Always-On for Primary and Secondary replica - If there is an AG on the server this step will disable the AG in the entire server
                                    #DisableAlwayOn $PrimaryReplica
                                    #DisableAlwayOn $SecondaryReplica
                                    $sqlquery4 = "DROP AVAILABILITY GROUP [$AGGroupName]"
                                    
                                    LogActivity "Dropping Availability Group"                                                                                                                               
                                   # Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery4 -QueryTimeout 200 -ea 'Stop' 
                                   
                                    LogActivity "Error Creating Availability Group"
                                    LogActivity "FINAL STATUS = FAILURE"
                                    LogActivity "SQL IQOQ verification FAILED. Return code is 1"
                                    LogActivity "All the changes have been rolled back.Please review the verification steps and address the failed step"
                                    Return $false
                                    # break
				    EXIT
                                }
                                finally
                                {
                                   # $scope.Dispose()
                                }



}


$ReturnStatus = CofigureAG

########################### Deploy maintenance jobs on both nodes ###########################

IF ($ReturnStatus -eq $true)
{

If (Test-Path C:\ReDeployJobs) { Remove-Item C:\ReDeployJobs\* -recurse } else { mkdir "C:\ReDeployJobs" }
Invoke-Command -ComputerName $SecondaryReplica1 -ScriptBlock { If (Test-Path C:\ReDeployJobs) { Remove-Item C:\ReDeployJobs\* -recurse } else { mkdir C:\ReDeployJobs } }

$Time = get-date -Uformat "%Y%m%d%H%M"
$LogPath = "C:\ReDeployJobs\DBIntegrityJobsDeployment_$Time.txt"

Write-Host ""
Write-Host "=========== PRIMARY REPLICA : $PrimaryReplica1 ==========="
Write-Host ""

"" > $LogPath
"=========== PRIMARY REPLICA : $PrimaryReplica1 ===========" >> $LogPath
""  >> $LogPath

$iName = "MSSQLSERVER"

Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\Update_LOG_job_And_DataIntegrity_job.sql" "C:\ReDeployJobs" -force
Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" "C:\ReDeployJobs" -force
Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" "C:\ReDeployJobs" -force

Copy-Item "C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force
Copy-Item "C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force
Copy-Item "C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
$sqlver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version
$sqlbuild = $sqlver.substring(0,2)

  $fso = New-Object -ComObject Scripting.FileSystemObject


IF ($sqlbuild -eq "11")
{
  $TF=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
  $ToolsFolder=$TF + "\Binn\sqlcmd"
}

ELSEIF ($sqlbuild -eq "12")
{
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\120\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
   #$ToolsFolder = '"D:\MSSQL2014\Client SDK\ODBC\110\Tools\Binn\SQLCMD.EXE"'
}

ElseIF ($sqlbuild -eq "13")
{
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\130\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
}


ElseIF ($sqlbuild -eq "14")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\140\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
}


ELSEIF ($sqlbuild -eq "15")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\150\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
}




################# Updating of existing jobs on PRIMARY replica ##################

 $Final_Status_Error = 0

 $cmd_1 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql -o C:\ReDeployJobs\QueryOutput3.txt -x && exit 0 || exit 1"
 $cmd_2 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql -o C:\ReDeployJobs\QueryOutput4.txt -x && exit 0 || exit 1"
 $cmd_3 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql -o C:\ReDeployJobs\QueryOutput5.txt -x && exit 0 || exit 1"

& cmd.exe /c $cmd_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Failed" -f red
	"Update DB Integrity and optimization maintenance plan : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Success" -f green
	"Update DB Integrity and optimization maintenance plan : Success" >> $LogPath
}


& cmd.exe /c $cmd_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy FULL backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy FULL backup job : Success" >> $LogPath
}


& cmd.exe /c $cmd_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy DIFF backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy DIFF backup job : Success" >> $LogPath
}


################# Updating existing jobs on SECONDARY replica ##################

Write-Host ""
Write-Host "=========== SECONDARY REPLICA : $SecondaryReplica1 ==========="
Write-Host ""

"" > $LogPath
"=========== SECONDARY REPLICA : $SecondaryReplica1 ===========" >> $LogPath
""  >> $LogPath


Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\DBIntegrityJobUpdateOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Failed" -f red
	"Update DB Integrity and optimization maintenance plan : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Success" -f green
	"Update DB Integrity and optimization maintenance plan : Success" >> $LogPath
}	     

Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\UpdateFULLBkpOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy FULL backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy FULL backup job : Success" >> $LogPath
}

Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\UpdateDIFFBkpOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy DIFF backup job: " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy DIFF backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy DIFF backup job : Success" >> $LogPath
}


If ($Final_Status_Error -eq 1)
{
 Write-Host ""
 Write-Host "Modifying of FULL, DIFF and DB Integrity and optimization jobs on primary and secondary replicas : " -f white -nonewline; Write-Host "Failed" -f red
 Write-Host ""
}
ELSE
{
  Write-Host ""
  Write-Host "Modifying of FULL, DIFF and DB Integrity and optimization jobs on primary and secondary replicas : " -f white -nonewline; Write-Host "Success" -f green
  Write-Host ""

  LogActivity "SQL IQOQ verification PASSSED"
}

########################### Configure the AG setup so that the reporting queries are routed only to the secondary replica ###########################

  IF($AsyncSecondary -eq $true)
   {

        $fqdn = (gwmi WIN32_ComputerSystem).Domain

	$PrimaryRoutingUrl = "N'" + "TCP://" + ($PrimaryReplica1) + "." + $fqdn + ":1433'"
	$SecondaryRoutingUrl = "N'" + "TCP://" + ($SecondaryReplica1) + "." + $fqdn + ":1433'"

	$sqlquery4 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (SECONDARY_ROLE (READ_ONLY_ROUTING_URL = $PrimaryRoutingUrl));
	GO"

	$sqlquery5 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (SECONDARY_ROLE (READ_ONLY_ROUTING_URL = $SecondaryRoutingUrl));
	GO"

	$sqlquery6 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=('$SecondaryReplica1')));
	GO"

	$sqlquery7 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=('$PrimaryReplica1')));
	GO"


	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery4 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ4Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery5 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ5Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery6 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ6Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery7 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ7Log.txt
   }


}
