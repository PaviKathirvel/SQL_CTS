###################################################################################################
$ScriptName = "sddc_sql_InstallSQLServer.PS1"
$Scriptver = "6.0"
#Description: Description: Install SQL Server, use DML based on Server Location 
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			07/24/2014	Atul Patil	New Script
#2.0			11/17/2014	Jay Sangam	Named instance coding
#3.0 			Sept/2/2019	Sanjiv		#Adding 2017 Installation logic	and Baseline Performance framework
#4.0 			Feb/2/2020	Sanjiv		#Adding 2019 Installation logic	
#5.0 			Dec/10/2020	Sanjiv		#Adding New Location hosted on CDOT 
#6.0 			APR/15/2021	Sanjiv		#Promoting SQL2019 
#7.0 			FEB/26/2024	Shubham		#Promoting SQL2022
###################################################################################################


#*********** Install Parameters*************
$Process = $args[0]
$ver = $args[1]
$Edition = $args[2]
$SPackVer = $args[3]
$CollationSet = $args[4]
$InstName = $args[5]
$InstName = "MSSQLSERVER"	#Delete this line later for named instance installs.


IF (($Process -ne "SDDC") -and ($Process -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
"Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" >> $Log
Exit 0
}

IF (($ver -ne "SQL2005") -and ($ver -ne "SQL2008") -and ($ver -ne "SQL2012") -and ($ver -ne "SQL2014") -and ($ver -ne "SQL2016") -and ($ver -ne "SQL2017") -and ($ver -ne "SQL2019") -and ($ver -ne "SQL2022"))
{
Write-host ""
Write-Host "Pass only SQL2005 or SQL2008 or SQL2012 or SQL2014 or SQL2016 or SQL2017  or SQL2019 or SQL2022 as 2nd parameter" -f red
Write-host ""
EXIT
}



#*********** Accept valid SP for the SQL version passed *************

IF ($ver -eq "SQL2005")
{
 IF (($SPackVer -ne "SP3") -and ($SPackVer -ne "SP4"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2005. Please pass SP3 or SP4 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2008")
{
 IF (($SPackVer -ne "SP3") -and ($SPackVer -ne "SP4") -and ($SPackVer -ne "SP4_10.00.6556"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2008. Please pass SP3 or SP4 or SP4_10.00.6556 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2012")
{
 IF (($SPackVer -ne "SP2") -and ($SPackVer -ne "SP3") -and ($SPackVer -ne "SP3CU11.0.6567") -and ($SPackVer -ne "SP4") -and ($SPackVer -ne "SP4_11.0.7462"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2012. Please pass SP2 or SP3 or SP3CU11.0.6567 or SP4 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2014")
{
 IF (($SPackVer -ne "SP2") -and ($SPackVer -ne "SP2_12.0.5557") -and ($SPackVer -ne "SP2_12.0.5589") -and ($SPackVer -ne "SP3_12.0.6319"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2014. Please pass SP2 or SP2_12.0.5557 or SP2_12.0.5589 or SP3_12.0.6329  as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2016") 
{
 IF (($SPackVer -ne "SP1") -and ($SPackVer -ne "SP2")  -and ($SPackVer -ne "SP2_13.0.5201") -and ($SPackVer -ne "SP2_13.0.5426") -and ($SPackVer -ne "SP2_13.0.5830") -and ($SPackVer -ne "SP3")  -and ($SPackVer -ne "SP3_13.0.6419"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2016. Please pass SP1 or SP2 or SP3 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
 }
ELSEIF ($ver -eq "SQL2017") 
{
 IF (($SPackVer -ne "RTM") -and ($SPackVer -ne "CU16") -and ($SPackVer -ne "CU29"))
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2017. Please pass RTM or CU16 or CU29 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2019") 
{
 IF (($SPackVer -ne "RTM") -and ($SPackVer -ne "CU17")) 
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2019. Please pass RTM or CU17 as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}
ELSEIF ($ver -eq "SQL2022") 
{
 IF (($SPackVer -ne "RTM") ) 
  {
    Write-Host ""
    Write-Host "Service pack version not valid for SQL2022. Please pass RTM as 4th parameter" -f red
    Write-Host ""
    EXIT 0
  }
}



#*********** Accept valid collation set *************

$arrCol = @("SQL_Latin1_General_CP1_CI_AS",
"Latin1_General_CI_AI",
"Latin1_General_CI_AS",
"Latin1_General_CI_AS_KS_WS",
"SQL_Latin1_General_CP850_CI_AI",
"Chinese_PRC_CI_AS",
"SQL_Latin1_General_CP1_CI_AI",
"SQL_Latin1_General_CP850_BIN2",
"Chinese_Taiwan_Stroke_CI_AS",
"SQL_Latin1_General_CP1_CS_AS",
"Cyrillic_General_CI_AS",
"Finnish_Swedish_CI_AS",
"Japanese_CI_AS",
"SQL_Czech_CP1250_CI_AS",
"Arabic_BIN",
"Czech_BIN",
"French_BIN",
"Latin1_General_CS_AS",
"SQL_Latin1_General_CP850_BIN",
"Thai_CI_AS",
"Finnish_Swedish_CS_AI",
"Hebrew_CI_AS",
"Japanese_CI_AI",
"Korean_Wansung_CI_AS",
"Latin1_General_CS_AI",
"Polish_CI_AS",
"SQL_1xCompat_CP850_CI_AS",
"SQL_Hungarian_CP1250_CS_AS",
"SQL_Slovak_CP1250_CI_AS")

If ($arrCol -notcontains $CollationSet)

{
    Write-Host ""
    Write-Host "Invalid collation. Please pass a valid collation name as 5th parameter" -f red
    Write-Host ""
    EXIT 0
}


#***************************************************************

$BatchOutput2 = "C:\IQOQ\Status.txt"
#$cnfgfl_lab = '\ConfigFiles\NonSDDCDefaultConfigurationFile.ini"'  #Non SDDC config



	$LabSQLDML= '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
	$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
	$EMEASQLDML = '\\itsbebec1snap01.jnj.com\msqldml\NCSUSGroupData\sqlsrvr\MSSQLDML'
	$ASPACSQLDML = '\\itssgsgc1snap01.jnj.com\msqldml\NCSUSGroupData\sqlsrvr\MSSQLDML'
	$LASQLDML = '\\itsusrac1ts1.jnj.com\msqldml\NCSUSGroupData\sqlsrvr\MSSQLDML'

If ($ver -eq "SQL2014"){

   	$EPIDNumber = '/PID="TJYBJ-8YGH6-QK2JJ-M9DFB-D7M9D"'
   	$SPIDNumber = '/PID="P7FRV-Y6X6Y-Y8C6Q-TB4QR-DMTTK"' 
   	$updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2014'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2014RSAS_SDDC_DefaultConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2014\MSSQL12.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2014\MSSQL12.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2014\MSSQL12.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2014\MSSQL12.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2014RSAS_DefaultConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=G:\MSSQL2014\MSSQL12.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=E:\MSSQL2014\MSSQL12.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=F:\MSSQL2014\MSSQL12.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2014\MSSQL12.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=E:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=F:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=G:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2014\MSAS12.' + $InstName + '\OLAP\Temp'

	}

#*********** Lab DML*************
 	IF ($SPackVer -eq "SP2")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2014SP2\setup.exe"	#For SP2
	 }
    ELSEIF($SPackVer -eq "SP2_12.0.5557")
         {
           $LabSetup =  $LabSQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SSP2_12.0.5557
           $LabPatch = "/UpdateSource=" + $LabSQLDML +  "\Binaries\SQL2014_SP2_Securitypatch"
         }
	
	$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

#*********** NA DML *************
 	IF ($SPackVer -eq "SP2")
	 {
	   $NASetup  = $NASQLDML + "\Binaries\SQL2014SP2\setup.exe"	#For SP2
	   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2014_SP2_MS16-136_HF"
	 }
    ELSEIF($SPackVer -eq "SP2_12.0.5557")
     {
        $NASetup = $NASQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SP2_12.0.5557
        $NAPatch = "/UpdateSource=" +$NASQLDML +  "\Binaries\SQL2014_SP2_Securitypatch"
     }  

    ELSEIF($SPackVer -eq "SP2_12.0.5589")
     {
        $NASetup = $NASQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SP2_12.0.5557
        #$NAPatch = $NASQLDML +  "\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe"
     }   
	ELSEIF($SPackVer -eq "SP3_12.0.6329")
    {
        IF($EDITION -eq "E")
		{
			$NASetup = $NASQLDML + "\Binaries\SQL2014ENT_withSP3\setup.exe"  #For SP3 
			$NAPatch = "/UpdateSource=" +$NASQLDML +  "\SP_HF\SQL2014_SP3_6329"
  		}
		else
		{
			$NASetup = $NASQLDML + "\Binaries\SQL2014STD_withSP3\setup.exe"	#For SP3
			$NAPatch = "/UpdateSource=" +$NASQLDML +  "\SP_HF\SQL2014_SP3_6329"
		}
	} 
	$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl

#*********** EMEA DML*************
 	IF ($SPackVer -eq "SP2")
	 {
	   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2014SP2\setup.exe"	#For SP2
	   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2014_SP2_MS16-136_HF"
	 }
    ELSEIF($SPackVer -eq "SP2_12.0.5557")                         #For SP2_12.0.5557
		{
           $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2014SP2\setup.exe"	
           $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2014_SP2_Securitypatch"
        }
    ELSEIF($SPackVer -eq "SP2_12.0.5589")
        {
            $EMEASetup = $EMEASQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SP2_12.0.5557
            #$NAPatch = $NASQLDML +  "\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe"
        }
	ELSEIF($SPackVer -eq "SP3_12.0.6329")  # For SP3
    {
        IF($EDITION -eq "E")
		{
			$EMEASetup = $EMEASQLDML + "\Binaries\SQL2014ENT_withSP3\setup.exe"  #For SP3 
			$EMEAPatch = "/UpdateSource=" +$EMEASQLDML +  "\SP_HF\SQL2014_SP3_6329"
  		}
		else
		{
			$EMEASetup = $EMEASQLDML + "\Binaries\SQL2014STD_withSP3\setup.exe"	#For SP3
			$EMEAPatch = "/UpdateSource=" +$EMEASQLDML +  "\SP_HF\SQL2014_SP3_6329"
		}
	} 
	$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

#*********** ASPAC DML************
 	IF ($SPackVer -eq "SP2")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2014SP2\setup.exe"	#For SP2
	   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2014_SP2_MS16-136_HF"
	 }
    ELSEIF($SPackVer -eq "SP2_12.0.5557")
     {
            $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2014SP2\setup.exe"
            $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2014_SP2_Securitypatch"
     }  
    ELSEIF($SPackVer -eq "SP2_12.0.5589")
     {
        $ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SP2_12.0.5557
        #$NAPatch = $NASQLDML +  "\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe"
     }
	
	ELSEIF($SPackVer -eq "SP3_12.0.6329")  #For SP3
    {
        IF($EDITION -eq "E")
		{
			$ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2014ENT_withSP3\setup.exe"  #For SP3 
			$ASPACPatch = "/UpdateSource=" +$ASPACSQLDML +  "\SP_HF\SQL2014_SP3_6329"
  		}
		else
		{
			$ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2014STD_withSP3\setup.exe"	#For SP3
			$ASPACPatch = "/UpdateSource=" +$ASPACSQLDML +  "\SP_HF\SQL2014_SP3_6329"
		}
	} 
	
	$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

#*********** LA DML*************
 	IF ($SPackVer -eq "SP2")
	{
	   $LASetup  = $LASQLDML + "\Binaries\SQL2014SP2\setup.exe"	#For SP2
	   $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2014_SP2_MS16-136_HF"
	}
    ELSEIF($SPackVer -eq "SP2_12.0.5557")
    {
       $LASetup  = $LASQLDML + "\Binaries\SQL2014SP2\setup.exe"
       $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2014_SP2_Securitypatch"
    } 
    ELSEIF($SPackVer -eq "SP2_12.0.5589")
    {
       $LASetup = $LASQLDML + "\Binaries\SQL2014SP2\setup.exe"   #For SP2_12.0.5557
       #$NAPatch = $NASQLDML +  "\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe"
    }
	
	ELSEIF($SPackVer -eq "SP3_12.0.6329")
    {
        IF($EDITION -eq "E")
		{
			$LASetup = $LASQLDML + "\Binaries\SQL2014ENT_withSP3\setup.exe"  #For SP3 
			$LAPatch = "/UpdateSource=" +$LASQLDML +  "\SP_HF\SQL2014_SP3_6329"
  		}
		else
		{
			$LASetup = $LASQLDML + "\Binaries\SQL2014STD_withSP3\setup.exe"	#For SP3
			$LAPatch = "/UpdateSource=" +$LASQLDML +  "\SP_HF\SQL2014_SP3_6329"
		}
	} 
	
	
	$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

}

If ($ver -eq "SQL2012")
{
   	$EPIDNumber = '/PID="FH666-Y346V-7XFQ3-V69JM-RHW28"'
   	$SPIDNumber = '/PID="YFC4R-BRRWB-TVP9Y-6WJQ9-MCJQ7"' 
   	$Updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2012'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2012RSAS_SDDC_DefaultConfigurationFile.ini"'
		# $cnfgfl = '\Scripts\Staging\ConfigFiles\SQL2012RSAS_SDDC_DefaultConfigurationFile.ini"'	#staging Config file

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2012\MSSQL11.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2012\MSSQL11.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2012RSAS_DefaultConfigurationFile.ini"'
		# $cnfgfl = '\Scripts\Staging\ConfigFiles\SQL2012RSAS_DefaultConfigurationFile.ini"'	#Personal Config file

		$BkpDir = '/SQLBACKUPDIR=G:\MSSQL2012\MSSQL11.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=E:\MSSQL2012\MSSQL11.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=F:\MSSQL2012\MSSQL11.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2012\MSSQL11.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=E:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=F:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=G:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2012\MSAS11.' + $InstName + '\OLAP\Temp'

	}

	#*********** Lab DML*************
 	IF ($SPackVer -eq "SP2")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"	#For SP2
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3
	 }
        ELSEIF ($SPackVer -eq "SP4")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $LabPatch = "/UpdateSource=" + $LabSQLDML + "\Binaries\SQL2012SP4"
	 }
	$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

	#*********** NA DML *************
 	IF ($SPackVer -eq "SP2")
	 {
	   $NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"	#For SP2
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3
	 }
	ELSEIF ($SPackVer -eq "SP3CU11.0.6567")
	 {
	   $NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3+HF
	   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2012_SP3_MS16-136_HF"
	 }
	ELSEIF ($SPackVer -eq "SP4")
	 {
           $NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"
	   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2012SP4"	#For SP4
	   
	 }
	ELSEIF ($SPackVer -eq "SP4_11.0.7462")
	 {
           $NASetup  = $NASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"
	   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2012SP4"	#For SP4

	   
	 }

	$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl


	#*********** EMEA DML*************
 	IF ($SPackVer -eq "SP2")
	 {
	   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"	#For SP2
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3
	 }
	ELSEIF ($SPackVer -eq "SP3CU11.0.6567")
	 {
	   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3+HF
	   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2012_SP3_MS16-136_HF"
	 }
	ELSEIF ($SPackVer -eq "SP4")
	 {
	   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2012SP4"
	 }
	ELSEIF ($SPackVer -eq "SP4_11.0.7462")
	 {
           $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"
	   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2012SP4"	#For SP4

	   
	 }

	$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

	#*********** ASPAC DML************
 	IF ($SPackVer -eq "SP2")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"	#For SP2
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3
	 }
	ELSEIF ($SPackVer -eq "SP3CU11.0.6567")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3+HF
	   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2012_SP3_MS16-136_HF"
	 }
	ELSEIF ($SPackVer -eq "SP4")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2012SP4"
	 }
	ELSEIF ($SPackVer -eq "SP4_11.0.7462")
	 {
	   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2012SP4"

	   
	 }

	$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

	#*********** LA DML*************
 	IF ($SPackVer -eq "SP2")
	 {
	   $LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP2\setup.exe"	#For SP2
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3
	 }

	ELSEIF ($SPackVer -eq "SP3CU11.0.6567")
	 {
	   $LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP3+HF
	   $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2012_SP3_MS16-136_HF"
	 }
	ELSEIF ($SPackVer -eq "SP4")
	 {
	   $LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2012SP4"
	 }
	ELSEIF ($SPackVer -eq "SP4_11.0.7462")
	 {
	   $LASetup  = $LASQLDML + "\Binaries\SQL2012EEWithSP3\setup.exe"	#For SP4
           $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2012SP4"

	   
	 }

	$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

}

If ($ver -eq "SQL2008")
{

   	$EPIDNumber = '/PID="JD8Y6-HQG69-P9H84-XDTPG-34MBB"'
	$SPIDNumber = '/PID="FXHQY-JQF42-68VVV-PYVVR-RY3BB"' 
   	$Action = '/ACTION=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2008'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2008RSAS_SDDC_DefaultConfigurationFile.ini"'
		#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\SQL2008RSAS_SDDC_DefaultConfigurationFile.ini" '	#Personal Config file
		
		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2008\MSSQL10.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2008\MSSQL10.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2008\MSSQL10.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2008\MSSQL10.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2008RSAS_DefaultConfigurationFile.ini"'
		#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\SQL2008RSAS_DefaultConfigurationFile.ini"'	#Personal Config file

		$BkpDir = '/SQLBACKUPDIR=G:\MSSQL2008\MSSQL10.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=E:\MSSQL2008\MSSQL10.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=F:\MSSQL2008\MSSQL10.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2008\MSSQL10.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=E:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=F:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=G:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2008\MSAS10.' + $InstName + '\OLAP\Temp'

	}

	#*********** Lab DML*************
 	IF ($SPackVer -eq "SP4")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2008EEWithSP3\setup.exe"
	 }

	# $LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl_lab + " /PCUSOURCE=""" + $LabSQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	$LabConfig = "/configurationfile=""" + $LabSQLDML  + $cnfgfl
	$LAPCU = "/PCUSOURCE=""" + $LabSQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	$LabPatch =  $LabSQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"

	#*********** NA DML *************

 	IF ($SPackVer -eq "SP4")
	 {
	   #$NASetup = $NASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $NASetup = $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\setup.exe"
	   $NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	   #$NAPCU = "/PCUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	   $NAPCU = "/PCUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\PCU"""
	
	   #$NAPatch = $NASQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	   $NAPatch = "/CUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\SecurityPatch"""
	 }
        ELSEIF($SPackVer -eq "SP4_10.00.6556")
          {

	   $NASetup = $NASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   #$NASetup = $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\setup.exe"
	   $NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	   $NAPCU = "/PCUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	   #$NAPCU = "/PCUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\PCU"""
	
	   #$NAPatch = $NASQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	   #$NAPatch = "/CUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\SecurityPatch"""
  
	   

          }  

	
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $NASetup = $NASQLDML + "\Binaries\SQL2008EEWithSP3\setup.exe"
	   $NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	   $NAPCU = "/PCUSOURCE=""" + $NASQLDML + "\Binaries\SQL2008EEWithSP3\PCU"""
	   $NAPatch = $NASQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	 }

	#*********** EMEA DML*************
 	IF ($SPackVer -eq "SP4")
	 {
	   # $EMEASetup = $EMEASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $EMEASetup = $EMEASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\setup.exe"
	   $EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   # $EMEAPCU = "/PCUSOURCE=""" + $EMEASQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	   $EMEAPCU = "/PCUSOURCE=""" + $EMEASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\PCU"""
	   $EMEAPatch = "/CUSOURCE=""" + $EMEASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\SecurityPatch"""
	 }
        ELSEIF($SPackVer -eq "SP4_10.00.6556")
          {

	   $EMEASetup = $EMEASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $EMEAPCU = "/PCUSOURCE=""" + $EMEASQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
           
          } 
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $EMEASetup = $EMEASQLDML + "\Binaries\SQL2008EEWithSP3\setup.exe"
	   $EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $EMEAPCU = "/PCUSOURCE=""" + $EMEASQLDML + "\Binaries\SQL2008EEWithSP3\PCU"""
	   $EMEAPatch = $EMEASQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	 }   

	#*********** ASPAC DML************
 	IF ($SPackVer -eq "SP4")
	 {
	   #$ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\setup.exe"
	   $ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   #$APACPCU = "/PCUSOURCE=""" + $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
	   $APACPCU = "/PCUSOURCE=""" + $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\PCU"""
	   $ASPACPatch = "/CUSOURCE=""" + $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\SecurityPatch"""
	 }
        ELSEIF($SPackVer -eq "SP4_10.00.6556")
          {

	   $ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $APACPCU = "/PCUSOURCE=""" + $ASPACSQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
           
          } 
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $ASPACSetup = $ASPACSQLDML + "\Binaries\SQL2008EEWithSP3\setup.exe"
	   $ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $APACPCU = "/PCUSOURCE=""" + $ASPACSQLDML + "\Binaries\SQL2008EEWithSP3\PCU"""
	   $ASPACPatch = $ASPACSQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	 }

	#*********** LA DML*************
 	IF ($SPackVer -eq "SP4")
	 {
	   $LASetup = $LASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $LAPCU = "/PCUSOURCE=""" + $LASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\PCU"""
	   $LAPatch = "/CUSOURCE=""" + $LASQLDML + "\Binaries\SQL2008EEWithSP4WithSecurtyPatch\SecurityPatch"""
	 }
        ELSEIF($SPackVer -eq "SP4_10.00.6556")
          {

	   $LASetup = $LASQLDML + "\Binaries\SQL2008EEWithSP4\setup.exe"
	   $LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $LAPCU = "/PCUSOURCE=""" + $LASQLDML + "\Binaries\SQL2008EEWithSP4\PCU"""
           
          } 
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LASetup = $LASQLDML + "\Binaries\SQL2008EEWithSP3\setup.exe"
	   $LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	   $LAPCU = "/PCUSOURCE=""" + $LASQLDML + "\Binaries\SQL2008EEWithSP3\PCU"""
	   $LAPatch = $LASQLDML + "\Binaries\SQL2008_MS15-058_HF\SQLServer2008-KB3045308-x64.exe"
	 }  

}

If ($ver -eq "SQL2005")
{
   	$EPIDNumber = '/PIDKEY "WXGDGDJ8DJCC77F8FDJVDFBYG"'
   	$SPIDNumber = '/PIDKEY "B4H74BJX3P37RX2J9TTBH9RMJ"' 
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2005'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Config'

	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2005RSAS_SDDC_DefaultConfigurationFile.ini"'
		#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\SQL2005RSAS_SDDC_DefaultConfigurationFile.ini"'	#Personal Config file

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2005\MSSQL9.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2005\MSSQL9.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2005\MSSQL9.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2005\MSSQL9.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2005RSAS_DefaultConfigurationFile.ini"'
		#$cnfgfl = '\Scripts\Development\Release_BatchNamedInstance\ConfigFiles\SQL2005RSAS_DefaultConfigurationFile.ini"'	#Personal Config file

		$BkpDir = '/SQLBACKUPDIR=G:\MSSQL2005\MSSQL9.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=E:\MSSQL2005\MSSQL9.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=F:\MSSQL2005\MSSQL9.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2005\MSSQL9.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=E:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=F:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=G:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2005\MSAS9.' + $InstName + '\OLAP\Temp'

	}

	#*********** Lab DML*************

	  If ($Edition -eq 'E')
	   { 
	    $LabSetup =  $LabSQLDML + "\Binaries\SQL2005EE\Servers\setup.exe"
	   }
	  ELSEIF($Edition -eq 'S')
	   {
	    $LabSetup =  $LabSQLDML + "\Binaries\SQL2005SE\Servers\setup.exe"
	   }

 	IF ($SPackVer -eq "SP4")
	 {
	   $LabPatch =  $LabSQLDML + "\Binaries\SQL2005SP4\SQLServer2005SP4-KB2463332-x64-ENU.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LabPatch =  $LabSQLDML + "\Binaries\SQL2005SP3\SQLServer2005SP3-KB955706-x64-ENU.exe"
	 }

	$LabConfig = "/settings """ + $LabSQLDML + $cnfgfl

	#*********** NA DML *************

	  If ($Edition -eq 'E')
	   {
	    $NASetup  = $NASQLDML + "\Binaries\SQL2005EE\Servers\setup.exe"
	   }
	  ELSEIF($Edition -eq 'S')
	   {
	    $NASetup  = $NASQLDML + "\Binaries\SQL2005SE\Servers\setup.exe"
	   }

 	IF ($SPackVer -eq "SP4")
	 {
	   $NAPatch =  $NASQLDML + "\Binaries\SQL2005SP4\SQLServer2005SP4-KB2463332-x64-ENU.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $NAPatch =  $NASQLDML + "\Binaries\SQL2005SP3\SQLServer2005SP3-KB955706-x64-ENU.exe"
	 }

	$NAConfig = "/settings """ + $NASQLDML  + $cnfgfl

	#*********** EMEA DML*************

	  If ($Edition -eq 'E')
	   {
	    $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2005EE\Servers\setup.exe"
	   }
	  ELSEIF($Edition -eq 'S')
	   {
	    $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2005SE\Servers\setup.exe"
	   }

 	IF ($SPackVer -eq "SP4")
	 {
	   $EMEAPatch =  $EMEASQLDML + "\Binaries\SQL2005SP4\SQLServer2005SP4-KB2463332-x64-ENU.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $EMEAPatch =  $EMEASQLDML + "\Binaries\SQL2005SP3\SQLServer2005SP3-KB955706-x64-ENU.exe"
	 }

	$EMEAConfig = "/settings """ + $NASQLDML  + $cnfgfl

	#*********** ASPAC DML************

	  If ($Edition -eq 'E')
	   {
	    $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2005EE\Servers\setup.exe"
	   }
	  ELSEIF($Edition -eq 'S')
	   {
	    $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2005SE\Servers\setup.exe"
	   }

 	IF ($SPackVer -eq "SP4")
	 {
	   $ASPACPatch =  $ASPACSQLDML + "\Binaries\SQL2005SP4\SQLServer2005SP4-KB2463332-x64-ENU.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $ASPACPatch =  $ASPACSQLDML + "\Binaries\SQL2005SP3\SQLServer2005SP3-KB955706-x64-ENU.exe"
	 }
	$ASPACConfig = "/settings """ + $NASQLDML + $cnfgfl

	#*********** LA DML*************

	  If ($Edition -eq 'E')
	   {
	    $LASetup  = $LASQLDML + "\Binaries\SQL2005EE\Servers\setup.exe"
	   }
	  ELSEIF($Edition -eq 'S')
	   {
	    $LASetup  = $LASQLDML + "\Binaries\SQL2005SE\Servers\setup.exe"
	   }

 	IF ($SPackVer -eq "SP4")
	 {
	   $LAPatch =  $LASQLDML + "\Binaries\SQL2005SP4\SQLServer2005SP4-KB2463332-x64-ENU.exe"
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {
	   $LAPatch =  $LASQLDML + "\Binaries\SQL2005SP3\SQLServer2005SP3-KB955706-x64-ENU.exe"
	 }
	$LAConfig = "/settings """ + $NASQLDML + $cnfgfl

}

If ($ver -eq "SQL2016")
{
   	#$EPIDNumber = '/PID="TBR8B-BXC4Y-298NV-PYTBY-G3BCP"'
   	#$SPIDNumber = '/PID="P7FRV-Y6X6Y-Y8C6Q-TB4QR-DMTTK"' 
   	$updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2016'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2016_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2016\MSSQL13.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2016\MSSQL13.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2016\MSSQL13.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2016\MSSQL13.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2016_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2016\MSSQL13.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2016\MSSQL13.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2016\MSSQL13.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2016\MSSQL13.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2016\MSAS13.' + $InstName + '\OLAP\Temp'

	}


#*********** Lab DML*************
IF ($SPackVer -eq "SP1")
{
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
 }

$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl


#**********SP1 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP1")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP1
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"	#For SP1
}
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}
#*********** EMEA DML*************
IF ($SPackVer -eq "SP1")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP1
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"	#For SP1
}
$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP1")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#*********** LA DML*************
IF ($SPackVer -eq "SP1")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}




#**********SP2 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP2")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** EMEA DML*************
IF ($SPackVer -eq "SP2")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP2")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}


#**********5201 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP2_13.0.5201")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** EMEA DML*************
IF ($SPackVer -eq "SP2_13.0.5201")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP2_13.0.5201")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2"	#For SP1
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** LA DML************
IF ($SPackVer -eq "SP2_13.0.5201")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"
  $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2016SP2"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2016SP2"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}



#**********5426 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP2_13.0.5426")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2_5426"	
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2016SP2_5426"	
}

$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** EMEA DML*************
IF ($SPackVer -eq "SP2_13.0.5426")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2_5426"	
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2016SP2_5426"	
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP2_13.0.5426")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2_5426"	
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2016SP2_5426"	
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** LA DML************
IF ($SPackVer -eq "SP2_13.0.5426")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"
  $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2016SP2_5426"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $LAPatch = "/UpdateSource=" + $LASQLDML + "\Binaries\SQL2016SP2_5426"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#**********SP3 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP3")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
}

$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** EMEA DML*************
IF ($SPackVer -eq "SP3")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP3")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016EE_withSP1\setup.exe"	#For SP2
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP1\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF_QA\SQL2016_SP3"	#For SP3
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}


#**********6419 ****************#

#*********** NA DML *************
IF ($SPackVer -eq "SP3_13.0.6419")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF_QA\SQL2016"	
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF_QA\SQL2016"	
}

$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** EMEA DML*************
IF ($SPackVer -eq "SP3_13.0.6419")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF_QA\SQL2016"	
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF_QA\SQL2016"	
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************
IF ($SPackVer -eq "SP3_13.0.6419")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"	
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF_QA\SQL2016"	
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF_QA\SQL2016"	
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** LA DML************
IF ($SPackVer -eq "SP3_13.0.6419")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2016ENT_withSP2\setup.exe"
  $LAPatch = "/UpdateSource=" + $LASQLDML + "\SP_HF_QA\SQL2016"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2016STD_withSP2\setup.exe"
   $LAPatch = "/UpdateSource=" + $LASQLDML + "\SP_HF_QA\SQL2016"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}



#*********** Get Edition ************* 

IF($Edition -eq 'S')
{
 	$PIDNumber = $SPIDNumber 
	$SelectedEdition = 'Standard Edition..'
}
ELSEIF($Edition -eq 'E')
{
	$PIDNumber = $EPIDNumber 
	$SelectedEdition = 'Enterprise Edition..'
}
ELSE 
{
        Write-Host ""
        Write-Host "Pass S for Standard or E for Enterprise edition as 3rd parameter" -f red
        Write-Host ""

	Exit 0
}

#*********** Get Instance name ************* 

IF($InstName -eq $null)
{

        Write-Host ""
        Write-Host "Please pass instance name as 5th parameter" -f red
        Write-Host ""

	Exit 0
}

}

#*********** SQL2017 *************

If ($ver -eq "SQL2017")
{
   	#$EPIDNumber = '/PID="TBR8B-BXC4Y-298NV-PYTBY-G3BCP"'
   	#$SPIDNumber = '/PID="P7FRV-Y6X6Y-Y8C6Q-TB4QR-DMTTK"' 
   	$updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2017'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2017_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2017\MSSQL14.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2017\MSSQL14.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2017\MSSQL14.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2017\MSSQL14.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2017_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2017\MSSQL14.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2017\MSSQL14.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2017\MSSQL14.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2017\MSSQL14.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2017\MSAS14.' + $InstName + '\OLAP\Temp'

	}



#*********** Lab DML*************
IF ($SPackVer -eq "RTM")
{
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP2
 }

$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

#*********** NA DML *************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP1
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"	#For SP1
}
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}
#*********** EMEA DML*************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP1
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"	#For SP1
}
$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

}

#*********** ASPAC DML************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#*********** LA DML*************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#*********** NA DML *************
IF ($SPackVer -eq "CU16")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2017CU16"	
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\Binaries\SQL2017CU16"	
}
}
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl

#*********** EMEA DML*************

IF ($SPackVer -eq "CU16")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP2
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2017CU16"	#For SP1
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\Binaries\SQL2017CU16"	#For SP1
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************

IF ($SPackVer -eq "CU16")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP2
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2017CU16"	#For SP1
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\Binaries\SQL2017CU16"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}


#***************CU29***************************#
#*********** NA DML *************
IF ($SPackVer -eq "CU29")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF\SQL2017"	#Changing from \Binaries\SQL2017CU16 to \SP_HF\SQL2017
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF\SQL2017"	
}
}
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl

#*********** EMEA DML*************

IF ($SPackVer -eq "CU29")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	#For SP2
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF\SQL2017"	#For SP1
   
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF\SQL2017"	#For SP1
}

$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}

#*********** ASPAC DML************

IF ($SPackVer -eq "CU29")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017EE_RTM_UNZIP\setup.exe"	
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF\SQL2017"	
   
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2017STD_RTM_UNZIP\setup.exe"
   $ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF\SQL2017"	
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}
#*********** Get Edition ************* 

IF($Edition -eq 'S')
{
 	$PIDNumber = $SPIDNumber 
	$SelectedEdition = 'Standard Edition..'
}
ELSEIF($Edition -eq 'E')
{
	$PIDNumber = $EPIDNumber 
	$SelectedEdition = 'Enterprise Edition..'
}
ELSE 
{
        Write-Host ""
        Write-Host "Pass S for Standard or E for Enterprise edition as 3rd parameter" -f red
        Write-Host ""

	Exit 0
}

}


#*********** SQL2019 *************

If ($ver -eq "SQL2019")
{	#$EPIDNumber = '/PID="TBR8B-BXC4Y-298NV-PYTBY-G3BCP"'
   	#$SPIDNumber = '/PID="P7FRV-Y6X6Y-Y8C6Q-TB4QR-DMTTK"' 
   	$updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2019'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2019_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2019\MSSQL15.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2019\MSSQL15.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2019\MSSQL15.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2019\MSSQL15.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC")
	{
 
		$cnfgfl = '\ConfigFiles\SQL2019_ConfigurationFile.ini"'

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2019\MSSQL15.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2019\MSSQL15.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2019\MSSQL15.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2019\MSSQL15.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2019\MSAS15.' + $InstName + '\OLAP\Temp'

	}



	#*********** Lab DML*************
	IF ($SPackVer -eq "RTM")
	{
		$LabSetup =  $LabSQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"	#For SP2
	}

	$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

	#*********** NA DML *************
	IF ($SPackVer -eq "RTM")
	{
	IF($EDITION -eq "E")
	{
	$NASetup  = $NASQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"	#For SP1
	
	}
	else
	{
	$NASetup  = $NASQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"	#For SP1
	}
	$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	}
	#*********** EMEA DML*************
	IF ($SPackVer -eq "RTM")
	{
	IF($EDITION -eq "E")
	{
	$EMEASetup  = $EMEASQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"	#For SP1
	}
	else
	{
	$EMEASetup  = $EMEASQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"	#For SP1
	}
	$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

	}

	#*********** ASPAC DML************
	IF ($SPackVer -eq "RTM")
	{
	IF($EDITION -eq "E")
	{
	$ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"
	}
	else
	{
	$ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"	#For SP1
	}

	$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	}

	#*********** LA DML*************
	IF ($SPackVer -eq "RTM")
	{
	IF($EDITION -eq "E")
	{
	$LASetup  = $LASQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"
	}
	else
	{
	$LASetup  = $LASQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"
	}

	$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
	}

	#*********** NA DML *************
	IF ($SPackVer -eq "CU17")
	{
	IF($EDITION -eq "E")
	{
	$NASetup  = $NASQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"	
	$NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF\SQL2019"
	
	}
	else
	{
	$NASetup  = $NASQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"
	$NAPatch = "/UpdateSource=" + $NASQLDML + "\SP_HF\SQL2019"	
	}
	}
	$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl

	#*********** EMEA DML*************

	IF ($SPackVer -eq "CU17")
	{
	IF($EDITION -eq "E")
	{
	$EMEASetup  = $EMEASQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"        #For SP2
	$EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF\SQL2019"	#For SP1
	
	}
	else
	{
	$EMEASetup  = $EMEASQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"
	$EMEAPatch = "/UpdateSource=" + $EMEASQLDML + "\SP_HF\SQL2019"	#For SP1
	}

	$EMEAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	}

	#*********** ASPAC DML************

	IF ($SPackVer -eq "CU17")
	{
	IF($EDITION -eq "E")
	{
	$ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2019EE_RTM_UNZIP\setup.exe"	#For SP2
	$ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF\SQL2019"	#For SP1
	
	}
	else
	{
	$ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2019STD_RTM_UNZIP\setup.exe"
	$ASPACPatch = "/UpdateSource=" + $ASPACSQLDML + "\SP_HF\SQL2019"	#For SP1
	}

	$ASPACConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
	}


	#*********** Get Edition ************* 

	IF($Edition -eq 'S')
	{
		$PIDNumber = $SPIDNumber 
		$SelectedEdition = 'Standard Edition..'
	}
	ELSEIF($Edition -eq 'E')
	{
		$PIDNumber = $EPIDNumber 
		$SelectedEdition = 'Enterprise Edition..'
	}
	ELSE 
	{
			Write-Host ""
			Write-Host "Pass S for Standard or E for Enterprise edition as 3rd parameter" -f red
			Write-Host ""

		Exit 0
	}

}

#*********** SQL2022 ************* #Shubham - 26/02/2024

If ($ver -eq "SQL2022")
{
   	#$EPIDNumber = '/PID="TBR8B-BXC4Y-298NV-PYTBY-G3BCP"'
   	#$SPIDNumber = '/PID="P7FRV-Y6X6Y-Y8C6Q-TB4QR-DMTTK"' 
   	$updates ='/UpdateEnabled=TRUE'
   	$Action ='/Action=Install'
   	$InstParam = '/INSTANCENAME=' + $InstName
   	$InstParamID = '/INSTANCEID=' + $InstName
   	$DataDir = '/INSTALLSQLDATADIR=E:\MSSQL2022'
   	$ASConfigDir = '/ASCONFIGDIR=D:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Config'
	$Collation = '/SQLCOLLATION=' + $CollationSet


	IF ($InstName -eq 'MSSQLSERVER')
	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
	}

	ELSE

	{
	 $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
	 $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
	}


	IF ($Process -eq "SDDC") 
	{

		$cnfgfl = '\ConfigFiles\SQL2022_ConfigurationFile.ini"' 
		

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2022\MSSQL16.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2022\MSSQL16.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2022\MSSQL16.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2022\MSSQL16.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Temp'

	}

	ELSEIF ($Process -eq "NON_SDDC") 
	
	{
 
		$cnfgfl = '\ConfigFiles\SQL2022_ConfigurationFile.ini"'
		

		$BkpDir = '/SQLBACKUPDIR=F:\MSSQL2022\MSSQL16.' + $InstName + '\MSSQL\Backup'
		$UserDBDir = '/SQLUSERDBDIR=F:\MSSQL2022\MSSQL16.' + $InstName + '\Data'
		$UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MSSQL2022\MSSQL16.' + $InstName + '\Log'
		$TempDBDir = '/SQLTEMPDBDIR=H:\MSSQL2022\MSSQL16.' + $InstName + '\Tempdb'

		$ASDataDir = '/ASDATADIR=F:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Data'
		$ASLogDir = '/ASLOGDIR=G:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Log'
		$ASBackupDir = '/ASBACKUPDIR=F:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Backup'
		$ASTempDir = '/ASTEMPDIR=H:\MSSQL2022\MSAS16.' + $InstName + '\OLAP\Temp'

	}



#*********** Lab DML*************
IF ($SPackVer -eq "RTM")
{
	   $LabSetup =  $LabSQLDML + "\Binaries\SQL2022EE_RTM_UNZIP\setup.exe"	#For RTM
	   
 }

$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

#*********** NA DML *************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2022EE_RTM_UNZIP\setup.exe"	#For SP1
   
}
else
{
   $NASetup  = $NASQLDML + "\Binaries\SQL2022STD_RTM_UNZIP\setup.exe"	#For SP1
}
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
}
#*********** EMEA DML*************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2022EE_RTM_UNZIP\setup.exe"	#For SP1
}
else
{
   $EMEASetup  = $EMEASQLDML + "\Binaries\SQL2022STD_RTM_UNZIP\setup.exe"	#For SP1
}
$EMEAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl

}

#*********** ASPAC DML************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2022EE_RTM_UNZIP\setup.exe"
}
else
{
   $ASPACSetup  = $ASPACSQLDML + "\Binaries\SQL2022STD_RTM_UNZIP\setup.exe"	#For SP1
}

$ASPACConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#*********** LA DML*************
IF ($SPackVer -eq "RTM")
{
IF($EDITION -eq "E")
{
  $LASetup  = $LASQLDML + "\Binaries\SQL2022EE_RTM_UNZIP\setup.exe"
}
else
{
   $LASetup  = $LASQLDML + "\Binaries\SQL2022STD_RTM_UNZIP\setup.exe"
}

$LAConfig = "/configurationfile=""" + $NASQLDML + $cnfgfl
}

#*********** Get Edition ************* 

IF($Edition -eq 'S')
{
 	$PIDNumber = $SPIDNumber 
	$SelectedEdition = 'Standard Edition..'
}
ELSEIF($Edition -eq 'E')
{
	$PIDNumber = $EPIDNumber 
	$SelectedEdition = 'Enterprise Edition..'
}
ELSE 
{
        Write-Host ""
        Write-Host "Pass S for Standard or E for Enterprise edition as 3rd parameter" -f red
        Write-Host ""

	Exit 0
}

}



#*************************** Function Verify SQL Install ***************************

Function verifySQLInstall()
{

IF ($ver -eq "SQL2014")
{
	write-host "Inside verifySQLInstall"  #Atul on 12/11/2018#
		$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
			$Path = 'C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\' + $LatestFolder
		$file_txt = 'C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\Summary.txt'	
		write-host "verifySQLInstall completed"  #Atul on 12/11/2018#
}
	
ELSEIF ($ver -eq "SQL2012")
{
		write-host "Inside verifySQLInstall"  #Atul on 12/11/2018#
		$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
			$Path = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\' + $LatestFolder
		$file_txt = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\Summary.txt'	
		write-host "verifySQLInstall completed"  #Atul on 12/11/2018#
}
	
ELSEIF ($ver -eq "SQL2008")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log\Summary.txt'
}
ELSEIF ($ver -eq "SQL2005")
{
	$file_txt = 'C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\LOG\Summary.txt'
}

ELSEIF ($ver -eq "SQL2016")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log\Summary.txt'
}

ELSEIF ($ver -eq "SQL2017")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\Summary.txt'
}

ELSEIF ($ver -eq "SQL2019")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\150\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\150\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\150\Setup Bootstrap\Log\Summary.txt'
}

ELSEIF ($ver -eq "SQL2022") #Shubham 26/02/2024
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\160\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
    	$Path = 'C:\Program Files\Microsoft SQL Server\160\Setup Bootstrap\Log\' + $LatestFolder
	$file_txt = 'C:\Program Files\Microsoft SQL Server\160\Setup Bootstrap\Log\Summary.txt'
}

IF ($ver -eq "SQL2008")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*GlobalRules.txt"
}
ELSEIF ($ver -eq "SQL2012")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}
ELSEIF ($ver -eq "SQL2014")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}
ELSEIF ($ver -eq "SQL2016")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}

ELSEIF ($ver -eq "SQL2017")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}

ELSEIF ($ver -eq "SQL2019")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}

ELSEIF ($ver -eq "SQL2022")
{
	$SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
}

IF (($ver -eq "SQL2014") -or ($ver -eq "SQL2012") -or ($ver -eq "SQL2008") -or ($ver -eq "SQL2016") -or ($ver -eq "SQL2017") -or ($ver -eq "SQL2019") -or ($ver -eq "SQL2022"))
{
write-host "Inside sddc_sql_Installation_Verification file creation 1" #Atul on 12/11/2018 #

	$ResultFile = $Path + "\" + $SummaryFile
	$exitmsg = (Get-Content $ResultFile)[2].Trim()

	If ($exitmsg -eq "Exit code (Decimal):           -2067919934")
	{
    	  Write-Host ""
    	  Write-Host "A Computer restart is required. Installation of $ver instance $($InstName) : " -f white -nonewline; Write-Host "FAILED" -f red
    	  Write-Host ""
    	  "" >> $Log
    	  "A Computer restart is required. Installation of $ver instance $InstName : FAILED" >> $Log
	  "FAILED" > $BatchOutput2
	  EXIT 0
	}

    $Time = get-date -Uformat "%Y%m%d%H%M"

    $s1 = (Get-Content $file_txt)[1]
    $s2 = (Get-Content $file_txt)[3]
    $s3 = (Get-Content $file_txt)[4]
    $s4 = (Get-Content $file_txt)[2].Trim()
    #$exitcode = "  Final result:                  Passed"
    $exitPass  = "Exit code (Decimal):           0"
    $exitPassReboot  = "Exit code (Decimal):           3010"

    write-host "Inside sddc_sql_Installation_Verification file creation 2" #Atul on 12/11/2018 #
    ################External Files##########################
    $Log = "C:\SQLInstall_Logs\sddc_sql_Installation_Verification_$Time.txt"

    Write-host ""
    Write-Host "#######################################################################"
    "#######################################################################" > $Log
	write-host "sddc_sql_Installation_Verification log file created" #Atul on 12/11/2018 #
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >> $Log
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >> $Log
    Write-Host "Executed On: $Exec_Time"
    "Execute On: $Exec_Time" >> $Log
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >> $Log
    "Execution string: $ScriptName $Process $ver $SPackVer $Edition $InstName" >> $Log

    Write-Host "#######################################################################"
    "#######################################################################" >> $Log


    if ($s4 -eq $exitPass)  
    {
    	Write-Host ""
    	Write-Host "Installation of $ver instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL" -f green
    	Write-Host ""
    	"" >> $Log
    	"Installation of $ver instance $InstName : SUCCESSFUL" >> $Log
	"SUCCESS" > $BatchOutput2
    }
    ELSEIF ($s4 -eq $exitPassReboot)
    {
    	Write-Host ""
    	Write-Host "Installation of $ver instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL, but reboot the server before proceeding to next step" -f red
    	Write-Host ""
    	"" >> $Log
    	"SUCCESSFUL, but reboot the server before proceeding to next step" >> $Log
	"REBOOT" > $BatchOutput2
    }
    ELSE
    {
    	Write-Host ""
    	Write-Host "Installation of $ver instance $InstName : " -f white -nonewline; Write-Host "FAILED" -f red
    	Write-Host ""
    	"" >> $Log
    	"Installation of $ver instance $InstName : FAILED" >> $Log
	"FAILED" > $BatchOutput2
    }

        Write-Host ""
        Write-Host "------------------------ Installation Summary -------------------------"  
        Write-Host ""
        Write-Host "$s1"
        Write-Host "$s2"
        Write-Host "$s3"
        Write-Host ""

        "" >> $Log
        "------------------------ Installation Summary -------------------------"  >> $log
        "" >> $Log
        "$s1" >> $log
        "$s2" >> $log
        "$s3" >> $log

        $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances

}

ELSEIF ($ver -eq "SQL2005")

{

    ################External Files##########################
    $Log = "C:\SQLInstall_Logs\sddc_sql_Installation_Verification_$Time.txt"

    Write-host ""
    Write-Host "#######################################################################"
    "#######################################################################" > $Log
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >> $Log
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >> $Log
    Write-Host "Executed On: $Exec_Time"
    "Execute On: $Exec_Time" >> $Log
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >> $Log
    "Execution string: $ScriptName $Process $ver $SPackVer $Edition $InstName" >> $Log

    Write-Host "#######################################################################"
    "#######################################################################" >> $Log



If (get-content $file_txt | select-string -pattern "Error String    :" -encoding ASCII | select -last 1)

{

    	Write-Host ""
    	Write-Host "Installation of $ver instance $InstName : " -f white -nonewline; Write-Host "FAILED" -f red
    	Write-Host ""
    	"" >> $Log
    	"Installation of $ver instance $InstName : FAILED" >> $Log
	"FAILED" > $BatchOutput2

	Write-Host "Installation failed with below error messages in log file: "
	Write-Host ""
	"Installation failed with below error messages in log file: " >> $Log
	"" >> $Log
	$demo = get-content $file_txt
	$demo | select-string "Error String    :" | %{($_.line).substring(($_.line).IndexOf(":")+1)}
	$demo | select-string "Error String    :" | %{($_.line).substring(($_.line).IndexOf(":")+1)} >> $Log

}

ELSE

{

    	Write-Host ""
    	Write-Host "Installation of $ver instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL" -f green
    	Write-Host ""
    	"" >> $Log
    	"Installation of $ver instance $InstName : SUCCESSFUL" >> $Log
	"SUCCESS" > $BatchOutput2

}



    	# $s1 = (Get-Content $file_txt)[-3].Trim()

        Write-Host ""
        Write-Host "------------------------ Installation Summary -------------------------"  
        Write-Host ""

        "" >> $Log
        "------------------------ Installation Summary -------------------------"  >> $log
        "" >> $Log
    	

        $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
}

        # Verify SQL instances
        foreach ($inst in $instances)
        {
        $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	

	IF (($ver -eq "SQL2014") -and ($p -eq 'MSSQL12.' + $InstName))
	 {
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"

	}
ELSEIF (($ver -eq "SQL2016") -and ($p -eq 'MSSQL13.' + $InstName))
	 {
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"

	}

ELSEIF (($ver -eq "SQL2017") -and ($p -eq 'MSSQL14.' + $InstName))
	 {
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"

	}


ELSEIF (($ver -eq "SQL2019") -and ($p -eq 'MSSQL15.' + $InstName))
{
		  $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
		  $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
		  $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
		  $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
		  $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
		  $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
		  $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
		  $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
		  $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
		  $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
		  $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
		  $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
		  $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
		  $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
		  $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
		

	   # Update values
		
	   "  Instance Name:  	 	 $inst" >> $Log
	   "  CurrentVersion: 		 $CurrentVersion" >> $Log
	   "  SP: 				 $SP" >> $Log
	   "  Language: 			 $Language" >> $Log
	   "  Edition: 			 $Edition" >> $Log
	   "  PatchLevel:	 		 $PatchLevel" >> $Log
	   "  Collation:	 		 $Collation" >> $Log
	   "  SQLPath:		 	 $SQLPath" >> $Log
	   "  DataDirectory: 		 $SQLDataDir" >> $Log
	   "  BackupDirectory:		 $BackupDir" >> $Log
	   "" >> $Log
	   "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log. " >> $Log
	   "" >> $Log
	   "-----------------------------------------------------------------------" >> $Log

		
	   write-host "  Instance Name:  	 	" $inst
	   Write-Host "  CurrentVersion: 		" $CurrentVersion
	   Write-Host "  SP: 				" $SP
	   Write-Host "  Language: 			" $Language
	   Write-Host "  Edition: 			" $Edition
	   Write-Host "  PatchLevel:	 		" $PatchLevel
	   Write-Host "  Collation:	 		" $Collation
	   Write-Host "  SQLPath:		 	" $SQLPath
	   Write-Host "  Data Directory		" $SQLDataDir
	   Write-Host "  Backup Directory		" $BackupDir
	   #Write-Host "  Is Cluster? :		" $Cluster
	   #Write-Host "  ClusterName:	 	" $ClusterName
	   #Write-Host "  TCPPort: 		" $TCPPort   
	   #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
	   Write-Host ""
	   Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log. "
	   Write-Host ""
	   Write-Host "#######################################################################"

  }

  ELSEIF (($ver -eq "SQL2022") -and ($p -eq 'MSSQL16.' + $InstName)) #Shubham 26/02/2024
{
		  $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
		  $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
		  $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
		  $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
		  $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
		  $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
		  $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
		  $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
		  $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
		  $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
		  $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
		  $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
		  $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
		  $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
		  $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
		

	   # Update values
		
	   "  Instance Name:  	 	 $inst" >> $Log
	   "  CurrentVersion: 		 $CurrentVersion" >> $Log
	   "  SP: 				 $SP" >> $Log
	   "  Language: 			 $Language" >> $Log
	   "  Edition: 			 $Edition" >> $Log
	   "  PatchLevel:	 		 $PatchLevel" >> $Log
	   "  Collation:	 		 $Collation" >> $Log
	   "  SQLPath:		 	 $SQLPath" >> $Log
	   "  DataDirectory: 		 $SQLDataDir" >> $Log
	   "  BackupDirectory:		 $BackupDir" >> $Log
	   "" >> $Log
	   "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\160\Setup Bootstrap\Log. " >> $Log #need change
	   "" >> $Log
	   "-----------------------------------------------------------------------" >> $Log

		
	   write-host "  Instance Name:  	 	" $inst
	   Write-Host "  CurrentVersion: 		" $CurrentVersion
	   Write-Host "  SP: 				" $SP
	   Write-Host "  Language: 			" $Language
	   Write-Host "  Edition: 			" $Edition
	   Write-Host "  PatchLevel:	 		" $PatchLevel
	   Write-Host "  Collation:	 		" $Collation
	   Write-Host "  SQLPath:		 	" $SQLPath
	   Write-Host "  Data Directory		" $SQLDataDir
	   Write-Host "  Backup Directory		" $BackupDir
	   #Write-Host "  Is Cluster? :		" $Cluster
	   #Write-Host "  ClusterName:	 	" $ClusterName
	   #Write-Host "  TCPPort: 		" $TCPPort   
	   #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
	   Write-Host ""
	   Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\160\Setup Bootstrap\Log. " #need change
	   Write-Host ""
	   Write-Host "#######################################################################"

  }


	ELSEIF (($ver -eq "SQL2012") -and ($p -eq 'MSSQL11.' + $InstName))

	{
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"
	}


	ELSEIF (($ver -eq "SQL2008") -and ($p -eq 'MSSQL10.' + $InstName))

	{

           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $Cluster=(Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster")
           $ClusterName=If ($Cluster) {(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName} else {"Null"}
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $Collation=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Collation
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Language: 			 $Language" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  Collation:	 		 $Collation" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  Collation:	 		" $Collation
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        #Write-Host "  Is Cluster? :		" $Cluster
        #Write-Host "  ClusterName:	 	" $ClusterName
        #Write-Host "  TCPPort: 		" $TCPPort   
        #Write-Host "  NumErrorLogs: 		" $NumErrorLogs
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log. "
        Write-Host ""
        Write-Host "#######################################################################"

	}

	ELSEIF (($ver -eq "SQL2005") -and ($p -like 'MSSQL.*'))

	{

           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst

           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel
           $SQLPath=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLPath
           $SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot
           $TCPPort=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
           $BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
           $NumErrorLogs=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").NumErrorLogs
         

        # Update values
         
        "  Instance Name:  	 	 $inst" >> $Log
        "  CurrentVersion: 		 $CurrentVersion" >> $Log
        "  SP: 				 $SP" >> $Log
        "  Edition: 			 $Edition" >> $Log
        "  PatchLevel:	 		 $PatchLevel" >> $Log
        "  SQLPath:		 	 $SQLPath" >> $Log
        "  DataDirectory: 		 $SQLDataDir" >> $Log
        "  BackupDirectory:		 $BackupDir" >> $Log
        "" >> $Log
        "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\LOG. " >> $Log
        "" >> $Log
        "-----------------------------------------------------------------------" >> $Log

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host "  SQLPath:		 	" $SQLPath
        Write-Host "  Data Directory		" $SQLDataDir
        Write-Host "  Backup Directory		" $BackupDir
        Write-Host ""
        Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\LOG. "
        Write-Host ""
        Write-Host "#######################################################################"

	}

    }


}
#*************************** End of Verify SQL Install Function ***************************

#*************************** InstallSQLInstance Function ***************************

Function InstallSQLInstance
{
Param(
	[string] $setp,
    [string] $ConfigFile,
	[string] $Dlocation,
	[string] $PCUSource,
	[string] $PatchSource	
     )

IF ($ver -eq "SQL2014")

{
        Write-Host ""
        Write-Host "---- Installing SQL2014 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""
		write-host "Inside InstallSQLInstance for $ver"  # Atul on 12/11/2018 #

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource

    	# WRITE-HOST "Installation completed..."
		write-host "InstallSQLInstance Completed"  # Atul on 12/11/2018 #
        
}

ELSEIF ($ver -eq "SQL2012")

{
        Write-Host ""
        Write-Host "---- Installing SQL2012 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""
		
		write-host "Inside InstallSQLInstance for $ver"  # Atul on 12/11/2018 #

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource
	
        
    	# WRITE-HOST "Installation completed..."
		write-host "InstallSQLInstance Completed"  # Atul on 12/11/2018 #       
}

ELSEIF ($ver -eq "SQL2016")

{
        Write-Host ""
        Write-Host "---- Installing SQL2016 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource 

    	
        
}
ELSEIF ($ver -eq "SQL2017")

{
        Write-Host ""
        Write-Host "---- Installing SQL2017 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource 

    	# WRITE-HOST "Installation completed..."
        
}

ELSEIF ($ver -eq "SQL2019")

{
        Write-Host ""
        Write-Host "---- Installing SQL2019 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource 

    	# WRITE-HOST "Installation completed..."
        
}

ELSEIF ($ver -eq "SQL2022") #Shubham

{
        Write-Host ""
        Write-Host "---- Installing SQL2022 instance $InstName" $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""
		
		write-host "Inside InstallSQLInstance for $ver"  

	& $setp $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $PIDNumber $Updates $PatchSource
	
        
    	# WRITE-HOST "Installation completed..."
		write-host "InstallSQLInstance Completed"  # Atul on 12/11/2018 #       
}


ELSEIF ($ver -eq "SQL2008")
{
#	$Filpathlab = "file:\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\Binaries\*"    
#	$FilpathNA  = "file:\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\*"     
#	$FilpathEMEA  = "file:\\itsbebec1snap01.jnj.com\msqldml\Binaries\*"    
#	$FilpathASPAC  = "file:\\itssgsgc1snap01.jnj.com\msqldml\Binaries\*"     
#	$FilpathLA  = 	"file:\\itsusrac1ts1.jnj.com\msqldml\Binaries\*"     

# Start-Process "cmd.exe /c" -FilePath "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\Development\AS_RS\caspol.cmd" -Wait

#*********** UNC path to access DML, as per the recommendation by the Windows team and Microsoft *************# 
<#----------    New code start- WIP --------#>

     $cas64 = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\caspol.exe' 
     $cas32 = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\caspol.exe' 

	If (!(Test-Path C:\Caspolexclude))
	{
	  MKDIR "C:\Caspolexclude"
	}

	$cmdLog = 'C:\Caspolexclude\caspolexclude.txt'

	start-process -FilePath $cas64 -ArgumentList '-pp off'
	start-process -FilePath $cas32 -ArgumentList '-pp off'


	  IF ($Dlocation -eq "on LAB Server")
	    {
 		start-process -FilePath $cas32 -ArgumentList '-m -ag 1 -url file:\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\Binaries\* FullTrust -exclusive on'    
		start-process -FilePath $cas64 -ArgumentList '-m -ag 1 -url file:\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\Binaries\* FullTrust -exclusive on'    
	    }
	  ELSEIF ($Dlocation -eq "on NA Server")
	    	
	    {
 		start-process -FilePath $cas32 -ArgumentList '-m -ag 1 -url file:\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\* FullTrust -exclusive on'
 		start-process -FilePath $cas64 -ArgumentList '-m -ag 1 -url file:\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\* FullTrust -exclusive on'
	    }
	  ELSEIF ($Dlocation -eq "on EMEA Server")
	    {
 		start-process -FilePath $cas32 -ArgumentList '-m -ag 1 -url file:\\itsbebec1snap01.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
 		start-process -FilePath $cas64 -ArgumentList '-m -ag 1 -url file:\\itsbebec1snap01.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
	    }
	  ELSEIF ($Dlocation -eq "on ASPAC Server")
	    {
 		start-process -FilePath $cas32 -ArgumentList '-m -ag 1 -url file:\\itssgsgc1snap01.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
 		start-process -FilePath $cas64 -ArgumentList '-m -ag 1 -url file:\\itssgsgc1snap01.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
	    }
	  ELSEIF ($Dlocation -eq "on LA Server")
	    {
 		start-process -FilePath $cas32 -ArgumentList '-m -ag 1 -url file:\\itsusrac1ts1.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
 		start-process -FilePath $cas64 -ArgumentList '-m -ag 1 -url file:\\itsusrac1ts1.jnj.com\msqldml\Binaries\* FullTrust -exclusive on'    
	    }

# Commented by Atul based on Microsofts recommendation- Case # 116062414332891 - 6/25/2016
<#

	start-process -FilePath $cas64 -ArgumentList '-pp off'
	start-process -FilePath $cas32 -ArgumentList '-pp off'


	$yes = new-Object System.Management.Automation.Host.ChoiceDescription "&Yes","help";
	$no = new-Object System.Management.Automation.Host.ChoiceDescription "&No","help";
	$choices = [System.Management.Automation.Host.ChoiceDescription[]]($yes,$no);
	$answer = $host.ui.PromptForChoice($caption,$message,$choices,0)

	switch ($answer)
	{
	    0 {""; continue}
	    1 {""; break}
	}
#>

<#----------    New code end- WIP --------#>

        Write-Host ""
        Write-Host "---- Installing SQL2008 instance $InstName"  $SelectedEdition $Dlocation 
        Write-Host ""
        Write-Host ""

 	IF ($SPackVer -eq "SP4")
	 {

	    # Write-Host "$setp $Action $ConfigFile $PCUSource $PatchSource $InstParamID $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber" 
	    & $setp $Action $ConfigFile $PCUSource $PatchSource $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber 
	 }
	ELSEIF ($SPackVer -eq "SP4_10.00.6556")
	 {

	    # Write-Host "$setp $Action $ConfigFile $PCUSource $InstParamID $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber" 
	    & $setp $Action $ConfigFile $PCUSource $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber 
	 }
	ELSEIF ($SPackVer -eq "SP3")
	 {

	    # Write-Host "$setp $Action $ConfigFile $PCUSource $InstParamID $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber" 
	    & $setp $Action $ConfigFile $PCUSource $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $PIDNumber 
	 }

	# Write-Host ""
    	# WRITE-HOST "Applying Security hotfix MS15-058. Please wait..." Run the security hotfix MS15-058 installatinon from TMP-7664
	# Write-Host ""

	# & $PatchSource /quiet /ACTION=Patch /INSTANCENAME=$iName | Out-Null

	#VerifySQLInstall

}

ELSEIF ($ver -eq "SQL2005")

{

        Write-Host ""
        Write-Host "------Installing SQL2005 instance $InstName"  $SelectedEdition $Dlocation
        Write-Host ""
        Write-Host ""

#	To suppress the Program Compatibility assistant dialog box which pops up during installation.

	$RegKey ="HKLM:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags"
	$RegKey_cur = (get-itemproperty 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags').ApphelpUIExe
	$RegKey_new = $RegKey_cur + "_1"
	Set-ItemProperty -Path $RegKey -Name ApphelpUIExe -Value $RegKey_new

	# & $setp /qn $ConfigFile $PIDNumber

	Start-Process "cmd.exe" "/c $setp /qn $ConfigFile $PIDNumber" -Wait
    	# WRITE-HOST "Patching with SP4..."
	Start-Process "cmd.exe" "/c $PatchSource /instancename=MSSQLSERVER /quiet" -Wait
        VerifySQLInstall

#	To reset the Program Compatibility assistant dialog box registry key.

	Set-ItemProperty -Path $RegKey -Name ApphelpUIExe -Value $RegKey_cur
}



}
#*************************** End InstallSQLInstance Function ***************************

#*************************** Verify if the instance already exists ***************************

IF (Test-Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')

{

	$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances

	IF (($instances -ne $null) -and ($ver -eq "SQL2014"))
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	# IF($dinst -eq 'MSSQL12.' + $InstName)
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	# Exit 0    
		}
	 }


	}
        ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2016"))
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	# IF($dinst -eq 'MSSQL13.' + $InstName)
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	Exit 0    
		}
	 }


	}

	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2017"))
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	Exit 0    
		}
	 }


	}

	
	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2019"))
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	Exit 0    
		}
	 }


	}

	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2022")) #Shubham 26/02/2024
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	Exit 0    
		}
	 }


	}

	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2012"))
	{
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	# IF($dinst -eq 'MSSQL11.' + $InstName)
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	Exit 0    
		}
	 }


	}
	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2008"))
	{
	
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	# IF($dinst -eq 'MSSQL10.' + $InstName)
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
        		Exit 0    
		}
	 }
	}
	ELSEIF (($instances -ne $null) -and ($ver -eq "SQL2005"))
	{
	
	 foreach ($inst in $instances)
	 {
	 	$dinst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
	 	# IF($dinst -eq 'MSSQL.' + $InstName)
	 	IF($inst -eq 'MSSQLSERVER')
		{
			Write-Host ""
	#		Write-host "Instance $InstName already exists. Please pass a different name"	Un-comment later for named instance installs.
			Write-host "A default instance $InstName already exists."		#Delete this line later for named instance installs.
			Write-Host ""
			"FAILED" > $BatchOutput2  
	        	# Exit 0    
		}
	 }
	}
	
}
	
ELSE

{

	# Fresh install

}

Function JNU()
{

IF (($SPackVer -eq "SP4_11.0.7462") -and ($ver -eq "SQL2012"))
{
 write-host "Inside JNU"   # Atul on 12/11/2018 #
 $NAPC = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2012SP\sqlserver2012-kb4057116-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
 Invoke-Expression -command $NAPC | out-null;
 start-sleep -s 600
 $ErrorActionPreference = "SilentlyContinue"
 write-host "JNU Completed"   # Atul on 12/11/2018 #
 #VerifySQLInstall
}

ELSEIF (($SPackVer -eq "SP2_12.0.5589") -and ($ver -eq "SQL2014"))

{
	write-host "Inside JNU"   # Atul on 12/11/2018 #
	$NAG = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAG | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
	write-host "JNU Completed"   # Atul on 12/11/2018 #
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP4_10.00.6556") -and ($ver -eq "SQL2008"))

{
    $NAP = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2008SP4N\sqlserver2008-kb4057114-x64.exe /allinstances /quiet"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 480
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP3_13.0.6419") -and ($ver -eq "SQL2016"))

{
    $NAP = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\SP_HF_QA\SQL2016\SQLServer2016-KB5014355-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
IF (($SPackVer -eq "RTM") -and ($ver -eq "SQL2019"))
{
 write-host "Inside JNU"   # Atul on 12/11/2018 #
 $NAPC = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019\15.0.4249.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
 Invoke-Expression -command $NAPC | out-null;
 start-sleep -s 600
 $ErrorActionPreference = "SilentlyContinue"
 write-host "JNU Completed"   # Atul on 12/11/2018 #
 #VerifySQLInstall
}

}

Function JNUEM()
{

IF (($SPackVer -eq "SP4_11.0.7462") -and ($ver -eq "SQL2012"))
{
 $NAPC = "\\itsbebec1snap01.jnj.com\msqldml\Binaries\SQL2012SP4_7462\sqlserver2012-kb4057116-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms" 
 Invoke-Expression -command $NAPC | out-null;
 start-sleep -s 600
 $ErrorActionPreference = "SilentlyContinue"
 #VerifySQLInstall
}

ELSEIF (($SPackVer -eq "SP2_12.0.5589") -and ($ver -eq "SQL2014"))

{
    $NAG = "\\itsbebec1snap01.jnj.com\msqldml\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAG | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP4_10.00.6556") -and ($ver -eq "SQL2008"))

{
    $NAP = "\\itsbebec1snap01.jnj.com\msqldml\Binaries\SQL2008SP4_6556\sqlserver2008-kb4057114-x64.exe /allinstances /quiet"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 480
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP2_13.0.5201") -and ($ver -eq "SQL2016"))

{
    $NAP = "\\itsbebec1snap01.jnj.com\msqldml\SP_HF_QA\SQL2016\SQLServer2016-KB5014355-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
}

Function JNUAS()
{

IF (($SPackVer -eq "SP4_11.0.7462") -and ($ver -eq "SQL2012"))
{
 $NAPC = "\\itssgsgc1snap01.jnj.com\msqldml\Binaries\SQL2012SP4_7462\sqlserver2012-kb4057116-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms" 
 Invoke-Expression -command $NAPC | out-null;
 start-sleep -s 600
 $ErrorActionPreference = "SilentlyContinue"
 #VerifySQLInstall
}

ELSEIF (($SPackVer -eq "SP2_12.0.5589") -and ($ver -eq "SQL2014"))

{
    $NAG = "\\itssgsgc1snap01.jnj.com\msqldml\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAG | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP4_10.00.6556") -and ($ver -eq "SQL2008"))

{
    $NAP = "\\itssgsgc1snap01.jnj.com\msqldml\Binaries\SQL2008SP4_6556\sqlserver2008-kb4057114-x64.exe /allinstances /quiet"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 480
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP2_13.0.5201") -and ($ver -eq "SQL2016"))
{
    $NAP = "\\itssgsgc1snap01.jnj.com\msqldml\SP_HF_QA\SQL2016\SQLServer2016-KB5014355-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
}


Function JNULA()
{

IF (($SPackVer -eq "SP4_11.0.7462") -and ($ver -eq "SQL2012"))
{
 $NAPC = "\\itsusrac1ts1.jnj.com\msqldml\Binaries\SQL2012SP4_7462\sqlserver2012-kb4057116-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms" 
 Invoke-Expression -command $NAPC | out-null;
 start-sleep -s 600
 $ErrorActionPreference = "SilentlyContinue"
 #VerifySQLInstall
}

ELSEIF (($SPackVer -eq "SP2_12.0.5589") -and ($ver -eq "SQL2014"))

{
    $NAG = "\\itsusrac1ts1.jnj.com\msqldml\Binaries\SQL2014SP2_5589\sqlserver2014-kb4130489-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAG | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP4_10.00.6556") -and ($ver -eq "SQL2008"))

{
    $NAP = "\\itsusrac1ts1.jnj.com\msqldml\Binaries\SQL2008SP4_6556\sqlserver2008-kb4057114-x64.exe /allinstances /quiet"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 480
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
ELSEIF (($SPackVer -eq "SP3_13.0.6419") -and ($ver -eq "SQL2016"))
{
    $NAP = "\\itsusrac1ts1.jnj.com\msqldml\SP_HF_QA\SQL2016\SQLServer2016-KB5014355-x64.exe /allinstances /quiet /IAcceptSQLServerLicenseTerms"
    Invoke-Expression -command $NAP | out-null;
    #invoke-command {& $NASSM /install /quiet /IAcceptSQLServerLicenseTerms  }
    start-sleep -s 720
    $ErrorActionPreference = "SilentlyContinue"
    #VerifySQLInstall

}
}
#*********** End of Verifying if the instance already existis*************


#****************** Identify server location based on IP address *****************
 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	$location = "on LAB Server"
	InstallSQLInstance $LabSetup $LabConfig $location $LABPCU $LabPatch
 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 
	$location =  "on NA Server"
	    write-host "Before InstallSQLInstance"   # Atul on 12/11/2018 # 
    	InstallSQLInstance $NASetup $NAConfig $location $NAPCU $NAPatch
		write-host "After InstallSQLInstance"   # Atul on 12/11/2018 # 
		write-host "Before JNU"   # Atul on 12/11/2018 #
        JNU
		write-host "After JNU"   # Atul on 12/11/2018 # 
		write-host "Before VerifySQLInstall"   # Atul on 12/11/2018 #
		# Commented in Function calling out Explictly for lower patch versions #
		VerifySQLInstall 
		write-host "After verifySQLInstall"   # Atul on 12/11/2018 # 

 }
 ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 { 	
	$location = "on LA Server"
	InstallSQLInstance $LASetup $LAConfig $location $LAPCU $LAPatch
    	JNULA
		# Commented in Function calling out Explictly for lower patch versions #
		VerifySQLInstall 
 }
 ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 { 	
	$location = "on EMEA Server"
    	InstallSQLInstance $EMEASetup $EMEAConfig $location $EMEAPCU $EMEAPatch
        JNUEM
		# Commented in Function calling out Explictly for lower patch versions #
		VerifySQLInstall
 }
 ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 { 	
	$location = "on ASPAC Server"
    	InstallSQLInstance $ASPACSetup $ASPACConfig $location $APACPCU $ASPACPatch
        JNUAS
		# Commented in Function calling out Explictly for lower patch versions #
		VerifySQLInstall
 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
 }

}

start-sleep -s 240
#******************End of identifying server location based on IP address *****************


#****************** Installing SSRS for 2017 ***************** #

IF (($ver -eq "SQL2017") -and  ($Edition = 'S') )
{
   Write-host "Installing SSRS for 2017" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017EE_ML\SQL2017RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=PHDV4-3VJWD-N7JVP-FGPKY-XBV89
   $SSRS
   Write-host "2017 SSRS Installation complete " -f green
}

ELSEIF (($ver -eq "SQL2017") -and  ($Edition = 'E') )
{
   Write-host "Installing SSRS for 2017" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017EE_ML\SQL2017RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=6GPYM-VHN83-PHDM2-Q9T2R-KBV83
   $SSRS
   Write-host "2017 SSRS Installation complete " -f green
}


IF (($ver -eq "SQL2019") -and  ($Edition = 'S') )
{
   Write-host "Installing SSRS for 2019" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019_RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=PMBDC-FXVM3-T777P-N4FY8-PKFF4
   $SSRS
   Write-host "2019 SSRS Installation complete " -f green
}

ELSEIF (($ver -eq "SQL2019") -and  ($Edition = 'E') )
{
   Write-host "Installing SSRS for 2019" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019_RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=2C9JR-K3RNG-QD4M4-JQ2HR-8468J
   $SSRS
   Write-host "2019 SSRS Installation complete " -f green
}

IF (($ver -eq "SQL2022") -and  ($Edition = 'S') )
{
   Write-host "Installing SSRS for 2022" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019_RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=PMBDC-FXVM3-T777P-N4FY8-PKFF4
	$SSRS
   Write-host "2022 SSRS Installation complete " -f green
}

ELSEIF (($ver -eq "SQL2022") -and  ($Edition = 'E') )
{
   Write-host "Installing SSRS for 2022" -f green
   $SSRS = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019_RS\SQLServerReportingServices.exe /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms /PID=2C9JR-K3RNG-QD4M4-JQ2HR-8468J
   $SSRS
   Write-host "2022 SSRS Installation complete " -f green
}

start-sleep -s 120

#********************************END OF SSRS INSTALLATION ********************************* #


#****************** Installing SSMS for 2016, 2017 and 2019 *****************
IF (($SPackVer -eq "SP2_13.0.5201") -or ($SPackVer -eq "SP2") -and ($ver -eq "SQL2016"))
{
   Write-host "Installing SSMS" -f green
   $NASSMS  = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2016_SSMS\SSMS-Setup-ENU.exe /install /quiet /norestart	
   
}

ELSEIF ($ver -eq "SQL2017")
  {     Write-host "Installing SSMS" -f green
   #Installing 2017 SSMS includes PowerShell Module # 
   $NASSMS  = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017_SSMS\SSMS-Setup-ENU.exe /install /quiet /norestart	
   
}

ELSEIF ($ver -eq "SQL2019")
  {     Write-host "Installing SSMS" -f green
   #Installing 2019 SSMS includes PowerShell Module # 
   $NASSMS  = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2019_SSMS\SSMS-Setup-ENU.exe /install /quiet /norestart	
   
}

ELSEIF ($ver -eq "SQL2022") 
  {     Write-host "Installing SSMS" -f green
   #Installing 2022 SSMS includes PowerShell Module # 
   $NASSMS  = \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSStaging\SQL2022_SSMS\SSMS-Setup-ENU.exe /install /quiet /norestart	
   
}
$NASSMS


start-sleep -s 240

#************************* END OF SSMS INSTALLATION MODULE **************************************** #


#****************** Installing SQL Powershell Module 2017, 2019 & 2022  *****************#

IF ($ver -eq "SQL2017")
{
    #Write-host "Installing Powershell Module for 2017" -f green
    #Xcopy /S /I /E /H "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017_SSMS\sqlserver_PS_module.zip" "c:\temp"
    #expand-archive -path "C:\Temp\sqlserver_PS_module.zip" -destinationpath "c:\temp"

    #If (Test-Path "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080\") 
     #   { 
    #      Remove-Item "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080\" -Force -recurse 
	#	} 
    #else 
    #    { 
    #       mkdir "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080\" 
    #    }

	#Xcopy /S /I /E /H "C:\temp\sqlserver PS module\21.1.18080" "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080"
	#Import-Module SqlServer -Version 21.1.18080 
	#Write-host "Installation of Powershell Module for 2017 Completed" -f green

	Write-host "Installing Powershell Module for 2017" -f green
	$powershellmodulepath = "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080"
    if(!(Test-Path $powershellmodulepath))
    { 
		New-Item -path $powershellmodulepath -ItemType Directory
	}
    else 
    { 
        Remove-Item -path "$powershellmodulepath\*" -recurse -force
    }

    Xcopy /S /I /E /H "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017_SSMS\PS_module\sqlserver_PS_module\21.1.18080" $powershellmodulepath
	Sleep -s 120
	Import-Module SqlServer -Version 21.1.18080 
	Write-host "Installation of Powershell Module for 2017 Completed" -f green

}

ELSEIF ($ver -eq "SQL2019")
{

	Write-host "Installing Powershell Module for 2019" -f green
	$powershellmodulepath = "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080"
    if(!(Test-Path $powershellmodulepath))
    { 
		New-Item -path $powershellmodulepath -ItemType Directory
	}
    else 
    { 
        Remove-Item -path "$powershellmodulepath\*" -recurse -force
    }

    Xcopy /S /I /E /H "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017_SSMS\PS_module\sqlserver_PS_module\21.1.18080" $powershellmodulepath
	Sleep -s 120
	Import-Module SqlServer -Version 21.1.18080 
	Write-host "Installation of Powershell Module for 2019 Completed" -f green
}

ELSEIF ($ver -eq "SQL2022")
{
	
	Write-host "Installing Powershell Module for 2022" -f green
	$powershellmodulepath = "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080"
    if(!(Test-Path $powershellmodulepath))
    { 
		New-Item -path $powershellmodulepath -ItemType Directory
	}
    else 
    { 
        Remove-Item -path "$powershellmodulepath\*" -recurse -force
    }

    Xcopy /S /I /E /H "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Binaries\SQL2017_SSMS\PS_module\sqlserver_PS_module\21.1.18080" $powershellmodulepath
	Sleep -s 120
	Import-Module SqlServer -Version 21.1.18080 
	Write-host "Installation of Powershell Module for 2022 Completed" -f green
}
#*****************************END OF POWERSHELL INSTALLATION MODULE *********************************************#
Sleep -s 240

Write-host "Installation of SQL Completed Successfully " -f green


