
SET NOCOUNT ON

declare @machinName nvarchar(1000)
declare @grpName nvarchar(1000)
declare @sql nvarchar(4000)

SET @machinName = cast(SERVERPROPERTY('machinename') as nvarchar)

set @grpName = 'NT Service\ReportServer'

if not exists (select * from sys.syslogins where loginname in (@grpName))
begin
set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'

exec sp_executesql @sql


set @sql = ''
set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName,'''') + ', @rolename = ' + quotename('sysadmin','''')

exec sp_executesql @sql
end