###################################################################################################
$ScriptName = "DB_Refresh.ps1"
$Scriptver = "2.0"
#Description: Description: DBRefresh script for OneDB & MulDB Source to OneDB & MulDB target server DBRefresh.
#Example:- DB_Refresh.ps1 CHG000010331101 APP000010012177 single itssusrawsp00424 test itsusrawsp00423 test1
###################################################################################################
#Version Author		Reason for Change
###################################################################################################
#1.0	Kishore 	New Script
#2.0	Sanjiv		New Nas Modification

###################################################################################################

$RFC = $args[0]
$AppName = $args[1]
$RefreshType = $args[2]
$DBNumber = $args[3]
$SOURCE = $args[4]
$sdb = $args[5]
$TARGET = $args[6]
$Tdb = $args[7]

IF (($RFC -eq $null) -or ($AppName -eq $null) )
{
Write-host ""
Write-Host "Pass RFC as 1st parameter and AppName as 2nd parameter " -f red
Write-host ""
EXIT
}


IF (($SOURCE -eq $null) -or ($sdb -eq $null))
{
Write-host ""
Write-Host "Pass Sourceserver as 4th parameter and Source databasename as 5th parameter" -f red
Write-host ""
EXIT
}

IF (($TARGET -eq $null) -or ($Tdb -eq $null))
{
Write-host ""
Write-Host "Pass Targetserver as 5th parameter and Target databasename as 6th parameter" -f red
Write-host ""
EXIT
}

$startDTM = (Get-Date)

 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1


# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

$EMEApath = "\\itsbebec1ts1.jnj.com\sqldbrefresh_be_1\REFRESH\"
$NApath = "\\itsusrac1ts1.jnj.com\sqldbrefresh_ra_1\REFRESH\" 
$ASPACpath = "\\itssgsgc1ts1.jnj.com\sqldbrefresh_sg_1\REFRESH\"


[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

        echo $IpPartsIdentifier2
	$location =  "on NA Server"
        
    	$NApath
	
 }
 ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 { 	
	$location = "on EMEA Server"
    	$EMEApath

 }
 ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 { 	
        echo $IpPartsIdentifier2 
        $location = "on ASPAC Server"
        echo $location
    	$ASPACpath

 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
 }

}

$SBpath = "\\itssgsgc1ts1.jnj.com\sqldbrefresh_sg_1\REFRESH\" 
$SBpath = "\\itsusrac1ts1.jnj.com\sqlbrefesh_ra_1\REFRESH\" 
$SBpath = "\\itsbebec1ts1.jnj.com\sqldbrefresh_be_1\REFRESH\" 
$datetime = get-date -uformat "%Y-%m-%d@%H-%M-%S"

if($location -eq "on ASPAC Server")
{
  $SBpath = $ASPACpath+"\$RFC"+"_"+$datetime
  $TBpath = $ASPACpath + "\target"
  echo $sbpath
  echo $tbpath
}

elseif($location -eq "on EMEA Server")
{
  $SBpath = $EMEApath+"\$RFC"+"_"+$datetime
  $TBpath = $EMEApath + "\target"
  echo $sbpath
  echo $tbpath
}

elseif($location -eq "on NA Server")
{
  $SBpath = $NApath+"\$RFC"+"_"+$datetime
  $TBpath = $NApath + "\target"
  echo $tbpath
  echo $sbpath
}


if((Test-Path $SBpath) -eq 0)
{
mkdir $SBpath
}

if((Test-Path $TBpath) -eq 0)
{
mkdir $TBpath
}

$Targetfile = "\\$target\c$\DBRefreshlogs"

if((Test-Path $Targetfile ) -eq 0)
{
mkdir $Targetfile
}

#To check Log Folder
$LogFolder = $env:SystemDrive+"\DBRefreshlogs"
#echo $LogFolder

$FolderCheck = test-path $LogFolder
if (-Not($FolderCheck)) {
                New-Item $LogFolder -type directory
               
}else{
                Write-host "the log folder exist"
}
"`n"
"`n"

$date =  get-date -uFormat "%m%d%Y%H%MS"

#To Create Logfile
$LogFolder1 =  $LogFolder+"\$date"+"\$SOURCE"+"\$RFC"

$FolderCheck = test-path $LogFolder1
if (-Not($FolderCheck)) {
                New-Item $LogFolder1 -type directory
    $logfile = $LogFolder1 + "\Logfile.txt"
                if (-Not (test-Path $logfile)) {New-Item $logfile -type File}
                else {
    $logfile = $LogFolder1 + "\Logfile.txt"
                                if (-Not (test-Path $Logfile)) {New-Item $logfile -type File}
                                }
                }else{
                #Write-host "the log file created"

$logfile = $LogFolder1 + "\Logfile.txt"
if (-Not (test-Path $logfile)) {New-Item $logfile -type File}
$logfoldercheck = "the log file created"
}

Write-output "MSSQL DBRefersh Logfile" >> $logfile
Write-output ********************************************************************** >> $logfile
"`n"
Write-output RFC:$RFC >>$logfile
Write-output AppName:$AppName >>$logfile
Write-output RefreshType:$RefreshType >>$logfile
Write-output DBNumber:$DBNumber >>$logfile
Write-output SourceServer:$SOURCE >>$logfile
Write-output SourcedatabaseName:$Sdb >>$logfile
Write-output TargetServer:$Target >>$logfile
Write-output TargetDatabaseName:$tdb >>$logfile
"`n"
write-output ********************************************************************** >>$logfile

Write-host "the log file created in path $logfile" -f yellow

 #To Append Log
 
 $logfoldercheck = "the log file created"
 $Date = get-date -format g
 Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$logfoldercheck" 
$statusfile1 = "\\$source\c$\SQLInstall_Logs\refresh\"

if((Test-Path $statusfile1) -eq 0)
{
mkdir $statusfile1
}

$status300 = $statusfile1 +"\"+"$RFC-implement-status.txt"

if (Test-Path $status300) {
  Remove-Item $status300
}

$NAS = "\\$source\c$\SQLInstall_Logs\refresh\"  

if((Test-Path $NAS) -eq 0)
{
mkdir $NAS
}

$C300log = $NAS +"\"+"$RFC-AUTOMATION_SDDC_TASK300.log"

if (Test-Path $C300log) {
  Remove-Item $C300log
}

write-output "*******************************************************" >> $C300log
write-output "ChangeNumber : $rfc" >> $C300log
write-output "Source server : $source" >> $C300log
write-output "Target server : $target" >> $C300log
write-output "Source database : $sdb" >> $C300log
write-output "Target database : $tdb" >> $C300log
write-output "*******************************************************" >> $C300log


IF(($RefreshType -eq "single") -and ($dbnumber -eq "1"))
{

#$SsOURCE = $source.split('\')[0]
#$ssinstance = $source.split('\')[1]

If($SInstance -eq ""){[String]$dataSource1 = $SOURCE}
ELSE{[String]$dataSource1 = $SOURCE+"\"+$SInstance}

$connectionString1 = "Data Source=$dataSource1; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog= 'master'"

$SqlBackCmd = " declare @DefaultBack varchar(250)
            exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @DefaultBack output
               select @DefaultBack [BackupPath]"            
IF($SBpath -eq ""){
    $connectionSB = new-object system.data.SqlClient.SQLConnection($connectionString1)
    $commandSB = new-object system.data.sqlclient.sqlcommand($SqlBackCmd,$connectionSB)
    $connectionSB.Open()
    $adapterSB = New-Object System.Data.sqlclient.sqlDataAdapter $commandSB
    $datasetSB = New-Object System.Data.DataSet
    $adapterSB.Fill($datasetSB) | Out-Null
    $SBpath = $dataSetSB.Tables[0].rows[0].BackupPath
    $connectionSB.Close()
    write-host "Default Source Backup Folders is " $SBpath -foregroundcolor "YELLOW"
    }
$connectionsuccess1 = "Connection is Successfull in Source server"
write-host "Connection is Successfull in Source server" -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$connectionsuccess1" 
IF($connectionsuccess1 -eq "Connection is Successfull in Source server")
    {
    [String]$bkupdbscript = "backup database "+$Sdb+" to disk = '"+$SBpath+"\"+$source+"_"+$Sdb+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK' with copy_only"
try
  {
    $connection1 = new-object system.data.SqlClient.SQLConnection($connectionString1)
    $command1 = new-object system.data.sqlclient.sqlcommand($bkupdbscript,$connection1)
    $connection1.Open()
    $adapter1 = New-Object System.Data.sqlclient.sqlDataAdapter $command1
    $command1.commandtimeout = 0 
    $dataset1 = New-Object System.Data.DataSet
    $adapter1.Fill($dataSet1) | Out-Null
    $dataSet1.Tables
    Write-Host "Backup in progress" 
    $connection1.Close()
    }
catch 
  {
     $err = $_.Exception   
     [String]$Msg = $err.Message   
     while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message >>$C300log
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300
    }
    $issue1 = "Something went wrong while taking Backup in Source Server"
    Write-Host $issue1 -foregroundcolor "red"
    Add-Content -Path $logfile -Value "$Date`tIssue:$issue1"
    Read-Host "Press Enter to Exit"  
    
  }
finally {
     IF($Msg){
     Echo $Msg
    #break
     }
     ELSE {
     Write-host "Successfully Backed up" -foregroundcolor "GREEN"
     }
   }
}
else
  {
  Write-Host "Connection Not established" -foregroundcolor "RED"
  Read-Host "Press Enter to Exit"
  break
  }
  
IF($issue1 -ne "Something went wrong while taking Backup in Source Server")
    {
    $bakupntsuc = "Backup Successfull in the path: "+$SBpath+""  
    Write-Host $bakupntsuc -foregroundcolor "yellow"
    $Date = get-date -format g
    Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$bakupntsuc"   
    }
    ELSE
    {
    $bakupntsuc = "Unable to take backup"
    Write-Host $bakupntsuc -foregroundcolor "red"
    $Date = get-date -format g
    Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$bakupntsuc"   
    break
    }


 
 If($TInstance -eq ""){[String]$dataSourceT = $TARGET}
 ELSE{[String]$dataSourceT = $TARGET+"\"+$TInstance}

$connectionStringT = "Data Source=$dataSourceT; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog= 'master'"

Write-Host "Connection is Successfull in Target server" -f green
$connectionStringTT = "Connection is Successfull in Target server"
$Date = get-date -format g
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$connectionStringTT" 
 
 
"`n"
"`n"
  
 
  
  IF($TBpath -eq ""){
    $connectionTB = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $commandTB = new-object system.data.sqlclient.sqlcommand($SqlBackCmd,$connectionTB)
    $connectionTB.Open()
    $adapterTB = New-Object System.Data.sqlclient.sqlDataAdapter $commandTB
    $datasetTB = New-Object System.Data.DataSet
    $adapterTB.Fill($datasetTB) | Out-Null
    $TBpath = $dataSetTB.Tables[0].rows[0].BackupPath
    $connectionTB.Close()
    write-host "Default Target Backup Folder is " $TBpath -foregroundcolor "Yellow"
    }
    $SCPath = $SBpath+"\"+$source+"_"+$Sdb+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK" -replace ":", "$"
    $TCpath = $TBpath -replace ":", "$" 
    #echo $SCpath
    #echo $TCpath
    move-item $SCpath -Destination $TCpath
    write-host "Backup copied from $SCpath to $TCpath"
    $copypath= "Backup copied from $SCpath to $TCpath"
    Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$copypath" 
 

if ($connectionStringTT -eq "Connection is Successfull in Target server")
 {

 $sqlscript2 = "SP_helpdb ["+ $Tdb+"]"       
 $sp_helpdboutput = $TCPath+"\sp_helpdboutput_"+$datetoday+".txt"


 try
 {
     $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command21 = new-object system.data.sqlclient.sqlcommand($sqlscript2,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command21 
   #$global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2) 
    $DataSet2.Tables[0] | out-file $sp_helpdboutput
    $connection.Close()
   #$dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "SP_helpdb script is executed" 
  #Write-Host "SP_helpdb script is Successful and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
   $sphelp4 = "SP_helpdb script is executed" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp4" 
   }
   
   catch 
  {
     $err = $_.Exception   
    [String]$MsgTSP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message >> $C300log
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300
    
                
    }
  }

   finally {
     IF($MsgTSB){
     Echo $MsgTSB
   $sphelp = "SP_helpdb script is not Successfull."
   write-host "SP_helpdb script is not Successfull.Check the above error" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-Host "SP_helpdb script is Successfull" -foregroundcolor "GREEN"
     Write-Host "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
   $sphelp = "SP_helpdb script is Successfull" 
   $sphelp1 = "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" 
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp1"   

     }
   }

   }
   
   else
   {
   $sphelp = "SP_helpdb script is not Successful"
   write-host "SP_helpdb script is not Successful" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
   Read-host "Press enter to exit"
     break
  } 

 if ($connectionStringTT -eq "Connection is Successfull in Target server")
 {     
  
 $sqlscriptout = "Use ["+ $Tdb +"];

SET NOCOUNT ON

DECLARE @sql VARCHAR(2048), @sort INT
create table ##tmpcmds(SQL_Stmt varchar(max))

insert into ##tmpcmds 
SELECT	'USE' +  QUOTENAME(DB_NAME()) +';' AS [-- SQL STATEMENTS --]

insert into ##tmpcmds 
SELECT 'CREATE USER [' + name + '] for login [' + name + ']'+ SPACE(1) AS [-- SQL STATEMENTS --]
 from sys.database_principals where type In ('U' , 'S' , 'G') 

insert into ##tmpcmds  
SELECT	'EXEC sp_addrolemember @rolename ='+QUOTENAME(USER_NAME(rm.role_principal_id), '''')+', @membername ='+QUOTENAME(USER_NAME(rm.member_principal_id), '''') AS [-- SQL STATEMENTS --] FROM	sys.database_role_members AS rm 
WHERE	USER_NAME(rm.member_principal_id) IN (SELECT [name] FROM sys.database_principals WHERE [principal_id] > 4 and [type] IN ('G', 'S', 'U'))

insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.state_desc ELSE 'GRANT ' END
+SPACE(1)+perm.permission_name+' ON '+QUOTENAME(SCHEMA_NAME(obj.schema_id))+'.'+QUOTENAME(obj.name) 
+ CASE
WHEN cl.column_id IS NULL THEN SPACE(0) ELSE '('+QUOTENAME(cl.name)+')' END
+' TO '+QUOTENAME(USER_NAME(usr.principal_id)) COLLATE database_default
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
FROM sys.database_permissions AS perm 
INNER JOIN sys.objects AS obj
ON perm.major_id = obj.[object_id]
INNER JOIN
sys.database_principals AS usr
ON perm.grantee_principal_id = usr.principal_id
LEFT JOIN
sys.columns AS cl
ON cl.column_id = perm.minor_id AND cl.[object_id] = perm.major_id


insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.[state_desc] ELSE 'GRANT ' END
+SPACE(1)+perm.[permission_name]
+' TO '+'['+USER_NAME(usr.[principal_id])+']' COLLATE database_default
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
FROM	sys.[database_permissions] AS perm
INNER JOIN
sys.[database_principals] AS usr
ON perm.[grantee_principal_id] = usr.[principal_id]
WHERE	[perm].[major_id] = 0
	AND [usr].[principal_id] > 4
	AND [usr].[type] IN ('G', 'S', 'U')

insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.[state_desc] ELSE 'GRANT ' END
+SPACE(1)+perm.[permission_name]
+' TO ' +perm.[class_desc]+'::' COLLATE database_default
+QUOTENAME(SCHEMA_NAME(perm.[grantee_principal_id]))
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
from sys.[database_permissions] AS perm
inner join sys.schemas s
on perm.[grantee_principal_id] = s.[schema_id] 
WHERE class = 3 



select * from ##tmpcmds
SET NOCOUNT OFF"
 $sqlscriptout_output = $TCpath+"\sqlscriptout_output_"+$datetoday+".txt"
# echo $sqlscriptout_output
  

    $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command2 = new-object system.data.sqlclient.sqlcommand($sqlscriptout,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command2 
   # $global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2)
     
    $resultcolumns=$DataSet2.Tables[0]
    foreach($dataitem in $resultcolumns.Rows)
{
$fir=$dataitem[0]
$fir|out-file $sqlscriptout_output -append
}

    $connection.Close()
   # $dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "Sqlscriptoutrun script is successfull" -foregroundcolor "GREEN"
   Write-Host "Sqlscriptoutrun script is saved in the path : $sqlscriptout_output" -foregroundcolor "YELLOW"
   $Sqlscriptoutrun = "Sqlscriptoutrun script is saved in the path : $sqlscriptout_output" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Sqlscriptoutrun" 
   
   }
   
   else
   
   {
   $Sqlscriptoutrun = "Sqlscriptoutrun script is not Successful" 
   write-host "Sqlscriptoutrun script is not Successful" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Sqlscriptoutrun"   
  } 

$sqlCommand3 = "restore filelistonly from disk = '"+$TBpath+"\"+$source+"_"+$Sdb+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK'"
    $SqlDataCmd = "declare @DefaultData varchar(250)
                exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', @DefaultData output
                select @DefaultData [DataPath]"
    $SqlLogCmd = "declare @DefaultLog varchar(250)
               exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', @DefaultLog output
               select @DefaultLog [LogPath]"            
                    
    $connectionT = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $commandT = new-object system.data.sqlclient.sqlcommand($sqlCommand3,$connectionT)
    $connectionT.Open()
    $adapterT = New-Object System.Data.sqlclient.sqlDataAdapter $commandT
    $datasetT = New-Object System.Data.DataSet 
    $adapterT.Fill($datasetT) 
    #$lognamesfolder = $LogFolder+"\$date"+"\$SOURCE"+"\names.txt"
    #$DFiles = @()
    $Lfiles = @()
    $NFiles = @()
    foreach($Row in $DatasetT.Tables[0].rows)
    {
      if($Row.Item('PhysicalName') -like '*mdf')  
      {
        $DFiles += $Row.Item('LogicalName')
       }
      if($Row.Item('PhysicalName') -like '*ldf')  
      {
        $LFiles += @($Row.Item('LogicalName'))
       }
      if($Row.Item('PhysicalName') -like '*ndf')  
      {
        $NFiles += @($Row.Item('LogicalName'))
       }
    }
    $connectionT.Close()
    
    $commandD = new-object system.data.sqlclient.sqlcommand($SqlDatacmd,$connectionT)    
    $connectionT.Open()
    $adapterD = New-Object System.Data.sqlclient.sqlDataAdapter $commandD
    $datasetD = New-Object System.Data.DataSet
    $adapterD.Fill($datasetD) | Out-Null
    #$dataSetD.Tables
    $testD = $dataSetD.Tables[0].rows[0].DataPath
    $connectionT.Close()
    
    $commandL = new-object system.data.sqlclient.sqlcommand($SqlLogCmd,$connectionT)
    $connectionT.Open()
    $adapterL = New-Object System.Data.sqlclient.sqlDataAdapter $commandL
    $datasetL = New-Object System.Data.DataSet
    $adapterL.Fill($datasetL) | Out-Null
    #$dataSetL.Tables
    $testL = $dataSetL.Tables[0].rows[0].LogPath
    $connectionT.Close()
    write-host "Default Datafile Folders is: " $testD -foregroundcolor "Yellow"
    write-host "Default Logfile Folders is: " $testL -foregroundcolor "Yellow"
    $restore1 = "restore filelistonly from disk is  successful" 
    write-host "restore filelistonly from disk is successful" -foregroundcolor "GREEN"
    Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$restore1"   




#Import-Module SQLPS -DisableNameChecking 3>$Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoExtended') | out-null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo') | out-null
$ErrorActionPreference = "SilentlyContinue"
$SQLInstanceName = "$target"
$Server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $SQLInstanceName
$DatabaseName = "$tdb"
$DBObject = $Server.Databases[$DatabaseName]
$DBObject.DatabaseOptions.UserAccess = [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]::single
$DBObject.Alter([Microsoft.SqlServer.Management.Smo.TerminationClause]"RollbackTransactionsImmediately")
$roll1 =  "$tdb database is set to single user mode"
write-host "$tdb database is set to single user mode" -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$roll1" 


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null  
$srv = new-object Microsoft.SqlServer.Management.Smo.Server("$target")
$srv.KillAllProcesses($tdb)

$time = (get-date -uformat "%Y-%m-%d@%H-%M-%S")


if($restore1 -eq "restore filelistonly from disk is  successful") 
 {
    $sqlCommand4 = $sql+ "RESTORE DATABASE "+$Tdb+" FROM  DISK =  '"+$TBpath+"\"+$source+"_"+$Sdb+"_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK' WITH 
        MOVE '"+$DFiles+"' TO '"+$testD+"\"+$DFiles+"_$time"+".mdf',"

<#
  $TMDFPath = $(read-host "Enter the preferred path for MDF file ('Hit ENTER for Default Data Folder')")
if($TMDFPath -ne ""){
        $sqlCommand4 = "RESTORE DATABASE "+$Tdb+" FROM  DISK =  '"+$TBpath+"\"+$Sdb+"_"+$datetoday+".BAK' +"WITH REPLACE,FILE = "+ WITH 
        MOVE '"+$DFiles+"' TO '"+$TMDFPath+"\"+$DFiles+".mdf',"
     }
     else {        
        $sqlCommand4 = "RESTORE DATABASE "+$Tdb+" FROM  DISK =  '"+$TBpath+"\"+$Sdb+"_"+$datetoday+".BAK' +$DFiles+"' TO '"+$testD+"\"+$DFiles+".mdf',"
        }
 #>   
    For($i=0; $i -lt $LFiles.length; $i++)
    {
        $sqlCommand4 = $sqlCommand4+" MOVE '"+$Lfiles[$i]+"' TO '"+$testL+"\"+$LFiles[$i]+"_$time"+".ldf'," 
    } 
<# 
        $TLDFPath = $(read-host "Enter the preferred path for ["$Lfiles"] file ('Hit ENTER for Default Data Folder')")   
        if($TLDFPath -ne ""){
        $sqlCommand4 = $sqlCommand4+" MOVE '"+$Lfiles[$i]+"' TO '"+$TLDFPath+"\"+$LFiles[$i]+".ldf',"
        $TLDFPath = ""
        }
        else {
        $sqlCommand4 = $sqlCommand4+" MOVE '"+$Lfiles[$i]+"' TO '"+$testL+"\"+$LFiles[$i]+".ldf',"
        }
     
#>
    For($i=0; $i -lt $NFiles.length; $i++)
    {
        $sqlCommand4 = $sqlCommand4+" MOVE '"+$Nfiles[$i]+"' TO '"+$testD+"\"+$NFiles[$i]+"_$time"+".ndf'," 
     }
<#
        $TNDFPath = $(read-host "Enter the preferred path for ["$Nfiles"] file ('Hit ENTER for Default Data Folder')")   
        if($TNDFPath -ne ""){
        $sqlCommand4 = $sqlCommand4+" MOVE '"+$Nfiles[$i]+"' TO '"+$TNDFPath+"\"+$NFiles[$i]+".ndf',"
        $TNDFPath = ""
        }
        else {
        $sqlCommand4 = $sqlCommand4+ $Nfiles[$i]+"' TO '"+$testD+"\"+$NFiles[$i]+".ndf',"
        }
     }
#>
}
#$target.ConnectionContext.StatementTimeout = 0
$sqlCommand4 = $sqlCommand4+" stats = 10, REPLACE"


$bkupdbscript = "backup database "+$Tdb+" to disk = '"+$TBpath+"\"+$target+"_"+$Tdb+"_Refresh_"+(Get-Date -Format "yyyyMMdd")+"_Full"+".BAK' with copy_only"
  try
   {
    $connectionT = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $commandTSB = new-object system.data.sqlclient.sqlcommand($bkupdbscript,$connectionT)
    $connectionT.Open()
    $adapterTSB = New-Object System.Data.sqlclient.sqlDataAdapter $commandTSB 
    $commandTSB.commandtimeout = 0
    $datasetTSB = New-Object System.Data.DataSet
    $adapterTSB.Fill($dataSetTSB) | Out-Null
    $dataSetTSB.Tables
    Write-Host "Backup successful" -foregroundcolor "green"
    $connectionT.Close()
    }
 catch 
  {
     $err = $_.Exception   
    [String]$MsgTSB = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message >> $C300log
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300
                
    }
  }
finally {
     IF($MsgTSB){
     Echo $MsgTSB
  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-host "Target database has successfully Backed up for safety as :"$bkupdbscript -foregroundcolor "YELLOW"
     $bakupntsuc = "Target database has successfully Backed up for safety as :$bkupdbscript"
     $bakupntsuc1 = "Target database has successfully Backed up for safety"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$bakupntsuc"   

     }
   }

If ($bakupntsuc1 -eq "Target database has successfully Backed up for safety")
 {
  try {  
    $connection2 = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command3 = new-object system.data.sqlclient.sqlcommand($Sqlcommand4,$connection2)
    $connection2.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command3 
    $command3.CommandTimeout = 0
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2) | out-null
    $dataSet2.Tables
    write-host "Restore in progress" -f green
    $connection2.Close()
    }
catch
    {
     #$err = $_.Exception   
    [String]$MsgR = $err.Message   
    while( $err.InnerException ) {           
        #$err = $err.InnerException           
        # write-output $err.Message>>$C300log
         write-output "*******************************************************" >> $C300log
         write-output "please check the $logfile for details">>$C300log
         write-output "*******************************************************" >> $C300log
         write-output " DB refresh failed:Return code 1" >>$C300log 
         write-output "*******************************************************" >> $C300log
         write-output "###1">>$status300
        }
        #write-host "Restoration UnSuccessful" -foregroundcolor "RED"
     #Read-host "Press enter to exit"
     #break   
        
    }
  
finally {
    if($MsgR)  {
   
        $Date = get-date -format g
        $restore2 = "Restore UnSuccessful"
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$restore2"   
        # write-host "Restoration UnSuccessful" -foregroundcolor "RED"
          #Read-host "Press enter to exit"
   #break
       
        }
    else
        {
        
        Write-host "Restore Successful" -foregroundcolor "GREEN"
        $restore2 = "Restore Successful"
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$restore2"   
        }
    }
}


$DBObject.DatabaseOptions.UserAccess = [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]::multiple
$DBObject.Alter([Microsoft.SqlServer.Management.Smo.TerminationClause]"RollbackTransactionsImmediately")
$roll = "$tdb database is set to multi user mode " 
write-host "$tdb database is set to multi user mode " -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$roll"

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null  
$srv = new-object Microsoft.SqlServer.Management.Smo.Server("$target")
$srv.KillAllProcesses($tdb)


If($restore2 -eq "Restore Successful")
  {
  $sqlscriptout_output = $TCpath+"\sqlscriptout_output_"+$datetoday+".txt"
  $ErrorActionPreference = "SilentlyContinue"
  $sqlscriptoutput2 = get-content  $sqlscriptout_output 
  
  try
  {
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlscriptoutput2,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables 
  $outputsuccess = "Output generated in step 2 was exceuted"
  write-host "Output generated in step 2 was exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
  $connection.Close()
  }
  catch 
  {
       $err = $_.Exception   
    [String]$MsgOSB = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        #write-output $err.Message 
        write-host "Output generated in step 2 was exceuted successfully :"$sqlscriptout_output -foregroundcolor "green"
        $outputsuccess1 = "Output generated in step 2 was exceuted successfully :$sqlscriptout_output"
        $outputsuccess = "Output generated in step 2 was exceuted successfully"
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess1" 
        #Read-host "Press enter to exit"
        break
    }
    
  }
<#
finally {
     IF($MsgOSB){
     #Echo $MsgOSB -foregroundcolor "RED"
     $sqlscriptout_exec = "Output generated in step 2 was exceuted successfully "
   #  write-host "SQL related issues.Kindly check the error displayed above and try to execute manually from step 5 in SOP" -foregroundcolor "RED"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sqlscriptout_exec"   
   #  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-host "Output generated in step 2 was exceuted successfully" -foregroundcolor "GREEN"
     Write-host "Output generated in step 2 was exceuted successfully :"$sqlscriptout_output -foregroundcolor "YELLOW"
     $outputsuccess1 = "Output generated in step 2 was exceuted successfully :$sqlscriptout_output"
     $outputsuccess = "Output generated in step 2 was exceuted successfully"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess1"   

     }
   }
 #> 
 }

if ($outputsuccess -eq "Output generated in step 2 was exceuted successfully")
  {
  $sqlorphan_output = $TCpath+"\sqlorphan_output_"+$datetoday+".txt"
  $sqlorphan = "Sp_change_users_login report"
  #$sqlorphan = "sp_change_users_login 'Report'"
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlorphan,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables  >>  $sqlorphan_output
  $view1= get-content $sqlorphan_output | Out-GridView
  $connection.Close()
# invoke-item "C:\logs\orphan.txt"
  $orphanscript = "Orphan script exceuted"
  write-host "Orphan script exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript"   
  }
else
 {
  $orphanscript = "Orphan script not exceuted"
  write-host "Orphan script not exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript"   
  write-host "Kindly try to execute manually from step 6 in SOP"
  Read-host "Press enter to exit"
  break
 }
  
  
   
#Running script to fix the orphaned users 

     

 

If($orphanscript -eq "Orphan script exceuted")
 {  
  
 $sqlorphan2 = "Use ["+ $Tdb +"];
  
 DECLARE @username varchar(25)

 DECLARE fixusers CURSOR 
 FOR

SELECT UserName = name FROM sysusers
WHERE issqluser = 1 and (sid is not null and sid <> 0x0)
and suser_sname(sid) is null
ORDER BY name

OPEN fixusers

FETCH NEXT FROM fixusers
INTO @username

WHILE @@FETCH_STATUS = 0
BEGIN
EXEC sp_change_users_login 'update_one', @username, @username

FETCH NEXT FROM fixusers
INTO @username
END


CLOSE fixusers
DEALLOCATE fixusers"
try
{
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlorphan2,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables
  $connection.Close()
  $orphanscript2 = "Orphan users fixing script is executed" 
  write-host "Orphan users fixing script is executed" 
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript2"   
  }
  catch 
  {
     $err = $_.Exception   
    [String]$MsgORP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        #write-output $err.Message  
        #$MsgORP >> $logfile
        #write-host "Orphan users has not been fixed.Please find the error above and Kindly try to execute manually " -foregroundcolor "RED"
        #Read-host "Press enter to exit"
        #break
    }
  }
  
  finally {
     IF($MsgORP){
    # Echo $MsgORP
    $orphanscript2 = "Orphan users has not been fixed.Please find the error above and Kindly try to execute manually"
   # write-host "Error with SQL.Please find the error above and Kindly try to execute manually " -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript2"   
  # Read-host "Press enter to exit"
   #break
   }
     
     ELSE {
     
      Write-host "Orphan users fixing script is exceuted successfully"  -foregroundcolor "GREEN"
     $orphanscript3 = "Orphan users fixing script is exceuted successfully"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript3" 
      
     }

     }
  }

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
$srv = New-Object "Microsoft.SqlServer.Management.SMO.Server" $target
$db = $srv.databases[$tdb]
echo $db.name
$rc = get-content 'c:\dba.txt'
$db.RecoveryModel = $rc
echo $db.RecoveryModel
$db.Alter() 

  if ($orphanscript -eq "Orphan script exceuted")
  {
    
  $Finalcheckscript = "SP_helpdb ["+ $Tdb+"]"       
  $Finalcheckscript_output = $TCPath+"\Finalcheckscript_output_"+$datetoday+".txt"
  try
  { 
 #echo $sp_helpdboutput
    $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command26 = new-object system.data.sqlclient.sqlcommand($Finalcheckscript,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command26 
 #$global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2) 
    $DataSet2.Tables[0] | format-list|out-file $Finalcheckscript_output
    $connection.Close()
    
    # $dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "Final script to check to Database owner and permissions has been executed" -foregroundcolor "GREEN"
   #Write-Host "Final script output to check to Database owner is saved in the path : $Finalcheckscript_output" -foregroundcolor "YELLOW"
   $Finalscript = "Final script to check to Database owner and permissions has been executed" 
  # $Finalscript1 = "Final script output to check to Database owner is saved in the path : $Finalcheckscript_output" 

   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript"  
  # Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript1"  

   }
   
   catch
   {
   
    $err = $_.Exception   
    [String]$MsgFRP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message  
         Echo $MsgFRP
         write-host "Error with SQL.Please find the error above and Kindly try to execute the last step manually from SOP" -foregroundcolor "RED"
         Read-host "Press enter to exit"
         break      
    }
  }
  
  finally {
     IF($MsgFRP){
    # Echo $MsgFRP
    $Finalscript = "Final script to check to Database owner and permissions has been not been executed properly"
   # write-host "Error with SQL.Please find the error above and Kindly try to execute the last step manually from SOP" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript"   
   #Read-host "Press enter to exit"
   #break
   }
     
     ELSE {
   # Write-Host "Final script to check to Database owner and permissions has been executed" -foregroundcolor "GREEN"
   Write-Host "Final script output to check to Database owner is saved in the path : $Finalcheckscript_output" -foregroundcolor "YELLOW"
   $Finalscript = "Final script to check to Database owner and permissions has been executed successfully" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript"  
   Get-ChildItem -Path $tbpath -Recurse -File | Move-Item -Destination $sbpath
   Remove-Item $tbpath -Force

   }

if($Finalscript -eq "Final script to check to Database owner and permissions has been executed successfully")
{
  $restore_output = $sbpath+"\restore_result.txt"
  $mydata = invoke-sqlcmd -query "SELECT TOP 2 [rs].[destination_database_name], 
  [rs].[restore_date], 
  [bs].[database_name] as [source_database_name], 
  [bmf].[physical_device_name] as [backup_file_used_for_restore]
  FROM msdb..restorehistory rs
  INNER JOIN msdb..backupset bs
  ON [rs].[backup_set_id] = [bs].[backup_set_id]
  INNER JOIN msdb..backupmediafamily bmf 
  ON [bs].[media_set_id] = [bmf].[media_set_id] 
  where [rs].[restore_date]>= DATEADD(dd, -1, GETDATE()) order by restore_date desc" -serverinstance $target -database $tdb;
  echo $mydata
  $mydata | format-list destination_database_name,restore_date,source_database_name,backup_file_used_for_restore|out-file $restore_output
  C:
}
  
if($Finalscript -eq "Final script to check to Database owner and permissions has been executed successfully")
 {
    write-host "DB Refresh is success" -f green
    write-output "###0" >> $status300
 }
else{
   write-host "DB Refresh failed please check the $logfile for details" -f red
   write-output "###1" >> $status300
           
}


if($Finalscript -eq "Final script to check to Database owner and permissions has been executed successfully")
 {
    write-host "Database refresh is success" -f green 
    write-output "*******************************************************" >> $C300log
    write-output "Target database backup is taken in NAS path $SBpath" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Restore SourceDB $sdb Backup to targetDB $tdb is successfull" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "TargetDB $tdb is online" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Database refresh is success:Return code 0" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Completed successfully" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Database refresh is success">>$logfile
    write-output "Completed successfully">>$logfile
   
 }
else{
   write-host "Database refresh failed please check the $logfile for details" -f red
   write-output "Database refresh failed please check the $logfile for details" >> $logfile
   write-output "Database refresh failed kk:Return code 1" >> $C300log    
  }
  }
  
  }

}


IF(($RefreshType -eq "multiple") -and ($dbnumber -ge "2"))
{

write-host $DBNumber
write-host $sdb.count
write-host $tdb.count

<#
if(($DBNumber -eq $sdb.count) -and ($DBNumber -eq $tdb.count))
  {
     write-host "matching"
   } 
else
{
  write-host "Please select databases as per DBNumber"
  exit
}
#>
$check = "matching"

if($check -eq "matching")
{
$startDTM = (Get-Date)
   
#$SBpath = "\\$Source\f$\mulrefresh\"
#$TBpath = "\\$target\f$\mulrefresh\"

#$SBpath = "\\itssgsgsdna005.jnj.com\sqldbawork_aspac$\REFRESH\" +"\$RFC"
#$TBpath = "\\itssgsgsdna005.jnj.com\sqldbawork_aspac$\REFRESH\Target"

if((Test-Path $SBpath) -eq 0)
{
mkdir $SBpath
}

if((Test-Path $TBpath) -eq 0)
{
mkdir $TBpath
}

<#
Write-output "MSSQL DBRefersh Logfile" >> $logfile
Write-output ********************************************************************** >> $logfile
"`n"
Write-output RFC:$RFC >>$logfile
Write-output AppName:$AppName >>$logfile
Write-output RefreshType:$RefreshType >>$logfile
Write-output DBNumber:$DBNumber >>$logfile
Write-output SourceServer:$SOURCE >>$logfile
Write-output SourcedatabaseName:$Sdb >>$logfile
Write-output TargetServer:$Target >>$logfile
Write-output TargetDatabaseName:$tdb >>$logfile
"`n"
write-output ********************************************************************** >>$logfile
#>
Write-host "the log file created in path $logfile" -f yellow

 #To Append Log
 
 $logfoldercheck = "the log file created"
 $Date = get-date -format g
 Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$logfoldercheck" 

If($SInstance -eq ""){[String]$dataSource1 = $SOURCE}
ELSE{[String]$dataSource1 = $SOURCE+"\"+$SInstance}

$connectionString1 = "Data Source=$dataSource1; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog= 'master'"

$SqlBackCmd = " declare @DefaultBack varchar(250)
            exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @DefaultBack output
               select @DefaultBack [BackupPath]"            
IF($SBpath -eq ""){
    $connectionSB = new-object system.data.SqlClient.SQLConnection($connectionString1)
    $commandSB = new-object system.data.sqlclient.sqlcommand($SqlBackCmd,$connectionSB)
    $connectionSB.Open()
    $adapterSB = New-Object System.Data.sqlclient.sqlDataAdapter $commandSB
    $datasetSB = New-Object System.Data.DataSet
    $adapterSB.Fill($datasetSB) | Out-Null
    $SBpath = $dataSetSB.Tables[0].rows[0].BackupPath
    $connectionSB.Close()
    write-host "Default Source Backup Folders is " $SBpath -foregroundcolor "YELLOW"
    }
$connectionsuccess1 = "Connection is Successfull in Source server"
write-host "Connection is Successfull in Source server" -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$connectionsuccess1" 

$n = 0
IF($connectionsuccess1 -eq "Connection is Successfull in Source server")
 
   {
   foreach($db in $Sdb.split(",")) 
   { 
    $path = $sbpath+"\"+$db+$n
    If(!(test-path $path))
    {
    New-Item -ItemType Directory -Force -Path $path
    }   
    $bkupdbscript = "backup database "+$db+" to disk = '"+$path+"\"+$source+"_"+$db+$n+"_FULL"+".BAK' with copy_only"
    $n++
try
  {
    $connection1 = new-object system.data.SqlClient.SQLConnection($connectionString1)
    $command1 = new-object system.data.sqlclient.sqlcommand($bkupdbscript,$connection1)
    $connection1.Open()
    $adapter1 = New-Object System.Data.sqlclient.sqlDataAdapter $command1
    $command1.commandtimeout = 0 
    $dataset1 = New-Object System.Data.DataSet
    $adapter1.Fill($dataSet1) | Out-Null
    $dataSet1.Tables
    Write-Host "Backup in progress" 
    $connection1.Close()
    }
catch 
  {
     $err = $_.Exception   
     [String]$Msg = $err.Message   
     while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message >> $C300log 
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300       
    }
    $issue1 = "Something went wrong while taking Backup in Source Server"
    Write-Host $issue1 -foregroundcolor "red"
    Add-Content -Path $logfile -Value "$Date`tIssue:$issue1"
    Read-Host "Press Enter to Exit"  
    
  }
finally {
     IF($Msg){
     Echo $Msg
    #break
     }
     ELSE {
     Write-host "Successfully Backed up" -foregroundcolor "GREEN"
     }
   }
}

}

IF($issue1 -ne "Something went wrong while taking Backup in Source Server")
    {
    $bakupntsuc = "Backup Successfull in the path: "+$SBpath+""  
    Write-Host $bakupntsuc -foregroundcolor "yellow"
    $Date = get-date -format g
    Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$bakupntsuc"   
    }
    ELSE
    {
    $bakupntsuc = "Unable to take backup"
    Write-Host $bakupntsuc -foregroundcolor "red"
    $Date = get-date -format g
    Add-Content -Path $logfile -Value "$Date`tServerName:$SOURCE`tInstanceName:$SInstance`:`tDatabaseName:$Sdb`t:$bakupntsuc"   
    break
    }


 
 If($TInstance -eq ""){[String]$dataSourceT = $TARGET}
 ELSE{[String]$dataSourceT = $TARGET+"\"+$TInstance}

$connectionStringT = "Data Source=$dataSourceT; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog= 'master'"

Write-Host "Connection is Successfull in Target server" -f green
$connectionStringTT = "Connection is Successfull in Target server"
$Date = get-date -format g
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$connectionStringTT" 
 
 
"`n"
"`n"

get-content $sbpath -ErrorAction SilentlyContinue | %{

    if($_ -match ".bak")
    {
        mkdir "$sbpath+$db\$_";
        $i++
    }
} 

#$rootdir="$sbpath"
#gci $rootdir  -Directory -Recurse| %{$i=1;%{Ren $_.FullName -NewName ('ab_1' -f $i++)} }
#gci $_.FullName -recurse -directory
<#
Get-ChildItem -Path "$sbpath" | sort CreationTime|
% -Begin { $i = 1 } -Process { 
    Rename-Item -LiteralPath $_.FullName -NewName ("filename_s01e{0:D3}" -f $i++)
    }
#>

Get-ChildItem -Path "$sbpath" | select name|sort-object -property CreationTime 
% -Begin { $i = 1 } -Process { 
    #Rename-Item -LiteralPath $_.FullName -NewName ("filename_s01e{0:D3}" -f $i++)
}



$endDate = Get-Date;
Write-Host $endDate
  IF($TBpath -eq ""){
    $connectionTB = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $commandTB = new-object system.data.sqlclient.sqlcommand($SqlBackCmd,$connectionTB)
    $connectionTB.Open()
    $adapterTB = New-Object System.Data.sqlclient.sqlDataAdapter $commandTB
    $datasetTB = New-Object System.Data.DataSet
    $adapterTB.Fill($datasetTB) | Out-Null
    $TBpath = $dataSetTB.Tables[0].rows[0].BackupPath
    $connectionTB.Close()
    write-host "Default Target Backup Folder is " $TBpath -foregroundcolor "Yellow"
    }
    

    #echo $SCpath
    #echo $TCpath
    $TCpath = $TBpath
    #Get-ChildItem -path $sbpath+$db
    #move-item $sbpath -Destination $TCpath -force
    #Get-ChildItem -path $sbpath |  copy-Item -Destination $TCpath  -recurse




    #move-item $SCpath -Destination $TCpath -force
    write-host "Backup copied from $Sbpath to $TCpath"
    $copypath= "Backup copied from $SCpath to $TCpath"
    Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$copypath" 


if ($connectionStringTT -eq "Connection is Successfull in Target server")
{

foreach($db in $tdb.split(','))
{
  echo $db
 $sqlscript2 = "sp_helpdb ["+$db+"]" 
     
 $sp_helpdboutput = $TCPath+"\sp_helpdboutput_$db"+$datetoday+".txt"
 
 try
 {
    $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command21 = new-object system.data.sqlclient.sqlcommand($sqlscript2,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command21 
   #$global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2) 
    $DataSet2.Tables[0] | out-file $sp_helpdboutput
    $connection.Close()
   #$dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "SP_helpdb script is executed" 
  #Write-Host "SP_helpdb script is Successful and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
   $sphelp4 = "SP_helpdb script is executed" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp4" 
   }
   
   catch 
  {
     $err = $_.Exception   
    [String]$MsgTSP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message>> $C300log
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300
                
    }
  }

finally {
     IF($MsgTSB){
     Echo $MsgTSB
   $sphelp = "SP_helpdb script is not Successfull."
   write-host "SP_helpdb script is not Successfull.Check the above error" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-Host "SP_helpdb script is Successfull" -foregroundcolor "GREEN"
     Write-Host "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
   $sphelp = "SP_helpdb script is Successfull" 
   $sphelp1 = "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" 
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp1"   

     }
   }

   }
   }
   else
   {
   $sphelp = "SP_helpdb script is not Successful"
   write-host "SP_helpdb script is not Successful" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
   Read-host "Press enter to exit"
     break
  } 
 
if ($connectionStringTT -eq "Connection is Successfull in Target server")
 {  
   
$db1 =  $tdb.split(',')[0,1,2,3] 
foreach($db in $db1)
{
$sqlscriptout = "Use ["+ $db +"];

SET NOCOUNT ON

DECLARE @sql VARCHAR(2048), @sort INT
create table ##tmpcmds(SQL_Stmt varchar(max))

insert into ##tmpcmds 
SELECT	'USE' +  QUOTENAME(DB_NAME()) +';' AS [-- SQL STATEMENTS --]

insert into ##tmpcmds 
SELECT 'CREATE USER [' + name + '] for login [' + name + ']'+ SPACE(1) AS [-- SQL STATEMENTS --]
 from sys.database_principals where type In ('U' , 'S' , 'G') 

insert into ##tmpcmds  
SELECT	'EXEC sp_addrolemember @rolename ='+QUOTENAME(USER_NAME(rm.role_principal_id), '''')+', @membername ='+QUOTENAME(USER_NAME(rm.member_principal_id), '''') AS [-- SQL STATEMENTS --] FROM	sys.database_role_members AS rm 
WHERE	USER_NAME(rm.member_principal_id) IN (SELECT [name] FROM sys.database_principals WHERE [principal_id] > 4 and [type] IN ('G', 'S', 'U'))

insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.state_desc ELSE 'GRANT ' END
+SPACE(1)+perm.permission_name+' ON '+QUOTENAME(SCHEMA_NAME(obj.schema_id))+'.'+QUOTENAME(obj.name) 
+ CASE
WHEN cl.column_id IS NULL THEN SPACE(0) ELSE '('+QUOTENAME(cl.name)+')' END
+' TO '+QUOTENAME(USER_NAME(usr.principal_id)) COLLATE database_default
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
FROM sys.database_permissions AS perm 
INNER JOIN sys.objects AS obj
ON perm.major_id = obj.[object_id]
INNER JOIN
sys.database_principals AS usr
ON perm.grantee_principal_id = usr.principal_id
LEFT JOIN
sys.columns AS cl
ON cl.column_id = perm.minor_id AND cl.[object_id] = perm.major_id


insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.[state_desc] ELSE 'GRANT ' END
+SPACE(1)+perm.[permission_name]
+' TO '+'['+USER_NAME(usr.[principal_id])+']' COLLATE database_default
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
FROM	sys.[database_permissions] AS perm
INNER JOIN
sys.[database_principals] AS usr
ON perm.[grantee_principal_id] = usr.[principal_id]
WHERE	[perm].[major_id] = 0
	AND [usr].[principal_id] > 4
	AND [usr].[type] IN ('G', 'S', 'U')

insert into ##tmpcmds 
SELECT	CASE 
WHEN perm.state <> 'W' THEN perm.[state_desc] ELSE 'GRANT ' END
+SPACE(1)+perm.[permission_name]
+' TO ' +perm.[class_desc]+'::' COLLATE database_default
+QUOTENAME(SCHEMA_NAME(perm.[grantee_principal_id]))
+CASE 
WHEN perm.state <> 'W' THEN SPACE(0) ELSE  'WITH GRANT OPTION' END
AS [-- SQL STATEMENTS --]
from sys.[database_permissions] AS perm
inner join sys.schemas s
on perm.[grantee_principal_id] = s.[schema_id] 
WHERE class = 3 



select * from ##tmpcmds
SET NOCOUNT OFF"
 $sqlscriptout_output = $TCpath+"\sqlscriptout_output_"+$datetoday+".txt"
# echo $sqlscriptout_output
  

    $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command2 = new-object system.data.sqlclient.sqlcommand($sqlscriptout,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command2 
   # $global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2)
     
    $resultcolumns=$DataSet2.Tables[0]
    foreach($dataitem in $resultcolumns.Rows)
{
$fir=$dataitem[0]
$fir|out-file $sqlscriptout_output -append
}

    $connection.Close()
   # $dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "Sqlscriptoutrun script is successfull" -foregroundcolor "GREEN"
   $restore2 = "Sqlscriptoutrun script is successfull"
   Write-Host "Sqlscriptoutrun script is saved in the path : $sqlscriptout_output" -foregroundcolor "YELLOW"
   $Sqlscriptoutrun = "Sqlscriptoutrun script is saved in the path : $sqlscriptout_output" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Sqlscriptoutrun" 
   }
}   
else
  { 
    $Sqlscriptoutrun = "Sqlscriptoutrun script is not Successful" 
   write-host "Sqlscriptoutrun script is not Successful" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Sqlscriptoutrun"   
  } 
 

If($restore2 -eq "Sqlscriptoutrun script is successfull")
 {
   $db1 =  $tdb.split(',')[0,1,2,3,4,5]
foreach($db in $db1)
 {
  $sqlscriptout_output = $TCpath+"\sqlscriptout_output_"+$datetoday+".txt"
  $ErrorActionPreference = "SilentlyContinue"
  $sqlscriptoutput2 = get-content  $sqlscriptout_output 
  
  try
  {
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlscriptoutput2,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables 
  $outputsuccess = "Output generated in step 2 was exceuted"
  write-host "Output generated in step 2 was exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
  $connection.Close()
  }
  catch 
  {
       $err = $_.Exception   
    [String]$MsgOSB = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        #write-output $err.Message 
        write-host "Output generated in step 2 was exceuted successfully :"$sqlscriptout_output -foregroundcolor "green"
        $outputsuccess1 = "Output generated in step 2 was exceuted successfully :$sqlscriptout_output"
        $outputsuccess = "Output generated in step 2 was exceuted successfully"
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess1" 
        #Read-host "Press enter to exit"
        break
    }
    
  }
}
}

#$Tback = "\\$target\f$\targetbackup"
#$Tback = "\\itssgsgsdna005.jnj.com\sqldbawork_aspac$\REFRESH\target"
$Tback = $tbpath

if((Test-Path $Tback) -eq 0)
{
mkdir $Tback
}


If($copypath -eq "Backup copied from $SCpath to $TCpath")
  {
   foreach($gdb in $tdb.split(",")) 
  {
   $bkupdbscript = "backup database "+$gdb+" to disk = '"+$Tback+"\"+$target+"_"+$gdb+"_Full"+".BAK' with copy_only"
  try
   {
    $connectionT = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $commandTSB = new-object system.data.sqlclient.sqlcommand($bkupdbscript,$connectionT)
    $connectionT.Open()
    $adapterTSB = New-Object System.Data.sqlclient.sqlDataAdapter $commandTSB
    $commandTSB.commandtimeout = 0  
    $datasetTSB = New-Object System.Data.DataSet
    $adapterTSB.Fill($dataSetTSB) | Out-Null
    $dataSetTSB.Tables
    Write-Host "Backup successful" -foregroundcolor "green"
    $connectionT.Close()
    }
 catch 
  {
     $err = $_.Exception   
    [String]$MsgTSB = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message >> $C300log
     write-output "*******************************************************" >> $C300log
     write-output "please check the $logfile for details">>$C300log
     write-output "*******************************************************" >> $C300log
     write-output " DB refresh failed:Return code 1" >>$C300log 
     write-output "*******************************************************" >> $C300log
     write-output "###1">>$status300 
                
    }
  }
finally {
     IF($MsgTSB){
     Echo $MsgTSB
  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-host "Target database has successfully Backed up for safety as :"$bkupdbscript -foregroundcolor "YELLOW"
     $bakupntsuc = "Target database has successfully Backed up for safety as :$bkupdbscript"
     $bakupntsuc1 = "Target database has successfully Backed up for safety"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$bakupntsuc"   

     }
   }
}
}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SmoExtended') | out-null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo') | out-null
$ErrorActionPreference = "SilentlyContinue"
$SQLInstanceName = "$target"
$Server = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $SQLInstanceName
$DatabaseName = $tdb.split(',')

$DBObject = $Server.Databases[$DatabaseName]
$DBObject.DatabaseOptions.UserAccess = [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]::single
$DBObject.Alter([Microsoft.SqlServer.Management.Smo.TerminationClause]"RollbackTransactionsImmediately")


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null  
$srv = new-object Microsoft.SqlServer.Management.Smo.Server("$target")
$srv.KillAllProcesses($tdb.split(","))

$roll1 =  "$tdb database is set to single user mode"
write-host "$tdb database is set to single user mode" -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$roll1" 

 

#$path = "\\$target\f$\mulrefresh"
$path = "$sbpath"

$path1 = Get-ChildItem  -Path $path -Recurse 
$BkFiles = $sbpath+"\kish.txt"
foreach ($item in $path1)
 {
   if ($item.Attributes -eq "Directory")
    {
      $item.Name >> $BkFiles
    }
}

 
$items = Get-ChildItem -Path $path -file -Recurse -Filter "*.bak"

$dbName1 = $tdb.split(',')

If (Test-Path "\\$target\f$\Restore")
{
# Set-ItemProperty -Path "\\$target\f$\Restore\*.bak" -Name IsReadOnly -Value $False
Remove-Item "\\$target\f$\Restore\*" -recurse
}
If (!(Test-Path "\\$target\f$\Restore\"))
{
  mkdir "\\$target\f$\Restore"
}

$BkpFiles = $sbpath+"\BackupFileNames.txt"

foreach ($item in $items)
{

      if ($item.Attributes -ne "Directory")
      {
        $item.Name >> $BkpFiles
      }
}

   


[int]$x = 0
  foreach($db in $dbName1)

   {

        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null  
        $srv = new-object Microsoft.SqlServer.Management.Smo.Server("$target")
        #$serverConn = new-object Microsoft.SqlServer.Management.Smo.Server($target)
        #$serverConn.ConnectionContext.StatementTimeout = 0  
        $bk = (get-content $BkFiles)[$x]
        $bkpFileName = (Get-Content $BkpFiles)[$x]

Write-Host "(get-content $BkFiles)[$x]"
Write-Host "(Get-Content $BkpFiles)[$x]"
Write-Host "bk is $bk"
Write-Host "bk is $bkpFileName"
        $srv.KillAllProcesses($db) 
        #$target.StatementTimeout = 0;
        Write-Host "Restore-SqlDatabase -ServerInstance $target -Database $db -BackupFile $path\$bk\$bkpFileName -ReplaceDatabase"
        Restore-SqlDatabase -ServerInstance $target -Database $db -BackupFile $path\$bk\$bkpFileName -connectiontimeout 0 -ReplaceDatabase 
        $bk = ""
        $bkpFileName = "" 
         
        $x++ 
        C:

}

      
Write-host "Restore Successful" -foregroundcolor "GREEN"
$restore2 = "Restore Successful"
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$restore2"   



$DBObject.DatabaseOptions.UserAccess = [Microsoft.SqlServer.Management.Smo.DatabaseUserAccess]::multiple
$DBObject.Alter([Microsoft.SqlServer.Management.Smo.TerminationClause]"RollbackTransactionsImmediately")
$roll = "$tdb database is set to multi user mode " 
write-host "$tdb database is set to multi user mode " -f green
Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$roll"

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null  
$srv = new-object Microsoft.SqlServer.Management.Smo.Server("$target")
$srv.KillAllProcesses($tdb)

If($restore2 -eq "Restore Successful")
 {
   $db1 =  $tdb.split(',')[0,1,2,3,4,5]
foreach($db in $db1)
 {
  $sqlscriptout_output = $TCpath+"\sqlscriptout_output_"+$datetoday+".txt"
  $ErrorActionPreference = "SilentlyContinue"
  $sqlscriptoutput2 = get-content  $sqlscriptout_output 
  
  try
  {
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlscriptoutput2,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables 
  $outputsuccess = "Output generated in step 2 was exceuted"
  write-host "Output generated in step 2 was exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
  $connection.Close()
  }
  catch 
  {
       $err = $_.Exception   
    [String]$MsgOSB = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        #write-output $err.Message 
        write-host "Output generated in step 2 was exceuted successfully :"$sqlscriptout_output -foregroundcolor "green"
        $outputsuccess1 = "Output generated in step 2 was exceuted successfully :$sqlscriptout_output"
        $outputsuccess = "Output generated in step 2 was exceuted successfully"
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess"   
        Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$outputsuccess1" 
        #Read-host "Press enter to exit"
        break
    }
    
  }
}
}

foreach($db in $tdb.split(','))
{
if ($outputsuccess -eq "Output generated in step 2 was exceuted successfully")
{

  $sqlorphan_output = $TCpath+"\sqlorphan_output_"+$datetoday+".txt"
  $sqlorphan = "Sp_change_users_login report"
  #$sqlorphan = "sp_change_users_login 'Report'"
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlorphan,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables  >>  $sqlorphan_output
  $view1= get-content $sqlorphan_output | Out-GridView
  $connection.Close()
# invoke-item "C:\logs\orphan.txt"
  $orphanscript = "Orphan script exceuted"
  write-host "Orphan script exceuted"
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript"   
  }
else
 {
   $orphanscript = "Orphan script not exceuted"
   write-host "Orphan script not exceuted"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript"   
   write-host "Kindly try to execute manually from step 6 in SOP"
   Read-host "Press enter to exit"
   break
  }
 } 

System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
$srv = New-Object "Microsoft.SqlServer.Management.SMO.Server" $target

$dbname = $tdb.split(',')[0]
foreach($db1 in $dbname)
{
$db = $srv.databases[$db1]
echo $db.name
$rc = get-content 'c:\dba.txt'
$db.RecoveryModel = $rc
echo $db.RecoveryModel
$db.Alter()
}


$dbname1 = $tdb.split(',')[1]
foreach($db1 in $dbname1)
{
$db = $srv.databases[$db1]
echo $db.name
$rc = get-content 'c:\dba1.txt'
$db.RecoveryModel = $rc
echo $db.RecoveryModel
$db.Alter()
}


foreach($db in $tdb.split(','))
{
If($orphanscript -eq "Orphan script exceuted")
 {  
  
 $sqlorphan2 = "Use ["+ $db +"];
  
 DECLARE @username varchar(25)

 DECLARE fixusers CURSOR 
 FOR

SELECT UserName = name FROM sysusers
WHERE issqluser = 1 and (sid is not null and sid <> 0x0)
and suser_sname(sid) is null
ORDER BY name

OPEN fixusers

FETCH NEXT FROM fixusers
INTO @username

WHILE @@FETCH_STATUS = 0
BEGIN
EXEC sp_change_users_login 'update_one', @username, @username

FETCH NEXT FROM fixusers
INTO @username
END


CLOSE fixusers
DEALLOCATE fixusers"
try
{
  $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
  $command = new-object system.data.sqlclient.sqlcommand($sqlorphan2,$connection)
  $connection.Open()
  $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command 
  $dataset = New-Object System.Data.DataSet
  $adapter.Fill($dataset) 
  $dataSet.Tables
  $connection.Close()
  $orphanscript2 = "Orphan users fixing script is executed" 
  write-host "Orphan users fixing script is executed" 
  $Date = get-date -format g
  Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript2"   
  }
  catch 
  {
     $err = $_.Exception   
    [String]$MsgORP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        #write-output $err.Message  
        $MsgORP >> $logfile
        #write-host "Orphan users has not been fixed.Please find the error above and Kindly try to execute manually " -foregroundcolor "RED"
        #Read-host "Press enter to exit"
        #break
    }
  }
  
  finally {
     IF($MsgORP){
    # Echo $MsgORP
    $orphanscript2 = "Orphan users has not been fixed.Please find the error above and Kindly try to execute manually"
   # write-host "Error with SQL.Please find the error above and Kindly try to execute manually " -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript2"   
  # Read-host "Press enter to exit"
   #break
   }
     
     ELSE {
     
      Write-host "Orphan users fixing script is exceuted successfully"  -foregroundcolor "GREEN"
     $orphanscript3 = "Orphan users fixing script is exceuted successfully"
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$orphanscript3"   
        }

     }
  }

}

  
if ($outputsuccess -eq "Output generated in step 2 was exceuted successfully")
{

foreach($db in $tdb.split(','))
{
  echo $db
 $sqlscript2 = "sp_helpdb ["+$db+"]" 
     
 $sp_helpdboutput = $TCPath+"\Finalcheckscript_output_$db"+$datetoday+".txt"
 
 try
 {
    $connection = new-object system.data.SqlClient.SQLConnection($connectionStringT)
    $command21 = new-object system.data.sqlclient.sqlcommand($sqlscript2,$connection)
    $connection.Open()
    $adapter2 = New-Object System.Data.sqlclient.sqlDataAdapter $command21 
   #$global:DataSet = New-Object System.Data.DataSet
    $dataset2 = New-Object System.Data.DataSet
    $adapter2.Fill($dataset2) 
    $DataSet2.Tables[0] | out-file $sp_helpdboutput
    $connection.Close()
   #$dataSet.Tables | out-file $scriptoutusersoutput
   Write-Host "SP_helpdb script is executed" 
  #Write-Host "SP_helpdb script is Successful and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
   $sphelp4 = "SP_helpdb script is executed" 
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp4" 
   }
   
   catch 
  {
     $err = $_.Exception   
    [String]$MsgTSP = $err.Message   
    while( $err.InnerException ) {           
        $err = $err.InnerException           
        write-output $err.Message 
                
    }
  }

finally {
     IF($MsgTSB){
     Echo $MsgTSB
   $sphelp = "SP_helpdb script is not Successfull."
   write-host "SP_helpdb script is not Successfull.Check the above error" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
  Read-host "Press enter to exit"
     #break
     }
     ELSE {
     Write-Host "Final script to check to Database owner and permissions has been executed" -foregroundcolor "GREEN"
     Write-Host "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" -foregroundcolor "YELLOW"
     $Finalscript = "Final script to check to Database owner and permissions has been executed"  
     $sphelp1 = "SP_helpdb script is Successfull and saved in the path : $sp_helpdboutput" 
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript"   
     Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$Finalscript"   
     
    }
   }

   }
   }
   else
   {
   $sphelp = "SP_helpdb script is not Successful"
   write-host "SP_helpdb script is not Successful" -foregroundcolor "RED"
   $Date = get-date -format g
   Add-Content -Path $logfile -Value "$Date`tServerName:$TARGET`tInstanceName:$TInstance`:`tDatabaseName:$Tdb`t:$sphelp"   
   Read-host "Press enter to exit"
     break
  } 


if($Finalscript -eq "Final script to check to Database owner and permissions has been executed")
{
foreach($db in $tdb.split(","))
{
  $restore_output = $sbpath+"\restore_result.txt"
  $mydata = invoke-sqlcmd -query "SELECT [rs].[destination_database_name], 
  [rs].[restore_date], 
  [bs].[database_name] as [source_database_name], 
  [bmf].[physical_device_name] as [backup_file_used_for_restore]
  FROM msdb..restorehistory rs
  INNER JOIN msdb..backupset bs
  ON [rs].[backup_set_id] = [bs].[backup_set_id]
  INNER JOIN msdb..backupmediafamily bmf 
  ON [bs].[media_set_id] = [bmf].[media_set_id] 
  where [rs].[restore_date]>= DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), 0) order by restore_date desc" -serverinstance $target -database $db;
  echo $mydata
  $mydata | format-list destination_database_name,restore_date,source_database_name,backup_file_used_for_restore|out-file $restore_output
  C:
}
}

if($Finalscript -eq "Final script to check to Database owner and permissions has been executed")
 {
    write-host "DB Refresh is success" -f green
    write-output "###0" >> $status300
 }
else{
   write-host "DB Refresh failed please check the $logfile for details" -f red
   write-output "###1" >> $status300
           
}


if($Finalscript -eq "Final script to check to Database owner and permissions has been executed")
 {
    write-host "Database refresh is success" -f green
    write-output "*******************************************************" >> $C300log
    write-output "Target database backup is taken in NAS path $SBpath" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Restore SourceDB $sdb Backup to targetDB $tdb is successfull" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "TargetDB $tdb is online" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Database refresh is success:Return code 0" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Completed successfully" >> $C300log
    write-output "*******************************************************" >> $C300log
    write-output "Database refresh is success">>$logfile
    write-output "Completed successfully">>$logfile
}
else
{
   write-host "Database refresh failed please check the $logfile for details" -f red
   write-output "Database refresh failed please check the $logfile for details" >> $logfile
   write-output "Database refresh failed:Return code 1" >> $C300log
   
       
  }
 }
}

Get-ChildItem -Path $tbpath -Recurse -file | Move-Item -Destination $sbpath
Remove-Item $tbpath -Force
remove-item $BkFiles
remove-item $BkpFiles
$endDTM = (Get-Date)
# Echo Time elapsed
"Elapsed Time: $(($endDTM-$startDTM).totalseconds) seconds"
