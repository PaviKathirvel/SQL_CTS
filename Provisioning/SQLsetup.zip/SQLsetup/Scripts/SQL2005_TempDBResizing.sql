/*Configure TempDB Data and LogFiles*/
DECLARE @rc int
DECLARE @TDB_Size_Source INT,@TDB_Size INT,@STDB_Size INT, @CMD NVARCHAR(4000), @CMD_2 NVARCHAR(4000), @CMD_3 NVARCHAR(4000), @i INT, @Loc VARCHAR(1000), @T_CPU INT
CREATE TABLE #output (id int identity(1,1), disksize nvarchar(255) null)
insert #output (disksize) exec @rc = master..xp_cmdshell 'powershell.exe -file "C:\IQOQ\sddc_sql2005_TempDBDiskSpace.ps1" -nologo'
SELECT @Loc = (SELECT SUBSTRING(physical_name,0,CHARINDEX('\tempdb.mdf',physical_name)+1) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' AND FILE_ID = 1)

SELECT @TDB_Size_Source = (select disksize from #output where disksize is not null)

/*
SELECT @TDB_Size_Source = (SELECT 
						(((total_bytes/1024)/1024)/1024)
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
*/

SELECT @T_CPU = (SELECT cpu_count FROM sys.dm_os_sys_info)
IF @TDB_Size_Source < 10
BEGIN
SELECT @TDB_Size = (select disksize from #output where disksize is not null)

/*
(SELECT 
						(total_bytes/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
*/

SET @STDB_Size = @TDB_size * 0.10 * 1024

IF @T_CPU = 1
BEGIN

	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + ''',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
END
IF @TDB_Size_Source >= 10
BEGIN
SELECT @TDB_Size = (select disksize from #output where disksize is not null)

/*
(SELECT 
						((total_bytes/1024)/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
*/
IF (@TDB_size * 0.10) <= 10
	SET @STDB_Size = @TDB_size * 0.10
ELSE
	SET @STDB_Size = 10

IF @T_CPU = 1
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	print @CMD
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_SIZE)+'GB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
END

