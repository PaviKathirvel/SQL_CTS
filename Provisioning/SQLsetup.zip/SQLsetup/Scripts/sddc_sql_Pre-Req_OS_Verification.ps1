###################################################################################################
$ScriptName = "sddc_sql_Pre-Req_OS_Verification.PS1"
$Scriptver = "11.0"
#Description: OS Verification for SQL Server Provisioning in SDDC
###################################################################################################
#Version		Date		Author		       Reason for Change
###################################################################################################
#1.0			05/07/2014	Bruno Campos	       New Script
#2.0			06/13/2014	Bruno Campos	       Added process to verify CPU, Memory and 
#							       Disk from an external file.
#3.0			08/20/2014	Bruno Campos	       Removed verification of .MMM and .LLL in 
#							       					NetBackup verfication
#4.0			11/24/2014	Jay Sangam	       		Single batch script to install Named instances 
#5.0            Jan/19/2017	Saketh Valluripalli     Provisioning of SQL 2014   
#7.0 			Sept/2/2019		Sanjiv				Adding 2017 Installation logicc-- Nochanges made
#8.0 			FEB/26/2020		Sanjiv				Adding 2019 Installation logic -- Nochanges made
#9.0 			Dec/10/2020		Sanjiv				Adding New Location hosted on CDOT 
#10.0 			APR/15/2021		Sanjiv				#Promoting SQL2019 
#11.0 			FEB/26/2024		Shubham				#Promoting SQL2022
###################################################################################################

#---------------- Lab DML ----------------
$LabSQLDML= '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML' 

#---------------- NA DML ----------------
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'

#---------------- LA DML ----------------
$LASQLDML = '\\itsusrac1ts1.jnj.com\msqldml'

#---------------- EMEA DML ----------------
$EMEASQLDML = '\\itsbebec1snap01.jnj.com\msqldml'

#---------------- ASPAC DML ----------------
$ASPACSQLDML = '\\itssgsgc1snap01.jnj.com\MSSQLDML'

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
$Final_Status_Error = 0
$Process = $args[0]  #----For SDDC / NON-SDDC------#
$Tier = $args[1]
$Env = $args[2]
$If2K5 = $args[3]


#--------------------------------- Checking Parameters Values ---------------------------------#

IF (($Process -ne "SDDC") -and ($Process -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
EXIT
}

IF (($Tier -ne "Small") -and ($Tier -ne "Medium") -and ($Tier -ne "Large"))
{
Write-Host ""
Write-Host "Size not Valid. Pass SMALL or MEDIUM or LARGE as 2nd parameter" -f red
Write-Host ""
EXIT
}

IF (($Env -ne "DEV") -and ($Env -ne "QA") -and ($Env -ne "PROD"))
{
Write-Host ""
Write-Host "Environment not Valid. Pass DEV or QA or PROD as 3rd parameter" -f red
Write-Host ""
EXIT
}

<#
IF (($If2K5 -ne "SQL2005") -and ($If2K5 -ne "SQL2008") -and ($If2K5 -ne "SQL2012") -and ($If2K5 -ne "SQL2014"))
{
Write-Host ""
Write-Host "SQL Version not Valid. Pass SQL2005 or SQL2008 or SQL2012 or SQL2014 as 4th parameter" -f red
Write-Host ""
EXIT
}

#>

#*********************************** Start Function O/S verification ***********************************

FUNCTION sddc_sql_Pre-Req_OS_Verification ($IDMLLOC)
{

$Time = get-date -Uformat "%Y%m%d%H%M"

If (!(Test-Path C:\SQLInstall_Logs))
{
mkdir "C:\SQLInstall_Logs"
}
$Log = "C:\SQLInstall_Logs\sddc_sql_Pre-Req_OS_Verification_$Time.txt"

#*********** O/S verification Parameters*************
Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $env:computername"
"Server Host: $Hostname" >> $Log
"Execution string: $ScriptName $Process $Tier $Env" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

#$VM_Size_IAll =   $($IDMLLOC) + "\ConfigFiles\sddc_sql_VM_Size.txt"
#$VM_Size_All = Import-Csv $VM_Size_IAll 
#$Disk_Layout_IAll = $($IDMLLOC)+ "\ConfigFiles\sddc_sql_Disk_Layout.txt"
#$Disk_Layout_All = Import-Csv $Disk_Layout_IAll 
#$Disk_Sizes_IAll = $($IDMLLOC) + "\ConfigFiles\sddc_sql_Disk_Sizes.txt"
#$Disk_Sizes_All = Import-Csv $Disk_Sizes_IAll

#$VM_Size_IAll = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\sddc_sql_VM_Size.txt"
$VM_Size_IAll = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\sddc_sql_VM_Size_test2.txt"
$VM_Size_All = Import-Csv $VM_Size_IAll

$Disk_Layout_IAll = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\sddc_sql_Disk_Layout.txt"
$Disk_Layout_All = Import-Csv $Disk_Layout_IAll

#$Disk_Sizes_IAll = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\sddc_sql_Disk_Sizes.txt"
$Disk_Sizes_IAll = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\sddc_sql_Disk_Sizes_test2.txt"
$Disk_Sizes_All = Import-Csv $Disk_Sizes_IAll

If (Test-Path C:\IQOQ)
{
Set-ItemProperty -Path "C:\IQOQ\*.txt" -Name IsReadOnly -Value $False
Remove-Item C:\IQOQ\* -recurse
}
mkdir "C:\IQOQ"
$IQOQ_1 = "C:\IQOQ\IQOQ_1.txt" #Enable Read-only mode
$BatchOutput1 = "C:\IQOQ\Status.txt"

Function Drive 
{  
PARAM($DriveLetter)  
(New-Object System.IO.DriveInfo($driveletter)).DriveType -ne 'NoRootDirectory'    
}  

Function Error
{
Exit 1
Break
}

#--------------------------------- Verify Os Version ---------------------------------#
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify Minimum OS Version"
"Verify Minimum OS Version" >> $Log
Write-Host "Expected Value: 6.1"
"Expected Value: 6.1" >> $Log
$Major = [environment]::OSVersion.Version.Major
$Minor = [environment]::OSVersion.Version.Minor
$Build = [environment]::OSVersion.Version.Build
$OS_Version = "$Major.$Minor"
Write-Host "Current Value: $OS_Version"
"Current Value: $OS_Version" >> $Log
IF (($OS_Version -ne "6.1") -and ($OS_Version -ne "6.2") -and ($OS_Version -ne "6.3") -and ($OS_Version -ne "10.0"))
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify Processor Type --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify Processor Type"
"Verify Processor Type" >> $Log
Write-Host "Expected Value: Different from x86"
"Expected Value: Different from x86" >> $Log
$Proc = (Get-Process -Id $PID).StartInfo.EnvironmentVariables["PROCESSOR_ARCHITECTURE"]
Write-Host "Current Value: $Proc"
"Current Value: $Proc" >> $Log
IF ($Proc -eq "x86")
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#----------------------- Verify if IIS is running ----------------------------#

IF ($If2K5 -eq "SQL2005")

{

Write-Host  "-------"
 "-------" >> $Log

   Write-Host "Verify if IIS is installed"
   Write-Host "Expected value: Installed"
   "Verify if IIS is installed" >> $Log
   "Expected value: Installed" >> $Log

   IF (Get-Service | where-object {$_.name -eq 'W3SVC'} -ErrorAction SilentlyContinue)
    {
      Write-Host "Current value: Installed"
      Write-Host "Verification: " -f white -nonewline; write-Host "OK" -f green
      "Current value: Installed" >> $Log
      "Verification: OK" >> $Log

    }
   ELSE
    {
      Write-Host "Current value: Not installed"
      Write-Host "Verification: " -f white -nonewline; write-Host "FAIL" -f red
      "Current value: Not installed" >> $Log
      "Verification: FAIL" >> $Log
	$Final_Status_Error = 1
    }

Write-Host "-------"
"-------" >> $Log

}

#--------------------------------- Verify .NET --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify .NET Version"
"Verify .NET Version" >> $Log
Write-Host "Expected Value: 4.0*"
"Expected Value: 4.0*" >> $Log
$error.clear()
$NET = Get-ItemProperty 'HKLM:\Software\Microsoft\NET Framework Setup\NDP\v4\Client\1033'
IF ($error[0])
{
$NET_Version = "N/A"
}
ELSE
{
$NET_Version = $NET.Version
}
Write-Host "Current Value: $Net_Version"
"Current Value: $Net_Version" >> $Log
IF ($NET_Version -eq "N/A")
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify NetBackup Configuration --------------------------------- #

if($Process -eq "SDDC")
{
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify NetBackup Exclusion List"
"Verify NetBackup Exclusion List" >> $Log
Write-Host "Expected Value: *.MDF,*.NDF,*.LDF"
"Expected Value: *.MDF,*.NDF,*.LDF,*.MMM,*.LLL" >> $Log
$NBU = Get-ItemProperty 'HKLM:\Software\Veritas\NetBackup\CurrentVersion\Config'
$NBU_EL = $NBU.Exclude
IF ($NBU_EL -Contains "*.MDF") {$NBU_Final = "*.MDF"}
IF ($NBU_EL -Contains "*.NDF") {$NBU_Final = $NBU_Final + ",*.NDF"}
IF ($NBU_EL -Contains "*.LDF") {$NBU_Final = $NBU_Final + ",*.LDF"}
Write-Host "Current Value: $NBU_Final"
"Current Value: $NBU_Final" >> $Log
IF ($NBU_Final -ne "*.MDF,*.NDF,*.LDF")
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log
}
#--------------------------------- Verify Pagefile Size --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify Pagefile Size"
"Verify Pagefile Size" >> $Log
Write-Host "Expected Value: Bigger than 8G"
"Expected Value: Bigger than 8G" >> $Log
$PageFile_All = Get-WmiObject -class Win32_PageFileUsage
$PageFile = $PageFile_All.AllocatedBaseSize / 1024
Write-Host "Current Value: $Pagefile GB"
"Current Value: $Pagefile GB" >> $Log
IF ($PageFile -lt 8)
#IF ($PageFile -lt 4)
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify VM Size - CPU --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify # of CPUs"
"Verify # of CPUs" >> $Log
$Tmp_Exp_CPU = $VM_Size_All | select Process,Tier,CPU | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
$Exp_CPU = $Tmp_Exp_CPU.CPU
$property = "numberOfCores"
$Tmp_Curr_CPU = Get-WmiObject -class win32_processor -Property $property -ErrorAction Stop | Select-Object -Property $property
if ($Tmp_Curr_CPU -is [system.array])
{
$Curr_CPU = 0
$Curr_CPU_Count = $Tmp_Curr_CPU.Count
foreach ($Tmp_Curr_CPU_2 in $Tmp_Curr_CPU) 
{
$Curr_CPU += $Tmp_Curr_CPU_2.numberOfCores
}
if ($Curr_CPU -eq 0)
{
$Curr_CPU = $Tmp_Curr_CPU.Count
}
}
ELSE
{
$Curr_CPU = $Tmp_Curr_CPU.numberOfCores
}

[int]$Min_CPU = 2

#Write-Host "Expected # of CPUs: $Exp_CPU"
Write-Host "Expected # of CPUs: 2"
"Expected # of CPUs: $EXp_CPU" >> $Log
Write-Host "Current # of CPUs: $Curr_CPU"
"Current # of CPUs: $Curr_CPU" >> $Log
#IF ($Exp_CPU -ne $Curr_CPU)
IF ($Curr_CPU -lt $Min_CPU)
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify VM Size - Memory --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Verify Memory"
"Verify Memory" >> $Log
$Tmp_Exp_Mem = $VM_Size_All | select Process,Tier,Memory | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
$Exp_Mem = $Tmp_Exp_Mem.Memory
$Tmp_Curr_Mem = Get-WmiObject Win32_ComputerSystem
$Curr_Mem = [decimal]::round((($Tmp_Curr_Mem.TotalPhysicalMemory/1024)/1024)/1024)

[decimal]$Min_Mem = 4
Write-Host "Expected Memory (GB): $Min_Mem"
"Expected Memory (GB): $EXp_Mem" >> $Log
Write-Host "Current Memory (GB): $Curr_Mem"
"Current Memory (GB): $Curr_Mem" >> $Log
#IF ($Curr_Mem -lt $Exp_Mem)
IF ($Curr_Mem -lt $Min_Mem)
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify WinAdmin group exists --------------------------------- #

Write-Host "-------"
"-------" >> $Log


$group =[ADSI]"WinNT://./Administrators,group" 
$members = @($group.psbase.Invoke("Members"))

IF (($members | foreach {$_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}) -contains "ITS-EP-APP-DBServers-WinAdmin")

{
     IF ($IpPartsIdentifier2 -eq 0)
      {
	Write-Host "DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "OK" -f green
	"DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: OK" >> $Log
      }
      ELSE
      {
	Write-Host "JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "OK" -f green
	"JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: OK" >> $Log
      }
}
ELSE
{
     IF ($IpPartsIdentifier2 -eq 0)
      {
	Write-Host "DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "FAIL" -f red
	"DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: FAIL" >> $Log
	$Final_Status_Error = 1
      }
      ELSE
      {
	Write-Host "JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "FAIL" -f red
	"JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: FAIL" >> $Log
	$Final_Status_Error = 1
      }
}

Write-Host "-------"
"-------" >> $Log
<#
#--------------------------------- Verify Default DBA groups exist --------------------------------- #

Write-Host "-------"
"-------" >> $Log

$def_dba = 'ITS-EP-SQL-' + $env:COMPUTERNAME + '-DEFAULT-DBA'
$def_dbatemp = 'ITS-EP-SQL-' + $env:COMPUTERNAME + '-DEFAULT-DBA-Temp'

$Searcher1 = New-Object DirectoryServices.DirectorySearcher
$Searcher1.Filter = '(&(objectCategory=Group)(anr=' + $def_dba + '))'
$Searcher1.SearchRoot = 'LDAP://DC=jnj,DC=com'
$Result1 = $Searcher1.FindOne()

IF( $Result1 -eq $null)
{
	Write-Host "Existence of default DBA group JNJ\$($def_dba): " -f white -nonewline; Write-Host "FAIL" -f red
	"Existence of default DBA group JNJ\$($def_dba): FAIL" >> $Log
	$Final_Status_Error = 1
}
Else 
{              
	Write-Host "Existence of default DBA group JNJ\$($def_dba): " -f white -nonewline; Write-Host "OK" -f green
	"Existence of default DBA group JNJ\$($def_dba) : OK" >> $Log
}


$Searcher2 = New-Object DirectoryServices.DirectorySearcher
$Searcher2.Filter = '(&(objectCategory=Group)(anr=' + $def_dbatemp + '))'
$Searcher2.SearchRoot = 'LDAP://DC=jnj,DC=com'
$Result2 = $Searcher2.FindOne()

IF( $Result2 -eq $null)
{
	Write-Host "Existence of default DBA-TEMP group JNJ\$($def_dbatemp): " -f white -nonewline; Write-Host "FAIL" -f red
	"Existence of default DBA-TEMP group JNJ\$($def_dbatemp): FAIL" >> $Log
	$Final_Status_Error = 1
}
Else 
{              
	Write-Host "Existence of default DBA-TEMP group JNJ\$($def_dbatemp): " -f white -nonewline; Write-Host "OK" -f green
	"Existence of default DBA-TEMP group JNJ\$($def_dbatemp) : OK" >> $Log
}

Write-Host "-------"
"-------" >> $Log
#>
#--------------------------------- Verify Disk Configuration Layout --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Disk Layout Configuration"
"Disk Layout Configuration" >> $Log
$Tmp_Exp_Disk_Layout = $Disk_Layout_All | select Process,Drive | Where-Object {$_.Process -eq $Process}
foreach($item in $Tmp_Exp_Disk_Layout) 
{
$Tmp_Exp_Disk_Layout_2 = $item.Drive
$Exp_Disk_Layout = $Exp_Disk_Layout + $Tmp_Exp_Disk_Layout_2 + ","
$Tmp_Curr_Disk_Layout = $item.Drive
$Tmp_Curr_Disk_Layout_2 = Drive $Tmp_Curr_Disk_Layout
IF ($Tmp_Curr_Disk_Layout_2 -eq "True")
{
$Curr_Disk_Layout = $Curr_Disk_Layout + $Tmp_Curr_Disk_Layout + ","
}
}
Write-Host "Expected Disk Layout: $Exp_Disk_Layout"
"Expected Disk Layout: $Exp_Disk_Layout" >> $Log
Write-Host "Current Disk Layout: $Curr_Disk_Layout"
"Current Disk Layout: $Curr_Disk_Layout" >> $Log
IF ($Exp_Disk_Layout -ne $Curr_Disk_Layout)
{
Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
"Verification: FAIL" >> $Log
$Final_Status_Error = 1
}
ELSE
{
Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
"Verification: OK" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Verify Disk Size Configuration --------------------------------- #
Write-Host "-------"
"-------" >> $Log
Write-Host "Disk Size Configuration:"
Write-host ""
"Disk Size Configuration" >> $Log
"" >> $Log

# Enable native auditing on all environments (DEV, QA and PROD)
"Native Auditing:Enable" > $IQOQ_1

IF ($Env -eq "DEV")
 {
 "DEV" >> $IQOQ_1
 }
ELSE
 {
 "PROD" >> $IQOQ_1
 }

# IF (($Env -eq "PROD") -or ($Env -eq "QA"))
# {
# "Native Auditing:Enable" > $IQOQ_1
# }
# ELSE
# {
# "Native Auditing:Enable" > $IQOQ_1
# }

Set-ItemProperty -Path $IQOQ_1 -Name IsReadOnly -Value $True

IF ($Env -ne "DEV")
{
$Env = "NON_DEV"
}
IF ($PRocess -eq "NON_SDDC")
{
$i=0

$Tmp_Exp_Disk_Size = $Disk_Sizes_All | select Process,Drive,Env,Tier,Size | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier -and $_.Env -eq $Env}
foreach($item in $Tmp_Exp_Disk_Size) 
{
  $Tmp_Exp_Disk_Size_2 = $item.Drive
  [decimal]$Exp_Disk_Size = $item.Size
  [decimal]$tolerance = ($Exp_Disk_Size)*0.05
  [decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
# [decimal]$Exp_Disk_Size_more = $Exp_Disk_Size+2

  Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less"
  "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 $Exp_Disk_Size_less" >> $Log
  $Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | select DeviceID,Size | Where {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
  $Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)
  Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 $Curr_Disk_Size"
  "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 $Curr_Disk_Size" >> $Log

  Write-Host "--"
  "--" >> $Log

  IF($Curr_Disk_Size -lt $Exp_Disk_Size_less)
   {
     $i = 1
   }
}

IF($i -eq 1)
 {
   Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
   "Verification: FAIL" >> $Log
   $Final_Status_Error = 1
 }
ELSE
 {
   Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
   "Verification: OK" >> $Log
 }

}
IF ($Process -eq "SDDC")
{
	$i=0
	$Tmp_Exp_Disk_Size = $Disk_Sizes_All | select Process,Drive,Tier,Size,UsedFor | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
	foreach($item in $Tmp_Exp_Disk_Size) 
	{
		$Tmp_Exp_Disk_Size_2 = $item.Drive
		$Tmp_Exp_Disk_Size_3 = $item.UsedFor
		IF (($Tmp_Exp_Disk_Size_3 -eq "Binary") -or ($Tmp_Exp_Disk_Size_3 -eq "Sysdb"))
		{
			[decimal]$Exp_Disk_Size = $item.Size
			[decimal]$tolerance = ($Exp_Disk_Size)*0.05
			[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
			#[decimal]$Exp_Disk_Size_more = $Exp_Disk_Size+5

			Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less"
			"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less" >> $Log
			$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | select DeviceID,Size | Where {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
			$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)
			Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size"
			"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size" >> $Log
			Write-Host "--"
			"--" >> $Log

			IF($Curr_Disk_Size -lt $Exp_Disk_Size_less)
			{
				$i = 1
			}
		}
		IF (($Tmp_Exp_Disk_Size_3 -eq "Data1") -or ($Tmp_Exp_Disk_Size_3 -eq "Data2"))
		{ 
			[decimal]$Exp_Disk_Size = $item.Size
			[decimal]$tolerance = ($Exp_Disk_Size)*0.05
			[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
			#[decimal]$Exp_Disk_Size_more = $Exp_Disk_Size+5

			Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less"
			"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less" >> $Log
			$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | select DeviceID,Size | Where {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
			$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)
			Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size"
			"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size" >> $Log
			IF ($Tmp_Exp_Disk_Size_3 -eq "Data1")
			{
				$Data1 = $Curr_Disk_Size
			}
			ELSE
			{
				# $Data2 = $Curr_Disk_Size
			}
			Write-Host "--"
			"--" >> $Log

			IF($Curr_Disk_Size -lt $Exp_Disk_Size_less)
			{
				$i = 1
			}
		}
		IF (($Tmp_Exp_Disk_Size_3 -eq "Log") -or ($Tmp_Exp_Disk_Size_3 -eq "TempDB"))
		{
			IF ($Data1 + $Data2 -gt 100)
			{
				# [decimal]$Exp_Disk_Size = ($Data1 + $Data2) * 0.30
				[decimal]$Exp_Disk_Size = $item.Size
				[decimal]$tolerance = ($Exp_Disk_Size)*0.05
				[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
				#[decimal]$Exp_Disk_Size_more = $Exp_Disk_Size+5		
			}
			ELSE
			{
				[decimal]$Exp_Disk_Size = $item.Size
				[decimal]$tolerance = ($Exp_Disk_Size)*0.05
				[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
				#[decimal]$Exp_Disk_Size_more = $Exp_Disk_Size+5
			}
			Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less"
			"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Exp_Disk_Size_less" >> $Log
			$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | select DeviceID,Size | Where {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
			$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)
			Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size"
			"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2  $Curr_Disk_Size" >> $Log
			Write-Host "--"
			"--" >> $Log
			#IF($Exp_Disk_Size -lt $Curr_Disk_Size)
			IF($Curr_Disk_Size -lt $Exp_Disk_Size_less)
			{
				$i = 1
			}
		}
	}

	IF($i -eq 1)
	{
		Write-Host "Verification: " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification: FAIL" >> $Log
		$Final_Status_Error = 1
	}
	ELSE
	{
		Write-Host "Verification: " -f white -nonewline; Write-Host "OK" -f green
		"Verification: OK" >> $Log
	}
}
Write-Host "-------"
"-------" >> $Log

<#
if ($edition -eq 's')
{

$cs = Get-WmiObject -class Win32_ComputerSystem
$Sockets=$cs.numberofprocessors
echo $Sockets
if ($Sockets -gt 4)
{
write-host "Sockets are more than 4 : failure  " -f red
}
else
{
write-host "Sockets are less than 4 : Success  " -f green
}
}
$Cores=$cs.numberoflogicalprocessors
echo $Cores
#>
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
IF ($Final_Status_Error -eq 1)
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"FINAL STATUS = FAILED" >> $Log
"FAILED" > $BatchOutput1
Write-Host "Please review the verification steps and address the failed step"
"Please review the verification steps and address the failed step" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1  
}
ELSE
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
"FINAL STATUS = SUCCESS" >> $Log
"SUCCESS" > $BatchOutput1
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}
}

#*********************************** End Function O/S verification ***********************************



#*********************************** Identify server location based on IP address ***********************************
 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	sddc_sql_Pre-Req_OS_Verification $LabSQLDML

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

	sddc_sql_Pre-Req_OS_Verification $NASQLDML

 }
 ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 { 	

	sddc_sql_Pre-Req_OS_Verification $LASQLDML 

   	
 }
 ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 { 	

	sddc_sql_Pre-Req_OS_Verification $EMEASQLDML 

 }
 ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 { 	

	sddc_sql_Pre-Req_OS_Verification $ASPACSQLDML 

 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
	
 }

}

