 #########################################################################
###################################################################################################
$ScriptName = "Precheck.ps1"
$Scriptver = "1.0"
#Description: Pre-implementation script for Decommission.
#Example:- Precheck.ps1 ChangeNumber ServerName InstanceName DatabaseName CoolDownPeriod Type_Of_Decommission
###################################################################################################
#Version Author		Reason for Change
###################################################################################################
#1.0	Darshana	New Script

###################################################################################################
 $ChangeNumber = $args[0]
 $ServerName = $args[1]
 $InstanceName = $args[2]
 $DatabaseName = $args[3]
 $CTaskOrder = $args[4]
 $Type_Of_Decommission = $args[5]##Only for Precheck
 $status = $args[6]

$ESTime = Get-Date
$timenow = (Get-Date -uformat "%m%d%Y%H%M%S")
$Decommission = "$Type_Of_Decommission"


if($Decommission -eq "Database_Decommission")
{
 $Decommission1 = "Database_Decommission"
}elseif($Decommission -eq "InstanceDecommission")
{
 $Decommission2 = "InstanceDecommission"
}elseif($Decommission -eq "Server_Decommission")
{
 $Decommission3 = "Server_Decommission"
}

 if(($ChangeNumber -eq $null) -or ($ServerName -eq $null) -or ($InstanceName -eq $null) -or ($DatabaseName -eq $null) -or ($CTaskOrder -eq $null) -or ($Type_Of_Decommission -eq $null))
 {
  write-host "Please pass the valid Parameters" -f red
  write-host

  write-host "Sample:ChangeNumber as first Parameter,ServerName as second Parameter,InstanceName as third Parameter,DatabaseName as fourth parameter and CTaskOrder as fifth Parameter" -f red
  EXIT 1
 }

if(($Decommission1 -eq "$Decommission") -and ($CTaskOrder -ne "0"))
{
 $Decommission1 = "$Decommission"
 $ChangeNumber = $args[0]
 $ServerName   = $args[1]
 $InstanceName = $args[2]
 [array]$DatabaseName = $args[3]
 $CTaskOrder = $args[4]
 if(($ChangeNumber -eq $null) -or ($ServerName -eq $null) -or ($InstanceName -eq $null) -or ($DatabaseName -eq $null) -or ($CTaskOrder -eq $null) -or ($Type_Of_Decommission -eq $null))
 {
  write-host "Please pass the valid Parameters" -f red

  write-host "Sample:ChangeNumber as first Parameter,ServerName as second Parameter,InstanceName as third Parameter,DatabaseName as fourth parameter and CTaskOrder as fifth Parameter" -f red
  EXIT 1
 }
  else
   {
	
    $text = "$DatabaseName"
	$text|out-file  C:\SQLInstall_Logs\file.txt

   
    $DatabaseDecommission = 'E:\Decom\Db_Decommission.ps1'
    ##########Execute Database Decommission Logic##########
    powershell.exe -ExecutionPolicy Bypass $DatabaseDecommission  $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder $Type_Of_Decommission
   
    
   }       
}



$FinalStatus = '0'

 [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
 [System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null;
 $s = New-Object ('Microsoft.SqlServer.Management.Smo.Server') 
 $DBServerInstanceName = "$ServerName"
 #$connectionString ="Data Source=$s;Integrated Security=true;Initial Catalog=master;Connect Timeout=3;"
 $connectionString = "Data Source=$DBServerInstanceName; " +
            "Integrated Security=SSPI; " +
            "Initial Catalog = 'master'"
 $sqlConn = new-object ("Data.SqlClient.SqlConnection") $connectionString


if(($status -eq "check") -and ($CTaskOrder -eq "1"))
{
 Function status()
 {

try
{

IF ($InstanceName -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstanceName
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{

$BackupStat = "SELECT session_id as SPID, command, a.text AS Query,status, start_time, percent_complete, dateadd(second,estimated_completion_time/1000, getdate()) as estimated_completion_time 
FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) a 
WHERE r.command in ('BACKUP DATABASE')"
$da1 = New-Object System.Data.SqlClient.SqlDataAdapter ($BackupStat, $connectionString)
		 $dt1 = New-Object System.Data.DataTable
		 $da1.fill($dt1)
		 foreach($Row in $dt1.Rows)
		 {
		  $stat = $Row[3]
		  $wait_type = $Row[7]
		  [String]$percent_complete = $Row[5]
		  [String]$Estimated_Completion_time = $Row[6]
	         
	
		}


if(($stat -eq "runnable") -or ($stat -eq "running"))
{
  write-host "Backup Status: " -f white -nonewline; write-host "$stat" -f Yellow
  write-host "Backup is: " -f white -nonewline; write-host "Running" -f Green
  write-host "Percent_Complete: " -f white -nonewline; write-host "$percent_complete" -f Green
  write-host "Estimated Completion Time is: " -f white -nonewline; write-host "$Estimated_Completion_time" -f Green
  write-host "EXIT CODE:99"
EXIT 99
  #write-host "Please wait..." -f White
EXIT $LastExitCode
}
elseif($stat -eq "suspended")
{
   write-host "Backup Status: " -f white -nonewline; write-host "$stat" -f Yellow
  write-host "Backup is in: " -f white -nonewline; write-host "Progress" -f Green
  write-host "Percent_Complete: " -f white -nonewline; write-host "$percent_complete" -f Green
  write-host "Estimated Completion Time is: " -f white -nonewline; write-host "$Estimated_Completion_time" -f Green
  write-host "EXIT CODE:99"
EXIT 99
 #write-host "Please wait..." -f White
EXIT $LastExitCode
}
elseif($stat -eq "Background")
{
  write-host "Backup Status: " -f white -nonewline; write-host "$stat" -f Yellow
  write-host "Backup is waiting for" -f white -nonewline; write-host "$wait_type" -f Green
  write-host "Estimated Completion Time is: " -f white -nonewline; write-host "$Estimated_Completion_time" -f Green 
  write-host "Please fix the problem and continue with Auto-Decommission..." -f Green
  write-host "Exiting.." -f Red
  write-host "EXIT CODE:1"
EXIT 1
 EXIT $LastExitCode
}
elseif($stat -eq "Sleeping")
{
  write-host "Backup Status: " -f white -nonewline; write-host "$status" -f Yellow
 write-host "Backup did not initiate" -F Yellow
 write-host "Please fix the problem and continue with Auto-Decommission..." -f Green
 write-host "Exiting.." -f Red
 write-host "EXIT CODE:1"
EXIT 1
EXIT $LastExitCode
}
elseif($stat -eq $null)
{
 write-host "Adding the server to Blackout window" -f Yellow
 write-host "Backup will start in 2 min." -f Yellow
 write-host "Exiting.." -f Red
 write-host "EXIT CODE:0"
EXIT 0
EXIT $LastExitCode
}
}
IF ($InstanceName -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstanceName
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "stopped")
		{
		Write-Host "SQL Server is offline." -f GREEN
		"" >> $Log
		"SQL Server is offline." >> $LogFolder1
		"" >> $Log
		"######################################################################################" >> $LogFolder1
		
 write-host "Backup Completed: " -f White -nonewline; write-host "Successfully" -f Red
 write-host " EXIT CODE:0 "
EXIT 0
EXIT $LastExitCode

}

}
catch
{
 $ex = $_.Exception
             write-host "Exception is:$ex!"
               write-host "  "
	write-host " $LastExitCode "
}
}
status
}











if(($Decommission2 -eq "$Decommission")-and($CTaskOrder -ne "0"))
{
 $ChangeNumber = $args[0]
 $ServerName = $args[1]
 $InstanceName = $args[2]
 $DatabaseName = $args[3]
 $CTaskOrder = $args[4]
 if(($ChangeNumber -eq $null) -or ($ServerName -eq $null) -or ($InstanceName -eq $null) -or ($DatabaseName -eq $null)  -or ($CTaskOrder -eq $null) -or ($Type_Of_Decommission -eq $null))
 {
  write-host "Please pass the valid Parameters" -f red

  write-host "Sample:ChangeNumber as first Parameter,ServerName as second Parameter,InstanceName as third Parameter and DatabaseName  as fourth Parameter and Version
  as fifth parameter and CTaskOrder as Sixth parameter." -f red
  EXIT 1
 } else
   {
    if(($DatabaseName -eq "ALL") -and ($status -eq $null)) 
    {


     $InstanceDecommission = ' \\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\InstanceDecommission.ps1'
    ###################Execute Instance Decommission Logic#######################
    powershell.exe -ExecutionPolicy Bypass $InstanceDecommission $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder
	EXIT 0
   }
   elseif($DatabaseName -ne "ALL")
   {
     write-host "Please pass the DatabaseName as ALL" -F RED
     write-host "EXIT 1"
     EXIT 1
   }
  }	
}


if(($Decommission3 -eq "$Decommission")-and($CTaskOrder -ne "0"))
{
 $ChangeNumber = $args[0]
 $ServerName = $args[1]
 $InstanceName = $args[2]
 $DatabaseName = $args[3]
 $CDPeriod = $args[4]
 if(($ChangeNumber -eq $null) -or ($ServerName -eq $null) -or ($InstanceName -eq $null) -or ($DatabaseName -eq $null)  -or ($CTaskOrder -eq $null) -or ($Type_Of_Decommission -eq $null))
 {
  write-host "Please pass the valid Parameters" -f red

  write-host "Sample:ChangeNumber as first Parameter,ServerName as second Parameter,InstanceName as third Parameter and DatabaseName  as fourth Parameter and Version
  as fifth parameter and CTaskOrder as Sixth parameter." -f red
  EXIT 1
 } else
   {
    if(($DatabaseName -eq "ALL") -and ($CTaskOrder -ne "0"))
    {


    $ServerDecommission = 'E:\Decom\Server_Decommission.ps1'
    ###################Execute Instance Decommission Logic#######################
    powershell.exe -ExecutionPolicy Bypass $ServerDecommission $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder
    }elseif($DatabaseName -ne "ALL")
     {
       write-host "Please pass the DatabaseName as ALL" -F RED
	Write-host "EXIT 1"
	EXIT 1
     }
   }

}


#########################################################################################
###########################Server Validation Check###################################
######################################################################################
#write-host "Success"


Function getLocation()
{
 
foreach($serv in $ServerName)
{
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]

	IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
	 {
	   IF ($IpPartsIdentifier2 -eq 0) 

 	    { 
		$ServerLocation	= "LAB"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder1
	        " ">>$LogFolder1
		"ServerName:$ServerName">>$LogFolder1
	        write-output "Location:$ServerName belongs to $ServerLocation">>$LogFolder1
		"############################################################################################################################################">>$LogFolder1
		" ">>$LogFolder1

 	    }
	    ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 	    { 
		$ServerLocation	= "NA"
		write-host "$ServerName belongs to $ServerLocation"
		write-output "ServerName:$ServerName">>$LogFolder1
	        write-output "Location:$ServerName belongs to $ServerLocation">>$LogFolder1
		"#####################################################################################################################################">>$LogFolder1
		" ">>$LogFolder1

 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 	    {
		$ServerLocation	= "LA"	
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder1
	        " ">>$LogFolder1
		"ServerName:$ServerName">>$LogFolder1
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder1
		"#################################################################################################################################">>$LogFolder1
		" ">>$LogFolder1

	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 	    {
		$ServerLocation	= "EMEA"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder1
	        " ">>$LogFolder1
		"ServerName:$ServerName">>$LogFolder1
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder1
		"##############################################################################################################################################">>$LogFolder1
		" ">>$LogFolder1

 	    }ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 	    {
		$ServerLocation	= "ASPAC"
		write-host "$ServerName belongs to $ServerLocation"
		" ">>$LogFolder1
	        " ">>$LogFolder1
		"ServerName:$ServerName">>$LogFolder1
	        "Location:$ServerName belongs to $ServerLocation">>$LogFolder1
		"##############################################################################################################################################">>$LogFolder1
		" ">>$LogFolder1

 	    }
	   ELSE 
 	    {
		Write-Host "Server location is unknown, exiting now.." -f red
		" ">>$LogFolder1
	        " ">>$LogFolder1
	        "Server location is unknown, exiting now..">>$LogFolder1
		write-host "EXIT 1"
	        "Exit 1" >> $LogFolder1
		Exit 1
 	    }

	 }			
}

}

###############################To check Folder############################

$LogFolder0 = 'C:'+"\$ChangeNumber"

if(!(test-path $LogFolder0))
{
  New-Item $LogFolder0 -type directory
}else
{
  #Write-host " the log folder exist! "
}

 $LogFolder = $LogFolder0 + "\ITS_Pre-Check_Decommission" 

if(!(test-path $LogFolder))
{
  New-Item $LogFolder -type directory
}else
{
  #Write-host " The log folder exist! "
}

################################To Check File###############################
$LogFolder1 = $LogFolder + "\AUTOMATION_TASK200_VRO_Precheck" + "_$timenow" + ".log" 


if((($CTaskOrder -eq "0")-and($DatabaseName -eq "ALL") -or($status -eq $null)) -and(($Decommission2 -eq $Decommission) -or($Decommission3 -eq $Decommission)))
{

Write-host "   "
    Write-Host "#######################################################################"
    "#######################################################################">>$LogFolder1
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >>$LogFolder1
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >>$LogFolder1
    Write-Host "Execution Start Time: $ESTime"
    "Execution Start Time: $ESTime" >>$LogFolder1
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >>$LogFolder1
    "Execution string: $ScriptName $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder  $Type_Of_Decommission" >>$LogFolder1
getLocation
    Write-Host "#######################################################################"
    "     " >>$LogFolder1
   "     " >>$LogFolder1


###################################To check  if Server is online##########################################################

IF ($InstanceName -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstanceName
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{
		Write-Host "SQL Server is online." -f GREEN
		"" >> $Log
		"SQL Server is online." >> $LogFolder1
		"" >> $Log
		"######################################################################################" >> $LogFolder1
		}
	if ($arrService.Status -eq "Stopped")
		{ 
		Write-Host "ATTENTION: SQL Server is offline. Please check." -f RED
		"" >> $LogFolder1
		"ATTENTION: SQL Server is offline. Please check." >> $LogFolder1
		"" >> $LogFolder1
		"######################################################################################" >> $LogFolder1
		EXIT 1
		EXIT $LastExitCode
		}





write-host "****************Cluster Validation Check**********"
 "************************Cluster Validation Check**************************">>$LogFolder1
 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "   "
write-host "   "

$cs = Get-WmiObject -Class Win32_SystemServices -ComputerName $env:computername
 IF ($cs | select PartComponent | where {$_ -like "*ClusSvc*"}) 
 { 
  $IsClus = "YES" 
   write-host "This is a Clustered Server.Please follow Manual Decommission Process"  -f Green
  write-output "This is a Clustered Server.Please follow Manual Decommission Process" >> $LogFolder1
write-host "  "
write-host "  "
 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host "  "
write-host "  "
"  ">>$LogFolder1
"  ">>$logFolder1
write-host "EXIT 1"
  "EXIT 1">>$LogFolder1
  EXIT 1
EXIT $LastExitCode

 }
ELSE
 { 
   $IsClus = "NO"
   
   write-output "This is not a Clustered Server." >> $LogFolder1
   write-host "This is not a Clustered Server." -f Green
 
 }

##################################################################################################################

   "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "   "
write-host "   "

 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "*********************************Replication Check*********************************"
"*********************************Replication Check****************************************">>$LogFolder1
write-host "   "
write-host "   "

 "     " >>$LogFolder1
   "     " >>$LogFolder1

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null;
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Replication.dll") | Out-Null;
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Rmo") | Out-Null;

$rmo = New-Object Microsoft.SqlServer.Replication.ReplicationServer(".")


if (($rmo.DistributorInstalled -eq $True) -or ($rmo.IsDistributor -eq $True) -or ($rmo.IsPublisher -eq $True) -or ($rmo.RegisteredSubscribers -eq $True)) 
{
    write-output " Replication is present.Please follow Manual Decommission Process" >> $LogFolder1
    write-host " Replication is present.Please follow Manual Decommission Process." -f Red
write-host "  "
write-host "  "
 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host "  "
write-host "  "
"  ">>$LogFolder1
"  ">>$logFolder1
write-host "EXIT 1"
   "EXIT 1">>$LogFolder1
EXIT 1



}
else
{
 write-output "This server does not have Replication feature enabled."  >> $LogFolder1
 write-host "This server does not have Replication feature enabled." -f Green

}

 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host
write-host 

write-host "*********************************Mirroring Check*********************************"
"*********************************Mirroring Check****************************************">>$LogFolder1
write-host "   "
write-host "   "
 "     " >>$LogFolder1
   "     " >>$LogFolder1

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null;

$srv = New-Object Microsoft.SqlServer.Management.Smo.Server $ServerName
$db = New-Object Microsoft.SqlServer.Management.Smo.Database

$mirroreddb = $Servername.Databases | Where-Object { $_.IsMirroringEnabled -eq $true }

if($mirroreddb.length -gt 0)
{
            
   Write-output "Databases are being mirrored: $($mirroreddbname).Please follow Manual Decommission process." >>$LogFolder1
    Write-host "Databases are being mirrored: $($mirroreddbname).Please follow Manual Decommission process." - f red
   "EXIT 1">>$LogFolder1

write-host 

 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host
write-host "EXIT 1" 
"  ">>$LogFolder1
"  ">>$logFolder1
   "EXIT 1">>$LogFolder1  
 EXIT 1

}
              
else
{
   Write-output "No mirroring is configured on Databases." >> $LogFolder1
   Write-host "No mirroring is configured on Databases." -f green

  write-host 

#write-host "EXIT 0"
}

##################################################################################################################

 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "#################################################################################"
	write-host
	write-host

        write-host "cTaskname : Pre-implementation verification,
         status :  success,
         message:  Database $DatabaseName on host $ServerName found. Script executed on $ESTime,
         cTaskorder : 200"

	write-host "#################################################################################"
	write-host
	write-host

         "cTaskname : Pre-implementation verification,
         status :  success,
         message:  Database $DatabaseName on host $ServerName found. Script executed on $ESTime,
         cTaskorder : 200" >> $LogFolder1

#write-host "EXIT 0"
"EXIT 0" >>$LogFolder1

 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"

EXIT 0 
EXIT $LastExitCode

#################################################################################################################
}
elseif(($CTaskOrder -eq "0")-and($DatabaseName -ne "ALL")-and($Decommission1 -eq $Decommission))
{

Write-host "   "
    Write-Host "#######################################################################"
    "#######################################################################">>$LogFolder1
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >>$LogFolder1
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >>$LogFolder1
    Write-Host "Execution Start Time: $ESTime"
    "Execution Start Time: $ESTime" >>$LogFolder1
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >>$LogFolder1
    "Execution string: $ScriptName $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder  $Type_Of_Decommission" >>$LogFolder1
getLocation
    Write-Host "#######################################################################"
    "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host
write-host

###################################To check  if Server is online##########################################################

IF ($InstanceName -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstanceName
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{
		Write-Host "SQL Server is online." -f GREEN
		"" >> $Log
		"SQL Server is online." >> $LogFolder1
		"" >> $Log
		"######################################################################################" >> $LogFolder1
		}
	if ($arrService.Status -eq "Stopped")
		{ 
		Write-Host "ATTENTION: SQL Server is offline. Please check." -f RED
		"" >> $LogFolder1
		"ATTENTION: SQL Server is offline. Please check." >> $LogFolder1
		"" >> $LogFolder1
		"######################################################################################" >> $LogFolder1
		EXIT 1
		}




write-host "****************Cluster Validation Check**********"
 "************************Cluster Validation Check**************************">>$LogFolder1
 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "   "
write-host "   "

$cs = Get-WmiObject -Class Win32_SystemServices -ComputerName $env:computername
 IF ($cs | select PartComponent | where {$_ -like "*ClusSvc*"}) 
 { 
  $IsClus = "YES" 
   write-host "This is a Clustered Server.Please follow Manual Decommission Process"  -f Green
  write-output "This is a Clustered Server.Please follow Manual Decommission Process" >> $LogFolder1
write-host "  "
write-host "  "
 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host "  "
write-host "  "
"  ">>$LogFolder1
"  ">>$logFolder1
write-host "EXIT 1"
  "EXIT 1">>$LogFolder1
  EXIT 1


 }
ELSE
 { 
   $IsClus = "NO"
   
   write-output "This is not a Clustered Server." >> $LogFolder1
   write-host "This is not a Clustered Server." -f Green
 
 }

##################################################################################################################

   "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "   "
write-host "   "

 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "*********************************Replication Check*********************************"
"*********************************Replication Check****************************************">>$LogFolder1
write-host "   "
write-host "   "

 "     " >>$LogFolder1
   "     " >>$LogFolder1

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null;
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Replication.dll") | Out-Null;
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Rmo") | Out-Null;

$rmo = New-Object Microsoft.SqlServer.Replication.ReplicationServer(".")


if (($rmo.DistributorInstalled -eq $True) -or ($rmo.IsDistributor -eq $True) -or ($rmo.IsPublisher -eq $True) -or ($rmo.RegisteredSubscribers -eq $True)) 
{
    write-output " Replication is present.Please follow Manual Decommission Process" >> $LogFolder1
    write-host " Replication is present.Please follow Manual Decommission Process." -f Red
write-host "  "
write-host "  "
 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host "  "
write-host "  "
"  ">>$LogFolder1
"  ">>$logFolder1
write-host "EXIT 1"
   "EXIT 1">>$LogFolder1
EXIT 1



}
else
{
 write-output "This server does not have Replication feature enabled."  >> $LogFolder1
 write-host "This server does not have Replication feature enabled." -f Green

}

 "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host
write-host 

write-host "*********************************Mirroring Check*********************************"
"*********************************Mirroring Check****************************************">>$LogFolder1
write-host "   "
write-host "   "
 "     " >>$LogFolder1
   "     " >>$LogFolder1

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null;

$srv = New-Object Microsoft.SqlServer.Management.Smo.Server $ServerName
$db = New-Object Microsoft.SqlServer.Management.Smo.Database

$mirroreddb = $Servername.Databases | Where-Object { $_.IsMirroringEnabled -eq $true }

if($mirroreddb.length -gt 0)
{
            
   Write-output "Databases are being mirrored: $($mirroreddbname).Please follow Manual Decommission process." >>$LogFolder1
    Write-host "Databases are being mirrored: $($mirroreddbname).Please follow Manual Decommission process." - f red
   "EXIT 1">>$LogFolder1

write-host 

 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host
write-host "EXIT 1" 
"  ">>$LogFolder1
"  ">>$logFolder1
   "EXIT 1">>$LogFolder1  
 EXIT 1

}
              
else
{
   Write-output "No mirroring is configured on Databases." >> $LogFolder1
   Write-host "No mirroring is configured on Databases." -f green

  write-host 


}

##################################################################################################################

 "     " >>$LogFolder1
   "     " >>$LogFolder1


#"EXIT 0" >>$LogFolder1

       

 $EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"
write-host "EXIT 0"
#################################################################################################################
}
elseif(($CTaskOrder -eq "0") -and ($DatabaseName -ne "ALL") -and ($Decommission -ne "$Decommission1"))
{

    Write-host "   "
    Write-Host "#######################################################################"
    "#######################################################################">>$LogFolder1
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    "Script Name: $ScriptName" >>$LogFolder1
    Write-Host "Script Version: $Scriptver"
    "Script Version: $Scriptver" >>$LogFolder1
    Write-Host "Execution Start Time: $ESTime"
    "Execution Start Time: $ESTime" >>$LogFolder1
    Write-Host "Server Host: $Hostname"
    "Server Host: $Hostname" >>$LogFolder1
    "Execution string: $ScriptName $ChangeNumber $ServerName $InstanceName $DatabaseName $CTaskOrder $Type_Of_Decommission" >>$LogFolder1
    getLocation
    Write-Host "#######################################################################"
    "     " >>$LogFolder1
   "     " >>$LogFolder1

write-host "Please pass the valid parameter  " -f Red
write-host
write-host "Sample:For Precheck Implementation, Please pass the value as 'ALL' for fourth parameter,
                      Value as '0' for fifth parameter,
		      Value as Instance_Decommission or Server_Decommission depending on Type_Of_decommission
			 you want to perform for Sixth Parameter" -f Green

"Please pass the valid parameter" >>$LogFolder1

write-host 


 "     " >>$LogFolder1
   "     " >>$LogFolder1

"Sample:For Precheck Implementation, Please pass the value as 'ALL' for fourth parameter,
                      Value as '0' for fifth parameter,
		      Value as Instance_Decommission or Server_Decommission depending on Type_Of_decommission
			 you want to perform for Sixth Parameter" >>$LogFolder1

write-host

 "     " >>$LogFolder1
   "     " >>$LogFolder1

$EETime = Get-Date
 "Execution End Time: $EETime" >> $LogFolder1
 write-host "Execution End Time: $EETime"

 "     " >>$LogFolder1
   "     " >>$LogFolder1
write-host
write-host "EXIT 1"
"EXIT 1" >>$LogFolder1

EXIT 1

EXIT $LastExitCode
}
  
  