
/* ---------------------------------------------------------------------------------------------------------*/
/* SCRIPTS TO ENABLE AND CONFIGURE THE SQL SERVER 2005 NATIVE AUDITING FEATURE								*/
/* THIS SCRIPT WILL:														 								*/
/*			1. CREATE TRACE FILES USED TO COLLECT EVENTS													*/
/*			2. CREATE TABLES AND SP's IN master DB TO MAINTAIN THE PROCESS AND RETAIN EVENTS				*/
/*			   FOR 7 DAYS 																					*/
/*			3. CREATE JOBS TO MAINTAIN THE PROCESS															*/
/*			4. CREATE ROLE AND GRANT ACCESS TO RSA ACCOUNT													*/
/*----------------------------------------------------------------------------------------------------------*/
/* Date Of Issued	Revision Number		Author			Reason for Change									*/
/*----------------------------------------------------------------------------------------------------------*/
/* N/A				1.0					N/A				- New Procedure										*/
/* 11/14/2014		2.0					Bruno Campos	- Redefine events being collected					*/
/*														- Added scrip to create role and grant access to	*/
/*														  RSA account										*/
/*----------------------------------------------------------------------------------------------------------*/

/* ----------------------------------------------------------------------------------
 Procedure Name	:Usp_SecurityEventAudit						
 Description		:SQL Profile trace script			 		
--------------------------------------------------------------------------------------*/
USE master
GO

USE master
GO
sp_configure 'show advanced options', 1;
GO
reconfigure
GO
sp_configure 'xp_cmdshell',1
GO
reconfigure
GO

xp_cmdshell 'MD D:\SQLNativeAudit'
GO
xp_cmdshell 'DEL D:\SQLNativeAudit\*.* /Q'
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Usp_SecurityEventAudit]'))
drop procedure [dbo].[Usp_SecurityEventAudit]
go
create procedure Usp_SecurityEventAudit
as

-- Create a Queue
declare @rc int
declare @TraceID int
declare @maxfilesize bigint
set @maxfilesize = 5 

-- Please replace the text InsertFileNameHere, with an appropriate
-- filename prefixed by a path, e.g., c:\MyFolder\MyTrace. The .trc extension
-- will be appended to the filename automatically. If you are writing from
-- remote server to local drive, please use UNC path and make sure server has
-- write access to your network share

exec @rc = sp_trace_create @TraceID output, 0, N'D:\SQLNativeAudit\SecurityEventAudit', @maxfilesize, NULL 
if (@rc != 0) goto error

-- Client side File and Table cannot be scripted

-- Set the events
declare @on bit
set @on = 1
exec sp_trace_setevent @TraceID, 109, 7, @on
exec sp_trace_setevent @TraceID, 109, 23, @on
exec sp_trace_setevent @TraceID, 109, 39, @on
exec sp_trace_setevent @TraceID, 109, 8, @on
exec sp_trace_setevent @TraceID, 109, 40, @on
exec sp_trace_setevent @TraceID, 109, 64, @on
exec sp_trace_setevent @TraceID, 109, 9, @on
exec sp_trace_setevent @TraceID, 109, 41, @on
exec sp_trace_setevent @TraceID, 109, 49, @on
exec sp_trace_setevent @TraceID, 109, 10, @on
exec sp_trace_setevent @TraceID, 109, 26, @on
exec sp_trace_setevent @TraceID, 109, 42, @on
exec sp_trace_setevent @TraceID, 109, 50, @on
exec sp_trace_setevent @TraceID, 109, 3, @on
exec sp_trace_setevent @TraceID, 109, 11, @on
exec sp_trace_setevent @TraceID, 109, 27, @on
exec sp_trace_setevent @TraceID, 109, 35, @on
exec sp_trace_setevent @TraceID, 109, 43, @on
exec sp_trace_setevent @TraceID, 109, 51, @on
exec sp_trace_setevent @TraceID, 109, 4, @on
exec sp_trace_setevent @TraceID, 109, 12, @on
exec sp_trace_setevent @TraceID, 109, 28, @on
exec sp_trace_setevent @TraceID, 109, 44, @on
exec sp_trace_setevent @TraceID, 109, 60, @on
exec sp_trace_setevent @TraceID, 109, 21, @on
exec sp_trace_setevent @TraceID, 109, 29, @on
exec sp_trace_setevent @TraceID, 109, 37, @on
exec sp_trace_setevent @TraceID, 109, 6, @on
exec sp_trace_setevent @TraceID, 109, 14, @on
exec sp_trace_setevent @TraceID, 109, 38, @on
exec sp_trace_setevent @TraceID, 108, 7, @on
exec sp_trace_setevent @TraceID, 108, 23, @on
exec sp_trace_setevent @TraceID, 108, 8, @on
exec sp_trace_setevent @TraceID, 108, 40, @on
exec sp_trace_setevent @TraceID, 108, 64, @on
exec sp_trace_setevent @TraceID, 108, 1, @on
exec sp_trace_setevent @TraceID, 108, 9, @on
exec sp_trace_setevent @TraceID, 108, 41, @on
exec sp_trace_setevent @TraceID, 108, 49, @on
exec sp_trace_setevent @TraceID, 108, 10, @on
exec sp_trace_setevent @TraceID, 108, 26, @on
exec sp_trace_setevent @TraceID, 108, 34, @on
exec sp_trace_setevent @TraceID, 108, 42, @on
exec sp_trace_setevent @TraceID, 108, 50, @on
exec sp_trace_setevent @TraceID, 108, 3, @on
exec sp_trace_setevent @TraceID, 108, 11, @on
exec sp_trace_setevent @TraceID, 108, 27, @on
exec sp_trace_setevent @TraceID, 108, 35, @on
exec sp_trace_setevent @TraceID, 108, 43, @on
exec sp_trace_setevent @TraceID, 108, 51, @on
exec sp_trace_setevent @TraceID, 108, 4, @on
exec sp_trace_setevent @TraceID, 108, 12, @on
exec sp_trace_setevent @TraceID, 108, 28, @on
exec sp_trace_setevent @TraceID, 108, 60, @on
exec sp_trace_setevent @TraceID, 108, 21, @on
exec sp_trace_setevent @TraceID, 108, 29, @on
exec sp_trace_setevent @TraceID, 108, 37, @on
exec sp_trace_setevent @TraceID, 108, 6, @on
exec sp_trace_setevent @TraceID, 108, 14, @on
exec sp_trace_setevent @TraceID, 108, 38, @on
exec sp_trace_setevent @TraceID, 110, 7, @on
exec sp_trace_setevent @TraceID, 110, 23, @on
exec sp_trace_setevent @TraceID, 110, 39, @on
exec sp_trace_setevent @TraceID, 110, 8, @on
exec sp_trace_setevent @TraceID, 110, 40, @on
exec sp_trace_setevent @TraceID, 110, 64, @on
exec sp_trace_setevent @TraceID, 110, 1, @on
exec sp_trace_setevent @TraceID, 110, 9, @on
exec sp_trace_setevent @TraceID, 110, 41, @on
exec sp_trace_setevent @TraceID, 110, 49, @on
exec sp_trace_setevent @TraceID, 110, 10, @on
exec sp_trace_setevent @TraceID, 110, 26, @on
exec sp_trace_setevent @TraceID, 110, 34, @on
exec sp_trace_setevent @TraceID, 110, 42, @on
exec sp_trace_setevent @TraceID, 110, 50, @on
exec sp_trace_setevent @TraceID, 110, 3, @on
exec sp_trace_setevent @TraceID, 110, 11, @on
exec sp_trace_setevent @TraceID, 110, 27, @on
exec sp_trace_setevent @TraceID, 110, 35, @on
exec sp_trace_setevent @TraceID, 110, 43, @on
exec sp_trace_setevent @TraceID, 110, 51, @on
exec sp_trace_setevent @TraceID, 110, 4, @on
exec sp_trace_setevent @TraceID, 110, 12, @on
exec sp_trace_setevent @TraceID, 110, 28, @on
exec sp_trace_setevent @TraceID, 110, 60, @on
exec sp_trace_setevent @TraceID, 110, 21, @on
exec sp_trace_setevent @TraceID, 110, 29, @on
exec sp_trace_setevent @TraceID, 110, 37, @on
exec sp_trace_setevent @TraceID, 110, 6, @on
exec sp_trace_setevent @TraceID, 110, 14, @on
exec sp_trace_setevent @TraceID, 110, 38, @on
exec sp_trace_setevent @TraceID, 111, 7, @on
exec sp_trace_setevent @TraceID, 111, 23, @on
exec sp_trace_setevent @TraceID, 111, 8, @on
exec sp_trace_setevent @TraceID, 111, 40, @on
exec sp_trace_setevent @TraceID, 111, 64, @on
exec sp_trace_setevent @TraceID, 111, 9, @on
exec sp_trace_setevent @TraceID, 111, 41, @on
exec sp_trace_setevent @TraceID, 111, 49, @on
exec sp_trace_setevent @TraceID, 111, 6, @on
exec sp_trace_setevent @TraceID, 111, 10, @on
exec sp_trace_setevent @TraceID, 111, 14, @on
exec sp_trace_setevent @TraceID, 111, 26, @on
exec sp_trace_setevent @TraceID, 111, 38, @on
exec sp_trace_setevent @TraceID, 111, 50, @on
exec sp_trace_setevent @TraceID, 111, 3, @on
exec sp_trace_setevent @TraceID, 111, 11, @on
exec sp_trace_setevent @TraceID, 111, 27, @on
exec sp_trace_setevent @TraceID, 111, 35, @on
exec sp_trace_setevent @TraceID, 111, 51, @on
exec sp_trace_setevent @TraceID, 111, 4, @on
exec sp_trace_setevent @TraceID, 111, 12, @on
exec sp_trace_setevent @TraceID, 111, 28, @on
exec sp_trace_setevent @TraceID, 111, 60, @on
exec sp_trace_setevent @TraceID, 111, 21, @on
exec sp_trace_setevent @TraceID, 111, 29, @on
exec sp_trace_setevent @TraceID, 104, 7, @on
exec sp_trace_setevent @TraceID, 104, 23, @on
exec sp_trace_setevent @TraceID, 104, 8, @on
exec sp_trace_setevent @TraceID, 104, 40, @on
exec sp_trace_setevent @TraceID, 104, 64, @on
exec sp_trace_setevent @TraceID, 104, 9, @on
exec sp_trace_setevent @TraceID, 104, 41, @on
exec sp_trace_setevent @TraceID, 104, 49, @on
exec sp_trace_setevent @TraceID, 104, 6, @on
exec sp_trace_setevent @TraceID, 104, 10, @on
exec sp_trace_setevent @TraceID, 104, 14, @on
exec sp_trace_setevent @TraceID, 104, 26, @on
exec sp_trace_setevent @TraceID, 104, 42, @on
exec sp_trace_setevent @TraceID, 104, 50, @on
exec sp_trace_setevent @TraceID, 104, 3, @on
exec sp_trace_setevent @TraceID, 104, 11, @on
exec sp_trace_setevent @TraceID, 104, 27, @on
exec sp_trace_setevent @TraceID, 104, 35, @on
exec sp_trace_setevent @TraceID, 104, 43, @on
exec sp_trace_setevent @TraceID, 104, 51, @on
exec sp_trace_setevent @TraceID, 104, 4, @on
exec sp_trace_setevent @TraceID, 104, 12, @on
exec sp_trace_setevent @TraceID, 104, 28, @on
exec sp_trace_setevent @TraceID, 104, 60, @on
exec sp_trace_setevent @TraceID, 104, 5, @on
exec sp_trace_setevent @TraceID, 104, 21, @on
exec sp_trace_setevent @TraceID, 112, 7, @on
exec sp_trace_setevent @TraceID, 112, 23, @on
exec sp_trace_setevent @TraceID, 112, 8, @on
exec sp_trace_setevent @TraceID, 112, 40, @on
exec sp_trace_setevent @TraceID, 112, 64, @on
exec sp_trace_setevent @TraceID, 112, 1, @on
exec sp_trace_setevent @TraceID, 112, 9, @on
exec sp_trace_setevent @TraceID, 112, 41, @on
exec sp_trace_setevent @TraceID, 112, 49, @on
exec sp_trace_setevent @TraceID, 112, 6, @on
exec sp_trace_setevent @TraceID, 112, 10, @on
exec sp_trace_setevent @TraceID, 112, 14, @on
exec sp_trace_setevent @TraceID, 112, 26, @on
exec sp_trace_setevent @TraceID, 112, 34, @on
exec sp_trace_setevent @TraceID, 112, 38, @on
exec sp_trace_setevent @TraceID, 112, 50, @on
exec sp_trace_setevent @TraceID, 112, 3, @on
exec sp_trace_setevent @TraceID, 112, 11, @on
exec sp_trace_setevent @TraceID, 112, 27, @on
exec sp_trace_setevent @TraceID, 112, 35, @on
exec sp_trace_setevent @TraceID, 112, 51, @on
exec sp_trace_setevent @TraceID, 112, 4, @on
exec sp_trace_setevent @TraceID, 112, 12, @on
exec sp_trace_setevent @TraceID, 112, 28, @on
exec sp_trace_setevent @TraceID, 112, 60, @on
exec sp_trace_setevent @TraceID, 112, 29, @on
exec sp_trace_setevent @TraceID, 112, 37, @on
exec sp_trace_setevent @TraceID, 117, 7, @on
exec sp_trace_setevent @TraceID, 117, 23, @on
exec sp_trace_setevent @TraceID, 117, 8, @on
exec sp_trace_setevent @TraceID, 117, 40, @on
exec sp_trace_setevent @TraceID, 117, 64, @on
exec sp_trace_setevent @TraceID, 117, 1, @on
exec sp_trace_setevent @TraceID, 117, 9, @on
exec sp_trace_setevent @TraceID, 117, 41, @on
exec sp_trace_setevent @TraceID, 117, 49, @on
exec sp_trace_setevent @TraceID, 117, 6, @on
exec sp_trace_setevent @TraceID, 117, 10, @on
exec sp_trace_setevent @TraceID, 117, 14, @on
exec sp_trace_setevent @TraceID, 117, 26, @on
exec sp_trace_setevent @TraceID, 117, 50, @on
exec sp_trace_setevent @TraceID, 117, 3, @on
exec sp_trace_setevent @TraceID, 117, 11, @on
exec sp_trace_setevent @TraceID, 117, 27, @on
exec sp_trace_setevent @TraceID, 117, 35, @on
exec sp_trace_setevent @TraceID, 117, 51, @on
exec sp_trace_setevent @TraceID, 117, 12, @on
exec sp_trace_setevent @TraceID, 117, 44, @on
exec sp_trace_setevent @TraceID, 117, 60, @on
exec sp_trace_setevent @TraceID, 117, 5, @on
exec sp_trace_setevent @TraceID, 117, 21, @on
exec sp_trace_setevent @TraceID, 117, 29, @on
exec sp_trace_setevent @TraceID, 117, 37, @on
exec sp_trace_setevent @TraceID, 128, 7, @on
exec sp_trace_setevent @TraceID, 128, 23, @on
exec sp_trace_setevent @TraceID, 128, 8, @on
exec sp_trace_setevent @TraceID, 128, 40, @on
exec sp_trace_setevent @TraceID, 128, 64, @on
exec sp_trace_setevent @TraceID, 128, 1, @on
exec sp_trace_setevent @TraceID, 128, 41, @on
exec sp_trace_setevent @TraceID, 128, 49, @on
exec sp_trace_setevent @TraceID, 128, 6, @on
exec sp_trace_setevent @TraceID, 128, 10, @on
exec sp_trace_setevent @TraceID, 128, 14, @on
exec sp_trace_setevent @TraceID, 128, 26, @on
exec sp_trace_setevent @TraceID, 128, 34, @on
exec sp_trace_setevent @TraceID, 128, 50, @on
exec sp_trace_setevent @TraceID, 128, 3, @on
exec sp_trace_setevent @TraceID, 128, 11, @on
exec sp_trace_setevent @TraceID, 128, 35, @on
exec sp_trace_setevent @TraceID, 128, 51, @on
exec sp_trace_setevent @TraceID, 128, 4, @on
exec sp_trace_setevent @TraceID, 128, 12, @on
exec sp_trace_setevent @TraceID, 128, 28, @on
exec sp_trace_setevent @TraceID, 128, 60, @on
exec sp_trace_setevent @TraceID, 128, 21, @on
exec sp_trace_setevent @TraceID, 128, 29, @on
exec sp_trace_setevent @TraceID, 128, 37, @on
exec sp_trace_setevent @TraceID, 130, 7, @on
exec sp_trace_setevent @TraceID, 130, 23, @on
exec sp_trace_setevent @TraceID, 130, 39, @on
exec sp_trace_setevent @TraceID, 130, 8, @on
exec sp_trace_setevent @TraceID, 130, 40, @on
exec sp_trace_setevent @TraceID, 130, 64, @on
exec sp_trace_setevent @TraceID, 130, 1, @on
exec sp_trace_setevent @TraceID, 130, 41, @on
exec sp_trace_setevent @TraceID, 130, 49, @on
exec sp_trace_setevent @TraceID, 130, 6, @on
exec sp_trace_setevent @TraceID, 130, 10, @on
exec sp_trace_setevent @TraceID, 130, 14, @on
exec sp_trace_setevent @TraceID, 130, 26, @on
exec sp_trace_setevent @TraceID, 130, 34, @on
exec sp_trace_setevent @TraceID, 130, 42, @on
exec sp_trace_setevent @TraceID, 130, 50, @on
exec sp_trace_setevent @TraceID, 130, 3, @on
exec sp_trace_setevent @TraceID, 130, 11, @on
exec sp_trace_setevent @TraceID, 130, 35, @on
exec sp_trace_setevent @TraceID, 130, 43, @on
exec sp_trace_setevent @TraceID, 130, 51, @on
exec sp_trace_setevent @TraceID, 130, 4, @on
exec sp_trace_setevent @TraceID, 130, 12, @on
exec sp_trace_setevent @TraceID, 130, 28, @on
exec sp_trace_setevent @TraceID, 130, 60, @on
exec sp_trace_setevent @TraceID, 130, 21, @on
exec sp_trace_setevent @TraceID, 130, 29, @on
exec sp_trace_setevent @TraceID, 130, 37, @on
exec sp_trace_setevent @TraceID, 102, 7, @on
exec sp_trace_setevent @TraceID, 102, 23, @on
exec sp_trace_setevent @TraceID, 102, 39, @on
exec sp_trace_setevent @TraceID, 102, 8, @on
exec sp_trace_setevent @TraceID, 102, 40, @on
exec sp_trace_setevent @TraceID, 102, 64, @on
exec sp_trace_setevent @TraceID, 102, 1, @on
exec sp_trace_setevent @TraceID, 102, 9, @on
exec sp_trace_setevent @TraceID, 102, 41, @on
exec sp_trace_setevent @TraceID, 102, 49, @on
exec sp_trace_setevent @TraceID, 102, 10, @on
exec sp_trace_setevent @TraceID, 102, 26, @on
exec sp_trace_setevent @TraceID, 102, 34, @on
exec sp_trace_setevent @TraceID, 102, 42, @on
exec sp_trace_setevent @TraceID, 102, 50, @on
exec sp_trace_setevent @TraceID, 102, 3, @on
exec sp_trace_setevent @TraceID, 102, 11, @on
exec sp_trace_setevent @TraceID, 102, 19, @on
exec sp_trace_setevent @TraceID, 102, 27, @on
exec sp_trace_setevent @TraceID, 102, 35, @on
exec sp_trace_setevent @TraceID, 102, 43, @on
exec sp_trace_setevent @TraceID, 102, 51, @on
exec sp_trace_setevent @TraceID, 102, 4, @on
exec sp_trace_setevent @TraceID, 102, 12, @on
exec sp_trace_setevent @TraceID, 102, 28, @on
exec sp_trace_setevent @TraceID, 102, 60, @on
exec sp_trace_setevent @TraceID, 102, 5, @on
exec sp_trace_setevent @TraceID, 102, 21, @on
exec sp_trace_setevent @TraceID, 102, 29, @on
exec sp_trace_setevent @TraceID, 102, 37, @on
exec sp_trace_setevent @TraceID, 102, 6, @on
exec sp_trace_setevent @TraceID, 102, 14, @on
exec sp_trace_setevent @TraceID, 14, 7, @on
exec sp_trace_setevent @TraceID, 14, 23, @on
exec sp_trace_setevent @TraceID, 14, 8, @on
exec sp_trace_setevent @TraceID, 14, 64, @on
exec sp_trace_setevent @TraceID, 14, 1, @on
exec sp_trace_setevent @TraceID, 14, 9, @on
exec sp_trace_setevent @TraceID, 14, 21, @on
exec sp_trace_setevent @TraceID, 14, 25, @on
exec sp_trace_setevent @TraceID, 14, 41, @on
exec sp_trace_setevent @TraceID, 14, 49, @on
exec sp_trace_setevent @TraceID, 14, 2, @on
exec sp_trace_setevent @TraceID, 14, 6, @on
exec sp_trace_setevent @TraceID, 14, 10, @on
exec sp_trace_setevent @TraceID, 14, 14, @on
exec sp_trace_setevent @TraceID, 14, 26, @on
exec sp_trace_setevent @TraceID, 14, 3, @on
exec sp_trace_setevent @TraceID, 14, 11, @on
exec sp_trace_setevent @TraceID, 14, 27, @on
exec sp_trace_setevent @TraceID, 14, 35, @on
exec sp_trace_setevent @TraceID, 14, 51, @on
exec sp_trace_setevent @TraceID, 14, 12, @on
exec sp_trace_setevent @TraceID, 14, 60, @on
exec sp_trace_setevent @TraceID, 107, 7, @on
exec sp_trace_setevent @TraceID, 107, 23, @on
exec sp_trace_setevent @TraceID, 107, 8, @on
exec sp_trace_setevent @TraceID, 107, 40, @on
exec sp_trace_setevent @TraceID, 107, 64, @on
exec sp_trace_setevent @TraceID, 107, 1, @on
exec sp_trace_setevent @TraceID, 107, 9, @on
exec sp_trace_setevent @TraceID, 107, 41, @on
exec sp_trace_setevent @TraceID, 107, 49, @on
exec sp_trace_setevent @TraceID, 107, 10, @on
exec sp_trace_setevent @TraceID, 107, 26, @on
exec sp_trace_setevent @TraceID, 107, 34, @on
exec sp_trace_setevent @TraceID, 107, 42, @on
exec sp_trace_setevent @TraceID, 107, 50, @on
exec sp_trace_setevent @TraceID, 107, 3, @on
exec sp_trace_setevent @TraceID, 107, 11, @on
exec sp_trace_setevent @TraceID, 107, 27, @on
exec sp_trace_setevent @TraceID, 107, 35, @on
exec sp_trace_setevent @TraceID, 107, 43, @on
exec sp_trace_setevent @TraceID, 107, 51, @on
exec sp_trace_setevent @TraceID, 107, 4, @on
exec sp_trace_setevent @TraceID, 107, 12, @on
exec sp_trace_setevent @TraceID, 107, 28, @on
exec sp_trace_setevent @TraceID, 107, 60, @on
exec sp_trace_setevent @TraceID, 107, 21, @on
exec sp_trace_setevent @TraceID, 107, 29, @on
exec sp_trace_setevent @TraceID, 107, 37, @on
exec sp_trace_setevent @TraceID, 107, 6, @on
exec sp_trace_setevent @TraceID, 107, 14, @on
exec sp_trace_setevent @TraceID, 106, 7, @on
exec sp_trace_setevent @TraceID, 106, 23, @on
exec sp_trace_setevent @TraceID, 106, 8, @on
exec sp_trace_setevent @TraceID, 106, 40, @on
exec sp_trace_setevent @TraceID, 106, 64, @on
exec sp_trace_setevent @TraceID, 106, 1, @on
exec sp_trace_setevent @TraceID, 106, 9, @on
exec sp_trace_setevent @TraceID, 106, 41, @on
exec sp_trace_setevent @TraceID, 106, 49, @on
exec sp_trace_setevent @TraceID, 106, 10, @on
exec sp_trace_setevent @TraceID, 106, 26, @on
exec sp_trace_setevent @TraceID, 106, 34, @on
exec sp_trace_setevent @TraceID, 106, 42, @on
exec sp_trace_setevent @TraceID, 106, 50, @on
exec sp_trace_setevent @TraceID, 106, 3, @on
exec sp_trace_setevent @TraceID, 106, 11, @on
exec sp_trace_setevent @TraceID, 106, 27, @on
exec sp_trace_setevent @TraceID, 106, 35, @on
exec sp_trace_setevent @TraceID, 106, 43, @on
exec sp_trace_setevent @TraceID, 106, 51, @on
exec sp_trace_setevent @TraceID, 106, 4, @on
exec sp_trace_setevent @TraceID, 106, 12, @on
exec sp_trace_setevent @TraceID, 106, 28, @on
exec sp_trace_setevent @TraceID, 106, 60, @on
exec sp_trace_setevent @TraceID, 106, 5, @on
exec sp_trace_setevent @TraceID, 106, 21, @on
exec sp_trace_setevent @TraceID, 106, 29, @on
exec sp_trace_setevent @TraceID, 106, 37, @on
exec sp_trace_setevent @TraceID, 106, 6, @on
exec sp_trace_setevent @TraceID, 106, 14, @on
exec sp_trace_setevent @TraceID, 20, 7, @on
exec sp_trace_setevent @TraceID, 20, 23, @on
exec sp_trace_setevent @TraceID, 20, 31, @on
exec sp_trace_setevent @TraceID, 20, 8, @on
exec sp_trace_setevent @TraceID, 20, 12, @on
exec sp_trace_setevent @TraceID, 20, 60, @on
exec sp_trace_setevent @TraceID, 20, 64, @on
exec sp_trace_setevent @TraceID, 20, 1, @on
exec sp_trace_setevent @TraceID, 20, 9, @on
exec sp_trace_setevent @TraceID, 20, 21, @on
exec sp_trace_setevent @TraceID, 20, 49, @on
exec sp_trace_setevent @TraceID, 20, 6, @on
exec sp_trace_setevent @TraceID, 20, 10, @on
exec sp_trace_setevent @TraceID, 20, 14, @on
exec sp_trace_setevent @TraceID, 20, 26, @on
exec sp_trace_setevent @TraceID, 20, 3, @on
exec sp_trace_setevent @TraceID, 20, 11, @on
exec sp_trace_setevent @TraceID, 20, 27, @on
exec sp_trace_setevent @TraceID, 20, 35, @on
exec sp_trace_setevent @TraceID, 20, 51, @on
exec sp_trace_setevent @TraceID, 105, 7, @on
exec sp_trace_setevent @TraceID, 105, 23, @on
exec sp_trace_setevent @TraceID, 105, 8, @on
exec sp_trace_setevent @TraceID, 105, 40, @on
exec sp_trace_setevent @TraceID, 105, 64, @on
exec sp_trace_setevent @TraceID, 105, 9, @on
exec sp_trace_setevent @TraceID, 105, 41, @on
exec sp_trace_setevent @TraceID, 105, 49, @on
exec sp_trace_setevent @TraceID, 105, 6, @on
exec sp_trace_setevent @TraceID, 105, 10, @on
exec sp_trace_setevent @TraceID, 105, 14, @on
exec sp_trace_setevent @TraceID, 105, 26, @on
exec sp_trace_setevent @TraceID, 105, 42, @on
exec sp_trace_setevent @TraceID, 105, 50, @on
exec sp_trace_setevent @TraceID, 105, 3, @on
exec sp_trace_setevent @TraceID, 105, 11, @on
exec sp_trace_setevent @TraceID, 105, 27, @on
exec sp_trace_setevent @TraceID, 105, 35, @on
exec sp_trace_setevent @TraceID, 105, 43, @on
exec sp_trace_setevent @TraceID, 105, 51, @on
exec sp_trace_setevent @TraceID, 105, 4, @on
exec sp_trace_setevent @TraceID, 105, 12, @on
exec sp_trace_setevent @TraceID, 105, 28, @on
exec sp_trace_setevent @TraceID, 105, 60, @on
exec sp_trace_setevent @TraceID, 105, 21, @on
exec sp_trace_setevent @TraceID, 15, 7, @on
exec sp_trace_setevent @TraceID, 15, 15, @on
exec sp_trace_setevent @TraceID, 15, 23, @on
exec sp_trace_setevent @TraceID, 15, 8, @on
exec sp_trace_setevent @TraceID, 15, 16, @on
exec sp_trace_setevent @TraceID, 15, 64, @on
exec sp_trace_setevent @TraceID, 15, 9, @on
exec sp_trace_setevent @TraceID, 15, 13, @on
exec sp_trace_setevent @TraceID, 15, 17, @on
exec sp_trace_setevent @TraceID, 15, 21, @on
exec sp_trace_setevent @TraceID, 15, 41, @on
exec sp_trace_setevent @TraceID, 15, 49, @on
exec sp_trace_setevent @TraceID, 15, 6, @on
exec sp_trace_setevent @TraceID, 15, 10, @on
exec sp_trace_setevent @TraceID, 15, 14, @on
exec sp_trace_setevent @TraceID, 15, 18, @on
exec sp_trace_setevent @TraceID, 15, 26, @on
exec sp_trace_setevent @TraceID, 15, 3, @on
exec sp_trace_setevent @TraceID, 15, 11, @on
exec sp_trace_setevent @TraceID, 15, 27, @on
exec sp_trace_setevent @TraceID, 15, 35, @on
exec sp_trace_setevent @TraceID, 15, 51, @on
exec sp_trace_setevent @TraceID, 15, 12, @on
exec sp_trace_setevent @TraceID, 15, 60, @on
exec sp_trace_setevent @TraceID, 171, 27, @on
exec sp_trace_setevent @TraceID, 177, 7, @on
exec sp_trace_setevent @TraceID, 177, 23, @on
exec sp_trace_setevent @TraceID, 177, 39, @on
exec sp_trace_setevent @TraceID, 177, 8, @on
exec sp_trace_setevent @TraceID, 177, 40, @on
exec sp_trace_setevent @TraceID, 177, 64, @on
exec sp_trace_setevent @TraceID, 177, 1, @on
exec sp_trace_setevent @TraceID, 177, 9, @on
exec sp_trace_setevent @TraceID, 177, 41, @on
exec sp_trace_setevent @TraceID, 177, 49, @on
exec sp_trace_setevent @TraceID, 177, 10, @on
exec sp_trace_setevent @TraceID, 177, 26, @on
exec sp_trace_setevent @TraceID, 177, 34, @on
exec sp_trace_setevent @TraceID, 177, 42, @on
exec sp_trace_setevent @TraceID, 177, 50, @on
exec sp_trace_setevent @TraceID, 177, 3, @on
exec sp_trace_setevent @TraceID, 177, 11, @on
exec sp_trace_setevent @TraceID, 177, 27, @on
exec sp_trace_setevent @TraceID, 177, 35, @on
exec sp_trace_setevent @TraceID, 177, 43, @on
exec sp_trace_setevent @TraceID, 177, 51, @on
exec sp_trace_setevent @TraceID, 177, 4, @on
exec sp_trace_setevent @TraceID, 177, 12, @on
exec sp_trace_setevent @TraceID, 177, 28, @on
exec sp_trace_setevent @TraceID, 177, 60, @on
exec sp_trace_setevent @TraceID, 177, 5, @on
exec sp_trace_setevent @TraceID, 177, 21, @on
exec sp_trace_setevent @TraceID, 177, 29, @on
exec sp_trace_setevent @TraceID, 177, 37, @on
exec sp_trace_setevent @TraceID, 177, 45, @on
exec sp_trace_setevent @TraceID, 177, 6, @on
exec sp_trace_setevent @TraceID, 177, 14, @on
exec sp_trace_setevent @TraceID, 170, 7, @on
exec sp_trace_setevent @TraceID, 170, 23, @on
exec sp_trace_setevent @TraceID, 170, 8, @on
exec sp_trace_setevent @TraceID, 170, 40, @on
exec sp_trace_setevent @TraceID, 170, 64, @on
exec sp_trace_setevent @TraceID, 170, 1, @on
exec sp_trace_setevent @TraceID, 170, 9, @on
exec sp_trace_setevent @TraceID, 170, 41, @on
exec sp_trace_setevent @TraceID, 170, 49, @on
exec sp_trace_setevent @TraceID, 170, 10, @on
exec sp_trace_setevent @TraceID, 170, 26, @on
exec sp_trace_setevent @TraceID, 170, 34, @on
exec sp_trace_setevent @TraceID, 170, 42, @on
exec sp_trace_setevent @TraceID, 170, 50, @on
exec sp_trace_setevent @TraceID, 170, 3, @on
exec sp_trace_setevent @TraceID, 170, 11, @on
exec sp_trace_setevent @TraceID, 170, 19, @on
exec sp_trace_setevent @TraceID, 170, 35, @on
exec sp_trace_setevent @TraceID, 170, 43, @on
exec sp_trace_setevent @TraceID, 170, 51, @on
exec sp_trace_setevent @TraceID, 170, 4, @on
exec sp_trace_setevent @TraceID, 170, 12, @on
exec sp_trace_setevent @TraceID, 170, 28, @on
exec sp_trace_setevent @TraceID, 170, 60, @on
exec sp_trace_setevent @TraceID, 170, 21, @on
exec sp_trace_setevent @TraceID, 170, 29, @on
exec sp_trace_setevent @TraceID, 170, 37, @on
exec sp_trace_setevent @TraceID, 170, 6, @on
exec sp_trace_setevent @TraceID, 170, 14, @on


-- Set the Filters
declare @intfilter int
declare @bigintfilter bigint

exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Server Profiler'
-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1

-- display trace id for future references
select TraceID=@TraceID
goto finish

error: 
select ErrorCode=@rc

finish: 
go

/* ----------------------------------------------------------------------------------- 
 Procedure Name	:Usp_DBAActivityEventAudit					
 Description		:SQL Profile trace script			 		
--------------------------------------------------------------------------------------*/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Usp_DBAActivityEventAudit]'))
drop procedure [dbo].[Usp_DBAActivityEventAudit]
go

CREATE PROCEDURE Usp_DBAActivityEventAudit
as

-- Create a Queue
declare @rc int
declare @TraceID int
declare @maxfilesize bigint
set @maxfilesize = 5 

-- Please replace the text InsertFileNameHere, with an appropriate
-- filename prefixed by a path, e.g., c:\MyFolder\MyTrace. The .trc extension
-- will be appended to the filename automatically. If you are writing from
-- remote server to local drive, please use UNC path and make sure server has
-- write access to your network share

exec @rc = sp_trace_create @TraceID output, 0, N'D:\SQLNativeAudit\DBAActivityEventAudit', @maxfilesize, NULL 
if (@rc != 0) goto error

-- Client side File and Table cannot be scripted

-- Set the events
declare @on bit
set @on = 1
exec sp_trace_setevent @TraceID, 10, 7, @on
exec sp_trace_setevent @TraceID, 10, 15, @on
exec sp_trace_setevent @TraceID, 10, 31, @on
exec sp_trace_setevent @TraceID, 10, 8, @on
exec sp_trace_setevent @TraceID, 10, 16, @on
exec sp_trace_setevent @TraceID, 10, 48, @on
exec sp_trace_setevent @TraceID, 10, 64, @on
exec sp_trace_setevent @TraceID, 10, 1, @on
exec sp_trace_setevent @TraceID, 10, 9, @on
exec sp_trace_setevent @TraceID, 10, 17, @on
exec sp_trace_setevent @TraceID, 10, 41, @on
exec sp_trace_setevent @TraceID, 10, 49, @on
exec sp_trace_setevent @TraceID, 10, 2, @on
exec sp_trace_setevent @TraceID, 10, 10, @on
exec sp_trace_setevent @TraceID, 10, 18, @on
exec sp_trace_setevent @TraceID, 10, 26, @on
exec sp_trace_setevent @TraceID, 10, 34, @on
exec sp_trace_setevent @TraceID, 10, 50, @on
exec sp_trace_setevent @TraceID, 10, 3, @on
exec sp_trace_setevent @TraceID, 10, 11, @on
exec sp_trace_setevent @TraceID, 10, 35, @on
exec sp_trace_setevent @TraceID, 10, 51, @on
exec sp_trace_setevent @TraceID, 10, 4, @on
exec sp_trace_setevent @TraceID, 10, 12, @on
exec sp_trace_setevent @TraceID, 10, 60, @on
exec sp_trace_setevent @TraceID, 10, 13, @on
exec sp_trace_setevent @TraceID, 10, 6, @on
exec sp_trace_setevent @TraceID, 10, 14, @on
exec sp_trace_setevent @TraceID, 45, 7, @on
exec sp_trace_setevent @TraceID, 45, 55, @on
exec sp_trace_setevent @TraceID, 45, 8, @on
exec sp_trace_setevent @TraceID, 45, 16, @on
exec sp_trace_setevent @TraceID, 45, 48, @on
exec sp_trace_setevent @TraceID, 45, 64, @on
exec sp_trace_setevent @TraceID, 45, 1, @on
exec sp_trace_setevent @TraceID, 45, 9, @on
exec sp_trace_setevent @TraceID, 45, 17, @on
exec sp_trace_setevent @TraceID, 45, 25, @on
exec sp_trace_setevent @TraceID, 45, 41, @on
exec sp_trace_setevent @TraceID, 45, 49, @on
exec sp_trace_setevent @TraceID, 45, 10, @on
exec sp_trace_setevent @TraceID, 45, 18, @on
exec sp_trace_setevent @TraceID, 45, 26, @on
exec sp_trace_setevent @TraceID, 45, 34, @on
exec sp_trace_setevent @TraceID, 45, 50, @on
exec sp_trace_setevent @TraceID, 45, 3, @on
exec sp_trace_setevent @TraceID, 45, 11, @on
exec sp_trace_setevent @TraceID, 45, 35, @on
exec sp_trace_setevent @TraceID, 45, 51, @on
exec sp_trace_setevent @TraceID, 45, 4, @on
exec sp_trace_setevent @TraceID, 45, 12, @on
exec sp_trace_setevent @TraceID, 45, 28, @on
exec sp_trace_setevent @TraceID, 45, 60, @on
exec sp_trace_setevent @TraceID, 45, 5, @on
exec sp_trace_setevent @TraceID, 45, 13, @on
exec sp_trace_setevent @TraceID, 45, 29, @on
exec sp_trace_setevent @TraceID, 45, 61, @on
exec sp_trace_setevent @TraceID, 45, 6, @on
exec sp_trace_setevent @TraceID, 45, 14, @on
exec sp_trace_setevent @TraceID, 45, 22, @on
exec sp_trace_setevent @TraceID, 45, 62, @on
exec sp_trace_setevent @TraceID, 45, 15, @on
exec sp_trace_setevent @TraceID, 12, 7, @on
exec sp_trace_setevent @TraceID, 12, 15, @on
exec sp_trace_setevent @TraceID, 12, 31, @on
exec sp_trace_setevent @TraceID, 12, 8, @on
exec sp_trace_setevent @TraceID, 12, 16, @on
exec sp_trace_setevent @TraceID, 12, 48, @on
exec sp_trace_setevent @TraceID, 12, 64, @on
exec sp_trace_setevent @TraceID, 12, 1, @on
exec sp_trace_setevent @TraceID, 12, 9, @on
exec sp_trace_setevent @TraceID, 12, 17, @on
exec sp_trace_setevent @TraceID, 12, 41, @on
exec sp_trace_setevent @TraceID, 12, 49, @on
exec sp_trace_setevent @TraceID, 12, 6, @on
exec sp_trace_setevent @TraceID, 12, 10, @on
exec sp_trace_setevent @TraceID, 12, 14, @on
exec sp_trace_setevent @TraceID, 12, 18, @on
exec sp_trace_setevent @TraceID, 12, 26, @on
exec sp_trace_setevent @TraceID, 12, 50, @on
exec sp_trace_setevent @TraceID, 12, 3, @on
exec sp_trace_setevent @TraceID, 12, 11, @on
exec sp_trace_setevent @TraceID, 12, 35, @on
exec sp_trace_setevent @TraceID, 12, 51, @on
exec sp_trace_setevent @TraceID, 12, 4, @on
exec sp_trace_setevent @TraceID, 12, 12, @on
exec sp_trace_setevent @TraceID, 12, 60, @on
exec sp_trace_setevent @TraceID, 12, 13, @on
exec sp_trace_setevent @TraceID, 41, 7, @on
exec sp_trace_setevent @TraceID, 41, 15, @on
exec sp_trace_setevent @TraceID, 41, 55, @on
exec sp_trace_setevent @TraceID, 41, 8, @on
exec sp_trace_setevent @TraceID, 41, 16, @on
exec sp_trace_setevent @TraceID, 41, 48, @on
exec sp_trace_setevent @TraceID, 41, 64, @on
exec sp_trace_setevent @TraceID, 41, 1, @on
exec sp_trace_setevent @TraceID, 41, 9, @on
exec sp_trace_setevent @TraceID, 41, 17, @on
exec sp_trace_setevent @TraceID, 41, 25, @on
exec sp_trace_setevent @TraceID, 41, 41, @on
exec sp_trace_setevent @TraceID, 41, 49, @on
exec sp_trace_setevent @TraceID, 41, 10, @on
exec sp_trace_setevent @TraceID, 41, 18, @on
exec sp_trace_setevent @TraceID, 41, 26, @on
exec sp_trace_setevent @TraceID, 41, 50, @on
exec sp_trace_setevent @TraceID, 41, 3, @on
exec sp_trace_setevent @TraceID, 41, 11, @on
exec sp_trace_setevent @TraceID, 41, 35, @on
exec sp_trace_setevent @TraceID, 41, 51, @on
exec sp_trace_setevent @TraceID, 41, 4, @on
exec sp_trace_setevent @TraceID, 41, 12, @on
exec sp_trace_setevent @TraceID, 41, 60, @on
exec sp_trace_setevent @TraceID, 41, 5, @on
exec sp_trace_setevent @TraceID, 41, 13, @on
exec sp_trace_setevent @TraceID, 41, 29, @on
exec sp_trace_setevent @TraceID, 41, 61, @on
exec sp_trace_setevent @TraceID, 41, 6, @on
exec sp_trace_setevent @TraceID, 41, 14, @on


-- Set the Filters
declare @intfilter int
declare @bigintfilter bigint

exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Server Profiler'
exec sp_trace_setfilter @TraceID, 11, 0, 6, N'sa'
exec sp_trace_setfilter @TraceID, 35, 0, 7, N'master'
exec sp_trace_setfilter @TraceID, 35, 0, 7, N'msdb'
-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1

-- display trace id for future references
select TraceID=@TraceID
goto finish

error: 
select ErrorCode=@rc

finish: 
go

/* ------------------------------------------------------------------------------------
 Procedure Name	:Usp_DDLActivityEventAudit						
 Description		:SQL Profile trace script			 		
--------------------------------------------------------------------------------------*/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Usp_DDLActivityEventAudit]'))
drop procedure [dbo].[Usp_DDLActivityEventAudit]
go
Create proc Usp_DDLActivityEventAudit
as

-- Create a Queue
declare @rc int
declare @TraceID int
declare @maxfilesize bigint
set @maxfilesize = 5 

-- Please replace the text InsertFileNameHere, with an appropriate
-- filename prefixed by a path, e.g., c:\MyFolder\MyTrace. The .trc extension
-- will be appended to the filename automatically. If you are writing from
-- remote server to local drive, please use UNC path and make sure server has
-- write access to your network share

exec @rc = sp_trace_create @TraceID output, 0, N'D:\SQLNativeAudit\ddlActivityEventAudit', @maxfilesize, NULL 
if (@rc != 0) goto error

-- Client side File and Table cannot be scripted

-- Set the events
declare @on bit
set @on = 1
exec sp_trace_setevent @TraceID, 164, 7, @on
exec sp_trace_setevent @TraceID, 164, 8, @on
exec sp_trace_setevent @TraceID, 164, 24, @on
exec sp_trace_setevent @TraceID, 164, 56, @on
exec sp_trace_setevent @TraceID, 164, 64, @on
exec sp_trace_setevent @TraceID, 164, 9, @on
exec sp_trace_setevent @TraceID, 164, 25, @on
exec sp_trace_setevent @TraceID, 164, 41, @on
exec sp_trace_setevent @TraceID, 164, 49, @on
exec sp_trace_setevent @TraceID, 164, 6, @on
exec sp_trace_setevent @TraceID, 164, 10, @on
exec sp_trace_setevent @TraceID, 164, 14, @on
exec sp_trace_setevent @TraceID, 164, 22, @on
exec sp_trace_setevent @TraceID, 164, 26, @on
exec sp_trace_setevent @TraceID, 164, 34, @on
exec sp_trace_setevent @TraceID, 164, 50, @on
exec sp_trace_setevent @TraceID, 164, 3, @on
exec sp_trace_setevent @TraceID, 164, 11, @on
exec sp_trace_setevent @TraceID, 164, 35, @on
exec sp_trace_setevent @TraceID, 164, 51, @on
exec sp_trace_setevent @TraceID, 164, 4, @on
exec sp_trace_setevent @TraceID, 164, 12, @on
exec sp_trace_setevent @TraceID, 164, 28, @on
exec sp_trace_setevent @TraceID, 164, 60, @on
exec sp_trace_setevent @TraceID, 164, 21, @on
exec sp_trace_setevent @TraceID, 46, 7, @on
exec sp_trace_setevent @TraceID, 46, 8, @on
exec sp_trace_setevent @TraceID, 46, 24, @on
exec sp_trace_setevent @TraceID, 46, 56, @on
exec sp_trace_setevent @TraceID, 46, 64, @on
exec sp_trace_setevent @TraceID, 46, 9, @on
exec sp_trace_setevent @TraceID, 46, 25, @on
exec sp_trace_setevent @TraceID, 46, 41, @on
exec sp_trace_setevent @TraceID, 46, 49, @on
exec sp_trace_setevent @TraceID, 46, 6, @on
exec sp_trace_setevent @TraceID, 46, 10, @on
exec sp_trace_setevent @TraceID, 46, 14, @on
exec sp_trace_setevent @TraceID, 46, 22, @on
exec sp_trace_setevent @TraceID, 46, 26, @on
exec sp_trace_setevent @TraceID, 46, 34, @on
exec sp_trace_setevent @TraceID, 46, 50, @on
exec sp_trace_setevent @TraceID, 46, 3, @on
exec sp_trace_setevent @TraceID, 46, 11, @on
exec sp_trace_setevent @TraceID, 46, 35, @on
exec sp_trace_setevent @TraceID, 46, 51, @on
exec sp_trace_setevent @TraceID, 46, 4, @on
exec sp_trace_setevent @TraceID, 46, 12, @on
exec sp_trace_setevent @TraceID, 46, 28, @on
exec sp_trace_setevent @TraceID, 46, 60, @on
exec sp_trace_setevent @TraceID, 46, 21, @on
exec sp_trace_setevent @TraceID, 47, 7, @on
exec sp_trace_setevent @TraceID, 47, 8, @on
exec sp_trace_setevent @TraceID, 47, 24, @on
exec sp_trace_setevent @TraceID, 47, 56, @on
exec sp_trace_setevent @TraceID, 47, 64, @on
exec sp_trace_setevent @TraceID, 47, 9, @on
exec sp_trace_setevent @TraceID, 47, 25, @on
exec sp_trace_setevent @TraceID, 47, 41, @on
exec sp_trace_setevent @TraceID, 47, 49, @on
exec sp_trace_setevent @TraceID, 47, 6, @on
exec sp_trace_setevent @TraceID, 47, 10, @on
exec sp_trace_setevent @TraceID, 47, 14, @on
exec sp_trace_setevent @TraceID, 47, 22, @on
exec sp_trace_setevent @TraceID, 47, 26, @on
exec sp_trace_setevent @TraceID, 47, 34, @on
exec sp_trace_setevent @TraceID, 47, 50, @on
exec sp_trace_setevent @TraceID, 47, 3, @on
exec sp_trace_setevent @TraceID, 47, 11, @on
exec sp_trace_setevent @TraceID, 47, 35, @on
exec sp_trace_setevent @TraceID, 47, 51, @on
exec sp_trace_setevent @TraceID, 47, 4, @on
exec sp_trace_setevent @TraceID, 47, 12, @on
exec sp_trace_setevent @TraceID, 47, 28, @on
exec sp_trace_setevent @TraceID, 47, 60, @on
exec sp_trace_setevent @TraceID, 47, 21, @on


-- Set the Filters
declare @intfilter int
declare @bigintfilter bigint

exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Server Profiler'
-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1

-- display trace id for future references
select TraceID=@TraceID
goto finish

error: 
select ErrorCode=@rc

finish: 
go

/* -----------------------------------------------------------------------------------
 Procedure Name	:Usp_ExecuteTrace						
 Description		:This procedure will start the SQL Trace	 		
--------------------------------------------------------------------------------------*/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Usp_ExecuteTrace]'))
drop procedure [dbo].[Usp_ExecuteTrace]
go
create procedure Usp_ExecuteTrace
as

exec Usp_SecurityEventAudit
exec Usp_DBAActivityEventAudit
exec Usp_DDLActivityEventAudit

go

/*---------------------------------scripts to create tables-------------------------*/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLTraceEvents]') AND type in (N'U'))
DROP TABLE [dbo].[SQLTraceEvents]
GO

USE [master]
GO

/****** Object:  Table [dbo].[SQLTraceEvents]    Script Date: 04/14/2015 14:31:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SQLTraceEvents](
	[TraceID] [int] NULL,
	[EventName] [varchar](255) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/*---------------------------------scripts to insert trace events-------------------------*/
INSERT INTO SQLTraceEvents VALUES (10,'RPC:Completed')
INSERT INTO SQLTraceEvents VALUES (11,'RPC:Starting')
INSERT INTO SQLTraceEvents VALUES (12,'SQL:BatchCompleted')
INSERT INTO SQLTraceEvents VALUES (13,'SQL:BatchStarting')
INSERT INTO SQLTraceEvents VALUES (14,'Audit Login')
INSERT INTO SQLTraceEvents VALUES (15,'Audit Logout')
INSERT INTO SQLTraceEvents VALUES (16,'Attention')
INSERT INTO SQLTraceEvents VALUES (17,'ExistingConnection')
INSERT INTO SQLTraceEvents VALUES (18,'Audit Server Starts and Stops')
INSERT INTO SQLTraceEvents VALUES (19,'DTCTransaction')
INSERT INTO SQLTraceEvents VALUES (20,'Audit Login Failed')
INSERT INTO SQLTraceEvents VALUES (21,'EventLog')
INSERT INTO SQLTraceEvents VALUES (22,'ErrorLog')
INSERT INTO SQLTraceEvents VALUES (23,'Lock:Released')
INSERT INTO SQLTraceEvents VALUES (24,'Lock:Acquired')
INSERT INTO SQLTraceEvents VALUES (25,'Lock:Deadlock')
INSERT INTO SQLTraceEvents VALUES (26,'Lock:Cancel')
INSERT INTO SQLTraceEvents VALUES (27,'Lock:Timeout')
INSERT INTO SQLTraceEvents VALUES (28,'Degree of Parallelism Event (7.0 Insert)')
INSERT INTO SQLTraceEvents VALUES (33,'Exception')
INSERT INTO SQLTraceEvents VALUES (34,'SP:CacheMiss')
INSERT INTO SQLTraceEvents VALUES (35,'SP:CacheInsert')
INSERT INTO SQLTraceEvents VALUES (36,'SP:CacheRemove')
INSERT INTO SQLTraceEvents VALUES (37,'SP:Recompile')
INSERT INTO SQLTraceEvents VALUES (38,'SP:CacheHit')
INSERT INTO SQLTraceEvents VALUES (39,'Deprecated')
INSERT INTO SQLTraceEvents VALUES (40,'SQL:StmtStarting')
INSERT INTO SQLTraceEvents VALUES (41,'SQL:StmtCompleted')
INSERT INTO SQLTraceEvents VALUES (42,'SP:Starting')
INSERT INTO SQLTraceEvents VALUES (43,'SP:Completed')
INSERT INTO SQLTraceEvents VALUES (44,'SP:StmtStarting')
INSERT INTO SQLTraceEvents VALUES (45,'SP:StmtCompleted')
INSERT INTO SQLTraceEvents VALUES (46,'Object:Created')
INSERT INTO SQLTraceEvents VALUES (47,'Object:Deleted')
INSERT INTO SQLTraceEvents VALUES (48,'Reserved')
INSERT INTO SQLTraceEvents VALUES (49,'Reserved')
INSERT INTO SQLTraceEvents VALUES (50,'SQL Transaction')
INSERT INTO SQLTraceEvents VALUES (51,'Scan:Started')
INSERT INTO SQLTraceEvents VALUES (52,'Scan:Stopped')
INSERT INTO SQLTraceEvents VALUES (53,'CursorOpen')
INSERT INTO SQLTraceEvents VALUES (54,'TransactionLog')
INSERT INTO SQLTraceEvents VALUES (55,'Hash Warning')
INSERT INTO SQLTraceEvents VALUES (58,'Auto Stats')
INSERT INTO SQLTraceEvents VALUES (59,'Lock:Deadlock Chain')
INSERT INTO SQLTraceEvents VALUES (60,'Lock:Escalation')
INSERT INTO SQLTraceEvents VALUES (61,'OLE DB Errors')
INSERT INTO SQLTraceEvents VALUES (67,'Execution Warnings')
INSERT INTO SQLTraceEvents VALUES (68,'Showplan Text (Unencoded)')
INSERT INTO SQLTraceEvents VALUES (69,'Sort Warnings')
INSERT INTO SQLTraceEvents VALUES (70,'CursorPrepare')
INSERT INTO SQLTraceEvents VALUES (71,'Prepare SQL')
INSERT INTO SQLTraceEvents VALUES (72,'Exec Prepared SQL')
INSERT INTO SQLTraceEvents VALUES (73,'Unprepare SQL')
INSERT INTO SQLTraceEvents VALUES (74,'CursorExecute')
INSERT INTO SQLTraceEvents VALUES (75,'CursorRecompile')
INSERT INTO SQLTraceEvents VALUES (76,'CursorImplicitConversion')
INSERT INTO SQLTraceEvents VALUES (77,'CursorUnprepare')
INSERT INTO SQLTraceEvents VALUES (78,'CursorClose')
INSERT INTO SQLTraceEvents VALUES (79,'Missing Column Statistics')
INSERT INTO SQLTraceEvents VALUES (80,'Missing Join Predicate')
INSERT INTO SQLTraceEvents VALUES (81,'Server Memory Change')
INSERT INTO SQLTraceEvents VALUES (92,'Data File Auto Grow')
INSERT INTO SQLTraceEvents VALUES (93,'Log File Auto Grow')
INSERT INTO SQLTraceEvents VALUES (94,'Data File Auto Shrink')
INSERT INTO SQLTraceEvents VALUES (95,'Log File Auto Shrink')
INSERT INTO SQLTraceEvents VALUES (96,'Showplan Text')
INSERT INTO SQLTraceEvents VALUES (97,'Showplan All')
INSERT INTO SQLTraceEvents VALUES (98,'Showplan Statistics Profile')
INSERT INTO SQLTraceEvents VALUES (99,'Reserved')
INSERT INTO SQLTraceEvents VALUES (100,'RPC Output Parameter')
INSERT INTO SQLTraceEvents VALUES (101,'Reserved')
INSERT INTO SQLTraceEvents VALUES (102,'Audit Database Scope GDR')
INSERT INTO SQLTraceEvents VALUES (103,'Audit Object GDR Event')
INSERT INTO SQLTraceEvents VALUES (104,'Audit AddLogin Event')
INSERT INTO SQLTraceEvents VALUES (105,'Audit Login GDR Event')
INSERT INTO SQLTraceEvents VALUES (106,'Audit Login Change Property Event')
INSERT INTO SQLTraceEvents VALUES (107,'Audit Login Change Password Event')
INSERT INTO SQLTraceEvents VALUES (108,'Audit Add Login to Server Role Event')
INSERT INTO SQLTraceEvents VALUES (109,'Audit Add DB User Event')
INSERT INTO SQLTraceEvents VALUES (110,'Audit Add Member to DB Role Event')
INSERT INTO SQLTraceEvents VALUES (111,'Audit Add Role Event')
INSERT INTO SQLTraceEvents VALUES (112,'Audit App Role Change Password Event')
INSERT INTO SQLTraceEvents VALUES (113,'Audit Statement Permission Event')
INSERT INTO SQLTraceEvents VALUES (114,'Audit Schema Object Access Event')
INSERT INTO SQLTraceEvents VALUES (115,'Audit Backup/Restore Event')
INSERT INTO SQLTraceEvents VALUES (116,'Audit DBCC Event')
INSERT INTO SQLTraceEvents VALUES (117,'Audit Change Audit Event')
INSERT INTO SQLTraceEvents VALUES (118,'Audit Object Derived Permission Event')
INSERT INTO SQLTraceEvents VALUES (119,'OLEDB Call Event')
INSERT INTO SQLTraceEvents VALUES (120,'OLEDB QueryInterface Event')
INSERT INTO SQLTraceEvents VALUES (121,'OLEDB DataRead Event')
INSERT INTO SQLTraceEvents VALUES (122,'Showplan XML')
INSERT INTO SQLTraceEvents VALUES (123,'SQL:FullTextQuery')
INSERT INTO SQLTraceEvents VALUES (124,'Broker:Conversation')
INSERT INTO SQLTraceEvents VALUES (125,'Deprecation Announcement')
INSERT INTO SQLTraceEvents VALUES (126,'Deprecation Final Support')
INSERT INTO SQLTraceEvents VALUES (127,'Exchange Spill Event')
INSERT INTO SQLTraceEvents VALUES (128,'Audit Database Management Event')
INSERT INTO SQLTraceEvents VALUES (129,'Audit Database Object Management Event')
INSERT INTO SQLTraceEvents VALUES (130,'Audit Database Principal Management Event')
INSERT INTO SQLTraceEvents VALUES (131,'Audit Schema Object Management Event')
INSERT INTO SQLTraceEvents VALUES (132,'Audit Server Principal Impersonation Event')
INSERT INTO SQLTraceEvents VALUES (133,'Audit Database Principal Impersonation Event')
INSERT INTO SQLTraceEvents VALUES (134,'Audit Server Object Take Ownership Event')
INSERT INTO SQLTraceEvents VALUES (135,'Audit Database Object Take Ownership Event')
INSERT INTO SQLTraceEvents VALUES (136,'Broker:Conversation Group')
INSERT INTO SQLTraceEvents VALUES (137,'Blocked Process Report')
INSERT INTO SQLTraceEvents VALUES (138,'Broker:Connection')
INSERT INTO SQLTraceEvents VALUES (139,'Broker:Forwarded Message Sent')
INSERT INTO SQLTraceEvents VALUES (140,'Broker:Forwarded Message Dropped')
INSERT INTO SQLTraceEvents VALUES (141,'Broker:Message Classify')
INSERT INTO SQLTraceEvents VALUES (142,'Broker:Transmission')
INSERT INTO SQLTraceEvents VALUES (143,'Broker:Queue Disabled')
INSERT INTO SQLTraceEvents VALUES (146,'Showplan XML Statistics Profile')
INSERT INTO SQLTraceEvents VALUES (148,'Deadlock Graph')
INSERT INTO SQLTraceEvents VALUES (149,'Broker:Remote Message Acknowledgement')
INSERT INTO SQLTraceEvents VALUES (150,'Trace File Close')
INSERT INTO SQLTraceEvents VALUES (151,'Reserved')
INSERT INTO SQLTraceEvents VALUES (152,'Audit Change Database Owner')
INSERT INTO SQLTraceEvents VALUES (153,'Audit Schema Object Take Ownership Event')
INSERT INTO SQLTraceEvents VALUES (154,'Reserved')
INSERT INTO SQLTraceEvents VALUES (155,'FT:Crawl Started')
INSERT INTO SQLTraceEvents VALUES (156,'FT:Crawl Stopped')
INSERT INTO SQLTraceEvents VALUES (157,'FT:Crawl Aborted')
INSERT INTO SQLTraceEvents VALUES (158,'Audit Broker Conversation')
INSERT INTO SQLTraceEvents VALUES (159,'Audit Broker Login')
INSERT INTO SQLTraceEvents VALUES (160,'Broker:Message Undeliverable')
INSERT INTO SQLTraceEvents VALUES (161,'Broker:Corrupted Message')
INSERT INTO SQLTraceEvents VALUES (162,'User Error Message')
INSERT INTO SQLTraceEvents VALUES (163,'Broker:Activation')
INSERT INTO SQLTraceEvents VALUES (164,'Object:Altered')
INSERT INTO SQLTraceEvents VALUES (165,'Performance statistics')
INSERT INTO SQLTraceEvents VALUES (166,'SQL:StmtRecompile')
INSERT INTO SQLTraceEvents VALUES (167,'Database Mirroring State Change')
INSERT INTO SQLTraceEvents VALUES (168,'Showplan XML For Query Compile')
INSERT INTO SQLTraceEvents VALUES (169,'Showplan All For Query Compile')
INSERT INTO SQLTraceEvents VALUES (170,'Audit Server Scope GDR Event')
INSERT INTO SQLTraceEvents VALUES (171,'Audit Server Object GDR Event')
INSERT INTO SQLTraceEvents VALUES (172,'Audit Database Object GDR Event')
INSERT INTO SQLTraceEvents VALUES (173,'Audit Server Operation Event')
INSERT INTO SQLTraceEvents VALUES (175,'Audit Server Alter Trace Event')
INSERT INTO SQLTraceEvents VALUES (176,'Audit Server Object Management Event')
INSERT INTO SQLTraceEvents VALUES (177,'Audit Server Principal Management Event')
INSERT INTO SQLTraceEvents VALUES (178,'Audit Database Operation Event')
INSERT INTO SQLTraceEvents VALUES (180,'Audit Database Object Access Event')
INSERT INTO SQLTraceEvents VALUES (181,'TM: Begin Tran starting')
INSERT INTO SQLTraceEvents VALUES (182,'TM: Begin Tran completed')
INSERT INTO SQLTraceEvents VALUES (183,'TM: Promote Tran starting')
INSERT INTO SQLTraceEvents VALUES (184,'TM: Promote Tran completed')
INSERT INTO SQLTraceEvents VALUES (185,'TM: Commit Tran starting')
INSERT INTO SQLTraceEvents VALUES (186,'TM: Commit Tran completed')
INSERT INTO SQLTraceEvents VALUES (187,'TM: Rollback Tran starting')
INSERT INTO SQLTraceEvents VALUES (188,'TM: Rollback Tran completed')
INSERT INTO SQLTraceEvents VALUES (189,'Lock:Timeout (timeout > 0)')
INSERT INTO SQLTraceEvents VALUES (190,'Progress Report: Online Index Operation')
INSERT INTO SQLTraceEvents VALUES (191,'TM: Save Tran starting')
INSERT INTO SQLTraceEvents VALUES (192,'TM: Save Tran completed')
INSERT INTO SQLTraceEvents VALUES (193,'Background Job Error')
INSERT INTO SQLTraceEvents VALUES (194,'OLEDB Provider Information')
INSERT INTO SQLTraceEvents VALUES (195,'Mount Tape')
INSERT INTO SQLTraceEvents VALUES (196,'Assembly Load')
INSERT INTO SQLTraceEvents VALUES (197,'Reserved')
INSERT INTO SQLTraceEvents VALUES (198,'XQuery Static Type')
INSERT INTO SQLTraceEvents VALUES (199,'QN: subscription')
INSERT INTO SQLTraceEvents VALUES (200,'QN: parameter table')
INSERT INTO SQLTraceEvents VALUES (201,'QN: template')
INSERT INTO SQLTraceEvents VALUES (202,'QN: dynamics')
INSERT INTO SQLTraceEvents VALUES (212,'Bitmap Warning')
INSERT INTO SQLTraceEvents VALUES (213,'Database Suspect Data Page')
INSERT INTO SQLTraceEvents VALUES (214,'CPU threshold exceeded')
INSERT INTO SQLTraceEvents VALUES (215,'Indicates when a LOGON trigger or Resource Governor classifier function starts execution.')
INSERT INTO SQLTraceEvents VALUES (216,'PreConnect:Completed')
INSERT INTO SQLTraceEvents VALUES (217,'Plan Guide Successful')
INSERT INTO SQLTraceEvents VALUES (218,'Plan Guide Unsuccessful')
INSERT INTO SQLTraceEvents VALUES (235,'Audit Fulltext')

/****** Object:  Table [dbo].[DatabaseSecurityAuditEvents]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[DatabaseSecurityAuditEvents]') AND type in (N'U'))
DROP TABLE [dbo].[DatabaseSecurityAuditEvents]
GO

/****** Object:  Table [dbo].[DatabaseSecurityAuditEvents]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DatabaseSecurityAuditEvents](
	[EventClassDesc]	varchar(255),
	[TextData] [ntext] NULL,
	[BinaryData] [image] NULL,
	[DatabaseID] [int] NULL,
	[TransactionID] [bigint] NULL,
	[NTUserName] [nvarchar](128) NULL,
	[NTDomainName] [nvarchar](128) NULL,
	[HostName] [nvarchar](128) NULL,
	[ClientProcessID] [int] NULL,
	[ApplicationName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [int] NULL,
	[Severity] [int] NULL,
	[EventSubClass] [int] NULL,
	[ObjectID] [int] NULL,
	[Success] [int] NULL,
	[IndexID] [int] NULL,
	[IntegerData] [int] NULL,
	[EventClass] [int] NOT NULL,
	[ObjectType] [int] NULL,
	[NestLevel] [int] NULL,
	[State] [int] NULL,
	[Error] [int] NULL,
	[Mode] [int] NULL,
	[Handle] [int] NULL,
	[ObjectName] [nvarchar](128) NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[FileName] [nvarchar](128) NULL,
	[OwnerName] [nvarchar](128) NULL,
	[RoleName] [nvarchar](128) NULL,
	[TargetUserName] [nvarchar](128) NULL,
	[DBUserName] [nvarchar](128) NULL,
	[LoginSid] [image] NULL,
	[TargetLoginName] [nvarchar](128) NULL,
	[TargetLoginSid] [image] NULL,
	[ColumnPermissions] [int] NULL,
	[DateCreated] [datetime] NULL,
	[TraceType] [char](3) NULL,
	[ReportId] [int] NULL,
	[ReviewedOn] [datetime] NULL,
	[ReviewedBy] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[DatabaseSecurityAuditEvents]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[DatabaseSecurityAuditEventsHistory]') AND type in (N'U'))
DROP TABLE [dbo].[DatabaseSecurityAuditEventsHistory]
GO

CREATE TABLE [dbo].[DatabaseSecurityAuditEventsHistory](
	[EventClassDesc]	varchar(255),
	[TextData] [ntext] NULL,
	[BinaryData] [image] NULL,
	[DatabaseID] [int] NULL,
	[TransactionID] [bigint] NULL,
	[NTUserName] [nvarchar](128) NULL,
	[NTDomainName] [nvarchar](128) NULL,
	[HostName] [nvarchar](128) NULL,
	[ClientProcessID] [int] NULL,
	[ApplicationName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [int] NULL,
	[Severity] [int] NULL,
	[EventSubClass] [int] NULL,
	[ObjectID] [int] NULL,
	[Success] [int] NULL,
	[IndexID] [int] NULL,
	[IntegerData] [int] NULL,
	[EventClass] [int] NOT NULL,
	[ObjectType] [int] NULL,
	[NestLevel] [int] NULL,
	[State] [int] NULL,
	[Error] [int] NULL,
	[Mode] [int] NULL,
	[Handle] [int] NULL,
	[ObjectName] [nvarchar](128) NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[FileName] [nvarchar](128) NULL,
	[OwnerName] [nvarchar](128) NULL,
	[RoleName] [nvarchar](128) NULL,
	[TargetUserName] [nvarchar](128) NULL,
	[DBUserName] [nvarchar](128) NULL,
	[LoginSid] [image] NULL,
	[TargetLoginName] [nvarchar](128) NULL,
	[TargetLoginSid] [image] NULL,
	[ColumnPermissions] [int] NULL,
	[DateCreated] [datetime] NULL,
	[TraceType] [char](3) NULL,
	[ReportId] [int] NULL,
	[ReviewedOn] [datetime] NULL,
	[ReviewedBy] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


/****** Object:  Table [dbo].[TmpSecurityAuditEvents]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[TmpSecurityAuditEvents]') AND type in (N'U'))
DROP TABLE [dbo].[TmpSecurityAuditEvents]
GO

/****** Object:  Table [dbo].[TmpSecurityAuditEvents]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TmpSecurityAuditEvents](
	[TextData] [ntext] NULL,
	[BinaryData] [image] NULL,
	[DatabaseID] [int] NULL,
	[TransactionID] [bigint] NULL,
	[NTUserName] [nvarchar](128) NULL,
	[NTDomainName] [nvarchar](128) NULL,
	[HostName] [nvarchar](128) NULL,
	[ClientProcessID] [int] NULL,
	[ApplicationName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [int] NULL,
	[Severity] [int] NULL,
	[EventSubClass] [int] NULL,
	[ObjectID] [int] NULL,
	[Success] [int] NULL,
	[IndexID] [int] NULL,
	[IntegerData] [int] NULL,
	[ServerName] [nvarchar](128) NULL,
	[EventClass] [int] NOT NULL,
	[ObjectType] [int] NULL,
	[NestLevel] [int] NULL,
	[State] [int] NULL,
	[Error] [int] NULL,
	[Mode] [int] NULL,
	[Handle] [int] NULL,
	[ObjectName] [nvarchar](128) NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[FileName] [nvarchar](128) NULL,
	[OwnerName] [nvarchar](128) NULL,
	[RoleName] [nvarchar](128) NULL,
	[TargetUserName] [nvarchar](128) NULL,
	[DBUserName] [nvarchar](128) NULL,
	[LoginSid] [image] NULL,
	[TargetLoginName] [nvarchar](128) NULL,
	[TargetLoginSid] [image] NULL,
	[ColumnPermissions] [int] NULL,
	[DateCreated] [datetime] NULL,
	[TraceType] [char](3) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/* ------------------------------------------------------------------------------------ 
 Procedure Name	:Usp_SaveEventsInWindowsLog					
 Description	:Send events to Windows Application Log	
--------------------------------------------------------------------------------------*/

/****** Object:  StoredProcedure [dbo].[usp_UpdateAuditEventData]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[Usp_SaveEventsInWindowsLog]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].Usp_SaveEventsInWindowsLog
GO

/****** Object:  StoredProcedure [dbo].[Usp_SaveEventsInWindowsLog]     ******/
CREATE PROCEDURE Usp_SaveEventsInWindowsLog
AS
CREATE TABLE #Events
(
ID				INT IDENTITY(1,1),
EventClassDesc	VARCHAR(255),
StartTime		DATETIME,
TraceType		CHAR(5),
LoginName		VARCHAR(100),
HostName		VARCHAR(255),
TextData		TEXT,
ApplicationName VARCHAR(255),
DatabaseName	VARCHAR(255),
ObjectName		VARCHAR(255),
RoleName		VARCHAR(255)
)

INSERT INTO #Events (EventClassDesc,StartTime,TraceType,LoginName,HostName,TextData,ApplicationName,DatabaseName,ObjectName,RoleName)
SELECT
	EventClassDesc,
	StartTime,
	TraceType,
	LoginName,
	HostName,
	TextData,
	ApplicationName,
	DatabaseName,
	ObjectName,
	RoleName
FROM
	DatabaseSecurityAuditEvents
--WHERE
--	StartTime >= GETDATE() - 1
ORDER BY
	StartTime

DECLARE
@ID					INT,
@EventClassDesc		VARCHAR(255),
@StartTime			DATETIME,
@TraceType			CHAR(5),
@LoginName			VARCHAR(100),
@HostName			VARCHAR(255),
@TextData			VARCHAR(4000),
@ApplicationName	VARCHAR(255),
@DatabaseName		VARCHAR(255),
@ObjectName			VARCHAR(255),
@RoleName			VARCHAR(255),
@Message			VARCHAR(8000)

DECLARE CI CURSOR FOR SELECT DISTINCT ID FROM #Events
OPEN CI
FETCH NEXT FROM CI INTO @ID
WHILE @@FETCH_STATUS = 0
BEGIN
SELECT
	@EventClassDesc = ISNULL(EventClassDesc,'N/A'),
	@StartTime = Starttime,
	@TraceType = ISNULL(TraceType,'N/A'),
	@LoginName = ISNULL(LoginName,'N/A'),
	@HostName = ISNULL(HostName,'N/A'),
	@TextData = ISNULL(TextData,'N/A'),
	@ApplicationName = ISNULL(ApplicationName,'N/A'),
	@DatabaseName = ISNULL(DatabaseName,'N/A'),
	@ObjectName = ISNULL(ObjectName,'N/A'),
	@RoleName = ISNULL(RoleName,'N/A')
FROM
	#Events
WHERE
	ID = @ID
SET @Message = CHAR(13)+'StartTime:'+CONVERT(VARCHAR,@StartTime)+CHAR(13)+'TraceType:'+@TraceType+CHAR(13)+'EventClassDesc:'+@EventClassDesc+CHAR(13)+'LoginName:'+@LoginName+CHAR(13)+'HostName:'+@HostName+CHAR(13)+'TextData:'+@TextData+CHAR(13)+'ApplicationName:'+@ApplicationName+CHAR(13)+'DatabaseName:'+@DatabaseName+CHAR(13)+'ObjectName:'+@ObjectName+CHAR(13)+'RoleName:'+@RoleName
EXEC xp_logevent 60000, @Message, informational
FETCH NEXT FROM CI INTO @ID
END
CLOSE CI
DEALLOCATE CI

DROP TABLE #Events

GO

/* ------------------------------------------------------------------------------------ 
 Procedure Name	:usp_UpdateAuditEventData					
 Description		:Copy Data from temp table to DatabaseSecurityAuditEvents	
--------------------------------------------------------------------------------------*/

/****** Object:  StoredProcedure [dbo].[usp_UpdateAuditEventData]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[usp_UpdateAuditEventData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_UpdateAuditEventData]
GO

/****** Object:  StoredProcedure [dbo].[usp_UpdateAuditEventData]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create procedure [dbo].[usp_UpdateAuditEventData]
as

DELETE FROM TmpSecurityAuditEvents WHERE ApplicationName = 'Microsoft SQL Server Management Studio - Transact-SQL IntelliSense'

INSERT INTO DatabaseSecurityAuditEventsHistory
SELECT * FROM DatabaseSecurityAuditEvents

TRUNCATE TABLE DatabaseSecurityAuditEvents

insert into DatabaseSecurityAuditEvents
(
EventClassDesc,TextData      ,BinaryData       ,DatabaseID     ,TransactionID  ,NTUserName     ,
NTDomainName  ,HostName         ,ClientProcessID,ApplicationName,LoginName      ,
SPID          ,Duration         ,StartTime      ,EndTime        ,Reads          ,
Writes        ,CPU              ,Permissions    ,Severity       ,EventSubClass  ,
ObjectID      ,Success          ,IndexID        ,IntegerData    ,EventClass     ,
ObjectType    ,NestLevel        ,State          ,Error          ,Mode           ,
Handle        ,ObjectName       ,DatabaseName   ,FileName       ,OwnerName      ,
RoleName      ,TargetUserName   ,DBUserName     ,LoginSid       ,TargetLoginName,
TargetLoginSid,ColumnPermissions,DateCreated    ,TraceType)
select 
B.EventName,  TextData      ,BinaryData       ,DatabaseID     ,TransactionID  ,NTUserName     ,
NTDomainName  ,HostName         ,ClientProcessID,ApplicationName,LoginName      ,
SPID          ,Duration         ,StartTime      ,EndTime        ,Reads          ,
Writes        ,CPU              ,Permissions    ,Severity       ,EventSubClass  ,
ObjectID      ,Success          ,IndexID        ,IntegerData    ,EventClass     ,
ObjectType    ,NestLevel        ,State          ,Error          ,Mode           ,
Handle        ,ObjectName       ,DatabaseName   ,FileName       ,OwnerName      ,
RoleName      ,TargetUserName   ,DBUserName     ,LoginSid       ,TargetLoginName,
TargetLoginSid,ColumnPermissions,DateCreated    ,TraceType
from TmpSecurityAuditEvents A
inner join SQLTraceEvents B on A.EventClass = B.TraceID
where
(TraceType = 'sec' AND ApplicationName NOT LIKE 'SQLAgent%' AND ApplicationName <> 'Report Server')
OR
(TraceType = 'ddl' AND ObjectName not like '%_WA_Sys_%' AND ObjectName IS NOT NULL AND DatabaseName <> 'tempdb')
OR
(TraceType = 'dba')
--(TraceType <> 'ddl' AND (DatabaseName IS NULL OR DatabaseName <> 'TempDB') AND NTUserName <> 'SYSTEM')
order by StartTime

GO


/* ----------------------------------------------------------------------------------
 Procedure Name	:usp_RenameTraceFIles						
 Description		:Rename trace files and keep history for 7 days.		
-------------------------------------------------------------------------------------- */

/****** Object:  StoredProcedure [dbo].[usp_RenameTraceFIles]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[usp_RenameTraceFIles]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_RenameTraceFIles]
GO

/****** Object:  StoredProcedure [dbo].[usp_RenameTraceFIles]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create proc [dbo].[usp_RenameTraceFIles]
@filepath varchar(150),
@filename varchar(150)
as


set nocount on
declare @yesno int
declare @lsCommand varchar(200)
declare @mctr int
declare @file1 varchar(150)
declare @file2 varchar(150)
declare @deletestring varchar(1000)
declare @renstring varchar(1000)
declare @filectr int
declare @filedesc varchar(150)

select @filedesc = ltrim(rtrim(@filepath)) + ltrim(rtrim(@filename))

select @mctr = 45
select @filectr = 0

-- if we found the file for 7th day delete the file 

select @file1 = @filedesc + ltrim(rtrim(str(@mctr))) + '.trc' 
select @file1 = @filedesc + ltrim(rtrim(str(@mctr))) + '.trc' 
select @deletestring = 'del ' + @file1

exec master..xp_fileexist @file1, @yesno Out 
if @yesno = 1
	exec master..xp_cmdshell @deletestring

while @mctr > 0
begin
	select @mctr = @mctr - 1
	Select @file1 = @filedesc + ltrim(rtrim(str(@mctr))) + '.trc'
	exec master..xp_fileexist @file1, @yesno Out 

	if @yesno = 1
	begin
		while @mctr >= 1
		begin

			-- rename file in loop for all 7 days
			select @filectr = @mctr + 1
			select @file1 = @filedesc + ltrim(rtrim(str(@mctr))) + '.trc' 
			select @file2 = ' ' + ltrim(rtrim(@filename)) + ltrim(rtrim(str(@filectr))) + '.trc'
			select @renstring = 'ren ' + @file1 + @file2
			exec master..xp_cmdshell @renstring

			select @mctr = @mctr - 1

			select @deletestring = 'del ' + @file1
			exec master..xp_cmdshell @deletestring


		end

	end

	-- Always rename the currect filr to number 1
	if @mctr = 0
	begin
		select @mctr = 1
		select @file2 = ' ' + ltrim(rtrim(@filename)) + ltrim(rtrim(str(@mctr))) + '.trc' 
		select @file1 = @filedesc + '.trc' 
		select @renstring = 'ren ' + @file1 + @file2

		exec master..xp_cmdshell @renstring

		break
	end

end

GO


/* ----------------------------------------------------------------------------------
 Procedure Name	:Usp_ImportTraceData						
 Description		:Import all trace data from trace file to sql table.		
--------------------------------------------------------------------------------------*/

/****** Object:  StoredProcedure [dbo].[Usp_ImportTraceData]     ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[Usp_ImportTraceData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usp_ImportTraceData]
GO


/****** Object:  StoredProcedure [dbo].[Usp_ImportTraceData]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create procedure [dbo].[Usp_ImportTraceData]
as

declare @traceid tinyint,
	@desc varchar(2000),
	@FileName   varchar(400),
	@lsSubject varchar(50),
	@ServerName varchar(50)

truncate table TmpSecurityAuditEvents

--truncate table DatabaseSecurityAuditEvents
-- To remove the more than 90 days data in the table
Delete DatabaseSecurityAuditEventsHistory Where StartTime < (GETDATE()- 7);

-- Security Trace template
Select @FileName = 'D:\SQLNativeAudit\SecurityEventAudit.trc'

insert into TmpSecurityAuditEvents
select TextData,BinaryData,DatabaseID,TransactionID,NTUserName,NTDomainName,HostName,ClientProcessID,ApplicationName,LoginName,
SPID,Duration,StartTime,EndTime,Reads,Writes,CPU,Permissions,Severity,EventSubClass,ObjectID,Success,IndexID,IntegerData,
ServerName,EventClass,ObjectType,NestLevel,State,Error,Mode,Handle,ObjectName,DatabaseName,FileName,OwnerName,RoleName,
TargetUserName,DBUserName,LoginSid,TargetLoginName,TargetLoginSid,ColumnPermissions,getdate(),'sec' from ::fn_trace_gettable(@FileName, default)

-- DBA Trace template
Select @FileName = 'D:\SQLNativeAudit\DBAActivityEventAudit.trc'

insert into TmpSecurityAuditEvents
select TextData,BinaryData,DatabaseID,TransactionID,NTUserName,NTDomainName,HostName,ClientProcessID,ApplicationName,LoginName,
SPID,Duration,StartTime,EndTime,Reads,Writes,CPU,Permissions,Severity,EventSubClass,ObjectID,Success,IndexID,IntegerData,
ServerName,EventClass,ObjectType,NestLevel,State,Error,Mode,Handle,ObjectName,DatabaseName,FileName,OwnerName,RoleName,
TargetUserName,DBUserName,LoginSid,TargetLoginName,TargetLoginSid,ColumnPermissions,getdate(),'dba' from ::fn_trace_gettable(@FileName, default)

-- DDL Trace template
Select @FileName = 'D:\SQLNativeAudit\ddlActivityEventAudit.trc'

insert into TmpSecurityAuditEvents
select TextData,BinaryData,DatabaseID,TransactionID,NTUserName,NTDomainName,HostName,ClientProcessID,ApplicationName,LoginName,
SPID,Duration,StartTime,EndTime,Reads,Writes,CPU,Permissions,Severity,EventSubClass,ObjectID,Success,IndexID,IntegerData,
ServerName,EventClass,ObjectType,NestLevel,State,Error,Mode,Handle,ObjectName,DatabaseName,FileName,OwnerName,RoleName,
TargetUserName,DBUserName,LoginSid,TargetLoginName,TargetLoginSid,ColumnPermissions,getdate(),'ddl' from ::fn_trace_gettable(@FileName, default)

-- Transfer records to actual table.
exec usp_UpdateAuditEventData

-- Keep trace files for last 7 days.
exec usp_RenameTraceFIles 'D:\SQLNativeAudit\','SecurityEventAudit'
exec usp_RenameTraceFIles 'D:\SQLNativeAudit\','DBAActivityEventAudit'
exec usp_RenameTraceFIles 'D:\SQLNativeAudit\','ddlActivityEventAudit'

-- Delete All Trace File
--exec master..xp_cmdshell 'del e:\mssql\*.trc'

GO




/*

The script to delete the old audit log files from the specified folder 

*/

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[usp_admin_delete_files_by_date]    ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[Usr_admin_delete_files_by_date]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usr_admin_delete_files_by_date]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Usr_admin_delete_files_by_date] (@SourceDir varchar(1024), @SourceFile varchar(512), @DaysToKeep int)
-- EXEC master.dbo.Usr_Admin_Delete_Files_By_Date @SourceDir = 'E:\SQLNativeAudit\<<ServerName>>\'
--        , @SourceFile = 'SQL_Native_*'
--        , @DaysToKeep = 90

AS

/******************************************************************************
**
** Name: Usr_Admin_Delete_Files_By_Date.sql
**
** Description: Delete files older than X-days based on path & extension.
**
**  Depending on the output from xp_msver, we will execute either a
**  Windows 2000 or Windows 2003 specific INSERT INTO #_File_Details_02
**  operation as there is a small difference in the FOR output between
**  Windows 2000 and 2003 (Operating system versions).
**
** Return values: 0 - Success
**   -1 - Error
**
** Depends on: xp_cmdshell access to @SourceDir via SQLAgent account.
**
********************************************************************************/

SET NOCOUNT ON

DECLARE @CurrentFileDate char(10)
 , @OldFileDate char(10)
 , @SourceDirFOR varchar(255)
 , @FileName varchar(512)
 , @DynDelete varchar(512)
 , @ProcessName varchar(150)
 , @OSVersion decimal(3,1)
 , @Error int


SET @ProcessName = 'Usr_admin_delete_files_by_date - [' + @SourceFile + ']'
SET @CurrentFileDate = CONVERT(char(10),getdate(),121)
SET @OldFileDate = CONVERT(char(10),DATEADD(dd,-@DaysToKeep,@CurrentFileDate),121)
SET @SourceDirFOR = 'FOR %I IN ("' + @SourceDir + @SourceFile + '") DO @ECHO %~nxtI'
SET @Error = 0


-- Get Windows OS Version info for proper OSVer statement block exec.
CREATE TABLE #_OSVersion
 ( [Index] int
 , [Name] varchar(255)
 , [Internal_Value] varchar(255)
 , [Character_Value] varchar(255) )

INSERT INTO #_OSVersion
EXEC master..xp_msver 'WindowsVersion'

SET @OSVersion = (SELECT SUBSTRING([Character_Value],1,3) FROM #_OSVersion)

-- Start temp table population(s).
CREATE TABLE #_File_Details_01
 ( Ident int IDENTITY(1,1)
 , Output varchar(512) )

INSERT INTO #_File_Details_01
 EXEC master..xp_cmdshell @SourceDirFOR

CREATE TABLE #_File_Details_02
 (Ident int
 , [TimeStamp] datetime
 , [FileName] varchar(255) )

-- OS Version specifics.
IF @OSVersion = '5.0'
 BEGIN -- Exec Windows 2000 version.
  INSERT INTO #_File_Details_02
   SELECT Ident
    , CONVERT(datetime, LEFT(CAST(SUBSTRING([Output],1,8) AS datetime),12)) AS [TimeStamp]
    , SUBSTRING([Output],17,255) AS [FileName]
    FROM #_File_Details_01

   WHERE [Output] IS NOT NULL
   ORDER BY Ident
 END

IF @OSVersion = '5.1'
 BEGIN -- Exec Windows XP version.
  INSERT INTO #_File_Details_02
   SELECT Ident
    , CONVERT(char(10), SUBSTRING([Output],1,10), 121) AS [TimeStamp]
    , SUBSTRING([Output],21,255) AS [FileName]
    FROM #_File_Details_01
 
   WHERE [Output] IS NOT NULL
   ORDER BY Ident
 END

IF @OSVersion = '5.2'
 BEGIN -- Exec Windows 2003 version.
  INSERT INTO #_File_Details_02
   SELECT Ident
    , CONVERT(char(10), SUBSTRING([Output],1,10), 121) AS [TimeStamp]
    , SUBSTRING([Output],21,255) AS [FileName]
    FROM #_File_Details_01
 
   WHERE [Output] IS NOT NULL
   ORDER BY Ident
 END

IF @OSVersion = '6.0'
 BEGIN -- Exec Windows 2008 version.
  INSERT INTO #_File_Details_02
   SELECT Ident
    , CONVERT(char(10), SUBSTRING([Output],1,10), 121) AS [TimeStamp]
    , SUBSTRING([Output],21,255) AS [FileName]
    FROM #_File_Details_01
 
   WHERE [Output] IS NOT NULL
   ORDER BY Ident
 END

IF @OSVersion = '6.1'
 BEGIN -- Exec Windows 2008 R2 version.
  INSERT INTO #_File_Details_02
   SELECT Ident
    , CONVERT(char(10), SUBSTRING([Output],1,10), 121) AS [TimeStamp]
    , SUBSTRING([Output],21,255) AS [FileName]
    FROM #_File_Details_01
 
   WHERE [Output] IS NOT NULL
   ORDER BY Ident
 END

-- Start delete ops cursor.
DECLARE curDelFile CURSOR
READ_ONLY
FOR

 SELECT [FileName]
  FROM #_File_Details_02
 WHERE [TimeStamp] <= @OldFileDate

OPEN curDelFile

FETCH NEXT FROM curDelFile INTO @FileName
WHILE (@@fetch_status <> -1)
BEGIN
 IF (@@fetch_status <> -2)
 BEGIN

  SET @DynDelete = 'DEL /Q "' + @SourceDir + @FileName + '"'

  EXEC master..xp_cmdshell @DynDelete

 END
 FETCH NEXT FROM curDelFile INTO @FileName
END

CLOSE curDelFile
DEALLOCATE curDelFile

DROP TABLE #_OSVersion
DROP TABLE #_File_Details_01
DROP TABLE #_File_Details_02

GO

/*
The script to create view for the report
*/
/****** Object:  View [dbo].[vw_auditcsvexport]     ******/
USE master
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[vw_auditcsvexport]') AND type in (N'V', N'PC'))
DROP VIEW [dbo].[vw_auditcsvexport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[vw_auditcsvexport]
as
SELECT	CONVERT(VARCHAR(20), StartTime) AS StartTime,
		CONVERT(VARCHAR(20), EndTime) AS EndTime,
		CONVERT(CHAR(15), NTUserName) AS NTUserName,
		CONVERT(CHAR(15), NTDomainName) AS NTDomainName,
		CONVERT(CHAR(15), HostName) AS HostName,
		CONVERT(CHAR(15), LoginName) AS LoginName,	
		CONVERT(CHAR(25), ServerName) AS ServerName,
		CONVERT(VARCHAR(15), DatabaseName) as DBName,
		CONVERT(CHAR(30), ObjectName) AS ObjectName,
		CONVERT(VARCHAR(35), ApplicationName) as ApplicationName,
		CONVERT(VARCHAR(35), TextData) as [Statement]      
From [dbo].[TmpSecurityAuditEvents]

GO

/*

The script to generate the SQL Audit report
*/

USE [master]
GO

/****** Object:  StoredProcedure [dbo].[Usr_SQL258AuditReport]     ******/

IF  EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[Usr_SQL258AuditReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Usr_SQL258AuditReport]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Usr_SQL258AuditReport]
as

SET NOCOUNT ON

DECLARE @Command1 varchar(500)
DECLARE @filename varchar(100)
DECLARE @date varchar(24)
DECLARE @SrvName varchar(100)

select @date=convert(varchar(2),DATEPART(DD,getdate()))
+convert(varchar(2),DATEPART(MM,getdate()))
+convert(varchar(4),DATEPART(YYYY,getdate()))

select @SrvName = @@SERVERNAME 

SELECT @filename='Report_'+@date

Select @Command1 = 'SQLCMD -S' + @SrvName + ' -E -dmaster -Q'+'"'+'select * from master.dbo.vw_auditcsvexport'+'"'+ ' -o'+'"'+ 'D:\SQLNativeAudit\'+@filename+'.txt' + '"'

Exec master..xp_cmdshell @Command1

GO


/*
The script to schedule the jobs  and create a job to start trace 
*/

USE [msdb]
GO

/****** Object:  Job [ExecuteSecurityAuditTrace]    Script Date: 04/24/2012 14:28:29 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'ExecuteSecurityAuditTrace')
EXEC msdb.dbo.sp_delete_job @job_name=N'ExecuteSecurityAuditTrace', @delete_unused_schedule=1
GO
/****** Object:  Job [StopSecurityAuditTrace]    Script Date: 04/24/2012 14:30:50 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'StopSecurityAuditTrace')
EXEC msdb.dbo.sp_delete_job @job_name=N'StopSecurityAuditTrace', @delete_unused_schedule=1
GO

/****** Object:  Job [ITIS_NativeAudit]    Script Date: 04/29/2015 07:52:16 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ITIS_NativeAudit')
EXEC msdb.dbo.sp_delete_job @job_name=N'ITIS_NativeAudit', @delete_unused_schedule=1
GO

/****** Object:  Job [ITIS_NativeAudit]    Script Date: 04/29/2015 07:52:16 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ITIS_StopNativeAudit')
EXEC msdb.dbo.sp_delete_job @job_name=N'ITIS_StopNativeAudit', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [ITIS_NativeAudit]    Script Date: 04/29/2015 07:52:16 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 04/29/2015 07:52:16 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITIS_NativeAudit', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [StopSecurityAuditTrace]    Script Date: 04/29/2015 07:52:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'StopSecurityAuditTrace', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=4, 
		@on_fail_step_id=5, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @traceid int,
	@desc varchar(2000)

-- Get Trace Info

declare c1 cursor
for
select distinct traceid 
FROM :: fn_trace_getinfo(default)
where value in (''D:\SQLNativeAudit\SecurityEventAudit.trc'',
		''D:\SQLNativeAudit\DBAActivityEventAudit.trc'',
		''D:\SQLNativeAudit\ddlActivityEventAudit.trc'')

open c1

fetch c1 into @traceid

while @@fetch_status = 0
begin
	-- Stop Trace
	exec sp_trace_setstatus @traceid, 0

	-- Close Trace
	exec sp_trace_setstatus @traceid, 2

	fetch c1 into @traceid
end
close c1
deallocate c1

exec Usp_ImportTraceData
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete_Old_Reports_Step]    Script Date: 04/29/2015 07:52:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete_Old_Reports_Step', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC Usr_admin_delete_files_by_date
@SourceDir = ''D:\SQLNativeAudit\''
, @SourceFile = ''*.txt''
, @DaysToKeep = 7;
GO
EXEC Usr_admin_delete_files_by_date
@SourceDir = ''D:\SQLNativeAudit\''
, @SourceFile = ''*.trc*''
, @DaysToKeep = 7
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQLAuditReport_Step]    Script Date: 04/29/2015 07:52:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQLAuditReport_Step', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec Usr_SQL258AuditReport', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Save Events to Windows Log]    Script Date: 04/29/2015 07:52:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Save Events to Windows Log', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC Usp_SaveEventsInWindowsLog', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ExecuteSecurityAuditTrace]    Script Date: 04/29/2015 07:52:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ExecuteSecurityAuditTrace', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec Usp_ExecuteTrace', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Error Handling]    Script Date: 06/12/2015 09:04:12 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Error Handling', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC xp_logevent 60000, ''Native Audit Failed. Please check the SQL Jobs'', error', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'After Restart', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150416, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every Hour', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20040713, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [ITIS_StopNativeAudit]    Script Date: 5/29/2015 9:31:41 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/29/2015 9:31:41 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITIS_StopNativeAudit', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [StopSecurityAuditTrace]    Script Date: 5/29/2015 9:31:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'StopSecurityAuditTrace', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @traceid int,
	@desc varchar(2000)

-- Get Trace Info

declare c1 cursor
for
select distinct traceid 
FROM :: fn_trace_getinfo(default)
where value in (''D:\SQLNativeAudit\SecurityEventAudit.trc'',
		''D:\SQLNativeAudit\DBAActivityEventAudit.trc'',
		''D:\SQLNativeAudit\ddlActivityEventAudit.trc'')

open c1

fetch c1 into @traceid

while @@fetch_status = 0
begin
	-- Stop Trace
	exec sp_trace_setstatus @traceid, 0

	-- Close Trace
	exec sp_trace_setstatus @traceid, 2

	fetch c1 into @traceid
end
close c1
deallocate c1

exec Usp_ImportTraceData
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete_Old_Reports_Step]    Script Date: 5/29/2015 9:31:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete_Old_Reports_Step', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC Usr_admin_delete_files_by_date
@SourceDir = ''D:\SQLNativeAudit\''
, @SourceFile = ''*.txt''
, @DaysToKeep = 7;
GO
EXEC Usr_admin_delete_files_by_date
@SourceDir = ''D:\SQLNativeAudit\''
, @SourceFile = ''*.trc*''
, @DaysToKeep = 7
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQLAuditReport_Step]    Script Date: 5/29/2015 9:31:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQLAuditReport_Step', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec Usr_SQL258AuditReport', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Save Events to Windows Log]    Script Date: 5/29/2015 9:31:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Save Events to Windows Log', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC Usp_SaveEventsInWindowsLog', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

USE [master]
GO
if exists (select * from dbo.sysusers where name = 'NativeAuditRole')
BEGIN
if exists (select * from dbo.sysusers where name = 'JNJ\ITS-EP-SQLSELM-NativeAuditRole')
DROP USER [JNJ\ITS-EP-SQLSELM-NativeAuditRole]
DROP ROLE [NativeAuditRole]
DROP LOGIN [JNJ\ITS-EP-SQLSELM-NativeAuditRole]
END

--Native Audit Implementation Verification
USE master
GO
DECLARE 
@obj_count INT,
@job_count INT,
@final_count INT

SET @obj_count = (select count(*) from dbo.sysobjects where name in (
'DatabaseSecurityAuditEvents',
'DatabaseSecurityAuditEventsHistory',
'SQLTraceEvents','TmpSecurityAuditEvents',
'vw_auditcsvexport',
'Usp_DBAActivityEventAudit',
'Usp_DDLActivityEventAudit',
'Usp_ExecuteTrace',
'Usp_ImportTraceData',
'Usp_RenameTraceFIles',
'Usp_SaveEventsInWindowsLog',
'Usp_SecurityEventAudit',
'Usp_UpdateAuditEventData',
'Usr_admin_delete_files_by_date',
'Usr_SQL258AuditReport'))

SET @job_count = (SELECT count(*) FROM msdb.dbo.sysjobs_view WHERE name in (
'ITIS_NativeAudit',
'ITIS_StopNativeAudit'))

set @final_count = @obj_count + @job_count
IF @final_count <> 17
RAISERROR ('NATIVE AUDIT WAS NOT IMPLEMENTED!!! Please check the error messages.',20,-1) with log
ELSE
PRINT 'Native Audit Implemented.'
------------------------------------------------

USE msdb
GO
EXEC dbo.sp_start_job N'ITIS_NativeAudit'
