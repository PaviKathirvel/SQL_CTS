#----------------------------------------------------------------------------------------
# File                                     :               AlwaysOnSetup.ps1
# Description                     :               This script will create SQL Server AG group based on the inputs provided by user and enroll the databses to newly created AG group.
# LastModified                  :               12-23-2015
# Logs                                   :   Defualt path C:\SQLInstallLogs_2012\AlwaysOn_<TimeStamp>.txt
# Example                        :           c:\sqlalwayson\alwaysonsetup.ps1 -lnrIp 10.0.108.153 -LnrSubnet 255.255.255.0 -lnrName "ITSUSLW12SQLLN" -DatabaseList "ALL"
# Authors                            :               Jay Natarajan
# Parameters                     :[Backup Path] - Optional - fileshare that is accessible by both servers.
#                                 [AGName] - Optional - AG group Name.
#                                 [LnrName] - Optional - Listener Name   
#                                 [LnrIP] - Optional - Listener IP   
#                                 [LnrSubnet] - Optional - Listener Subnet   
#                                 [DatabaseList] - Optional - If nothing is specified all the databases in the server would be added. Specify List of databases in comma seperated format if only few databases in the server needs to be included.
#----------------------------------------------------------------------------------------
Param(
[string] $BackupPath,
[String] $AGName,
[String] $LnrName,
[String] $LnrIP,
[String] $LnrSubnet,
[String[]]$DatabaseList
)






# Local Variables
#
[String]$ModuleLogFile = "C:\\SQLInstall_Logs\\AlwaysOn_Log_" + [System.DateTime]::Now.ToString("ddMMyyyyHHmm") + ".txt"
             if ((Test-Path $ModuleLogFile) -eq $false)
    {
                                New-Item $ModuleLogFile -type file | Out-Null
    }
   # else
   # {
   # Write-Output "The log file location is invalid. Please make sure the log file location exists" 
    #Write-Output "FINAL STATUS = FAILURE" -f red
    #break
    #}



# Function to log all activities to a text file.
# <para>$log</para> - Contains text that needs to be logged in file
#
function LogActivity([String]$log)
{
   
                
                 Add-Content $ModuleLogFile "`r`n$log" 
                
                 if ($log -match 'FAIL')
                 {
                   
                    $log | Write-Host -fore red  
                 }
                 elseif   ($log -match 'SUCCESS')
                 {
                    $log | Write-Host -fore  green  
                 }
                 else
                 {
                    $log | Write-Host 
                 }
}

#GeT Listener IP Details

function GetIpDetails([string[]]$ComputerName)
{
              
       
begin {}            
process {            
 foreach ($Computer in $ComputerName) {   
  if(Test-Connection -ComputerName $Computer -Count 1 -ea 0) {            
   try {            
    $Networks = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $Computer -EA Stop | ? {$_.IPEnabled}            
   } catch {            
        Write-Warning "Error occurred while querying $computer."            
        Continue            
   }      
   foreach ($Network in $Networks) {      
   
    $IPAddress  = $Network.IpAddress[0]            
    $SubnetMask  = $Network.IPSubnet[0]            
    $DefaultGateway = $Network.DefaultIPGateway            
    $DNSServers  = $Network.DNSServerSearchOrder            
    $IsDHCPEnabled = $false            
    If($network.DHCPEnabled) {            
     $IsDHCPEnabled = $true            
    }   
  
 
    if ($DNSServers)
    {
    $MACAddress  = $Network.MACAddress            
    $OutputObj  = New-Object -Type PSObject            
    $OutputObj | Add-Member -MemberType NoteProperty -Name ComputerName -Value $Computer.ToUpper()            
    $OutputObj | Add-Member -MemberType NoteProperty -Name IPAddress -Value $IPAddress            
    $OutputObj | Add-Member -MemberType NoteProperty -Name SubnetMask -Value $SubnetMask            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name Gateway -Value $DefaultGateway            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name IsDHCPEnabled -Value $IsDHCPEnabled            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name DNSServers -Value $DNSServers            
    #$OutputObj | Add-Member -MemberType NoteProperty -Name MACAddress -Value $MACAddress            
    $OutputObj 
    }           
   }            
  }            
 }            
}            
            
end {}

}



if (!$DatabaseList)
{
    $DatabaseList = "ALL"
}




if (!$BackupPath)
{
    $BackupPath = $null
}


# Parameters
$clustername = get-cluster
#$PrimaryReplica = get-wmiobject -class win32_computersystem | select-object name
$PrimaryReplica = get-clustergroup -cluster $clustername -name "cluster Group"|select ownernode
$allnodes = get-clusternode | select-object name
$PrimaryReplica = $PrimaryReplica.ownernode.tostring()
[String]$SecondaryReplica = ($allnodes -notmatch $PrimaryReplica) | select-object -Expandproperty name

$PrimaryReplica1 = $PrimaryReplica
$SecondaryReplica1 = $SecondaryReplica

$PrimaryReplica = "tcp:$primaryreplica"
$SecondaryReplica = "tcp:$Secondaryreplica"


#if ($PrimaryReplica -ne $env:computername)
#{

 #   LogActivity "The script has to be run from primary node and the current node is not primary" 
  #  LogActivity "FINAL STATUS = FAILURE"
   # break


#}


#If Listener name is null then create listener name based on the predefined syntax
if (!$AGName)
{
    [String]$AGGroupName = $clustername.Name + "GRP"
}
else
{
    [String]$AGGroupName = $AGName
}


#Check Listener Ip and subnet
if (($LnrIP -and !$LnrSubnet) )
{

    LogActivity "Listener subnet is a required parameter when Listener IP is specified" 
    LogActivity "FINAL STATUS = FAILURE"
    break

}
if ((!$LnrIP -and $LnrSubnet) )
{

    LogActivity "Listener IP is a required parameter when Listener Subnet is specified" 
    LogActivity "FINAL STATUS = FAILURE"
    break

}

if (($LnrIP -or $LnrSubnet) -and (!$LnrName))
{

    LogActivity "Listener name is a required parameter when Listener IP and Listener Subnet is specified." 
    LogActivity "FINAL STATUS = FAILURE"
    break



}


if (!$LnrName)
{
    [String]$ListernerName = $clustername.Name + "LSNR"
}
else
{
    [String]$ListernerName = $LnrName
}


if (!$LnrIP -and !$LnrSubnet)
{
$lnrdetails = GetIpDetails $ListernerName

[String]$IpAddress = $lnrdetails.IPAddress
[String]$Subnet = $lnrdetails.Subnetmask
}
else
{
[String]$IpAddress = $LnrIp
[String]$Subnet = $LnrSubnet

}

if (!$IpAddress)
{

    LogActivity "The Listener name is invalid. Please validate that the DNS entry and make sure the Listener exists before proceeding." 
    LogActivity "FINAL STATUS = FAILURE"
    break


}



[String]$ListenerPort = "1433"
[String]$Port = "5022"
[string]$ReturnStatus = $false
[string]$AsyncSecondary = $false



if (!$PrimaryReplica -or !$SecondaryReplica) 
{
    LogActivity "Invalid Cluster nodes. Please check the Cluster name" 
    LogActivity "FINAL STATUS = FAILURE"
    break
}

#Check if Listener Name Exists

    $LnrNameExist = (invoke-sqlcmd -query "select dns_name from sys.availability_group_listeners where dns_name in ('$ListernerName')" -ServerInstance $PrimaryReplica -QueryTimeout 120).dns_name
    
   
     if ($LnrNameExist)
     {

        LogActivity "Validating the AlwaysOn Listener name for AlwaysOn:FAILURE. The Alwayson Listener already exist." 
        LogActivity "FINAL STATUS = FAILURE"
        break

     }

 
 #Check if Alwayson Group Name Exists       
    $AGNameExist = (invoke-sqlcmd -query "select name from sys.availability_groups where name in ('$AgGroupName')" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
    
  
     if ($AGNameExist)
     {

        LogActivity "Validating the AlwaysOn Group name for AlwaysOn:FAILURE. The Alwayson Group already exist." 
        LogActivity "FINAL STATUS = FAILURE"
        break

     }

#Validate database lists

   if ($DatabaseList -eq "ALL")
   {
    $DBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
    }
    
   
     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
 
    

       if (($DBList) -and ($DBinAG))
       {
        
        $errdb = Compare-Object -ReferenceObject $DBList  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }

    if ($DatabaseList -ne "ALL")
    {

    $PrimaryDBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name

    if ($PrimaryDBlist)
    {
        $errdbexists = Compare-Object -ReferenceObject $PrimaryDBlist  -DifferenceObject $DatabaseList -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject
        if ($errdbexists)
    {
        $errdb1 = $errdbexists.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }
     }  
     else
             
     {
        
                $errdb1 = $DatabaseList.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }

    }

#backup and restore databases


    if ($BackupPath)
    {
  
    $bkuppathexist = [System.IO.Directory]::Exists($backuppath)
   
    if (!$bkuppathexist)
    {
        LogActivity "Invalid Backup Path specified, please specifcy valid path and run the script again."
        break
    }
    else
    {   
        if ($DatabaseList -match "ALL")
        { 
             $dblists =  (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4 and name not in (select db_name(database_id) from sys.dm_hadr_database_replica_states)" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
             
            if ( !$dblists) 
            {
                 LogActivity "No valid databases found to be added to the Availability Group. Please check the input variables" 
                 LogActivity "FINAL STATUS = FAILURE"
                 break
            }
        }


        $dt = get-date -format yyyyMMddHHmmss
        $dblists = $DatabaseList.split(",")
        foreach ($db in $dblists)
        {

            $dbbkpath = "$BackupPath\$db$dt.bak"
 
            $backupsrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $PrimaryReplica
            $backupsrvrconn.ConnectionContext.StatementTimeout = 0

            $restoresrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $SecondaryReplica
            $restoresrvrconn.ConnectionContext.StatementTimeout = 0


            # Backup my database and its log on the primary
            Backup-SqlDatabase -Database $db -BackupFile "$dbbkpath" -InputObject $backupsrvrconn


            # Restore the database and log on the 1st secondary (using NO RECOVERY)
            Restore-SqlDatabase -Database $db -BackupFile "$dbbkpath"  -InputObject $restoresrvrconn -ReplaceDatabase -NoRecovery
           
            
        }
    }
       LogActivity "Backup and restore the databases for AlwaysOn:SUCCESS" 
    }   



# Check if database exist


    $Primarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
        
    $Secondarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 1 and database_id > 4 " -ServerInstance $SecondaryReplica -QueryTimeout 120).name
    
     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
  
     if (!$Secondarysrvdatabaselist)
     {

        LogActivity "Validating the databases for AlwaysOn:FAILURE. All the databases must be available on both nodes." 
        LogActivity "FINAL STATUS = FAILURE"
        break

     }
      
  if ($DatabaseList -match "ALL")
   {
  
    $DBListCompare = Compare-Object -ReferenceObject $Primarysrvdatabaselist -DifferenceObject $Secondarysrvdatabaselist -PassThru

    if ($DBListCompare)
    {
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases in either server must exist in all."
        LogActivity "FINAL STATUS = FAILURE"
        break
    }
    else
    {
        $DBList = $Primarysrvdatabaselist -join ","
        $DatabaseList = $Primarysrvdatabaselist

        
    
  
        $dblists = $DatabaseList.split(",")
         
       if ($dbinAG)
       {
        
        $errdb = Compare-Object -ReferenceObject $Primarysrvdatabaselist  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }
     

           if ($Secondarysrvdatabaselist)
           {
            $errdb = Compare-Object -ReferenceObject $Secondarysrvdatabaselist  -DifferenceObject $Primarysrvdatabaselist -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject


            if ($errdb)
            {
            
                $exists = $false
                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
            }
            else
            {
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $databaselist is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }



    }
    }
    else
    {
      
  
        $dblists = $DatabaseList.split(",")
        
# Check if database exist
       if ($dbinAG)
       {

      $errdb = Compare-Object -ReferenceObject $dblists  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
        }

      $errdb = Compare-Object -ReferenceObject $Primarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject

   



              if ($errdb)
            {
            
                $exists = $false
                $PrimarysrvdatabaselistOtherRecoveryModel = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model <> 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                $errdbrecmodel = Compare-Object -ReferenceObject $dblists  -DifferenceObject $PrimarysrvdatabaselistOtherRecoveryModel -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject
                $PrimarysrvdatabaselistExists = (invoke-sqlcmd -query "select name from sys.databases where state = 0  and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                
                $errdbexists = Compare-Object -ReferenceObject $PrimarysrvdatabaselistExists  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject
                if ($errdbrecmodel)
                {
                $errdbrecmodel1 = $errdbrecmodel.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbrecmodel1 has to be in full recovery model in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                if ($errdbexists)
                {
                $errdbexists1 = $errdbexists.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbexists1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
                exit
                }
                else
                {
                 $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
            }


           if ($Secondarysrvdatabaselist)
           {
            $errdb = Compare-Object -ReferenceObject $Secondarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject


            if ($errdb)
            {
            
                $exists = $false
                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
            }
            else
            {
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $databaselist is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }



      
    }








# Function to enable "AlwaysOn" for specific sql instance.
#
function EnableAlwayOn([String]$Server) 
{
                try
                {
                                # Importing SQLPS module to execute TSQL statements
                                Import-Module SQLPS -DisableNameChecking
                                
                                LogActivity "Enabling SQL Server AlwaysOn on $Server server."
                                
                                # Calling Enable-SqlAlwaysOn cmdlet
                                Enable-SqlAlwaysOn -Path SQL\$Server\DEFAULT -force
                                LogActivity "Enabling SQL Server AlwaysOn on $Server server: SUCCESS"
                }
                catch
                {
                                LogActivity "Enabling SQL Server AlwaysOn on $Server server: FAILURE"
                                LogActivity "FINAL STATUS = FAILURE"
                                break
                }
}




# Function to disable "AlwaysOn" for specific sql instance.
#
function DisableAlwayOn([String]$Server) 
{
                try
                {
                                # Importing SQLPS module to execute TSQL statements
                                Import-Module SQLPS -DisableNameChecking
                                
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server."
                                
                                # Calling Disable-SqlAlwaysOn cmdlet
                                Disable-SqlAlwaysOn -Path SQL\$Server\DEFAULT -force
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server: SUCCESS"
                }
                catch
                {
                                LogActivity "Disabling SQL Server AlwaysOn on $Server server: FAILURE"
                                LogActivity "FINAL STATUS = FAILURE"
                                break
                }
}

# Enable Always-On for Primary and Secondary replica
EnableAlwayOn $PrimaryReplica1
EnableAlwayOn $SecondaryReplica1




# Function to configure AlwaysOn Availability Groups for user selected dtatabses.
#
function CofigureAG
{

                                $PrimaryServer = $PrimaryReplica1
                                $SecondaryServer = $SecondaryReplica1
                                

                                $Domain = (gwmi WIN32_ComputerSystem).Domain

                                $PrimaryEndPointUrl = "TCP://" + ($PrimaryReplica1) + "." + $Domain + ":$Port"
                                $SecondaryEndPointUrl = "TCP://" + ($SecondaryReplica1) + "." + $Domain + ":$Port"
                               

                                # Creating Availability Group on Primary
                                if ($DatabaseList -match "ALL")
                                {
                                $DbList = $DbList
                                }
                                else
                                {
                                $DBlist = $databaselist -join ","
                                }

                                

                                if($AsyncSecondary -eq $false)
                                {
                                                $sqlquery1 =   "CREATE AVAILABILITY GROUP [$AGGroupName]
                                                                                                WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
                                                                                                FOR DATABASE $DBList
                                                                                                REPLICA ON N'$SecondaryServer' WITH (ENDPOINT_URL = N'$SecondaryEndPointUrl', 
                                                                                                FAILOVER_MODE = AUTOMATIC, 
                                                                                                AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL)),
                                                                                                N'$PrimaryServer' WITH (ENDPOINT_URL = N'$PrimaryEndPointUrl', 
                                                                                                FAILOVER_MODE = AUTOMATIC, 
                                                                                                AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL))"

                                }
                                else
                                {                                                                              
                                                $sqlquery1 =              "CREATE AVAILABILITY GROUP [$AGGroupName]
                                                                                                WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
                                                                                                FOR DATABASE $DBList
                                                                                                REPLICA ON N'$SecondaryServer' WITH (ENDPOINT_URL = N'$SecondaryEndPointUrl', 
                                                                                                FAILOVER_MODE = MANUAL , 
                                                                                                AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = READ_ONLY )),
                                                                                                N'$PrimaryServer' WITH (ENDPOINT_URL = N'$PrimaryEndPointUrl', 
                                                                                                FAILOVER_MODE = MANUAL, 
                                                                                                AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT , 
                                                                                                BACKUP_PRIORITY = 50, 
                                                                                                SECONDARY_ROLE(ALLOW_CONNECTIONS = READ_ONLY ));
                                                                                                GO"
                                }
                                
                                 $sqlquery2 =   "ALTER AVAILABILITY GROUP [$AGGroupName]
                                                                                ADD LISTENER N'$ListernerName' (
                                                                                WITH IP
                                                                                ((N'$IpAddress', N'$Subnet')
                                                                                ), PORT=$ListenerPort)"

                                $sqlquery3 = "ALTER AVAILABILITY GROUP $AGGroupName JOIN"

                          

                                               
                                try
                                {
                                   # $scope = New-Object -TypeName System.Transactions.TransactionScope
                                
                                    LogActivity "Creating Availability Group"                                                                                                                               
                                    Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery1 -QueryTimeout 200 -ea 'Stop' 
                                     LogActivity "Creating Availability group $AGGroupname:SUCCESS"
                                     LogActivity "Added databases $Dblist to Availability group  $AGGroupname"
                                    Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery2 -QueryTimeout 200 -ea 'Stop' 
         
                                    Invoke-Sqlcmd -ServerInstance $SecondaryReplica1 -Query $sqlquery3 -QueryTimeout 200 -ea 'Stop' 

                                    $dblists = $DatabaseList.split(",")
                                    foreach ($db in $dblists)
                                    {
                                   
                                               # $dbbkpath = "$BackupPath\$db$dt.bak"
                   
                                                 # Backup my database and its log on the primary
                                                # invoke-sqlcmd -query "backup log $db to disk ='$dbbkpath'" -ServerInstance $PrimaryReplica -QueryTimeout 120

                
                                                 # Restore the database and log on the 1st secondary (using NO RECOVERY)
                                                 #invoke-sqlcmd -query "restore log $db from disk = '$dbbkpath' with norecovery,replace" -ServerInstance $SecondaryReplica -QueryTimeout 120
            
                                   
                                        $sqlquery5 = "ALTER DATABASE $db SET HADR AVAILABILITY GROUP =  $AGGroupName "

                                        Invoke-Sqlcmd -ServerInstance $SecondaryReplica1 -Query $sqlquery5 -QueryTimeout 200 -ea 'Stop'

                                    }

                                   # $scope.Complete()
                                    LogActivity "SQL Server always on has been enabled on server $PrimaryReplica1 " #and following database have been enrolled for AlwaysOn - " + $DatabaseList 
                                    LogActivity "SQL IQOQ verification PASSSED"
                                    Return $true
                                }
                                catch
                                {
                                    Logactivity $_.exception.message
                                    
                                    # Disable Always-On for Primary and Secondary replica - If there is an AG on the server this step will disable the AG in the entire server
                                    #DisableAlwayOn $PrimaryReplica
                                    #DisableAlwayOn $SecondaryReplica
                                    $sqlquery4 = "DROP AVAILABILITY GROUP [$AGGroupName]"
                                    
                                    LogActivity "Dropping Availability Group $AgGroupname "                                                                                                                               
                                    Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery4 -QueryTimeout 200 -ea 'Stop' 
                                   
                                    LogActivity "Error Creating Availability Group"
                                    LogActivity "FINAL STATUS = FAILURE"
                                    LogActivity "SQL IQOQ verification FAILED. Return code is 1"
                                    LogActivity "All the changes have been rolled back.Please review the verification steps and address the failed step"
                                    Return $false
                                    break
                                }
                                finally
                                {
                                   # $scope.Dispose()
                                }

}

$ReturnStatus = CofigureAG


