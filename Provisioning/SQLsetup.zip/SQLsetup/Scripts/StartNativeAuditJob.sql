USE MSDB
GO
WAITFOR DELAY '000:00:20'
EXEC dbo.sp_start_job N'ExecuteSecurityAuditTrace'