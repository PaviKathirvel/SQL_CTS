#################################################################################################################################################################
# File                           : sddc_sql_Patch.ps1
# Description                    : This script will perform the SP/hotfix installation. This Script is No longer used for SQL 2016 and Above
# Logs                           : Default path C:\SQLInstall_Logs\<Hostname>_AUTOMATION_TASK300_VRO.log
# Example                        : sddc_sql_Patch.ps1 <SQLVersion> <InstanceName> <BuildNumberRequired> <Exec_Seq>
#################################################################################################################################################################
#Version		Date			Author				Reason for Change
#################################################################################################################################################################
#1.0			28-Apr-2017		Jayasimha Sangam          	New Script
#2.0			22-Feb-2018		Bruno Campos			Updated exit code from 1 to 0 if expected build number matches the current build number	
#3.0 			16-Jan-2020	 	Sanjiv					SQL 2016 New Logic 
#4.0			15-Sept-2020	Sanjiv					SQL 2017 New Logic 
#4.1 			8-Jun-2021		Mohan					Blackout Module Change/ Excluding MSDB and Model DB Cold Backup
#5.0			25-Sept-2021	Sanjiv					SQL 2019 New Logic 
#################################################################################################################################################################
#Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force #Bypass Group PolicyError# commeted as it throws GP error during exec --Sanjiv #
$SQLVer2 = $args[0]
$InstName2 = $args[1]
[int]$requestedBuild2 = $args[2]
$Execution = $args[3]
$Scriptver="5.0"
$Hostname = Hostname
###############################
#Protection for Testing
#IF (($Hostname -ne "ITSUSABWSD00166") -and ($Hostname -ne "ITSUSABWSI00050") -and ($Hostname -ne "ITSUSABWSQ00138") -and ($Hostname -ne "ITSUSABWSQ00139") -and ($Hostname -ne "ITSUSABWSD00148") -and ($Hostname -ne "ITSUSABWSD00163") -and ($Hostname -ne "ITSUSABWSQ00109"))
#{
#Write-Host $Hostname
#Write-Host "Not Authorized"
#EXIT 1
#}
###############################
IF (($InstName2 -eq $null) -or ($SQLVer2 -eq $null) -or ($requestedBuild2 -eq $null) -or ($Execution -eq $null))
{
Write-host ""
Write-Host "Pass a valid SQLServer version as 1st parameter, a valid instance name as 2nd parameter and the required build number as 3rd parameter" -f red
Write-host ""
EXIT 1
}


if((Test-Path C:\SQLInstall_Logs) -eq 0)
{
mkdir "C:\SQLInstall_Logs\"
}

$Time = get-date -Uformat "%Y%m%d%H%M"
#$Log2 = "C:\SQLInstall_Logs\$Hostname_AUTOMATION_TASK200_VRO.log"

$NA_SQLDML= '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML' #NA DML
$EMEA_SQLDML = '\\itsbebevsnap01.jnj.com\msqldml'
$ASPAC_SQLDML = '\\itssgsgsdsnap01.jnj.com\msqldml'
$LA_SQLDML = '\\itsbrsjvsnap01.jnj.com\msqldml'
echo $NA_SQLDML
#****************** Identify server location based on IP address *****************
 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]

	IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
	 {
	   IF ($IpPartsIdentifier2 -eq 0) 

 	    { 
		$ServerLocation	= "LAB"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 	    { 
		$ServerLocation	= "NA"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 	    {
		$ServerLocation	= "LA"	
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 	    {
		$ServerLocation	= "EMEA"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 	    {
		$ServerLocation	= "ASPAC"
 	    }
	   ELSE 
 	    {
		Write-Host "Server location is unknown, exiting now.."
		Exit 1
 	    }

	 }

#******************************* END of identifying server location ********************************************
#echo $serverlocation
write-host $serverlocation

Write-Host "###############################################################################"
#"###############################################################################" > $Log2
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: sddc_sql_PreChecks.ps1"
    #"Script Name: sddc_sql_PreChecks.ps1" >> $Log2
    Write-Host "Script Version: $Scriptver"
   # "Script Version: $Scriptver" >> $Log2
    Write-Host "Executed On: $Exec_Time"
    #"Execute On: $Exec_Time" >> $Log2
    Write-Host "Server Host: $Hostname"
   # "Server Host: $Hostname" >> $Log2
   # "Execution parameters: $SQLVer2 $InstName2 $requestedBuild2" >> $Log2

Write-Host "###############################################################################"
#"###############################################################################" >> $Log2

#$FileDetails = Import-Csv "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSDevelopment\PatchOrchestration\PatchVersions.txt"
$FileDetails = Import-Csv "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSDevelopment\PatchOrchestration\PatchVersions.txt"



$SQLValues = $FileDetails | select Region,SQLversion,SPbuildNumber | Where-Object {$_.SQLversion -eq $SQLVer2 -and ($_.Region -eq $ServerLocation)}

IF ($SQLValues -eq $null)

{
  Write-Host "SQLVersion $SQLVer2 is not supported"
  EXIT 1
}

#------------------------ Check instance name is valid for the SQLVersion passed as parameter ------------------------

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
#Write-Host "instances installed are : $instances"
IF ($instances -notcontains $InstName2)
{
Write-Host ""
Write-Host "Instance $InstName2 not found. Pass a valid instance name" -f red
Write-Host ""
Exit 1
}

   $p2= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName2
write-host "p2" $p2
   $ver2 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").Version
write-host "ver2" $ver2
   $pver2 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p2\Setup").PatchLevel
write-host "pver2" $pver2
   $build2 = $ver2.substring(0,2)

write-host "build2" $build2
   [int]$intVer = $ver2.replace('.','')
   [int]$patchintVer = $pver2.replace('.','')   

      # Write-Host "Ver no. is $ver2"
      # Write-Host "Ver with decimal removed is $intver"
      # Write-Host "Patch Ver no. is $pver2"
      # Write-Host "Patch Ver with decimal removed is $patchintver"


If(($build2 -eq "15") -and ($SQLVer2 -ne "2019"))
{

   write-Host ""
   write-Host "Instance $InstaName2 doesn't belong to $SQLVer2.Check again and pass correct parameters."
   write-Host ""
   EXIT 1

}	  
If(($build2 -eq "14") -and ($SQLVer2 -ne "2017"))
{

   write-Host ""
   write-Host "Instance $InstaName2 doesn't belong to $SQLVer2.Check again and pass correct parameters."
   write-Host ""
   EXIT 1

}

If(($build2 -eq "13") -and ($SQLVer2 -ne "2016"))
{

   write-Host ""
   write-Host "Instance $InstaName2 doesn't belong to $SQLVer2.Check again and pass correct parameters."
   write-Host ""
   EXIT 1

}

If(($build2 -eq "12") -and ($SQLVer2 -ne "2014"))
{

   write-Host ""
   write-Host "Instance $InstaName2 doesn't belong to $SQLVer2.Check again and pass correct parameters."
   write-Host ""
   EXIT 1

}

If (($build2 -eq "11") -and ($SQLVer2 -ne "2012"))
{
   Write-Host ""
   Write-host "Instance $InstName2 doesn't belong to $SQLVer2. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}

If (($build2 -eq "10") -and ($SQLVer2 -ne "2008"))
{
   Write-Host ""
   Write-host "Instance $InstName2 doesn't belong to $SQLVer2. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
} 

$BuildNum = $pver2.Split('.')
[int] $FourDigitBuildNum2 = $BuildNum[2]
write-host "buildnumber $FourDigitBuildNum2"
$BuildNumber = $ver2.Split('.')
$FourDigitBuildNumber = $BuildNumber[2]
write-host "buildnumber $FourDigitBuildNumber"

Write-Host ""
Write-Host "Current build number of the instance is : $FourDigitBuildNum2"
Write-Host "Requested build number of the instance is : $requestedBuild2"
Write-Host ""

#"" >> $Log2
#"Current build number of the instance is : $FourDigitBuildNum2" >> $Log2
#"Requested build number of the instance is : $requestedBuild2" >> $Log2
#"" >> $Log2

#----------------------- Backout Script ----------------------------#
<# $Blackout_StartTime = get-date (get-date).AddMinutes(1) -format "MM/dd/yyyy HH:mm:ss"
$Blackout_EndTime = get-date (get-date).AddHours(2) -format "MM/dd/yyyy HH:mm:ss"
$Blackout_Hostname = Hostname
$Blackout_Exec = "\\itsusrawsp03355\Blackout_Prod\bin\blackout.bat $Blackout_Hostname cmdb_ci_win_server $Blackout_StartTime $Blackout_EndTime Change ""Blackout Windows created for patching through Automation"" N"
Write-Host "Blackout Window"
Write-Host $Blackout_Exec

& \\itsusrawsp03355\Blackout_Prod\bin\blackout.bat $Blackout_Hostname cmdb_ci_win_server "$Blackout_StartTime" "$Blackout_EndTime" Change "Blackout Windows created for patching through Automation" N
 #>
$Winversion = (Get-CimInstance Win32_OperatingSystem).version
If ($Winversion -lt '7.0.0') 
{
$TZName =  (Get-WmiObject win32_timezone).StandardName 
} 
Else 
{ 
$TZName = Get-Timezone
$TZName=$TZName.id
}
$Blackout_StartTime =get-date (get-date).AddMinutes(1) -format "yyyy-MM-dd HH:mm"
$CIName= Hostname
Invoke-WebRequest -URI "http://itsusrawsp03271/Blackout/wsManageBlackout.asmx/CreateBlackout?strTzName=$TZName&stDtTm=$Blackout_StartTime&intDurH=2&intDurM=10&strComments=Automation&strJustification=Automation_change&strCIName=$CIName&strClassName=cmdb_ci_win_server" -UseDefaultCredentials -UseBasicParsing
Write-Host "Delay of 2 Minutes for Blackout Window"
Start-Sleep -s 120
#-------------------------------------------------------------------#


#------------------------ Get SPBuildNumber and PatchBuildNumber for the requested SQLVer and build from the remote text file  ------------------------
IF($Execution -eq "Build_1")
{
#$PatchValues = $FileDetails | SELECT Region,SQLversion,servicepack,SPbuildNumber,PatchbuildNumber,SPPath,PatchPath | Where-Object {$_.SQLversion -eq $SQLVer2 -and ($_.Region -eq $ServerLocation) -and [int]($_.SPbuildNumber) -eq $requestedBuild2}
$PatchValues = $FileDetails | SELECT Region,SQLversion,servicepack,SPbuildNumber,PatchbuildNumber,SPPath,PatchPath | Where-Object {$_.SQLversion -eq $SQLVer2 -and ($_.Region -eq $ServerLocation) -and [int]($_.PatchbuildNumber) -eq $requestedBuild2}
IF ($PatchValues -eq $null)

{
  Write-Host ""
  Write-Host "Build version $requestedBuild2 is not applicable for $SQLVer2 OR Pass the correct value to the 4th parameter
(Build_1 for ServicePack) and 
(Build_2 for Hotfix) "
  Write-Host ""

#"" >> $Log2
#"Build version $requestedBuild2 is not applicable for $SQLVer2 OR Pass the correct value to the 4th parameter(Build_1 for ServicePack) and (Build_2 for Hotfix)
#" >> $Log2
# "" >> $Log2
  EXIT 1
}
ELSE
{

  [int]$CurrentSPVer2 = $BuildNum[1]
  [int]$SPBuildNum2 = $PatchValues.SPbuildNumber
  [int]$PBuildNum2 = $PatchValues.PatchbuildNumber
  $RequestedSP = $PatchValues.servicepack
  $SPFolder2 = $PatchValues.SPPath


  IF ($PBuildNum2 -ne 0)
   {
     $PFolder2 = $PatchValues.PatchPath
   }
  ELSE
   {
     $PFolder2 = "EMPTY"
   }

  Write-Host ""
  Write-Host "Current SP version of the instance is SP$CurrentSPVer2"
  Write-Host ""


  Write-Host "SP path is $SPFolder2"
  Write-Host "Patch path is $PFolder2"
  Write-Host ""

  #"" >> $Log2
  #"Current SP version of the instance is SP$CurrentSPVer2" >> $Log2
  #"" >> $Log2

 # "SP path is $SPFolder2" >> $Log2
  #"Patch path is $PFolder2" >> $Log2
  #"" >> $Log2
}

IF (($FourDigitBuildNum2 -eq $requestedBuild2) -or ($FourDigitBuildNum2 -gt $requestedBuild2))
 {
  Write-Host ""
  Write-Host "No need to patch, build version is already at requested/higher level."
  Write-Host ""
  Write-Host "###############################################################################"

  #"" >> $Log2
  #"No need to patch, build version is already at requested/higher level." >> $Log2
  #"" >> $Log2
  #"###############################################################################" >> $Log2
  EXIT 0
 }
}
IF($Execution -eq "Build_2")
{

$BuildNumber = $ver2.Split('.')
$FourDigitBuildNumber = $BuildNumber[2]

$PatchValues = $FileDetails | SELECT Region,SQLversion,servicepack,SPbuildNumber,PatchbuildNumber,SPPath,PatchPath | Where-Object {$_.SQLversion -eq $SQLVer2 -and ($_.Region -eq $ServerLocation) -and [int]($_.PatchbuildNumber) -eq $requestedBuild2}

IF ($PatchValues -eq $null)

{
  Write-Host ""
  Write-Host "Build version $requestedBuild2 is not applicable for $SQLVer2.Or Please apply appropriate Service Pack first for $RequestedBuild2 and then proceed further with HotFix "
  Write-Host ""

  #"" >> $Log2
  #"Failed:Build version $requestedBuild2 is not applicable for $SQLVer2.Check if appropriate Service Pack is applied for $RequestedBuild2." >> $Log2
  #"" >> $Log2
  EXIT 1
}

ELSEIF ((($PatchValues.SPbuildNumber -ne $FourDigitBuildNumber)-and ($PatchValues.PatchbuildNumber -eq $requestedBuild2)) -or ($FourDigitBuildNumber -lt $PatchValues.SPbuildNumber ) )
{  

write-Host " "
write-Host "Build version $requestedBuild2 is not applicable for $FourDigitBuildNumber"
write-Host "Please apply appropriate Service Pack first for $RequestedBuild2 and then proceed further with HotFix"
write-Host " "
#" ">>$Log2 
#"Build version $requestedBuild2 is not applicable for $FourDigitBuildNumber.Please apply appropriate Service Pack first for $RequestedBuild2 and then proceed further with HotFix!">>$Log2
EXIT 1

}

ELSE
{

  [int]$CurrentSPVer2 = $BuildNum[1]
  [int]$SPBuildNum2 = $PatchValues.SPbuildNumber
  [int]$PBuildNum2 = $PatchValues.PatchbuildNumber
  $RequestedSP = $PatchValues.servicepack
  $SPFolder2 = $PatchValues.SPPath


  IF ($PBuildNum2 -ne 0)
   {
     $PFolder2 = $PatchValues.PatchPath
   }
  ELSE
   {
     $PFolder2 = "EMPTY"
   }

  Write-Host ""
  Write-Host "Current SP version of the instance is SP$CurrentSPVer2"
  Write-Host ""


  Write-Host "SP path is $SPFolder2"
  Write-Host "Patch path is $PFolder2"
  Write-Host ""

  #"" >> $Log2
  #"Current SP version of the instance is SP$CurrentSPVer2" >> $Log2
  #"" >> $Log2

  #"SP path is $SPFolder2" >> $Log2
  #"Patch path is $PFolder2" >> $Log2
  #"" >> $Log2
}

IF (($FourDigitBuildNum2 -eq $requestedBuild2) -or ($FourDigitBuildNum2 -gt $requestedBuild2))
 {
  Write-Host ""
  Write-Host "No need to patch, build version is already at requested/higher level."
  Write-Host ""
  Write-Host "###############################################################################"

  #"" >> $Log2
  #"No need to patch, build version is already at requested/higher level." >> $Log2
  #"" >> $Log2
 # "###############################################################################" >> $Log2
  EXIT 0
 }

}
#-------------------------------------- Verify SQL Patch install -----------------------------------------

Function verifySQLInstall
{
Param(
	[string] $sqlver3,
  	[string] $iName3
     )

    $Time = get-date -Uformat "%Y%m%d%H%M"
    #$Log3 = "C:\SQLPatching_Output\Patch_Installation_Verification_$Time.txt"
    #$Log4 = "C:\SQLPatching_Output\Patch_Installation_Reboot_Required_$Time.txt"


IF ($sqlver3 -eq "2019")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\150\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\150\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "150"
	$sqlFolder = "MSSQL15"
}	

ELSEIF ($sqlver3 -eq "2017")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "140"
	$sqlFolder = "MSSQL14"
}	

ELSEIF ($sqlver3 -eq "2016")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "130"
	$sqlFolder = "MSSQL13"
}	

ELSEIF ($sqlver3 -eq "2014")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "120"
	$sqlFolder = "MSSQL12"
}

ELSEIF ($sqlver3 -eq "2012")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "110"
	$sqlFolder = "MSSQL11"
}
ELSEIF ($sqlver3 -eq "2008")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\100\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "100"
	$sqlFolder = "MSSQL10"
}
ELSEIF($sqlver3 -eq "2005")
{
	$LatestFolder = gci "C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\Log" | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
	# Write-Host "Latest folder is $LatestFolder"
    	$Path = 'C:\Program Files\Microsoft SQL Server\90\Setup Bootstrap\Log\' + $LatestFolder
	$vFolder = "90"
	$sqlFolder = "MSSQL9"

}

	$SummaryFile = Get-ChildItem $Path -Filter "Summary_*.txt"

	$ResultFile = $Path + "\" + $SummaryFile
	$exitmsg = (Get-Content $ResultFile)[2].Trim()

	If ($exitmsg -eq "Exit code (Decimal):           -2067919934")
	{
    	  Write-Host ""
    	  Write-Host "A Computer restart is required. SP/Hotfix installation of $sqlver3 instance $iName3 : " -f white -nonewline; Write-Host "FAILED" -f red
    	  Write-Host ""
    	  #"" >> $Log3
    	  #"A Computer restart is required. Installation of $sqlver3 instance $iName3 : FAILED" >> $Log3

	  EXIT 1
	}

    $file_txt = "C:\Program Files\Microsoft SQL Server\$vFolder\Setup Bootstrap\Log\Summary.txt"
    $s1 = (Get-Content $file_txt)[1]
    $s2 = (Get-Content $file_txt)[3]
    $s3 = (Get-Content $file_txt)[4]
    $s4 = (Get-Content $file_txt)[2].Trim()

	# Condition added to check the summary.txt file creation time --->Sanjiv - 4th Feb 2019 # 
	###################################################################################################
	$lastWrite = (get-item $file_txt).LastWriteTime
	$timespan = new-timespan -Hours 12 

	if (((get-date) - $lastWrite) -gt $timespan) 
	{
	#Older File Found 
    Write-Host "Summary File dosent Exist  SP/Hotfix installation of $sqlver3 instance $iName3 : " -f white -nonewline; Write-Host "FAILED" -f red
	Exit 1 
	} 
	else 
	{
    # New File Created 
	Write-Host "Summary File Generated " -f white -nonewline; Write-Host "Success" -f red
	}
	#####################################################################################################
	
	
    #$exitcode = "  Final result:                  Passed"
    $exitPass  = "Exit code (Decimal):           0"
    $exitPassReboot  = "Exit code (Decimal):           3010"


    ################External Files##########################
    Write-host ""
    Write-Host "#######################################################################"
   # "#######################################################################" > $Log3
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: $ScriptName"
    #"Script Name: $ScriptName" >> $Log3
    Write-Host "Script Version: $Scriptver"
    #"Script Version: $Scriptver" >> $Log3
    Write-Host "Executed On: $Exec_Time"
    #"Execute On: $Exec_Time" >> $Log3
    Write-Host "Server Host: $Hostname"
    #"Server Host: $Hostname" >> $Log3
    #"Execution parameters: $sqlver3 $iName3" >> $Log3


    Write-Host "#######################################################################"
    #"#######################################################################" >> $Log3


    if ($s4 -eq $exitPass)  
    {
    	Write-Host ""
    	Write-Host "Patching of $sqlver3 instance $iName3 : " -f white -nonewline; Write-Host "SUCCESSFUL,but reboot the server before proceeding to next step" -f red
    	Write-Host ""
    	#"" >> $Log3
    	#"Patching of $sqlver3 instance $iName3 : SUCCESSFUL,but reboot the server before proceeding to next step " >> $Log3
        #"Reboot Required!!Patching of $sqlver3 instance $iName3 : SUCCESSFUL,but reboot the server before proceeding to next step" >>$Log4
    }
    ELSEIF ($s4 -eq $exitPassReboot)
    {
    	Write-Host ""
    	Write-Host "Patching of $sqlver3 instance $iName3 : " -f white -nonewline; Write-Host "SUCCESSFUL, but reboot the server before proceeding to next step" -f red
    	Write-Host ""
    	#"" >> $Log3
    	#"SUCCESSFUL, but reboot the server before proceeding to next step" >> $Log3
	   # "Reboot Required!!Patching of $sqlver3 instance $iName3 : SUCCESSFUL,but reboot the server before proceeding to next step" >>$Log5

    }
    ELSE
    {
    	Write-Host ""
    	Write-Host "Patching of $sqlver3 instance $iName3 : " -f white -nonewline; Write-Host "FAILED" -f Red
    	Write-Host ""
	[string]$ErrorMsg = Select-String -Path $file_txt -Pattern "(Exit Message)" | select line

	$pos = $ErrorMsg.IndexOf(':')
	$ErrorMsg = $ErrorMsg.Substring($pos+1)
	Write-Host $ErrorMsg.Trim() -f red

    	#"" >> $Log3
    	#"Patching of $sqlver3 instance $iName3 : FAILED" >> $Log3
	#"" >> $Log3
	#$ErrorMsg.Trim() >> $Log3

    }

        Write-Host ""
        Write-Host "------------------------ Installation Summary -------------------------"  
        Write-Host ""
        Write-Host "$s1"
        Write-Host "$s2"
        Write-Host "$s3"
        Write-Host ""

        #"" >> $Log3
        #"------------------------ Installation Summary -------------------------"  >> $Log3
        #"" >> $Log3
        #"$s1" >> $Log3
        #"$s2" >> $Log3
        #"$s3" >> $Log3

        $instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances

        # Verify SQL instances
        foreach ($inst in $instances)
        {
        $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst

	IF ($p -eq "$sqlFolder.$iName3")
	 {
           $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
           $CurrentVersion=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
           $SP=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SP
           $Language=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").Language
           $Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
           $PatchLevel=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").PatchLevel

        # Update values
         
        #"  Instance Name:  	 	 $inst" >> $Log3
        #"  CurrentVersion: 		 $CurrentVersion" >> $Log3
        #"  SP: 				 $SP" >> $Log3
        #"  Language: 			 $Language" >> $Log3
        #"  Edition: 			 $Edition" >> $Log3
        #"  PatchLevel:	 		 $PatchLevel" >> $Log3

        #"" >> $Log3
        #"Detailed log files are available inside -- $Path " >> $Log3
        #"" >> $Log3
        #"-----------------------------------------------------------------------" >> $Log3

         
        write-host "  Instance Name:  	 	" $inst
        Write-Host "  CurrentVersion: 		" $CurrentVersion
        Write-Host "  SP: 				" $SP
        Write-Host "  Language: 			" $Language
        Write-Host "  Edition: 			" $Edition
        Write-Host "  PatchLevel:	 		" $PatchLevel
        Write-Host ""
        Write-Host "Detailed log files are available inside -- $Path "
        Write-Host ""
        Write-Host "#######################################################################"
	}
      }

} 

#*************************** End of Verify SQL Patch Install Function ***************************


#-------------------------------------------------------- PatchSQLServer ------------------------------------------------------------

Function PatchSQLInstance
{
Param(
	[string] $SPpath,
	[string] $HFpath,
	[string] $sqlversion,
  	[string] $iName
     )
IF($Execution -eq "Build_1")
{

IF ($sqlversion -eq "2016")
{
	<#IF ($SPpath -ne "EMPTY")
	 {
	     #$SPpath1 = $SPpath +"SQLServer2016SP2-KB4052908-x64-ENU.exe"
             Write-Host ""
             Write-Host $SPpath /InstanceID=$iName /quiet /IAcceptSQLServerLicenseTerms="true" /Action=Patch 
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /InstanceID=$iName /quiet /IAcceptSQLServerLicenseTerms="true" /Action=Patch | Out-Null
	 }#>
	IF ($SPpath -ne "EMPTY")
	 {
echo $SPpath
echo $iname

	     
             Write-Host ""
             Write-Host $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
	 }
}

ELSEIF ($sqlversion -eq "2017")
{
	IF ($SPpath -ne "EMPTY")
	 {
	     
             Write-Host ""
             Write-Host $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
	 }
}

ELSEIF ($sqlversion -eq "2019")
{
	IF ($SPpath -ne "EMPTY")
	 {
	     
             Write-Host ""
             Write-Host $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
	 }
}


ELSEIF ($sqlversion -eq "2014")
{
	IF ($SPpath -ne "EMPTY")
	 {
	     
             Write-Host ""
             Write-Host $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
	 }
}

ELSEIF ($sqlversion -eq "2012")

{
        IF ($SPpath -ne "EMPTY")
	 {
	     
             Write-Host ""
             Write-Host $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName
             Write-Host ""
             Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""

            & $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
	 }
}
ELSEIF ($sqlversion -eq "2008")

{

        IF ($SPpath -ne "EMPTY")
	 {
            Write-Host ""
            Write-Host $SPpath /quiet /ACTION=Patch /INSTANCENAME=$iName
            Write-Host ""
            Write-Host "Installing $RequestedSP ($SPBuildNum2) on $sqlversion instance $iName. Please wait..."
            Write-Host ""

            & $SPpath /quiet /ACTION=Patch /INSTANCENAME=$iName | Out-Null
	 }
}

}

IF($Execution -eq "Build_2")

{

IF($sqlversion -eq "2016")
{
        IF ($HFpath -ne "EMPTY")

	 {
             Write-Host ""
	     Write-Host $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
             Write-Host ""
             Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""
             
            & $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null

	 }

}

ELSEIF($sqlversion -eq "2017")
{
        IF ($HFpath -ne "EMPTY")

	 {
             Write-Host ""
	     Write-Host $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
             Write-Host ""
             Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""
             
            & $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null

	 }

}


ELSEIF($sqlversion -eq "2019")
{
        IF ($HFpath -ne "EMPTY")

	 {
             Write-Host ""
	     Write-Host $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
             Write-Host ""
             Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""
             
            & $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null

	 }

}


ELSEIF($sqlversion -eq "2014")
{
        IF ($HFpath -ne "EMPTY")

	 {
             Write-Host ""
	     Write-Host $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
             Write-Host ""
             Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""
             
            & $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null

	 }

}

ELSEIF($sqlversion -eq "2012")
{
        IF ($HFpath -ne "EMPTY")

	 {
             Write-Host ""
	     Write-Host $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null
             Write-Host ""
             Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
             Write-Host ""
             
            & $HFpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=$iName | Out-Null

	 }

}

ELSEIF ($sqlversion -eq "2008")

{ 
        IF ($HFpath -ne "EMPTY")

	{
            Write-Host ""
            Write-Host $HFpath /quiet /ACTION=Patch /INSTANCENAME=$iName | Out-Null
            Write-Host ""
            Write-Host "Applying security hotfix ($PBuildNum2) on $sqlversion instance $iName. Please wait..."
            Write-Host ""

           & $HFpath /quiet /ACTION=Patch /INSTANCENAME=$iName | Out-Null
	}

}

ELSE
{
EXIT 1
}

}
	        
	Write-Host ""
    	WRITE-HOST "Patch installation completed..."
	Write-Host ""

        VerifySQLInstall $sqlversion $iName

}


#--------------------------------------------------------------------------------------------------

$OSArch = (gwmi Win32_ComputerSystem).SystemType

 If ($OSArch -eq "x64-based PC")
 {
  
  $SPFile = Get-ChildItem $SPFolder2 -Filter "*x64*.exe" 
  $Regional_SP =  $SPFolder2 + "\$SPFile"
  
  
  IF ($PFolder2 -ne "EMPTY")
   {
     $PFile = Get-ChildItem $PFolder2 -Filter "*x64*.exe" 
     $Regional_SecurityHF = $PFolder2 + "\$PFile"
   }
  ELSE
   {
     $Regional_SecurityHF = "EMPTY"
   }

 }
 else
 {
  $SPFile = Get-ChildItem $SPFolder2 -Filter "*x86.exe" 
  $Regional_SP =  $SPFolder2 + "\$SPFile"

    IF ($PFolder2 -ne "EMPTY")
     {
       $PFile = Get-ChildItem $PFolder2 -Filter "*x86.exe" 
       $Regional_SecurityHF = $PFolder2 + "\$PFile"
     }
    ELSE
     {
       $Regional_SecurityHF = "EMPTY"
     }

 }


#--------------------------------- COLD BACKUP of SYSTEM DATABASES -------------------------------------

Function BackupDBs
{
Param(
	[string] $sqlver3,
  	[string] $iName3
     )

    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended') | Out-Null
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SQLWMIManagement') | Out-Null

    $Time2 = get-date -Uformat "%Y%m%d%H%M"
<#
if (Test-Path "C:\SQLInstall_Logs\'$Hostname'_BACKUPCHECK_TASK200_VRO.log") {
 Clear-Content "C:\SQLInstall_Logs\'$Hostname'_BACKUPCHECK_TASK200_VRO.log"
}
#>
    #Clear-Content "C:\SQLInstall_Logs\'$Hostname'_BACKUPCHECK_TASK200_VRO.log"
    #$Log_Bkp = "C:\SQLInstall_Logs\'$Hostname'_BACKUPCHECK_TASK200_VRO.log"


#--------- First backup System DBs (master, Model, MSDB, SystemResource) ------------

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName3
$BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
$SQLDataDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").SQLDataRoot

$SysBkp = $BackupDir + "\"
$SysBkpFolder = $SysBkp + "SystemDBBackupBeforeSP"


IF ($iName3 -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $iName3
 $SQLAgtAcct = 'SQLAgent$' + $iName3
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}

$error.clear()

if ($error[0])
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host "Cold backup of System DBs failed. Cannot proceed with patching. Exiting..." -f red
	#"Stop SQL Server Services $SQLSvcAcct : FAILED" >> $Log_Bkp
	#"Cold backup of System DBs failed. Cannot proceed with patching. Exiting..."  >> $Log_Bkp
	EXIT 1
}
ELSE
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Success" -f green
	#"Stop SQL Server Service $SQLSvcAcct : Success" >> $Log_Bkp
	
	$ArchiveFolder = $SysBkp + "SystemDBBackupBeforeSP\ArchivedBeforeSP_$Time2"

	If (Test-Path $ArchiveFolder)
	{
	Remove-Item $ArchiveFolder + "SystemDBBackupBeforeSP\*" -recurse
	}

	mkdir $ArchiveFolder
}

IF ($sqlver3 -eq "2019")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL15.$iName3\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}



IF ($sqlver3 -eq "2017")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.$iName3\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}



IF ($sqlver3 -eq "2016")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL13.$iName3\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($sqlver3 -eq "2014")
{
	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.$iName3\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}

ELSEIF ($sqlver3 -eq "2012")
{

	$SQLBinDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL11.$iName3\Setup").SQLBinRoot

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

	Copy-Item $SQLBinDir\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item $SQLBinDir\mssqlsystemresource.ldf $ArchiveFolder

	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll
}
ELSEIF ($sqlver3 -eq "2008")
{

	Copy-Item $SQLDataDir\DATA\master.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\model.mdf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item $SQLDataDir\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item $SQLDataDir\DATA\MSDBLog.ldf $ArchiveFolder

}
ELSEIF ($sqlver3 -eq "2005")
{

	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\master.mdf $ArchiveFolder
	#Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\model.mdf $ArchiveFolder
	#Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	#Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\modellog.ldf $ArchiveFolder
	#Copy-Item E:\MSSQL2005\MSSQL9.$iName3\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
}

	Rename-Item $ArchiveFolder\master.mdf master.mmm
	#Rename-Item $ArchiveFolder\model.mdf model.mmm
	#Rename-Item $ArchiveFolder\MSDBData.mdf MSDBData.mmm
	Rename-Item $ArchiveFolder\mastlog.ldf mastlog.lll
	#Rename-Item $ArchiveFolder\modellog.ldf modellog.lll
	#Rename-Item $ArchiveFolder\MSDBLog.ldf MSDBLog.lll


if ($error[0])
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "FAILED" -f red
	Write-Host ""
	Write-Host "Cannot proceed further with patching. Exiting... " -f red
	#"Cold backup of system databases to $ArchiveFolder : FAILED" >> $Log_Bkp
	#"Cannot proceed further with patching. Exiting... " >> $Log_Bkp
	EXIT 1

}
ELSE
{
	Write-host ""
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Success" -f green
	#"Cold backup of system databases to $ArchiveFolder : Success" >> $Log_Bkp
}



Write-Host "-------"
#"-------" >> $Log_Bkp
$error.clear()
IF ($iName3 -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $iName3
 $SQLAgtAcct = 'SQLAgent$' + $iName3
}

 Start-Service -Name $SQLAgtAcct
 Start-Service -Name $SQLSvcAcct

if ($error[0])
{
	Write-Host ""
	#Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "FAILED" -f red -nonewline; Write-Host "Unable to proceed with patching. Try again." -f red "Start SQL Server Services : FAILED. Unable to proceed with patching. Try again." >> $Log_Bkp
	$error.clear()
	EXIT 0
}
ELSE
{
	Write-Host ""
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
	Write-Host ""
	#"Start SQL Server Services: Success" >> $Log_Bkp
}


}

#-------------------------------- PERFORM A COLD BACKUP of SYSTEM DATABASES --------------------------------

BackupDBs $SQLVer2 $InstName2

#-------------------------------- APPLY SP / HOTFIX --------------------------------
IF ((($FourDigitBuildNum2 -lt $SPBuildNum2) -and ($SPBuildNum2 -eq $requestedBuild2)) -or($FourDigitBuildNumber -lt $SPBuildNum2))
 {

  Write-Host ""
  Write-Host "Applying only the required ServicePack $RequestedSP ($SPBuildNum2)."
  Write-Host ""

  "" >> $Log2
  "Applying only the required ServicePack $RequestedSP ($SPBuildNum2)" >> $Log2
  "" >> $Log2

  PatchSQLInstance $Regional_SP "EMPTY" $SQLVer2 $InstName2

 }
ELSEIF(($PBuildNum2 -eq $requestedBuild2) -and ($FourDigitBuildNumber -eq $SPBuildNum2))
{

  Write-Host ""
  Write-Host "Applying patch with requested security hotfix $PBuildNum2."
  Write-Host ""

  "" >> $Log2
  "Applying patch with requested security hotfix $PBuildNum2." >> $Log2
  "" >> $Log2

  PatchSQLInstance "EMPTY" $Regional_SecurityHF $SQLVer2 $InstName2

}

ELSEIF ($FourDigitBuildNum2 -lt $SPBuildNum2)

 {

  Write-Host ""
  Write-Host "Applying ServicePack $RequestedSP ($SPBuildNum2) and then to patch with $PBuildNum2."
  Write-Host ""

  "" >> $Log2
  "Applying ServicePack $RequestedSP ($SPBuildNum2) and then to patch with $PBuildNum2." >> $Log2
  "" >> $Log2

  PatchSQLInstance $Regional_SP "EMPTY" $SQLVer2 $InstName2

 }

ELSEIF (($FourDigitBuildNum2 -eq $SPBuildNum2) -or ($FourDigitBuildNumber -eq $SPBuildNum2))

 {

  Write-Host ""
  Write-Host "Applying patch with requested security hotfix $PBuildNum2."
  Write-Host ""

  "" >> $Log2
  "Applying patch with requested security hotfix $PBuildNum2." >> $Log2
  "" >> $Log2

  PatchSQLInstance "EMPTY" $Regional_SecurityHF $SQLVer2 $InstName2

 }

ELSEIF (($FourDigitBuildNum2 -gt $SPBuildNum2) -and ($FourDigitBuildNum2 -lt $PBuildNum2))

 {

  Write-Host ""
  Write-Host "Applying patch with requested security hotfix $PBuildNum2."
  Write-Host ""

  "" >> $Log2
  "Applying patch with requested security hotfix $PBuildNum2." >> $Log2
  "" >> $Log2


  PatchSQLInstance "EMPTY" $Regional_SecurityHF $SQLVer2 $InstName2

 }

function get_PostCheckSummary
{

Param(
	[string] $InstName1
     )

$Time = get-date -Uformat "%Y%m%d%H%M"
################External Files##########################
#$Log = "C:\SQLInstall_Logs\"$Hostname"_AUTOMATION_TASK300_VRO.log"
$BatchOutput4 = "C:\IQOQ\Status.txt"
########################################################
   $p1= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName2
   $ver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").Version
   $pver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").PatchLevel

$build1 = $ver1.substring(0,2)
$build2 = $pver1.substring(0,2)

$BuildNum3 = $ver1.Split('.')
[int] $FourDigitBuildNum3 = $BuildNum3[2]


$BuildNum4 = $pver1.Split('.')
[int] $FourDigitBuildNum4 = $BuildNum4[2]



$Final_status = 0
  [int]$CurrentSPVer = $BuildNum3[1]
  [int]$SPBuildNum1 = $PatchValues.SPbuildNumber
  [int]$PBuildNum1 = $PatchValues.PatchbuildNumber
  $RequestedSP = $PatchValues.servicepack
  $SPFolder1 = $PatchValues.SPPath
  $RequestedSPNum = $RequestedSP.Substring(2,1)
   $ver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").Version
   $pver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").PatchLevel


$Hostname = Hostname


IF ((Test-Path C:\SQLInstall_Logs) -eq 0) { mkdir "C:\SQLInstall_Logs\" }

$Time = get-date -Uformat "%Y%m%d%H%M"
$test = "C:\SQLInstall_Logs"
if (Test-Path  $test+"\"+$Hostname+"_AUTOMATION_TASK300_VRO.log") 
{
 Clear-Content  $test+"\"+$Hostname+"_AUTOMATION_TASK300_VRO.log"
}

$Log5 =  $test+"\"+$Hostname+"_AUTOMATION_TASK300_VRO.log"

  #Write-Host "Requested number of Service pack is SP$RequestedSPNum" 
  "">>$Log5
  "######################################################################################" >>$Log5
  #Write-Host ""
  #Write-Host "Current SP version of the instance is SP$CurrentSPVer"
  #Write-Host ""

  "" >> $Log5
  #"Current SP version of the instance is SP$CurrentSPVer" >> $Log5
  "" >> $Log5

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')


IF ($InstName1 -eq "MSSQLSERVER")
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Final_Status_Error = 0
}
ELSE
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name + "\" + $InstName1
$Final_Status_Error = 0
}

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$Inst_Name

Write-Host "--------------------------------- IQOQ verification results ---------------------------------"
#"--------------------------------- IQOQ verification results ---------------------------------" >> $Log5

$conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
$conn.Open()

#--------------------------------- Checking SQL Server build version --------------------------------#
Write-Host "-------"
#"-------" >> $Log5

    IF($Execution -eq "Build_1")
{


       IF ( $FourDigitBuildNum3 -eq $requestedBuild2)
        {
	  Write-Host "Expected value for $sqlver3 version installed : $ver1"
	  Write-Host "Current value of $sqlver3 version installed : $ver1"
	  Write-Host "$sqlver3 version $ver1 installation: " -f white -nonewline; Write-Host "Success" -f green
          Write-Host ""
          Write-Host "EXIT CODE 0"
      		Get-ChildItem -Path $Log5 -file *log*  | Remove-Item -recurse
	  #"Starting to patch '$Hostname'" >>$Log5
	
	  "######################################################################################" >>$Log5
	  "" >> $Log5
	  #"Current Value : $build1.$RequestedSPNum.$requestedBuild2.0" >> $Log5
	   "Current Value : $requestedBuild2" >> $Log5
	   "" >> $Log5
	  #"Expected value : $build1.$RequestedSPNum.$requestedBuild2.0" >> $Log5
	  "Expected value : $requestedBuild2" >> $Log5
	   "" >> $Log5
	 "######################################################################################" >>$Log5
	 "" >> $Log5
	"Patching of server '$Hostname'.jnj.com completed successfully">> $Log5
	"Reboot Required!!Patching of $SQLVer2 instance $iName3 : SUCCESSFUL,but reboot the server before proceeding to next step" >>$Log5
	   "" >> $Log5
	 "######################################################################################" >>$Log5
	IF ($InstName1 -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstName1
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{
		Write-Host "Patching was completed and SQL Server is online."
		"" >> $Log5
		"Patching was completed and SQL Server is online." >> $Log5
		"" >> $Log5
		"######################################################################################" >> $Log5
		}
	if ($arrService.Status -eq "Stopped")
		{ 
		Write-Host "ATTENTION: Patching was completed but SQL Server is offline. Please check."
		"" >> $Log5
		"ATTENTION: Patching was completed but SQL Server is offline. Please check." >> $Log5
		"" >> $Log5
		"######################################################################################" >> $Log5
		}
	 # "$SQLVer2 version $ver1 installation : SUCCESS" >> $Log5
          "" >> $Log5
          "EXIT CODE 0" >> $Log5
	   EXIT 0
        }
       
}
    IF($Execution -eq "Build_2")
{
       IF ( $FourDigitBuildNum4 -eq $requestedBuild2)
        {
	$pver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").PatchLevel
	$build2 = $pver1.substring(0,2)
	$BuildNum4 = $pver1.Split('.')
	[int] $FourDigitBuildNum4 = $BuildNum4[2]		
	Write-Host "Expected Value: $requestedBuild2"
	  Write-Host "Current Value: $FourDigitBuildNum4"
	  Write-Host "Version $FourDigitBuildNum4 installation status: " -f white -nonewline; Write-Host "Success" -f green
          Write-Host ""
          Write-Host "EXIT CODE 0"
	  # "Starting to patch $Hostname" >> $Log5
	Get-ChildItem -Path $Log5 -file *log*  | Remove-Item -recurse
	  "######################################################################################" >> $Log5
	"" >> $Log5  
	"Current Value: $FourDigitBuildNum4" >> $Log5
	"" >> $Log5
	"Expected Value: $requestedBuild2" >> $Log5
	"" >> $Log5
	"######################################################################################" >> $Log5
	"" >> $Log5
	"Patching of database server $Hostname.jnj.com completed successfully" >> $Log5
	"Reboot Required!! Patching of $SQLVer2 instance $Inst_Name : SUCCESSFUL,but reboot the server before proceeding to next step" >> $Log5
	"" >> $Log5
	"######################################################################################" >> $Log5
	IF ($InstName1 -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstName1
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{
		Write-Host "Patching was completed and SQL Server is online."
		"" >> $Log5
		"Patching was completed and SQL Server is online." >> $Log5
		"" >> $Log5
		"######################################################################################" >> $Log5
		}
	if ($arrService.Status -eq "Stopped")
		{ 
		Write-Host "ATTENTION: Patching was completed but SQL Server is offline. Please check."
		"" >> $Log5
		"ATTENTION: Patching was completed but SQL Server is offline. Please check." >> $Log5
		"" >> $Log5
		"######################################################################################" >> $Log5
		}
	# "$SQLVer2 version $ver1 installation : SUCCESS" >> $Log5
        # "" >> $Log5
        # "EXIT CODE 0" >> $Log5
	EXIT 0
	}
       ELSE
        {
	$pver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").PatchLevel
	$build2 = $pver1.substring(0,2)
	$BuildNum4 = $pver1.Split('.')
	[int] $FourDigitBuildNum4 = $BuildNum4[2]		
	  Write-Host "Expected value for $sqlversion version installed : $requestedBuild2"
	  Write-Host "Current value of $sqlversion version installed : $FourDigitBuildNum4"
	  Write-Host "$sqlversion version $FourDigitBuildNum4 installation: " -f white -nonewline; Write-Host "Failed" -f red
          Write-Host ""
          Write-Host "EXIT CODE 1"
		Get-ChildItem -Path $Log5 -file *log*  | Remove-Item -recurse
	  "######################################################################################">>$Log5
	"" >> $Log5
	  "Current Value: $FourDigitBuildNum4" >> $Log5
	     "" >> $Log5
	  "Expected Value: $requestedBuild2" >> $Log5
	 "######################################################################################">>$Log5
	 "" >> $Log5
	"Patching of server $Hostname.jnj.com completed abnormally">> $Log5
	 "######################################################################################
	  ">>$Log5
	  "$sqlver3 version $build2.$RequestedSPNum.$requestedBuild2.0 installation : FAILED" >> $Log5
          # "" >> $Log5
	  # "EXIT CODE 1" >> $Log5
	   EXIT 1
        }
}
#------------------------------ CHECK IF ALL DATABASES ARE ONLINE ------------------------------------

    $SQLServer = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $Inst_Name
    foreach ($db in $SQLServer.Databases)
     {
    
        IF (!($db.IsAccessible))

           {
             Write-Host "Database $db is not accessible. Please check, exiting now.."
           }

     }
 
EXIT
#-------------------------------------------------------------------------------------------------
}

get_PostCheckSummary $InstName2
EXIT $LASTEXITCODE