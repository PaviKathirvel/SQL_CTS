#################################################################################################################################################################
# File                           : sddc_sql_PreChecks_Patch.ps1
# Description                    : This script will perform all the pre-checks required before installing SP or hotfix.This Script is No longer used for SQL 2016 and Above
# Logs                           : Default path C:\SQLInstall_Logs\<Hostname>_AUTOMATION_TASK200_VRO.log
# Example                        : sddc_sql_PreCheck_Patch.ps1 <SQLVersion> <InstanceName> <BuildNumberRequired>
#################################################################################################################################################################
#Version		Date		Author				Reason for Change
#################################################################################################################################################################
#1.0			28-Apr-2017	Jayasimha Sangam          	New Script					
#2.0			22-Feb-2018	Bruno Campos			Updated exit code from 1 to 0 if expected build number matches the current build number	
#3.0 			16-Jan-2020	 	Sanjiv					SQL 2016 New Logic 
#4.0			15-Sept-2020	Sanjiv					SQL 2017 New Logic 
#5.0			25-Aug -2021	Sanjiv					SQL 2019 New Logic 

################################################################################################################################################################
#Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force # Bypass Group PolicyError# commeted as it throws GP error during exec --Sanjiv #
$SQLVer1 = $args[0]
$InstName1 = $args[1]
[int]$requestedBuild1 = $args[2]
$Scriptver="5.0"
#$Hostname = Hostname
$Hostname = $env:computername 
<#get-variable
echo $sqlver1
echo $instname1
echo $requestedbuild1
#>
$Final_status = 0

IF (($SQLVer1 -eq $null) -or ($InstName1 -eq $null) -or ($requestedBuild1 -eq $null))
{
Write-host ""
Write-Host "Pass a valid SQLServer version as 1st parameter, a valid instance name as 2nd parameter and the required build number as 3rd parameter" -f red
Write-host ""
EXIT 1
}

  
IF ((Test-Path C:\SQLInstall_Logs) -eq 0) { mkdir "C:\SQLInstall_Logs\" }
IF ((Test-Path C:\SQLInstall_Logs\VBSCript) -eq 0) { mkdir "C:\SQLInstall_Logs\VBSCript\" }
#Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSDevelopment\PatchOrchestration\FindSQLInstalls.vbs" "C:\SQLInstall_Logs\VBSCript\"
Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\FindSQLInstalls.vbs" "C:\SQLInstall_Logs\VBSCript\"

$Time = get-date -Uformat "%Y%m%d%H%M"

$test = "C:\SQLInstall_Logs"
if (Test-Path $test+"\"+$Hostname+"_AUTOMATION_TASK200_VRO.log") {
 Clear-Content $test+"\"+$Hostname+"_AUTOMATION_TASK200_VRO.log"
}
$Log = $test+"\"+$Hostname+"_AUTOMATION_TASK200_VRO.log"

<#
if (Test-Path $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log") {
 Remove-item $Log_Bkp -filter *.log -recurse
}
#>

#****************** Identify server location based on IP address *****************
 
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1

# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2]

	IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
	 {
	   IF ($IpPartsIdentifier2 -eq 0) 

 	    { 
		$ServerLocation	= "LAB"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 	    { 
		$ServerLocation	= "NA"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 96 -and $IpPartsIdentifier2 -le 127) 
 	    {
		$ServerLocation	= "LA"	
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 	    {
		$ServerLocation	= "EMEA"
 	    }
	   ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 	    {
		$ServerLocation	= "ASPAC"
 	    }
	   ELSE 
 	    {
		Write-Host "Server location is unknown, exiting now.."
		Exit 1
 	    }

	 }

#******************************* END of identifying server location ********************************************


Write-Host "###############################################################################"
"###############################################################################" > $Log
    $Hostname = Hostname
    $Exec_Time = Get-Date
    Write-Host "Script Name: sddc_sql_PreChecks.ps1"
   # "Script Name: sddc_sql_PreChecks.ps1" >> $Log
    Write-Host "Script Version: $Scriptver"
    #"Script Version: $Scriptver" >> $Log
    Write-Host "Executed On: $Exec_Time"
    #"Execute On: $Exec_Time" >> $Log
    Write-Host "Server Host: $Hostname"
    #"Server Host: $Hostname" >> $Log
    #"Execution parameters: $SQLVer1 $InstName1 $requestedBuild1" >> $Log

Write-Host "###############################################################################"
#"###############################################################################" >> $Log


$FileDetails = Import-Csv "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSDevelopment\PatchOrchestration\PatchVersions.txt"

$SQLValues = $FileDetails | select Region,SQLversion,SPbuildNumber | Where-Object {$_.SQLversion -eq $SQLVer1 -and ($_.Region -eq $ServerLocation)}

IF ($SQLValues -eq $null)

{
  Write-Host "SQLVersion $SQLVer1 is not supported"
  EXIT 1
}

#------------------------ Check instance name is valid for the SQLVersion passed as parameter ------------------------

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
#Write-Host "instances installed are : $instances"

[int]$instCOunt = $instances.length

IF ($instCount -gt 1)
{
  Write-Host "The machine has more than 1 instance running which is against JnJ standard. Exiting.."
  Write-Host "EXIT CODE 1"

  "The machine has more than 1 instance running which is against JnJ standard. Exiting.." >> $Log
  "EXIT CODE 1" >> $Log
  "" >> $Log

  EXIT 1

} 

IF ($instances -notcontains $InstName1)
{
Write-Host ""
Write-Host "Instance $InstName1 not found. Pass a valid instance name" -f red
Write-Host ""
EXIT 1
}

   $p1= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName1

   $ver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").Version
   $pver1 = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p1\Setup").PatchLevel

   $build1 = $ver1.substring(0,2)


   [int]$intVer = $ver1.replace('.','')
   [int]$patchintVer = $pver1.replace('.','')   

      # Write-Host "Ver no. is $ver1"
      # Write-Host "Ver with decimal removed is $intver"
      # Write-Host "Patch Ver no. is $pver1"
      # Write-Host "Patch Ver with decimal removed is $patchintver"



If (($build1 -eq "15") -and ($SQLVer1 -ne "2019"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}
If (($build1 -eq "14") -and ($SQLVer1 -ne "2017"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}
If (($build1 -eq "13") -and ($SQLVer1 -ne "2016"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}

If (($build1 -eq "12") -and ($SQLVer1 -ne "2014"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}

If (($build1 -eq "11") -and ($SQLVer1 -ne "2012"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}

If (($build1 -eq "10") -and ($SQLVer1 -ne "2008"))
{
   Write-Host ""
   Write-host "Instance $InstName1 doesn't belong to $SQLVer1. Check again and pass correct parameters."
   Write-Host ""
   EXIT 1
}
$PatchValues = $FileDetails | SELECT Region,SQLversion,servicepack,SPbuildNumber,PatchbuildNumber,SPPath,PatchPath | Where-Object {$_.SQLversion -eq $SQLVer1 -and ($_.Region -eq $ServerLocation) -and ([int]($_.SPbuildNumber) -eq $requestedBuild1 -or [int]($_.PatchbuildNumber) -eq $requestedBuild1) }
$BuildNum = $pver1.Split('.')
[int] $FourDigitBuildNum1 = $BuildNum[2]
  [int]$CurrentSPVer = $BuildNum[1]
$SPBuildNum1 = $PatchValues.SPbuildNumber
  $PBuildNum1 = $PatchValues.PatchbuildNumber
  $RequestedSP = $PatchValues.servicepack
  $RequestedSPNum = $RequestedSP.Substring(2,1)
  $SPFolder1 = $PatchValues.SPPath
#[int] $FourDigitBuildNum1 = "5676"

IF ($InstName1 -eq "MSSQLSERVER")
		{
		$SQLSvcAcct = 'MSSQLSERVER'
		}
	ELSE
		{
		$SQLSvcAcct = 'MSSQL$' + $InstName1
		}
	$arrService = Get-Service -Name $SQLSvcAcct
	IF ($arrService.Status -eq "Running")
		{
		Write-Host "SQL Server is online."
		"" >> $Log
		"SQL Server is online." >> $Log
		"" >> $Log
		"######################################################################################" >> $Log
		}
	if ($arrService.Status -eq "Stopped")
		{ 
		Write-Host "ATTENTION: SQL Server is offline. Please check."
		"" >> $Log
		"ATTENTION: SQL Server is offline. Please check." >> $Log
		"" >> $Log
		"######################################################################################" >> $Log
		EXIT 1
		}

Write-Host ""
Write-Host "Current build number of the instance is : $FourDigitBuildNum1"
Write-Host "Requested build number of the instance is : $requestedBuild1"
Write-Host ""

"">> $Log
"Instance is currently patched at $FourDigitBuildNum1 and will be patched to $requestedBuild1 " >> $Log
"">> $Log
"###############################################################################" >> $Log
"">> $Log
"Patch plan for $Hostname.jnj.com has been created successfully">>$Log
"">> $Log
"######################################################################################">>$Log
"">> $Log
"Patch plan for server $Hostname.jnj.com completed successfully.">>$Log
"">> $Log
"######################################################################################">>$Log



#------------------------ Get SPBuildNumber and PatchBuildNumber for the requested SQLVer and build from the remote text file  ------------------------

$PatchValues = $FileDetails | SELECT Region,SQLversion,servicepack,SPbuildNumber,PatchbuildNumber,SPPath,PatchPath | Where-Object {$_.SQLversion -eq $SQLVer1 -and ($_.Region -eq $ServerLocation) -and ([int]($_.SPbuildNumber) -eq $requestedBuild1 -or [int]($_.PatchbuildNumber) -eq $requestedBuild1) }

IF ($PatchValues -eq $null)

{
  Write-Host ""
  Write-Host "Build version $requestedBuild1 is not applicable for $SQLVer1"
  Write-Host ""

  "" >> $Log
  "Build version $requestedBuild1 is not applicable for $SQLVer1" >> $Log
  "" >> $Log
  EXIT 1
}
ELSE
{

  [int]$CurrentSPVer = $BuildNum[1]
  $SPBuildNum1 = $PatchValues.SPbuildNumber
  $PBuildNum1 = $PatchValues.PatchbuildNumber
  $RequestedSP = $PatchValues.servicepack
  $SPFolder1 = $PatchValues.SPPath
  IF ($PBuildNum1 -ne 0)
   {
     $PFolder1 = $PatchValues.PatchPath
   }
  ELSE
   {
     $PFolder1 = "EMPTY"
   }
  Write-Host ""
  Write-Host "Current SP version of the instance is SP$CurrentSPVer"
  Write-Host ""

  # Write-Host "SP path is $SPFolder1"
  # Write-Host "Patch path is $PFolder1"
  # Write-Host ""

#  "" >> $Log
  #"Current SP version of the instance is SP$CurrentSPVer" >> $Log
#  "" >> $Log

  #"SP path is $SPFolder1" >> $Log
  #"Patch path is $PFolder1" >> $Log
 # "" >> $Log
}

IF (($FourDigitBuildNum1 -eq $requestedBuild1) -or ($FourDigitBuildNum1 -gt $requestedBuild1))
 {
  Write-Host ""
  Write-Host "No need to patch, already at requested or higher level."
  Write-Host ""
  Write-Host "###############################################################################"

  "" >> $Log
  "No need to patch, already at requested or higher level." >> $Log
  "" >> $Log
  "###############################################################################" >> $Log
  EXIT 0
 }
ELSE
{
  Write-Host ""
  Write-Host "Ready for deployment."
  Write-Host ""
  Write-Host "###############################################################################"

  "" >> $Log
  "Ready for deployment." >> $Log
  "" >> $Log
  "###############################################################################" >> $Log
}

#-------------------------------------- Check if any FULL, DIFF or LOG backup failures in the most recent run -----------------------------------------

[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo');
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc');
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO');
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended');
$test = "C:\SQLInstall_Logs"


#if (Test-Path $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log") {
# Clear-Content $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"
#}
#$Log_Bkp = $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"

      IF ($InstName1 -eq "MSSQLSERVER")
       {
	     $svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
	     $Inst_Name = $svr.name
       }

      ELSE

       {
	     $svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
	     $Inst_Name = $svr.name + "\" + $InstName1
       }



$FullBackupJob = "ITSSQL_DirectTape_FULL"

$ServerSMO = new-object ("Microsoft.SqlServer.Management.Smo.Server") $Inst_Name
$FullBackupJobExists=$ServerSMO.Jobserver.Jobs|where-object {$_.Name -like $FullBackupJob}

$sqlConn = new-object System.Data.SqlClient.sqlConnection "server=$Inst_Name;database=msdb;Integrated Security=sspi"
$sqlConn.Open()
 $ErrorActionPreference = "SilentlyContinue"
  IF ($FullBackupJobExists)	#--------- If ITSSQL_DirectTape_FULL job exists, it is a PROD or QA server -------

   {

#if (Test-Path $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log") {
# Clear-Content $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"
#}
#$Log_Bkp = $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"

	$MostRecentBkpFailures = "SELECT BackupType, DatabaseName  FROM [msdb].[dbo].[ITS_BACKUP_JOB] s1 WHERE BackupToTape='F' AND TapeBkpStartTime = (SELECT MAX(TapeBkpStartTime) FROM [msdb].[dbo].[ITS_BACKUP_JOB] s2 WHERE s1.DatabaseName = s2.DatabaseName)";
	$dAdapter = New-Object System.Data.SqlClient.SqlDataAdapter ($MostRecentBkpFailures,$sqlConn)
	$dTable = New-Object System.Data.DataTable
	$dAdapter.fill($dTable) | Out-Null


	IF(($dTable.Rows.Count -ne 0))
	   {
  		# Write-Host "******************************************************************************"
  		Write-Host ""
  		Write-Host "Checking for any most recent FULL, DIFF or LOG backup failures... "
  		Write-Host ""
#"" >> $Log_Bkp
#Get-ChildItem -Path $Log_Bkp -file *log*  | Remove-Item -recurse
		"###############################################################################" >> $Log
		"" >> $Log
  		"******************************************************************************" >> $Log 
  		"" >>   $Log 
  		"Checking for any most recent FULL, DIFF or LOG backup failures... " >> $Log 
  		"" >>   $Log 

  		FOREACH ($Row in $dTable.Rows)
		  {
			$BkpType = $Row[0]
			$DbName = $Row[1]
		
			IF ($BkpType -eq "TAPE_FULL")
		 	 {
		   	   Write-Host "Most recent FULL Backup for $DbName database has failed. "
			   "Most recent FULL Backup for $DbName database has failed." >> $Log 
		 	 }
			ELSEIF ($BkpType -eq "TAPE_DIFF")
		 	 {
		  	   Write-Host "Most recent DIFF Backup for $DbName database has failed."
			   "Most recent DIFF Backup for $DbName database has failed." >> $Log 
		 	 }
			ELSEIF ($BkpType -eq "TAPE_LOG")
		 	 {
		   	   Write-Host "Most recent LOG Backup for $DbName database has failed."
			   "Most recent LOG Backup for $DbName database has failed." >>  $Log 
		 	 }

		  }

  		Write-Host "Please resolve backup failure issues and start again. Exiting program..."
  		Write-Host ""


  		"Please resolve backup failure issues and start again. Exiting program..." >>  $Log 
  		"" >> $Log
		$Final_status = 1
	   }
	ELSE
	   {
  		Write-Host ""
  		Write-Host "Most recent FULL, DIFF and LOG backups have been SUCCESSFUL as per msdb..ITS_BACKUP_JOB table."
  		Write-Host ""
"" >> $Log	
#Get-ChildItem -Path $Log_Bkp -file *log*  | Remove-Item -recurse

  		Write-Host "******************************************************************************"

  		"###############################################################################" >> $Log
  		"Most recent FULL, DIFF and LOG backups have been SUCCESSFUL as per msdb..ITS_BACKUP_JOB table." >> $Log 
  		"" >> $Log

  		"******************************************************************************" >> $Log
	"###############################################################################" >> $Log 
	   }
   }
  ELSE
   {
       Write-Host "Instance $InstName1 is a DEV instance. Checking for any metadata backup failures.."
	$MostRecentBkpFailures = "SELECT BackupType, DatabaseName  FROM [msdb].[dbo].[ITS_BACKUP_JOB] s1 WHERE BackupToTape='F' AND DatabaseName = 'ALLDatabases' AND TapeBkpStartTime = (SELECT MAX(TapeBkpStartTime) FROM [msdb].[dbo].[ITS_BACKUP_JOB] s2 WHERE s1.DatabaseName = s2.DatabaseName)";
	$dAdapter = New-Object System.Data.SqlClient.SqlDataAdapter ($MostRecentBkpFailures,$sqlConn)
	$dTable = New-Object System.Data.DataTable
	$dAdapter.fill($dTable) | Out-Null

	IF($dTable.Rows.Count -ne 0)

	   {
	         Write-Host ""
	         Write-Host "Most recent metadata backup job FAILED for database : ALLDatabases (as per msdb..ITS_BACKUP_JOB table)"	
	         Write-Host "Please resolve backup failure issues and start again."
#"" >> $Log_Bkp                 
#Get-ChildItem -Path $Log_Bkp -file *log*  | Remove-Item -recurse
	         "" >> $Log
		"">> $Log
			"******************************************************************************" >> $Log
	         "Most recent metadata backup job FAILED for database : ALLDatabases (as per msdb..ITS_BACKUP_JOB table)" >> $Log 
		"">> $Log	
	         "Please resolve backup failure issues and start again." >> $Log 
		"******************************************************************************" >> $Log
		"###############################################################################" >> $Log
		$Final_status = 1	         
	   }
	ELSE
	   {
<#
if (Test-Path $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log") {
 Clear-Content $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"
}
$Log_Bkp = $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"
#>
	         Write-Host ""
	         Write-Host "Most recent metadata backup job SUCCESSFUL as per msdb..ITS_BACKUP_JOB table."	
	         Write-Host ""
#Clear-Content $test+"\"+$Hostname+"_BACKUPCHECK_TASK200_VRO.log"
#"" >> $Log_Bkp
#Get-ChildItem -Path $Log_Bkp -file *log*  | Remove-Item -recurse

			"******************************************************************************" >> $Log
	         "Most recent metadata backup job SUCCESSFUL as per msdb..ITS_BACKUP_JOB table." >> $Log 	
	         "" >> $Log 
		
		"******************************************************************************" >> $Log
		"###############################################################################" >> $Log
	   }
   }
#----------------------------------------- Missing MSP file -----------------------------------------
<#

cscript C:\SQLInstall_Logs\VBSCript\FindSQLInstalls.vbs C:\SQLInstall_Logs\VBSCript\missing_files.txt
Select-String  C:\SQLInstall_Logs\VBSCript\missing_files.txt -pattern "NOT exist in the Installer" | out-file C:\SQLInstall_Logs\VBSCript\missing_temp.txt

  IF ((Get-Content "C:\SQLInstall_Logs\VBSCript\missing_temp.txt") -ne $Null)

   {
      Get-Content "C:\SQLInstall_Logs\VBSCript\missing_temp.txt" | %{write-host $_}
      Write-Host ""
      Write-Host "Please resolve the MSP/MSI files issue before proceeding with patching. Details are available at : C:\SQLInstall_Logs\VBSCript\missing_temp.txt. Exiting now..."
      $Final_status = 1
   }

  ELSE

   {
      write-host "None of the MSI or MSP files are missing"
   }

IF ($Final_status = 1)
{
  Write-Host ""
  Write-Host "EXIT CODE 1"
  Write-Host ""
EXIT 1
}
ELSE
{
  Write-Host "Please proceed with patching the instance" >> $Log
  Write-Host ""
  Write-Host "EXIT CODE 0"
  Write-Host ""
EXIT 0
}
 
#>

#--------------------------------------------------------------------------------------------------

<#

IF (($FourDigitBuildNum1 -lt $SPBuildNum1) -and ($SPBuildNum1 -eq $requestedBuild1))
 {
  Write-Host ""
  Write-Host "Please proceed with installing the required ServicePack $RequestedSP ($SPBuildNum1)."
  Write-Host ""

  "" >> $Log
  #"Please proceed with installing the required ServicePack $RequestedSP ($SPBuildNum1)." >> $Log
  "" >> $Log

  # powershell.exe -ExecutionPolicy Bypass $InstallPatch -SQLVer2 $SQLVer1 -InstName2 $InstName1 -SPFolder2 $SPFolder1 -PFolder2 "EMPTY"
 }

ELSEIF ($FourDigitBuildNum1 -lt $SPBuildNum1)
 {
  Write-Host ""
  Write-Host "Please proceed with installing ServicePack $RequestedSP ($SPBuildNum1) and then patch with $PBuildNum1."
  Write-Host ""

  "" >> $Log
  #"Please proceed with installing ServicePack $RequestedSP ($SPBuildNum1) and then patch with $PBuildNum1." >> $Log
  #"" >> $Log

  # powershell.exe -ExecutionPolicy Bypass $InstallPatch -SQLVer2 $SQLVer1 -InstName2 $InstName1 -SPFolder2 $SPFolder1 -PFolder2 $PFolder1
 }

ELSEIF ($FourDigitBuildNum1 -eq $SPBuildNum1)

 {
  Write-Host ""
  Write-Host "Please proceed with installing the requested security hotfix $PBuildNum1."
  Write-Host ""

  #"" >> $Log
  #"Please proceed with installing the requested security hotfix $PBuildNum1." >> $Log
  "" >> $Log

  # powershell.exe -ExecutionPolicy Bypass $InstallPatch -SQLVer2 $SQLVer1 -InstName2 $InstName1 -PFolder2 $PFolder1
 }

ELSEIF (($FourDigitBuildNum1 -gt $SPBuildNum1) -and ($FourDigitBuildNum1 -lt $PBuildNum1))

 {
  Write-Host ""
  Write-Host "Please proceed with installing the requested security hotfix $PBuildNum1."
  Write-Host ""

  #"" >> $Log
  #"Please proceed with installing the requested security hotfix $PBuildNum1." >> $Log
  #"" >> $Log

  # powershell.exe -ExecutionPolicy Bypass $InstallPatch -SQLVer2 $SQLVer1 -InstName2 $InstName1 -PFolder2 $PFolder1
 }


#>