Use msdb
GO
--Full Backup
EXEC sp_add_jobstep
    @job_name = 'ITSSQL_DirectTape_FULL',
	@step_id=1, 
    @step_name = N'Check Primary Database',
    @subsystem = N'TSQL',
    @on_success_step_id = 0,
	@on_success_action=3,
	@on_fail_action=2,
	@command=N'if not exists(select primary_replica from sys.dm_hadr_availability_group_states where primary_replica = @@servername)
raiserror(''Exiting job because the current node is non Primary Server'',16,1)', 
	@database_name=N'master'
  GO

--Differential Backup
EXEC sp_add_jobstep
    @job_name = 'ITSSQL_DirectTape_DIFF',
	@step_id=1, 
    @step_name = N'Check Primary Database',
    @subsystem = N'TSQL',
    @on_success_step_id = 0,
     @on_success_action=3,
	@on_fail_action=2,
	@command=N'if not exists(select primary_replica from sys.dm_hadr_availability_group_states where primary_replica = @@servername)
raiserror(''Exiting job because the current node is non Primary Server'',16,1)', 
	@database_name=N'master'
  GO


USE msdb;
GO
--Log Backup
EXEC sp_add_jobstep
    @job_name = 'ITSSQL_DirectTape_Log',
	@step_id=1, 
    @step_name = N'Check Primary Database',
    @subsystem = N'TSQL',
    @on_success_step_id = 0,
   @on_success_action=3,
	@on_fail_action=2,
	@command=N'if not exists(select primary_replica from sys.dm_hadr_availability_group_states where primary_replica = @@servername)
raiserror(''Exiting job because the current node is non Primary Server'',16,1)', 
	@database_name=N'master'
  GO


  

 
  