foreach ($arg in $args)
{
	Get-Content $args
}