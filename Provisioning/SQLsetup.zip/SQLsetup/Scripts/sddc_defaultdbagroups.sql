
/*Grant access to server specific DBA groups*/


SET NOCOUNT ON

declare @machinName nvarchar(1000)
declare @grpName nvarchar(1000)
declare @grpName1 nvarchar(1000)
declare @sql nvarchar(4000)
set @machinName = cast(SERVERPROPERTY('machinename') as nvarchar)


set @grpName = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA'
set @grpName1 = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA-Temp'


if not exists (select * from sys.syslogins where loginname in (@grpName,@grpName1))
begin
set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
PRINT @SQL
exec sp_executesql @sql

set @sql = ''
set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName,'''') + ', @rolename = ' + quotename('sysadmin','''')
PRINT @SQL
exec sp_executesql @sql

set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName1) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
exec sp_executesql @sql

set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName1,'''') + ', @rolename = ' + quotename('sysadmin','''')
exec sp_executesql @sql
end
