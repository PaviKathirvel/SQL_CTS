###################################################################################################
$ScriptName = "sddc_sql_dbcreate.PS1"
$Scriptver = "1.0"
#Description: Default database creation. To be executed by member of ITS-EP-SQL-ALL-DBA or ITS-EP-ProvisioningDBAs-SQL
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			08-Oct-2014	Jay Sangam	New Script

###################################################################################################

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null

#$DBName = Read-Host -Prompt "Enter database name that needs to be created "

$DBName = "$($env:COMPUTERNAME)_SQL_DB"

Write-host ""
Write-Host "Creating default database $DBName..."
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("(local)")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database($srv, $DBName)

try     
{       

$db.Create()  
Write-Host ""
Write-host "Database $DBName creation : " -f white -nonewline; Write-Host "SUCCESS" -f green
Write-Host ""
}     

catch [Exception]     

{       
Write-Host ""
Write-Host $_.Exception.GetType().FullName, $_.Exception.Message -f red
Write-host ""
} 