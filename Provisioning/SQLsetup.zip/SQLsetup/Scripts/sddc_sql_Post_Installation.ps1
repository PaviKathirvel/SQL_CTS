###################################################################################################
$ScriptName = "sddc_sql_Post_Installation.PS1"
$Scriptver = "13.0"
#Description: Description: SQL Post Installation Steps for SDDC
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			05/07/2014	Bruno Campos	New Script
#2.0			06/02/2014	Bruno Campos	Removed Post Installation verification to 
#							a separate script.
#3.0			Jul/21/2014	Jay Sangam	Cold backup script added.
#4.0			Aug/25/2014	Bruno Campos	Automatically verification of SQLDML
#5.0			Sep/02/2014	Jay Sangam	Merging and Un-merging
#6.0			Sep/22/2014	Jay Sangam	Incorporating new Backup scripts
#7.0            Jun/19/2015 Praneet Kumar   Updating script for SQL 2005
#8.0			Jun/02/2016	Jay Sangam	Change authentication mode to Mixed
#9.0 			Sept/2/2019	Sanjiv		#Adding 2017 Installation logic	and Baseline Performance framework 
#10.0			Oct/14/2019	Bruno Campos	Added creation of new SQLAudit log for Native Audit
#11.0 			FEB/26/2020	Sanjiv		#Adding 2019 Installation logic	
#12.0 			APR/15/2021	Sanjiv		#Promoting SQL2019 
#13.0 			FEB/26/2024	Shubham		#Promoting SQL2024 
###################################################################################################

####
#*********** Lab DML************* 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML'

$LabConfig = "/configurationfile=""" + $LabSQLDML

#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'								

#####
$BatchOutput3 = "C:\IQOQ\Status.txt"
$Proc = $args[0]
$sqlv = $args[1]
$InstName = $args[2]
$InstName = "MSSQLSERVER"	#Delete this line later for named instance installs.


IF (($Proc -ne "SDDC") -and ($Proc -ne "NON_SDDC"))
{
Write-Host ""
Write-Host "Process not Valid. Please pass SDDC or NON_SDDC as 1st parameter" -f red
Write-Host ""
Exit 0
}
####################################################### #shubh
IF (($sqlv -ne "SQL2005") -and ($sqlv -ne "SQL2008") -and ($sqlv -ne "SQL2012") -and ($sqlv -ne "SQL2014") -and ($sqlv -ne "SQL2016") -and ($sqlv -ne "SQL2017") -and ($sqlv -ne "SQL2019") -and ($sqlv -ne "SQL2022")) 
{
Write-Host ""
Write-Host "SQL build version not Valid. Please pass SQL2005 or SQL2008 or SQL2012 or SQL2014 or SQL2016 or SQL2017 or SQL2019 or SQL2022 as 2nd parameter" -f red
Write-Host ""
Exit 0
}

IF ($sqlv -eq "SQL2008")
{
 $pat = "D:\MSSQL2008\MSSQL10.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}

IF ($sqlv -eq "SQL2012")
{
 $pat = "D:\MSSQL2012\MSSQL11.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}

IF ($sqlv -eq "SQL2014")
{
 $pat = "D:\MSSQL2014\MSSQL12.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}

IF ($sqlv -eq "SQL2016")
{
 $pat = "D:\MSSQL2016\MSSQL13.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}

IF ($sqlv -eq "SQL2017")
{
 $pat = "D:\MSSQL2017\MSSQL14.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}
IF ($sqlv -eq "SQL2019")
{
 $pat = "D:\MSSQL2019\MSSQL19.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}
IF ($sqlv -eq "SQL2022")
{
 $pat = "D:\MSSQL2022\MSSQL16.MSSQLSERVER\MSSQL\Log\"
if((Test-Path $pat) -eq 0)
{
mkdir $pat
} 
}

IF ($sqlv -eq "SQL2005")
{

  IF ($Proc -eq "SDDC")
   {

	If (!(Test-Path F:\MSSQL2005\MSSQL.1\MSSQL\Backup))
	{
  	mkdir "F:\MSSQL2005\MSSQL.1\MSSQL\Backup"
	}

	If (!(Test-Path F:\MSSQL2005\MSSQL.1\MSSQL\Data))

	{
  	mkdir "F:\MSSQL2005\MSSQL.1\MSSQL\Data"
	}

	If (!(Test-Path G:\MSSQL2005\MSSQL.1\MSSQL\Log))
	{
  	mkdir "G:\MSSQL2005\MSSQL.1\MSSQL\Log"
	}

	If (!(Test-Path H:\MSSQL2005\MSSQL.1\MSSQL\Tempdb))
	{
  	mkdir "H:\MSSQL2005\MSSQL.1\MSSQL\Tempdb"
	}

   }

  ELSEIF ($Proc -eq "NON_SDDC")

   {

	If (!(Test-Path G:\MSSQL2005\MSSQL.1\MSSQL\Backup))
	{
  	mkdir "G:\MSSQL2005\MSSQL.1\MSSQL\Backup"
	}

	If (!(Test-Path E:\MSSQL2005\MSSQL.1\MSSQL\Data))

	{
  	mkdir "E:\MSSQL2005\MSSQL.1\MSSQL\Data"
	}

	If (!(Test-Path F:\MSSQL2005\MSSQL.1\MSSQL\Log))

	{
  	mkdir "F:\MSSQL2005\MSSQL.1\MSSQL\Log"
	}

	If (!(Test-Path H:\MSSQL2005\MSSQL.1\MSSQL\Tempdb))

	{
  	mkdir "H:\MSSQL2005\MSSQL.1\MSSQL\Tempdb"
	}

   }

}

<#	Un-comment this block later for named instance installs.

IF ($InstName -eq $null)
{
Write-Host ""
Write-Host "Please pass valid instance name as 2nd parameter" -f red
Write-Host ""
Exit 0
}

#>


#------------------------ Check if valid instance name is being passed --------------------------------------

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -notcontains $InstName)
{
Write-Host ""
#Write-Host "Instance $InstName not found. Pass a valid instance name" -f red	Un-comment later for named instance installs.
Write-Host "Instance $InstName not found." -f red		#Delete this line later for named instance installs.
Write-Host ""
Exit 0
}

#------------------- Check if instance name really belongs to the SQLVersion passed as parameter ---------------------------

   $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName

   $ver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version

   $build = $ver.substring(0,2)

If (($build -eq "13") -and ($sqlv -ne "SQL2016"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "14") -and ($sqlv -ne "SQL2017"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "15") -and ($sqlv -ne "SQL2019"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "16") -and ($sqlv -ne "SQL2022")) #Shubham - 26/02/2024
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "12") -and ($sqlv -ne "SQL2014"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "11") -and ($sqlv -ne "SQL2012"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "10") -and ($sqlv -ne "SQL2008"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

ElseIf (($build -eq "9.") -and ($sqlv -ne "SQL2005"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}



#*********************************** Start of Post installation function ***********************************#

FUNCTION sddc_sql_Post_Installation($IDMLLOC, $Process, $sqlversion, $iName)  
{

$Time = get-date -Uformat "%Y%m%d%H%M"
$Log = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_$Time.txt"
$LogFilePath = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_SQLLog_$Time.txt"
$E_NativeAuditLog = "C:\SQLInstall_Logs\sddc_sql_ENT_NativeAudit_Log_$Time.txt"
$S_NativeAuditLog = "C:\SQLInstall_Logs\sddc_sql_STD_NativeAudit_Log_$Time.txt"
$S_StartAuditJob = "C:\SQLInstall_Logs\sddc_sql_STD_StartAuditJob_Log_$Time.txt"
$M_Plans_sql = $IDMLLOC + "\Scripts"

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log
"Execution String: $ScriptName $Process $sqlversion $iName" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')

IF ($iName -eq "MSSQLSERVER")
{
 $svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
 $Inst_Name = $svr.name
echo  $Inst_Name
 $Final_Status_Error = 0
}
ELSE
{
 $svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
 $Inst_Name = $svr.name + "\" + $iName
 $Final_Status_Error = 0
}

  $fso = New-Object -ComObject Scripting.FileSystemObject

  IF ($sqlversion -eq "SQL2014")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\120\DTS\Setup").SQLPath).ShortPath
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\120\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder='"' + $ClientTool + 'SQLCMD.EXE"'
  }
  
  ELSEIF ($sqlversion -eq "SQL2012")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
  }
  ELSEIF ($sqlversion -eq "SQL2008")

  {
   $M_Plans = $IDMLLOC + "\SSIS_2008"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\Setup").SQLPath).ShortPath
  }

  ELSEIF ($sqlversion -eq "SQL2005")

  {

   $M_Plans = $IDMLLOC + "\SSIS_2005"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\Setup").SQLPath).ShortPath
  }
  ELSEIF ($sqlversion -eq "SQL2016")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\130\DTS\Setup").SQLPath).ShortPath
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\130\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
  }
  
  ELSEIF ($sqlversion -eq "SQL2017")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\140\DTS\Setup").SQLPath).ShortPath
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\140\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
  }
  ELSEIF ($sqlversion -eq "SQL2019")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\150\DTS\Setup").SQLPath).ShortPath
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\150\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
  }
  ELSEIF ($sqlversion -eq "SQL2022") #Shubham - 26/02/2024
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\160\DTS\Setup").SQLPath).ShortPath
   $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\160\Tools\ClientSetup").ODBCToolsPath
   $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
  }
#--------------------------------- Backup Jobs Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log

If (Test-Path C:\SSISPackages) { Remove-Item C:\SSISPackages\* -recurse } else { mkdir "C:\SSISPackages" }

If (Test-Path C:\SQLInstall_Logs\BackupConfigLogs) { Remove-Item C:\SQLInstall_Logs\BackupConfigLogs\* -recurse } else { mkdir "C:\SQLInstall_Logs\BackupConfigLogs" }

$BKScriptsPath = $IDMLLOC + '\Scripts\BackupConfigScripts'	

$ScriptsPath = $IDMLLOC + '\Scripts'

$LogPath = 'C:\SQLInstall_Logs\BackupConfigLogs'

#------------------------------------------------------------------------------------------#

$Env_txt = (Get-Content C:\IQOQ\IQOQ_1.txt)[1]

IF ($Process -eq "SDDC")
{
 
 IF ($Env_txt -eq "DEV")

 {

 Write-Host "Backup Jobs Deployment - For DEV environment"
 Write-host ""
"Backup Jobs Deployment" >> $Log
"" >> $Log

IF(($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022"))
 {
  $bkp_1 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo_meta.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
  $bkp_2 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
  $bkp_3 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
  $bkp_sp = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITSSQL_DB_FULL_BACKUP_DEV.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 }
ELSE
 {
  $bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo_meta.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
  $bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
  $bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
 $bkp_sp = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_DB_FULL_BACKUP_DEV.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 }
echo $bkp_1
IF ($sqlv -eq "SQL2005")
 {
 $bkp_dev = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData_SQL2005.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 }

IF(($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022")) ########################shubham
 {
  $bkp_dev = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 }
Else
 {
  $bkp_dev = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 }

 
 IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019")  -or ($sqlv -eq "SQL2022")) ################################shubham
 {
 $bkp_10 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
 $bkp_11 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
 $bkp_12 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
 }
 ELSE
 {
 $bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
 $bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
 $bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
 }

& cmd.exe /c $bkp_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : SUCCESS" >> $Log
}


& cmd.exe /c $bkp_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create Table ITS_CFG_BLACKOUT : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create Table ITS_CFG_BLACKOUT : SUCCESS" >> $Log
}


& cmd.exe /c $bkp_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create Table ITS_BACKUP_JOB : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create Table ITS_BACKUP_JOB : SUCCESS" >> $Log
}

& cmd.exe /c $bkp_sp | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : " -f white -nonewline; Write-Host "Success" -f green
	 "ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : SUCCESS" >> $Log
}


& cmd.exe /c $bkp_dev | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create ITSSQL_MetaData job : " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create ITSSQL_MetaData job : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create ITSSQL_MetaData job : " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create ITSSQL_MetaData job : SUCCESS" >> $Log
}

& cmd.exe /c $bkp_10 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create Stored Procedure usp_blackout: FAILED" >> $Log
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create Stored Procedure usp_blackout: SUCCESS" >> $Log
}

& cmd.exe /c $bkp_11 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Failed" -f red
	"ITS Backup process - Create Stored Procedure usp_masterbackup_entry: FAILED" >> $Log
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Success" -f green
	"ITS Backup process - Create Stored Procedure usp_masterbackup_entry: SUCCESS" >> $Log
}

& cmd.exe /c $bkp_12 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Success" -f green
}


 }
 
 ELSE
 
 {

 Write-Host "Backup Jobs Deployment - For PROD/QA environment"
"Backup Jobs Deployment" >> $Log



IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022"))
{
 $bkp_1 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
 $bkp_2 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
 $bkp_3 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
}
else
{
$bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
$bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
$bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
}


IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022")) #Shubham
{
$bkp_6 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Full_Backup.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
$bkp_7 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Diff_Backup.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
$bkp_8 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Log_Backup_2014.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
$bkp_adhoc_full = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Adhoc_FULL_Backup.sql -o $LogPath\AdhocFullBkpJob.txt -x && exit 0 || exit 1"
$bkp_adhoc_diff = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Adhoc_DIFF_Backup.sql -o $LogPath\AdhocDiffBkpJob.txt -x && exit 0 || exit 1"
}

ELSEIF ($sqlv -eq "SQL2005")
{
$bkp_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Full_Backup_SQL2005.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
$bkp_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Diff_Backup_SQL2005.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
$bkp_8 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Log_Backup_SQL2005.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
}
Else
{
$bkp_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Full_Backup.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
$bkp_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Diff_Backup.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
$bkp_8 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Log_Backup.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
}



IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022")) #Shubham
 {
   $bkp_10 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
   $bkp_11 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
   $bkp_12 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
 }
ELSE
 {
   $bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
   $bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
   $bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
 }

& cmd.exe /c $bkp_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_6 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Full backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Full backup job: " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_7 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Differential backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Differential backup job: " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_8 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Transaction log backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Transaction log backup job: " -f white -nonewline; Write-Host "Success" -f green
}

#------------- Adhoc FULL and DIFF jobs ------------------

& cmd.exe /c $bkp_adhoc_full | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Adhoc FULL backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Adhoc FULL backup job: " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_adhoc_diff | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Adhoc DIFF backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Adhoc DIFF backup job: " -f white -nonewline; Write-Host "Success" -f green
}

#---------------------------------------------------------

& cmd.exe /c $bkp_10 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_11 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_12 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Success" -f green
}

}

}

IF ($Process -eq "NON_SDDC")
{
########################## Deploy Maintenance Plans ##########################
Write-Host "-------"
"-------" >> $Log
Write-Host "Maintenance Plans Deployment :"
Write-Host ""
"Maintenance Plans Deployment" >> $Log
$x = "D:\Program Files\Microsoft SQL Server\MSSQL11." + $iName + "\MSSQL\Binn"

#***************** Modify existing .dtsx pkgs to suit for named instances *****************

Write-host "M_Plans is $M_Plans"

Copy-Item $M_Plans\DiffDatabaseBackupMaintenance.dtsx C:\SSISPackages
Copy-Item $M_Plans\FullDatabaseBackupMaintenance.dtsx C:\SSISPackages
Copy-Item $M_Plans\TransactionLogBackupMaintenance.dtsx C:\SSISPackages

$path2 = 'C:\SSISPackages\DiffDatabaseBackupMaintenance.dtsx'
$path3 = 'C:\SSISPackages\FullDatabaseBackupMaintenance.dtsx'
$path4 = 'C:\SSISPackages\TransactionLogBackupMaintenance.dtsx'

$Server = $env:computername

  IF ($sqlversion -eq "SQL2014")
  {
	$NewLogPath = "D:\MSSQL2014\MSSQL12."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2014\MSSQL12."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }
ELSEIF ($sqlversion -eq "SQL2016")
  {
	$NewLogPath = "D:\MSSQL2016\MSSQL13."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2016\MSSQL13."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }

ELSEIF ($sqlversion -eq "SQL2017")
  {
	$NewLogPath = "D:\MSSQL2017\MSSQL14."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2017\MSSQL14."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }

  ELSEIF ($sqlversion -eq "SQL2019")
  {
	$NewLogPath = "D:\MSSQL2019\MSSQL15."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2019\MSSQL15."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }
  
  ELSEIF ($sqlversion -eq "SQL2022") #Shubham - 26/02/2024
  {
	$NewLogPath = "D:\MSSQL2022\MSSQL16."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2022\MSSQL16."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }

  ELSEIF ($sqlversion -eq "SQL2012")
  {
	$NewLogPath = "D:\MSSQL2012\MSSQL11."+$iName+"\MSSQL\Log"
	$NewBkpPath = "G:\MSSQL2012\MSSQL11."+$iName+"\MSSQL\Backup"

	$NewConnString = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

	$xml2 = [xml](Get-Content $path2)
	$xml3 = [xml](Get-Content $path3)
	$xml4 = [xml](Get-Content $path4)

	$node2 = $xml2.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node2.ConnectionString = $NewConnString

	$node3 = $xml3.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node3.ConnectionString = $NewConnString

	$node4 = $xml4.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
	$node4.ConnectionString = $NewConnString

	$node2a = $xml2.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node2b = $node2a.VariableValue
	$node2b."#text" = $NewLogPath
	$node3a = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node3b = $node3a.ObjectData.SqlTaskData
	$node3b.Path = $NewLogPath
	$node3c = $xml2.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node3d = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node3e = $node3d.ObjectData.SqlTaskData
	$node3e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node3f = $node3c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node3g = $node3f.ObjectData.SqlTaskData
	$node3g.FolderPath = $NewBKPPath

	$node4a = $xml3.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node4b = $node4a.VariableValue
	$node4b."#text" = $NewLogPath
	$node5a = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node5b = $node5a.ObjectData.SqlTaskData
	$node5b.Path = $NewLogPath
	$node5c = $xml3.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node5d = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node5e = $node5d.ObjectData.SqlTaskData
	$node5e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node5f = $node5c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node5g = $node5f.ObjectData.SqlTaskData
	$node5g.FolderPath = $NewBkpPath

	$node6a = $xml4.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
	$node6b = $node6a.VariableValue
	$node6b."#text" = $NewLogPath
	$node7a = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
	$node7b = $node7a.ObjectData.SqlTaskData
	$node7b.Path = $NewLogPath
	$node7c = $xml4.Executable.Executables.Executable | where {$_.refID -like 'Package\Subplan*'}
	$node7d = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Back Up Database*'}
	$node7e = $node7d.ObjectData.SqlTaskData
	$node7e.BackupDestinationAutoFolderPath = $NewBkpPath
	$node7f = $node7c.Executables.Executable | where {$_.refID -like 'Package\Subplan_1\Maintenance Cleanup *'}
	$node7g = $node7f.ObjectData.SqlTaskData
	$node7g.FolderPath = $NewBkpPath

	$xml2.Save($path2)
	$xml3.Save($path3)
	$xml4.Save($path4)
  }
  ELSEIF ($sqlversion -eq "SQL2008")
  {
	# $NewLogPath = "D:\MSSQL2008\MSSQL10."+$iName+"\MSSQL\Log"
	# $NewBkpPath = "G:\MSSQL2008\MSSQL10."+$iName+"\MSSQL\Backup"
  }
  ELSEIF ($sqlversion -eq "SQL2005")
  {
	# $NewLogPath = "D:\MSSQL2005\MSSQL9."+$iName+"\MSSQL\Log"
	# $NewBkpPath = "G:\MSSQL2005\MSSQL9."+$iName+"\MSSQL\Backup"
  }

 $cmd_2 = $DTSFolder + "\Binn\dtutil.exe /FILE C:\SSISPackages\DiffDatabaseBackupMaintenance.dtsx /DestServer $Inst_Name /COPY SQL;""\Maintenance Plans\DiffDatabaseBackupMaintenance"" && exit 0 || exit 1"
 $cmd_3 = $DTSFolder + "\Binn\dtutil.exe /FILE C:\SSISPackages\FullDatabaseBackupMaintenance.dtsx /DestServer $Inst_Name /COPY SQL;""\Maintenance Plans\FullDatabaseBackupMaintenance"" && exit 0 || exit 1"
 $cmd_4 = $DTSFolder + "\Binn\dtutil.exe /FILE C:\SSISPackages\TransactionLogBackupMaintenance.dtsx /DestServer $Inst_Name /COPY SQL;""\Maintenance Plans\TransactionLogBackupMaintenance"" && exit 0 || exit 1"

& cmd.exe /c $cmd_2 | out-null
if ($lastexitcode -eq 1)
{
	Write-Host "Differential Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Failed" -f red
	"Differential Backup Maintenance Plan Deployment: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Differential Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Success" -f green
	"Differential Backup Maintenance Plan Deployment: Success" >> $Log
}
& cmd.exe /c $cmd_3 | out-null
if ($lastexitcode -eq 1)
{
	Write-Host "Full Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Failed" -f red
	"Full Backup Maintenance Plan Deployment: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Full Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Success" -f green
	"Full Backup Maintenance Plan Deployment: Success" >> $Log
}
& cmd.exe /c $cmd_4 | out-null
if ($lastexitcode -eq 1)
{
	Write-Host "Transaction Log Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Failed" -f red
	"Transaction Log Backup Maintenance Plan Deployment: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Transaction Log Backup Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Success" -f green
	"Transaction Log Backup Maintenance Plan Deployment: Success" >> $Log
}
Write-Host "-------"
"-------" >> $Log
Write-Host "-------"
"-------" >> $Log
}


#---------------------------------- End of Backup Jobs Deployment --------------------------------

#--------------------------------Baseline Database Creation for SQL Performance Montioring Sanjiv / 1st March 2019 ------------------------------# 

Write-Host "Baseline Database Creation for SQL Performance Montioring " -f white -nonewline; Write-Host "Success" -f green
    "Baseline Database Creation for SQL Performance Monitoring : Started" >> $Log
    
$BaselineScript = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\Baseline\Baseline_DB_Framework.sql"


IF ($sqlversion -eq "SQL2019")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\150\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Baseline = $ToolsFolder + " -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}
ElseIF ($sqlversion -eq "SQL2022") #Shubham
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\160\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Baseline = $ToolsFolder + " -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2017")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\140\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Baseline = $ToolsFolder + " -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2016")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\130\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Baseline = $ToolsFolder + " -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2014")
{
	$ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\120\Tools\ClientSetup").ODBCToolsPath
	$ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
    $Baseline = $ToolsFolder + " -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2012")
{
 $fso = New-Object -ComObject Scripting.FileSystemObject
 $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
 $Baseline = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2008") 

{
 $fso = New-Object -ComObject Scripting.FileSystemObject
 $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\Setup").SQLPath).ShortPath
 $Baseline = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2005")

{
  $fso = New-Object -ComObject Scripting.FileSystemObject
  $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\Setup").SQLPath).ShortPath
  $Baseline = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BaselineScript -x && exit 0 || exit 1"
}



& cmd.exe /c $Baseline | out-null

Write-Host "Baseline Database Creation for SQL Performance Monitoring completed  " -f white -nonewline; Write-Host "Success" -f green
    "Baseline Database Creation for SQL Performance Monitoring : Success" >> $Log


##########################################################################################################################################

#---------------------------------- Integrity & Optimization for both SDDC & NON_SDDC ---------------------------------


Write-Host "Integrity & Optimization Jobs  Creation for SQL Server " -f white -nonewline; Write-Host "Started" -f green
    "Integrity & Optimization Jobs  Creation for SQL Server : Started" >> $Log
    
$DiScript = "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\DBaaSStaging\ConfigFiles\Databasemaintenance.sql"


IF ($sqlversion -eq "SQL2019")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\150\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Di = $ToolsFolder + " -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}
ElseIF ($sqlversion -eq "SQL2022") #Shubham
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\160\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Di = $ToolsFolder + " -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2017")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\140\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Di = $ToolsFolder + " -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2016")
{
 $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\130\Tools\ClientSetup").ODBCToolsPath
 $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
 $Di = $ToolsFolder + " -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ElseIF ($sqlversion -eq "SQL2014")
{
	$ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\120\Tools\ClientSetup").ODBCToolsPath
	$ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
    $Di = $ToolsFolder + " -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2012")
{
 $fso = New-Object -ComObject Scripting.FileSystemObject
 $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
 $Di = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2008") 

{
 $fso = New-Object -ComObject Scripting.FileSystemObject
 $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\Setup").SQLPath).ShortPath
 $Di = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}

ELSEIF ($sqlversion -eq "SQL2005")

{
  $fso = New-Object -ComObject Scripting.FileSystemObject
  $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\Setup").SQLPath).ShortPath
  $Di = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $DiScript -x && exit 0 || exit 1"
}



& cmd.exe /c $Di | out-null

Write-Host "Integrity & Optimization Jobs  Creation for SQL Server completed  " -f white -nonewline; Write-Host "Success" -f green
    "Integrity & Optimization Jobs  Creation for SQL Server : Success" >> $Log


##########################################################################################################################################


#-------------------------------- Move TempDB files to H drive if SQL2005 ------------------------------------------#

   IF ($sqlversion -eq "SQL2005")
   {
     $MoveTempDB = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\SQL2005_MoveTempDB.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005_MoveTempDB.txt -x && exit 0 || exit 1"
     
     & cmd.exe /c $MoveTempDB | out-null
   }


#--------------------------------- Script Execution for Post Installation Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log
Write-Host "Script Execution for Post Installation Configuration"
"Script Execution of Post Installation Configuration" >> $Log

IF ($sqlversion -eq "SQL2008")
{
Copy-Item $ScriptsPath\sddc_sql2008_TempDBDiskSpace.ps1 C:\IQOQ
}

IF ($sqlversion -eq "SQL2005")
{
Copy-Item $ScriptsPath\sddc_sql2005_TempDBDiskSpace.ps1 C:\IQOQ
}


If ($Process -eq "SDDC")

{
   IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016")  -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022")) #Shubham
   {
     $cmd_5 = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\sddc_sql_Post_Installation_sddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
   }

   ELSEIF ($sqlversion -eq "SQL2012")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql_Post_Installation_sddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
   }
   ELSEIF ($sqlversion -eq "SQL2008")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql2008_Post_Installation_sddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2008_SDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
   }
   ELSEIF ($sqlversion -eq "SQL2005")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql2005_Post_Installation_sddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005_SDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
   }

}
ELSEIF ($Process -eq "NON_SDDC")
{
   IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016")  -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022"))
   {
     $cmd_5 = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\sddc_sql_Post_Installation_nonsddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
   }

   ELSEIF ($sqlversion -eq "SQL2012")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql_Post_Installation_nonsddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
   }
   ELSEIF ($sqlversion -eq "SQL2008")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql2008_Post_Installation_nonsddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2008_NonSDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
   }
   ELSEIF ($sqlversion -eq "SQL2005")
   {
     $cmd_5 = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\sddc_sql2005_Post_Installation_nonsddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005_NonSDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
   }

}

& cmd.exe /c $cmd_5 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Failed" -f red
	"Script Execution of Post Installation Configuration: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Success" -f green
	"Script Execution of Post Installation Configuration: Success" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#---------------------------------------- TempDB Startup Parameters ----------------------------------------# need to change

IF (($sqlv -eq "SQL2005") -or ($sqlv -eq "SQL2008") -or ($sqlv -eq "SQL2012") -or ($sqlv -eq "SQL2014"))
{
Write-Host "-------"
"-------" >> $Log
Write-Host "TempDB Startup Parameters"
"TempDB Startup Parameters" >> $Log

$i = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName

$error.clear()
$regKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$i\MSSQLServer\Parameters"
$newRegProp = "SQLArg3"
$StartupParameter = "-T1118"
Set-ItemProperty -Path $RegKey -Name $newRegProp -Value $StartupParameter
$newRegProp = "SQLArg4"
$StartupParameter = "-T1117"
Set-ItemProperty -Path $RegKey -Name $newRegProp -Value $StartupParameter
if ($error[0])
{
$S_Param = 1
}
ELSE
{
$S_Param = 0
}
$error.clear()
if ($S_Param -eq 0)
{
	Write-Host "TempDB Configuration: " -f white -nonewline; Write-Host "Success" -f green
	"TempDB Configuration: Success" >> $Log
	$Final_Status = 0
}
ELSE
{
	Write-Host "TempDB Configuration: " -f white -nonewline; Write-Host "Failed" -f red
	"TempDB Configuration: Failed" >> $Log
	$Final_Status_Error = 1
}

Write-Host "-------"
"-------" >> $Log
}
#--------------------------------- Script Execution for enabling Native Auditing ---------------------------------#

Write-Host "-------"
"-------" >> $Log

New-Item -Path HKLM:\SYSTEM\ControlSet001\Services\EventLog -Name SQLAudit -Force
if ( -not (Test-Path -Path 'D:\SQLNativeAudit' -PathType Container )) {New-Item -Path "D:\" -Name "SQLNativeAudit" -ItemType "directory"}
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\SQLAudit" -Name "File" -Value "D:\SQLNativeAudit\SQLAudit.evtx"
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\SQLAudit" -Name "Flags" -Value "1" -PropertyType DWORD
Limit-EventLog -LogName "SQLAudit" -MaximumSize 200MB
New-EventLog -source MSSQL -LogName SQLAudit

$NativeAudit = (Get-Content "C:\IQOQ\IQOQ_1.txt")
$i = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
$Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$i\Setup").Edition

If (Test-Path "C:\IQOQ\IQOQ_2.txt")
{
Remove-Item "C:\IQOQ\IQOQ_2.txt"
}
$IQOQ_2 = "C:\IQOQ\IQOQ_2.txt" #Make it read-only

If ($NativeAudit -eq "Native Auditing:Enable")
{

	IF($sqlversion -eq "SQL2005")
	{
	Write-Host "Script Execution for enabling Native Auditing"
	"Script Execution for enabling Native Auditing" >> $Log
	$cmd_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_2005_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
	& cmd.exe /c $cmd_6 | out-null
	
		IF ($lastexitcode -eq 1)
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
		   "Script Execution for enabling Native Auditing: Failed" >> $Log
		   "Native Auditing:1" >> $IQOQ_2
		   $Final_Status_Error = 1
		}
		ELSE
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
		   "Native Auditing:0" >> $IQOQ_2
		   "Script Execution for enabling Native Auditing: Success" >> $Log
		}
	}
	ELSEIF(($Edition -eq "Enterprise Edition: Core-based Licensing") -or ($Edition -eq "Enterprise Edition"))
	{
	   Write-Host "Script Execution for enabling Native Auditing"
	   "Script Execution for enabling Native Auditing" >> $Log

	      IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016")  -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2022")) ##############################shubh
   	        {
	          $cmd_6 = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\SQLAudit_ENT_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
		}
	       ELSE
		{
	          $cmd_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_ENT_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
		}
	   & cmd.exe /c $cmd_6 | out-null

		IF ($lastexitcode -eq 1)
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
		   "Script Execution for enabling Native Auditing: Failed" >> $Log
		   "Native Auditing:1" >> $IQOQ_2
		   $Final_Status_Error = 1
		}
		ELSE
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
		   "Native Auditing:0" >> $IQOQ_2
		   "Script Execution for enabling Native Auditing: Success" >> $Log
		}
	}

	ELSEIF($Edition -eq "Standard Edition")

	{
	   Write-Host "Script Execution for enabling Native Auditing"
	   "Script Execution for enabling Native Auditing" >> $Log

	      IF (($sqlv -eq "SQL2014") -or ($sqlv -eq "SQL2016") -or ($sqlv -eq "SQL2017") -or ($sqlv -eq "SQL2019") -or ($sqlv -eq "SQL2022")) #####################shubham
   	        {
	          $cmd_6 = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\SQLAudit_STD_Script.sql -x -o $S_NativeAuditLog && exit 0 || exit 1"
		}
	      ELSE
		{
	          $cmd_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_STD_Script.sql -x -o $S_NativeAuditLog && exit 0 || exit 1"
		}

	   & cmd.exe /c $cmd_6 | out-null

		IF ($lastexitcode -eq 1)
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
		   "Script Execution for enabling Native Auditing: Failed" >> $Log
		   "Native Auditing:1" >> $IQOQ_2
		   $Final_Status_Error = 1
		}
		ELSE
		{
		   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
		   "Native Auditing:0" >> $IQOQ_2
		   "Script Execution for enabling Native Auditing: Success" >> $Log
		}
	}


}
ELSE
{

Write-host "Native Auditing disabled on NON-PROD environment: " -f white -nonewline; Write-Host "Success" -f green
"Native Auditing:D" >> $IQOQ_2
"Native Auditing disabled on NON-PROD environment: Success" >> $Log

}

Write-Host "-------"
"-------" >> $Log

#--------------------------------- Change to Mixed mode authentication ---------------------------------#

$registryPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer"

$Name = "LoginMode"
$value = "2"
Set-ItemProperty -Path $registryPath -Name $name -Value $value

#--------------------------------- Restart SQL Services ---------------------------------#
Write-Host "-------"
"-------" >> $Log

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
$BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory

$SysBkp = $BackupDir + "\"
$SysBkpFolder = $SysBkp + "SystemBackup"


IF ($iName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
 Stop-Service -Name $SQLAgtAcct -force
  Stop-Service -Name $SQLSvcAcct -force
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $iName
 $SQLAgtAcct = 'SQLAgent$' + $iName
 Stop-Service -Name $SQLAgtAcct
 Stop-Service -Name $SQLSvcAcct -force
}


if ($error[0])
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Failed" -f red
	"Stop SQL Server Services $SQLSvcAcct : Failed" >> $Log
	$Final_Status_Error = 1
	$error.clear()
}
ELSE
{
	Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Success" -f green
	"Stop SQL Server Service $SQLSvcAcct : Success" >> $Log

	
	$ArchiveFolder = $SysBkp + "SystemBackup\ArchiveAfter_$Time"
	If (Test-Path $SysBkpFolder)
	{
	Remove-Item $SysBkpFolder\* -recurse
	}

	mkdir $ArchiveFolder
	Start-Sleep -s 5

IF ($sqlversion -eq "SQL2014")
 
 {

	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2014\MSSQL12.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2014\MSSQL12.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2014\MSSQL12.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }
ELSEIF ($sqlversion -eq "SQL2016")
 
 {

	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2016\MSSQL13.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2016\MSSQL13.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2016\MSSQL13.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }


ELSEIF ($sqlversion -eq "SQL2017")
 
 {

	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2017\MSSQL14.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2014\MSSQL14.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2014\MSSQL14.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }


 ELSEIF ($sqlversion -eq "SQL2019")
 
 {

	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2019\MSSQL15.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2019\MSSQL15.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2019\MSSQL15.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }
 
 ELSEIF ($sqlversion -eq "SQL2022") ################################shubham
 
 {

	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2022\MSSQL16.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2022\MSSQL16.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2022\MSSQL16.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }



 ELSEIF ($sqlversion -eq "SQL2012")
 
 {

	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2012\MSSQL11.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2012\MSSQL11.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2012\MSSQL11.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }

ELSEIF ($sqlversion -eq "SQL2008")

 {

	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2008\MSSQL10.$iName\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item D:\MSSQL2008\MSSQL10.$iName\MSSQL\Binn\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item D:\MSSQL2008\MSSQL10.$iName\MSSQL\Binn\mssqlsystemresource.ldf $ArchiveFolder

 }

ELSEIF ($sqlversion -eq "SQL2005")

 {

	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\master.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\model.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\MSDBData.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\mastlog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\modellog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\MSDBLog.ldf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\mssqlsystemresource.mdf $ArchiveFolder
	Copy-Item E:\MSSQL2005\MSSQL.1\MSSQL\DATA\mssqlsystemresource.ldf $ArchiveFolder

 }


	Rename-Item $ArchiveFolder\master.mdf master.mmm
	Rename-Item $ArchiveFolder\model.mdf model.mmm
	Rename-Item $ArchiveFolder\MSDBData.mdf MSDBData.mmm
	Rename-Item $ArchiveFolder\mastlog.ldf mastlog.lll
	Rename-Item $ArchiveFolder\modellog.ldf modellog.lll
	Rename-Item $ArchiveFolder\MSDBLog.ldf MSDBLog.lll
	Rename-Item $ArchiveFolder\mssqlsystemresource.mdf mssqlsystemresource.mmm
	Rename-Item $ArchiveFolder\mssqlsystemresource.ldf mssqlsystemresource.lll


if ($error[0])
{
#Write-Host "Error : $error[0]"
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Failed" -f red
	"Cold backup of system databases to $ArchiveFolder : Failed" >> $Log
	"Cold Backup:1" >> $IQOQ_2
	$Final_Status_Error = 1
	$error.clear()
}
ELSE
{
	Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Success" -f green
	"Cold backup of system databases to $ArchiveFolder : Success" >> $Log
	"Cold Backup:0" >> $IQOQ_2
}


}
Write-Host "-------"
"-------" >> $Log
$error.clear()
IF ($iName -eq "MSSQLSERVER")
{
 $SQLSvcAcct = 'MSSQLSERVER'
 $SQLAgtAcct = 'SQLSERVERAGENT'
 $ASSVCAcct = 'MSSQLServerOLAPService'
 $RSSVCAcct = 'ReportServer'
}

ELSE

{
 $SQLSvcAcct = 'MSSQL$' + $iName
 $SQLAgtAcct = 'SQLAgent$' + $iName
 $ASSVCAcct = 'MSOLAP$' + $iName
 $RSSVCAcct = 'ReportServer$' + $iName
}

#------------ Set authentication mode to Mixed mode --------------------

$Mode = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").LoginMode

$value = "2"
$Name = "LoginMode"
$registryPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer"

IF($Mode -eq "1")

  {

    New-ItemProperty -Path $registryPath -Name $name -Value $value -PropertyType DWORD -Force | Out-Null

  }

#---------------------------------------------------------------------

 Start-Service -Name $SQLAgtAcct
 Start-Service -Name $SQLSvcAcct

 Set-service $SQLAgtAcct -startup automatic
 Set-service SQLBrowser -startup automatic
 Set-service $ASSVCAcct -startup Manual


 Start-Service -Name SQLBrowser
 Stop-Service -Name $ASSVCAcct
#######################################################shubham
IF (($sqlversion -eq "SQL2008") -or ($sqlversion -eq "SQL2012") -or ($sqlversion -eq "SQL2014") -or ($sqlversion -eq "SQL2016"))
{
 Set-service $RSSVCAcct -startup Manual
 Stop-Service -Name $RSSVCAcct 
}

ELSEIF(($sqlversion -eq "SQL2017") -or ($sqlversion -eq "SQL2019") -or ($sqlversion -eq "SQL2022"))
{
 $RSSVCAcct = 'SQLServerReportingServices'
 Set-service $RSSVCAcct -startup Manual
 Stop-Service -Name $RSSVCAcct 
}

if ($error[0])
{
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Failed" -f red
	"Start SQL Server Services: Failed" >> $Log
	$Final_Status_Error = 1
	$error.clear()
}
ELSE
{
	Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
	"Start SQL Server Services: Success" >> $Log
}

Write-Host "-------"
"-------" >> $Log


#--------------------------------- Resize TempB -----------------------------------------#

IF ($sqlversion -eq "SQL2005")
{
    $ResizeTempDB = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\SQL2005_TempDBResizing.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005TempDBResizing.txt -x && exit 0 || exit 1"
 	   & cmd.exe /c $ResizeTempDB | out-null

}

#--------------------------------- Start Native Audit job -----------------------------------------#

If ($NativeAudit -eq "Native Auditing:Enable")
{
	IF ($Edition -eq "Standard Edition")
	{

	$cmd_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\StartNativeAuditJob.sql -x -o $S_StartAuditJob && exit 0 || exit 1"

	   & cmd.exe /c $cmd_7 | out-null

	}
}
 

#--------------------------------- Deactivate CEIP -----------------------------------------#


Get-Service | 
    Where-Object { $_.Name -like '*telemetry*' -or $_.DisplayName -like '*CEIP*' } | 
    ForEach-Object { 
        $servicename = $_.Name; 
        $displayname = $_.DisplayName; 
        Set-Service -Name $servicename  -StartupType Disabled 
        $serviceinfo = Get-Service -Name $servicename 
        $startup = $serviceinfo.StartType
        Write-Host "$servicename : $startup : $displayname";  
    }

$Key = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server'
$FoundKeys = Get-ChildItem $Key -Recurse | Where-Object -Property Property -eq 'EnableErrorReporting'
foreach ($Sqlfoundkey in $FoundKeys)
{
$SqlFoundkey | Set-ItemProperty -Name EnableErrorReporting -Value 0
$SqlFoundkey | Set-ItemProperty -Name CustomerFeedback -Value 0
}
##################################################
# Set HKEY_LOCAL_MACHINE\Software\Wow6432Node\Microsoft\Microsoft SQL Server\***\CustomerFeedback=0
# Set HKEY_LOCAL_MACHINE\Software\Wow6432Node\Microsoft\Microsoft SQL Server\***\EnableErrorReporting=0
# *** --> Version of SQL Server(100,110,120,130,140,...)
##################################################
$WowKey = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Microsoft SQL Server"
$FoundWowKeys = Get-ChildItem $WowKey | Where-Object -Property Property -eq 'EnableErrorReporting'
foreach ($SqlFoundWowKey in $FoundWowKeys)
{
$SqlFoundWowKey | Set-ItemProperty -Name EnableErrorReporting -Value 0
$SqlFoundWowKey | Set-ItemProperty -Name CustomerFeedback -Value 0
echo $SqlFoundWowKey
}
c:

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
IF ($Final_Status_Error -eq 1)
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"FINAL STATUS = FAILED" >> $Log
Write-Host "Please review the verification steps and address the failed step"
"Please review the verification steps and address the failed step" >> $Log
"FAILED" > $BatchOutput3
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
"FINAL STATUS = SUCCESS" >> $Log
"SUCCESS" > $BatchOutput3
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}

}

#*********************************** End of Post installation function ***********************************#


#--------- Start POST install configuration ---------#

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 

	sddc_sql_Post_Installation $LabSQLDML $Proc $sqlv $InstName

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 223) 
 { 

	sddc_sql_Post_Installation $NASQLDML $Proc $sqlv $InstName
 }
}

#--------- End POST install configuration ---------#

