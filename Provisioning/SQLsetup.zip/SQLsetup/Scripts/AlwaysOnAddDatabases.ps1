﻿#----------------------------------------------------------------------------------------
# File                           :  AlwaysOnAddDatabases.ps1
# Description                    : This script will add existing databases to the AG Group..
# LastModified                   : 12-23-2015
# Logs                           : Defualt path C:\SQLInstallLogs_2012\AlwaysOn_<TimeStamp>.txt
# Example                        : c:\sqlalwayson\AlwaysOnAddDatabases.ps1 -Backuppath "\\10.0.108.146\Backups" -AGGroupName itsuslw12sqln1grp -DatabaseList = "TestDB,TestDB1"
# Authors                        : Jay Natarajan
# Parameters                     :[Backup Path] - Optional - fileshare that is accessible by both servers.
#                                 [AGGroupName] - Optional - If it is not specified, Availability group Name will be defined based on the formula.
#                                 [DatabaseList] - Optional - If nothing is specified all the databases in the server would be added. Specify List of databases in comma seperated format if only few databases in the server needs to be included.
#----------------------------------------------------------------------------------------
Param(
[string] $BackupPath,
[string] $AGGroupName,
[String[]]$DatabaseList
)


# Local Variables

# Parameters
$clustername = get-cluster
$PrimaryReplica = get-clustergroup -cluster $clustername -name "cluster Group"|select ownernode

$allnodes = get-clusternode | select-object name
$PrimaryReplica = $PrimaryReplica.ownernode.tostring()
[String]$SecondaryReplica = ($allnodes -notmatch $PrimaryReplica) | select-object -Expandproperty name

$PrimaryReplica1 = $PrimaryReplica
$SecondaryReplica1 = $SecondaryReplica

$PrimaryReplica = "tcp:$primaryreplica"
$SecondaryReplica = "tcp:$Secondaryreplica"

#if ($PrimaryReplica -ne $env:computername)
#{

 #   LogActivity "The script has to be run from primary node and the current node is not primary" 
  #  LogActivity "FINAL STATUS = FAILURE"
  #  break


#}


if (!$PrimaryReplica -or !$SecondaryReplica) 
{
    LogActivity "Invalid Cluster nodes. Please check the Cluster name" 
    LogActivity "FINAL STATUS = FAILURE"
    break
}


#
[String]$ModuleLogFile = "C:\\SQLInstall_Logs\\AlwaysOn_Log_" + [System.DateTime]::Now.ToString("ddMMyyyyHHmm") + ".txt"
    if ((Test-Path $ModuleLogFile) -eq $false)
    {
         New-Item $ModuleLogFile -type file | Out-Null
         
    }
  #  else
   # {
   # Write-Output "The log file location is invalid. Please make sure the log file location exists" 
   # Write-Output "FINAL STATUS = FAILURE" -f red
   # break
   # }



# Function to log all activities to a text file.

function LogActivity([String]$log)
{
   
                
                 Add-Content $ModuleLogFile "`r`n$log" 
                
                 if ($log -match 'FAIL')
                 {
                   
                    $log | Write-Host -fore red  
                 }
                 elseif   ($log -match 'SUCCESS')
                 {
                    $log | Write-Host -fore  green  
                 }
                 else
                 {
                    $log | Write-Host 
                 }
}




if (!$AGGroupName)
{
    [String]$AGGroupName = $clustername.Name + "GRP"
}


if (!$DatabaseList -or ($DatabaseList -eq "ALL"))
{
    $DatabaseList = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4 and name not in (select db_name(database_id) from sys.dm_hadr_database_replica_states)" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
        
}


if ( !$DatabaseList) 
{
    LogActivity "No valid databases found to be added to the Availability Group. Please check the input variables" 
    LogActivity "FINAL STATUS = FAILURE"
    break
}

if ( !$AGGroupName) 
{
    LogActivity "Availability Group is empty. Please check the input variables" 
    LogActivity "FINAL STATUS = FAILURE"
    break
}

if (!$BackupPath)
{
    $BackupPath = $null
}



   if ($DatabaseList -match "ALL")
   {
    $DBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
    }
    
   
     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
 
    

        if (($DBList) -and ($DBinAG))
       {
        
        $errdb = Compare-Object -ReferenceObject $DBList  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }

    if ($DatabaseList -ne "ALL")
    {

    $PrimaryDBlist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
    
    if ($PrimaryDBlist)
    {
 
        $errdbexists = Compare-Object -ReferenceObject $PrimaryDBlist  -DifferenceObject $DatabaseList -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject

        if ($errdbexists)
    {
        $errdb1 = $errdbexists.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }
     }  
     else
             
     {
        
                $errdb1 = $DatabaseList.InputObject -join ','
        LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit
    }

    }




#backup and restore databases
try
{

    if ($BackupPath)
    {
  
    $bkuppathexist = [System.IO.Directory]::Exists($backuppath)
   
    if (!$bkuppathexist)
    {
        LogActivity "Invalid Backup Path specified, please specifcy valid path and run the script again."
        break
    }
   else
    {    
        $dt = get-date -format yyyyMMddHHmmss
        $dblists = $DatabaseList.split(",")
        foreach ($db in $dblists)
        {

            $dbbkpath = "$BackupPath\$db$dt.bak"

            $backupsrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $PrimaryReplica
            $backupsrvrconn.ConnectionContext.StatementTimeout = 0

            $restoresrvrconn = New-Object ("Microsoft.SQLServer.management.Smo.Server") $SecondaryReplica
            $restoresrvrconn.ConnectionContext.StatementTimeout = 0


            # Backup my database and its log on the primary
            Backup-SqlDatabase -Database $db -BackupFile "$dbbkpath" -InputObject $backupsrvrconn


            # Restore the database and log on the 1st secondary (using NO RECOVERY)
            Restore-SqlDatabase -Database $db -BackupFile "$dbbkpath"  -InputObject $restoresrvrconn -ReplaceDatabase -NoRecovery
            
        }
    }
       LogActivity "Backup and restore the databases for AlwaysOn:SUCCESS" 
    }   
  }
catch 
 {
    LogActivity "Failed to backup and restore databases to configure AlwaysOn"
    break
}





# Check if database exist


    $Primarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model = 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
        
    $Secondarysrvdatabaselist = (invoke-sqlcmd -query "select name from sys.databases where state = 1 and database_id > 4 " -ServerInstance $SecondaryReplica -QueryTimeout 120).name

     $DBinAG = (invoke-sqlcmd -query "select db_name(database_id) as name from sys.dm_hadr_database_replica_states" -ServerInstance $PrimaryReplica -QueryTimeout 120).name


            

  
        $dblists = $DatabaseList.split(",")
        
        if (($dblists) -and ($dbinAG))
       {
        $errdb = Compare-Object -ReferenceObject $dblists  -DifferenceObject $dbinAG -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject


        if ($errdb)
            {
            
                $exists = $false

                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is already part of Availability Group." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }

            }

      $errdb = Compare-Object -ReferenceObject $Primarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject

        if ($errdb)
            {
            
                $exists = $false
                $PrimarysrvdatabaselistOtherRecoveryModel = (invoke-sqlcmd -query "select name from sys.databases where state = 0 and recovery_model <> 1 and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                $errdbrecmodel = Compare-Object -ReferenceObject $dblists  -DifferenceObject $PrimarysrvdatabaselistOtherRecoveryModel -IncludeEqual  | ?{$_.SideIndicator -eq "=="} | select inputobject
                $PrimarysrvdatabaselistExists = (invoke-sqlcmd -query "select name from sys.databases where state = 0  and database_id > 4" -ServerInstance $PrimaryReplica -QueryTimeout 120).name
                
                $errdbexists = Compare-Object -ReferenceObject $PrimarysrvdatabaselistExists  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject
                if ($errdbrecmodel)
                {
                $errdbrecmodel1 = $errdbrecmodel.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbrecmodel1 has to be in full recovery model in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                if ($errdbexists)
                {
                $errdbexists1 = $errdbexists.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdbexists1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
                exit
                }
                else
                {
                 $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in primary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                
                }
            }

           if ($Secondarysrvdatabaselist)
           {
            $errdb = Compare-Object -ReferenceObject $Secondarysrvdatabaselist  -DifferenceObject $Dblists -IncludeEqual  | ?{$_.SideIndicator -eq "=>"} | select inputobject


            if ($errdb)
            {
            
                $exists = $false
                $errdb1 = $errdb.InputObject -join ','
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $errdb1 is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }
            }
            else
            {
                LogActivity "Validating the databases for AlwaysOn:FAILURE. The databases $databaselist is not found in secondary replica." 
                LogActivity "FINAL STATUS = FAILURE"
                exit

            }








# Add Databases to AlwaysOn Availability Groups for user selected dtatabses.
#
$PrimaryServer = $PrimaryReplica1
$SecondaryServer = $SecondaryReplica1
try
{
    LogActivity "Adding database to Availability Group"  
       # Creating Availability Group on Primary
  
    $dblists = $DatabaseList.split(",")
    foreach ($db in $dblists)
    {
    
        $sqlquery1 = "ALTER AVAILABILITY GROUP $AGGroupName ADD DATABASE $db"
        Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery1 -QueryTimeout 200 -ea 'Stop'
        $sqlquery2 = "ALTER DATABASE $db SET HADR AVAILABILITY GROUP =  $AGGroupName "
        Invoke-Sqlcmd -ServerInstance $SecondaryReplica1 -Query $sqlquery2 -QueryTimeout 200 -ea 'Stop'      
    }
      LogActivity "Databases have been added to Avaialbility Group" 
      LogActivity "SQL IQOQ verification PASSSED"
      Return $true                          
}
catch
{
    Logactivity $_.exception.message
    LogActivity "Error adding databases to Availability Group"
    LogActivity "FINAL STATUS = FAILURE"
    LogActivity "SQL IQOQ verification FAILED. Return code is 1"
    LogActivity "All the changes have been rolled back.Please review the verification steps and address the failed step"
    Return $false
    break

}







