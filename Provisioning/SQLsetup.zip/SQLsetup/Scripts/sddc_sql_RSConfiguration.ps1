###################################################################################################
$ScriptName = "sddc_sql_RSConfiguration.PS1"
$Scriptver = "1.0"
#Description: Reporting services configuration for SQL2012, SQL2008 and SQL2005
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			10-Sept-2015	Jay Sangam	New Script
 
###################################################################################################

$sqlver = $args[0]

IF (($sqlver -ne "SQL2005") -and ($sqlver -ne "SQL2008") -and ($sqlver -ne "SQL2012"))
{
Write-Host ""
Write-Host "SQL Version not Valid. Pass SQL2012 or SQL2008 or SQL2005 as a parameter" -f red
Write-Host ""
EXIT
}


Try
{
   Write-Host ""
   $RSSVCAcct = 'ReportServer'
   Start-Service -Name $RSSVCAcct
   Set-service $RSSVCAcct -startup Automatic

   IF ($sqlver -eq "SQL2012")
    {
	Write-host ""
    	write-host "Attempting Connection to $sqlver RS instance.."
	Write-host ""
	$s = New-Object Management.ManagementScope("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v11\Admin")
	$s.Connect()

	$sc = New-Object Management.ManagementClass("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v11\Admin:MSReportServer_ConfigurationSetting")
	$sc.Get()
    }
   ELSEIF ($sqlver -eq "SQL2008")
    {
	Write-host ""
    	write-host "Attempting Connection to $sqlver RS instance.."
	Write-host ""
	$s = New-Object Management.ManagementScope("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v10\Admin")
	$s.Connect()

	$sc = New-Object Management.ManagementClass("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v10\Admin:MSReportServer_ConfigurationSetting")
	$sc.Get()
    }
   ELSEIF ($sqlver -eq "SQL2005")
    {
	Write-host ""
    	write-host "Attempting Connection to $sqlver RS instance.."
	Write-host ""
	$s = New-Object Management.ManagementScope("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v9\Admin")
	$s.Connect()

	$sc = New-Object Management.ManagementClass("\\localhost\root\Microsoft\SqlServer\ReportServer\RS_MSSQLServer\v9\Admin:MSReportServer_ConfigurationSetting")
	$sc.Get()
    }

}

Catch

{
    write-host "Caught an exception:" -ForegroundColor Red
    write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
    write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""

    IF ( $($_.Exception.Message) -match 'Invalid namespace')
     {
       Write-Host "Check whether default instance for $sqlver is available or not"
       Write-host ""
       EXIT
     }
}

$insts = $sc.GetInstances()
foreach ($n in $insts) 
{
 $inst = $n
}


#------------------------------- SQLCMD path -------------------------------
  $fso = New-Object -ComObject Scripting.FileSystemObject

  IF ($sqlver -eq "SQL2012")
  {
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
  }

  ELSEIF ($sqlver -eq "SQL2008")

  {
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\Setup").SQLPath).ShortPath
  }

  ELSEIF ($sqlversion -eq "SQL2005")

  {
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\Setup").SQLPath).ShortPath
  }

# Write-Host "Tools folder path is $ToolsFolder"

#---------------------------- Modify Web.Config file ---------------------------------------

IF ($sqlver -eq "SQL2012")
{
 $webconfigpath = "D:\MSSQL2012\MSRS11.MSSQLSERVER\Reporting Services\ReportManager"
}
ELSEIF ($sqlver -eq "SQL2008")
{
 $webconfigpath = "D:\MSSQL2008\MSRS10.MSSQLSERVER\Reporting Services\ReportManager"
}

IF (Test-path ($webconfigpath + "\Web_Original.config"))

{
 $lines = Get-Content ($webconfigpath + "\Web_Original.config")
 $pos = [array]::indexof($lines, $lines -like "*<system.web>")
}
ELSE
{
 $lines = Get-Content ($webconfigpath + "\Web.config")
 $pos = [array]::indexof($lines, $lines -like "*<system.web>")
 Rename-Item ($webconfigpath + "\Web.config") ($webconfigpath + "\Web_Original.config")
}

$machineKey = '    <machineKey validationKey="AutoGenerate,IsolateApps" decryptionKey="AutoGenerate,IsolateApps" validation="3DES" decryption="3DES"/>'
$newLines = $lines[0..($pos + 1)], $machineKey, $lines[($pos + 2)..($lines.Length - 1)]

$newLines | Set-Content ($webconfigpath + "\Web.config")

#-------------------------------------------------------------------------------------------

# Set Virtual Directories
$inst.RemoveURL("ReportServerWebService", "http://+:80", 1033);
$inst.RemoveURL("ReportManager", "http://+:80", 1033);

$inst.SetVirtualDirectory("ReportServerWebService", "ReportServer", 1033);
$inst.SetVirtualDirectory("ReportManager", "ReportManager", 1033);

$inst.ReserveURL("ReportServerWebService", "http://+:80", 1033);
$inst.ReserveURL("ReportManager", "http://+:80", 1033);

If (Test-Path C:\RSConfig)
{
  Remove-Item C:\RSConfig -recurse
  Start-Sleep -s 4
}
mkdir C:\RSConfig

# Create RS Database
$script = $inst.GenerateDatabaseCreationScript("ReportServer", 1033, $false);
$script.Script | Out-File C:\RSConfig\rs.sql

$rs_cmd = $ToolsFolder + "\Binn\SQLCMD.exe -S $env:COMPUTERNAME -i C:\RSConfig\rs.sql -o C:\RSConfig\rs_output.txt -x && exit 0 || exit 1"
& cmd.exe /c $rs_cmd | out-null

[string] $UName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

$script = $inst.GenerateDatabaseRightsScript($UName, "ReportServer", $false, $true);
$script.Script | Out-File C:\RSConfig\rs2.sql

$rs2_cmd = $ToolsFolder + "\Binn\SQLCMD.exe -S $env:COMPUTERNAME -i C:\RSConfig\rs2.sql -o C:\RSConfig\rs2_output.txt -x && exit 0 || exit 1"
& cmd.exe /c $rs2_cmd | out-null

$inst.SetDatabaseConnection("$env:COMPUTERNAME", "ReportServer", 2, "", "");


  $RSLoginScript = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\RSLogin.sql'
  Write-Host "Adding NT Service\ReportServer to sysadmin role.."
  $AddRSLogin = $ToolsFolder + "\Binn\SQLCMD.exe -S $env:COMPUTERNAME -i $RSLoginScript -o C:\RSConfig\RSLogin_output.txt -x && exit 0 || exit 1"
  & cmd.exe /c $AddRSLogin | out-null


#$inst.SetWindowsServiceIdentity($false, "<domain\username>", "<password>");
#$inst.SetUnattendedExecutionAccount("<domain\username>", "<password>");

$inst.SetServiceState($true, $true, $true);

Restart-Service -Name $RSSVCAcct

If (Test-Path C:\RSConfig)
{
  Remove-Item C:\RSConfig\*.sql -recurse
  Start-Sleep -s 4
}

Write-Host ""
Write-Host "##############################################################"
Write-Host ""
Write-Host "$sqlver Reporting services configuration completion : " -f white -nonewline; Write-Host "SUCCESS" -f green
Write-Host ""
Write-Host "##############################################################"

# $inst.SetEmailConfiguration($true, "smtp.mycompany.com", "reporting.services@mycompany.co.uk")
