###################################################################################################
$ScriptName = "sddc_sql_Size_PreCheck_MEMORY.PS1"
$Scriptver = "1.0"
#Description: Script used to check SQL Server memory when size of VM is changed.
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			10/07/2016	Bruno Campos	New Script
###################################################################################################

####
#*********** Lab DML************* 
#$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML' 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\SDDC' 
$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl


#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
#####

#Number of CPUs passed by VRA
$ErrorActionPreference = "SilentlyContinue"
$error.clear()
$N_MEMORY = $args[0]


#*********************************** Start of Post installation function ***********************************#

FUNCTION sddc_sql_Size_Modification($IDMLLOC)  
{

$Time = get-date -Uformat "%Y%m%d%H%M"
$Log = "C:\SQLInstall_Logs\sddc_sql_Size_PreCheck_MEMORY_$Time.txt"
$M_Plans_sql = $IDMLLOC + "\Scripts"

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Inst_Status = $svr.status
IF ($Inst_Status -ne "OnLine")
{
$Final_Status_Error = 1
}
ELSE
{
$Final_Status_Error = 0


$conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
$conn.Open()

#--------------------------------- Checking Memory Allocation ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$Max_Mem = (($N_MEMORY*1024)*0.75)-1
$cmdDD_4 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_4.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max server memory (MB)'"
$cmdDD_4.Connection = $conn
$SQL_Mem = $cmdDD_4.ExecuteScalar()
if ($Max_Mem -ne $SQL_Mem)
{
	Write-Host "Expected value for memory allocation to SQL Server : $Max_Mem"
	Write-Host "Current value of memory allocated to SQL Server : $SQL_Mem"
	"Expected value for memory allocation to SQL Server : $Max_Mem" >> $Log
	"Current value of memory allocated to SQL Server : $SQL_Mem" >> $Log
}
ELSE
{
	Write-Host "Expected value for memory allocation to SQL Server : $Max_Mem"
	Write-Host "Current value of memory allocated to SQL Server :  $SQL_Mem"
	"Expected value for memory allocation to SQL Server : $Max_Men" >> $Log
	"Current value of memory allocated to SQL Server : $SQL_Mem" >> $Log
}
}
IF ($Final_Status_Error -eq 1)
{
Write-Host "STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"STATUS = FAILED" >> $Log
Write-Host "SQl Server instance not on-line"
"SQl Server instance not on-line" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Exit 0
}

}

#*********************************** End of Post installation function ***********************************#


#--------- Start POST install configuration ---------#

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1
$ipAddressParts = $GetIp.Split('.') 

$IpPartsIdentifier1 = $ipAddressParts[0]
$IpPartsIdentifier2 = $ipAddressParts[1]
$IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	sddc_sql_Size_Modification $LabSQLDML

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

	sddc_sql_Size_Modification $NASQLDML
 }
}

#--------- End POST install configuration ---------#

