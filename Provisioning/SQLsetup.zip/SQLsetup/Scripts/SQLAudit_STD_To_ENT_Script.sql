/* ---------------------------------------------------------------------------------------------*/
/* SCRIPTS TO ENABLE AND CONFIGURE THE SQL SERVER 2008 ENT / 2012 ENT NATIVE AUDITING FEATURE	*/
/* THIS SCRIPT WILL:														 					*/
/*			1. CREATE FOLDER SAVE LOGS FROM WINDOWS APPLICATION LOG WITH RETATION OF 7 DAYS		*/
/*			2. CREATE SERVER AND DATABASE PARAMETER TO BE AUDITED								*/
/*			3. CREATE TABLES AND SP's IN master DB TO MAINTAIN THE PROCESS						*/
/*			4. CREATE JOBS TO MAINTAIN THE PROCESS												*/
/*----------------------------------------------------------------------------------------------*/
/* Date Of Issued	Revision Number		Author			Reason for Change						*/
/*----------------------------------------------------------------------------------------------*/
/* N/A				1.0					N/A				- New Procedure							*/
/* 09/25/2013		2.0					Bruno Campos	- Removed auditing of DML				*/
/*														- Added process to save the events from	*/ 
/*														  Windows Application Log and only keep */
/*														  the last 7 days						*/
/*	12/19/2016		3.0					Bruno Campos	- Add process to remove Native Audit	*/
/*														  for SQL STANDARD, if implemented.		*/
/*----------------------------------------------------------------------------------------------*/

USE [master]
GO

IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'ITIS_NativeAudit')
BEGIN

/*Stop audit of STANDARD EDITION */
declare	@traceid int,
		@desc varchar(2000)

-- Get Trace Info
declare c1 cursor
for
select distinct traceid 
FROM :: fn_trace_getinfo(default)
where value in ('D:\SQLNativeAudit\SecurityEventAudit.trc','D:\SQLNativeAudit\DBAActivityEventAudit.trc','D:\SQLNativeAudit\ddlActivityEventAudit.trc')
open c1
fetch c1 into @traceid
while @@fetch_status = 0
begin
	-- Stop Trace
	exec sp_trace_setstatus @traceid, 0
	-- Close Trace
	exec sp_trace_setstatus @traceid, 2
	fetch c1 into @traceid
end
close c1
deallocate c1

exec Usp_ImportTraceData

-------
EXEC Usr_admin_delete_files_by_date
@SourceDir = 'D:\SQLNativeAudit\',
@SourceFile = '*.txt',
@DaysToKeep = 7

EXEC Usr_admin_delete_files_by_date
@SourceDir = 'D:\SQLNativeAudit\',
@SourceFile = '*.trc*',
@DaysToKeep = 7
-------
Exec Usr_SQL258AuditReport
-------
EXEC Usp_SaveEventsInWindowsLog
/***********************************************************/

EXEC msdb.dbo.sp_delete_job @job_name=N'ITIS_NativeAudit', @delete_unused_schedule=1
EXEC msdb.dbo.sp_delete_job @job_name=N'ITIS_StopNativeAudit', @delete_unused_schedule=1
DROP TABLE [dbo].[DatabaseSecurityAuditEvents]
DROP TABLE [dbo].[DatabaseSecurityAuditEventsHistory]
DROP TABLE [dbo].[SQLTraceEvents]
DROP TABLE [dbo].[TmpSecurityAuditEvents]
DROP VIEW [dbo].[vw_auditcsvexport]
DROP PROCEDURE [dbo].[Usp_DBAActivityEventAudit]
DROP PROCEDURE [dbo].[Usp_DDLActivityEventAudit]
DROP PROCEDURE [dbo].[Usp_ExecuteTrace]
DROP PROCEDURE [dbo].[Usp_ImportTraceData]
DROP PROCEDURE [dbo].[Usp_RenameTraceFiles]
DROP PROCEDURE [dbo].[Usp_SaveEventsInWindowsLog]
DROP PROCEDURE [dbo].[Usp_SecurityEventAudit]
DROP PROCEDURE [dbo].[Usp_UpdateAuditEventData]
DROP PROCEDURE [dbo].[Usr_admin_delete_files_by_date]
DROP PROCEDURE [dbo].[Usr_SQL258AuditReport]
END

USE [master] 
GO

EXEC xp_cmdshell 'MD D:\SQLNativeAudit'
GO

IF  EXISTS (SELECT * FROM sys.server_audits WHERE name = N'SQL_NATIVE_AUDIT')
BEGIN
ALTER SERVER AUDIT [SQL_NATIVE_AUDIT] WITH (STATE = OFF)
DROP SERVER AUDIT [SQL_NATIVE_AUDIT]
END
GO

CREATE SERVER AUDIT [SQL_NATIVE_AUDIT] 
TO APPLICATION_LOG
WITH 
(  QUEUE_DELAY = 0 
   ,ON_FAILURE = CONTINUE 
 ) 
GO 

ALTER SERVER AUDIT [SQL_NATIVE_AUDIT]
WITH (STATE = ON)

-- TO CONFIGURE THE SERVER LEVEL AUDIT SPECIFICATION EVENT GROUPS

IF  EXISTS (SELECT * FROM sys.server_audit_specifications WHERE name = N'SERVER_MGMT_SPEC')
BEGIN
ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC] WITH (STATE = OFF)
DROP SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
END
GO

CREATE SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
	FOR SERVER AUDIT [SQL_NATIVE_AUDIT]
		ADD (SUCCESSFUL_LOGIN_GROUP),
		ADD (LOGOUT_GROUP),
		ADD (FAILED_LOGIN_GROUP),
		ADD (APPLICATION_ROLE_CHANGE_PASSWORD_GROUP),
		ADD (AUDIT_CHANGE_GROUP),
		ADD (DATABASE_OBJECT_CHANGE_GROUP),
		ADD (DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP),
		ADD (DATABASE_OWNERSHIP_CHANGE_GROUP),
		ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),
		ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP),
		ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),
		ADD (SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP),
		ADD (SERVER_OBJECT_CHANGE_GROUP),
		ADD (SERVER_OPERATION_GROUP),
		ADD (SERVER_PRINCIPAL_CHANGE_GROUP),
		ADD (SERVER_PRINCIPAL_IMPERSONATION_GROUP),
		ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
		ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),
		ADD (DATABASE_PERMISSION_CHANGE_GROUP),
		ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP),
		ADD (SERVER_OBJECT_PERMISSION_CHANGE_GROUP),
		ADD (SERVER_PERMISSION_CHANGE_GROUP)
	WITH (STATE = ON)
GO
/* 
THE SCRIPT TO CONFIGURE AND ENABLE THE DATABASE LEVEL AUDIT EVENT GROUPS FOR EACH READ/WRITE DATABASE
 * NOTE:-  IF WE WANT TO OMIT ANY DATABASES INCLUDE THE DATABASE NAME IN THE WHERE CLAUSE
		   WHERE NAME NOT IN ('master','model','msdb','tempdb') 
*/

DECLARE C1 CURSOR FOR SELECT NAME FROM sys.databases WHERE NAME NOT IN ('master','model','msdb','tempdb') and is_read_only <> 1
AND STATE = 0  
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(MAX)
DECLARE @command1 VARCHAR(MAX)

-- THE BELOW COMMAND WILL EXECUTE FOR EACH DATABASE TO CONFIGURE THE DATABASE LEVEL EVENT GROUPS

OPEN C1
FETCH NEXT FROM C1 INTO @DBNAME
WHILE @@FETCH_STATUS = 0
BEGIN
-- THE BELOW COMMAND WILL EXECUTE FOR EACH DATABASE TO CONFIGURE THE DATABASE LEVEL EVENT GROUPS
SET @command1= 'USE [' + @DBNAME +'];' + 
'IF  EXISTS (SELECT * FROM sys.database_audit_specifications WHERE name = N''' + @DBNAME +'_DB_MGMT_SPEC'')' +
'BEGIN; ALTER DATABASE AUDIT SPECIFICATION [' + @DBNAME +'_DB_MGMT_SPEC] WITH (STATE = OFF);'+
'DROP DATABASE AUDIT SPECIFICATION [' + @DBNAME +'_DB_MGMT_SPEC]; END;'
EXECUTE (@command1);
SET @command= 'USE [' + @DBNAME +'];' + ' CREATE DATABASE AUDIT SPECIFICATION ['+@DBNAME+ '_DB_MGMT_SPEC]'+
' FOR SERVER AUDIT [SQL_NATIVE_AUDIT]' +
' ADD (AUDIT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP),'+
' ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),'+
' ADD (DATABASE_PERMISSION_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_owner]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_accessadmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_datawriter]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_ddladmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_securityadmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_backupoperator])'+
' WITH (STATE = ON);' 
EXECUTE (@command);
FETCH NEXT FROM C1 INTO @DBNAME
END
CLOSE C1
DEALLOCATE C1
GO

/* 
THE SCRIPT TO CONFIGURE AND ENABLE THE DATABASE LEVEL AUDIT EVENT GROUPS FOR EACH READ ONLY DATABASE
 * NOTE:-  IF WE WANT TO OMIT ANY DATABASES INCLUDE THE DATABASE NAME IN THE WHERE CLAUSE
		   WHERE NAME NOT IN ('master','model','msdb','tempdb') 
*/

DECLARE C1 CURSOR FOR SELECT NAME FROM sys.databases WHERE NAME NOT IN ('master','model','msdb','tempdb') and is_read_only = 1
AND STATE = 0  
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(MAX)
DECLARE @command1 VARCHAR(MAX)

-- THE BELOW COMMAND WILL EXECUTE FOR EACH DATABASE TO CONFIGURE THE DATABASE LEVEL EVENT GROUPS
OPEN C1
FETCH NEXT FROM C1 INTO @DBNAME
WHILE @@FETCH_STATUS = 0
BEGIN
-- THE BELOW COMMAND WILL EXECUTE FOR EACH DATABASE TO CONFIGURE THE DATABASE LEVEL EVENT GROUPS
SET @command1= 'USE master; ALTER DATABASE [' + @DBNAME +'] SET READ_WRITE; USE [' + @DBNAME +'];' + 
'IF  EXISTS (SELECT * FROM sys.database_audit_specifications WHERE name = N''' + @DBNAME +'_DB_MGMT_SPEC'')' +
'BEGIN; ALTER DATABASE AUDIT SPECIFICATION [' + @DBNAME +'_DB_MGMT_SPEC] WITH (STATE = OFF);'+
'DROP DATABASE AUDIT SPECIFICATION [' + @DBNAME +'_DB_MGMT_SPEC]; END;'
EXECUTE (@command1);
SET @command= 'USE [' + @DBNAME +'];' + ' CREATE DATABASE AUDIT SPECIFICATION ['+@DBNAME+ '_DB_MGMT_SPEC]'+
' FOR SERVER AUDIT [SQL_NATIVE_AUDIT]' +
' ADD (AUDIT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP),'+
' ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),'+
' ADD (DATABASE_PERMISSION_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_owner]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_accessadmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_datawriter]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_ddladmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_securityadmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_backupoperator])'+
' WITH (STATE = ON);'+
'USE master; ALTER DATABASE [' + @DBNAME +'] SET READ_ONLY;' 
EXECUTE (@command);
FETCH NEXT FROM C1 INTO @DBNAME
END
CLOSE C1
DEALLOCATE C1
GO

/*
SCRIPT TO DROP TABLES AND SPs USED BY AUDIT TO FILE
*/
USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[SQLNATIVEADUTINGEVENTS]') AND TYPE IN (N'U'))
DROP TABLE [dbo].[SQLNATIVEADUTINGEVENTS]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TMPSQLNATIVEADUTINGEVENTS]') AND TYPE IN (N'U'))
DROP TABLE [dbo].[TMPSQLNATIVEADUTINGEVENTS]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_ADMIN_DELETE_FILES_BY_DATE]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_ADMIN_DELETE_FILES_BY_DATE]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_SQLAUDITREPORT]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_SQLAUDITREPORT]
GO



/*
SCRIPT TO CREATE THE TABLE FOR STORING THE SERVER AUDIT SPECIFICATION GROUPS
*/
USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_SERVERAUDITGRP]') AND TYPE IN (N'U', N'PC'))
DROP TABLE [dbo].[USR_SERVERAUDITGRP]
GO

CREATE TABLE dbo.USR_SERVERAUDITGRP
(AUDIT_ACTION_NAME NVARCHAR(60) NOT NULL,
 IS_ENABLED CHAR(1) NOT NULL,
 YEAR VARCHAR(4) NOT NULL)
GO

INSERT INTO [master].[dbo].[USR_SERVERAUDITGRP]
VALUES ('SUCCESSFUL_LOGIN_GROUP', 'Y', '2012')
, ('LOGOUT_GROUP', 'Y' , '2012')
, ('FAILED_LOGIN_GROUP', 'Y' , '2011')
, ('APPLICATION_ROLE_CHANGE_PASSWORD_GROUP', 'Y' , '2011')
, ('AUDIT_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_OBJECT_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_OWNERSHIP_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_PRINCIPAL_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_PRINCIPAL_IMPERSONATION_GROUP', 'Y' , '2011')
, ('DATABASE_ROLE_MEMBER_CHANGE_GROUP', 'Y' , '2011')
, ('SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP', 'Y' , '2011')
, ('SERVER_OBJECT_CHANGE_GROUP', 'Y' , '2011')
, ('SERVER_OPERATION_GROUP', 'Y' , '2011')
, ('SERVER_PRINCIPAL_CHANGE_GROUP', 'Y' , '2011')
, ('SERVER_PRINCIPAL_IMPERSONATION_GROUP', 'Y' , '2011')
, ('SERVER_ROLE_MEMBER_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_OBJECT_PERMISSION_CHANGE_GROUP', 'Y' , '2011')
, ('DATABASE_PERMISSION_CHANGE_GROUP', 'Y' , '2011')
, ('SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP','Y','2011')
, ('SERVER_OBJECT_PERMISSION_CHANGE_GROUP', 'Y' , '2011')
, ('SERVER_PERMISSION_CHANGE_GROUP', 'Y' , '2011')
GO

/*
SCRIPT TO CREATE THE TABLE FOR STORING THE DATABASE AUDIT SPECIFICATION GROUPS
*/
USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_DBAUDITGRP]') AND TYPE IN (N'U', N'PC'))
DROP TABLE [dbo].[USR_DBAUDITGRP]
GO

CREATE TABLE [dbo].[USR_DBAUDITGRP](
	[AUDIT_ACTION_NAME] [NVARCHAR](60) NULL,
	[AUDITED_PRINCIPAL_ID] [INT] NULL,
	[IS_GROUP] [BIT] NULL
) ON [PRIMARY]
GO

INSERT INTO [master].[dbo].[USR_DBAUDITGRP]
VALUES ('AUDIT_CHANGE_GROUP',0,1),
('DATABASE_OBJECT_CHANGE_GROUP',0,1),
('DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP',0,1),
('DATABASE_OWNERSHIP_CHANGE_GROUP',0,1),
('DATABASE_PRINCIPAL_CHANGE_GROUP',0,1),
('DATABASE_PRINCIPAL_IMPERSONATION_GROUP',0,1),
('DATABASE_ROLE_MEMBER_CHANGE_GROUP',0,1),
('SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP',0,1),
('DATABASE_OBJECT_PERMISSION_CHANGE_GROUP',0,1),
('DATABASE_PERMISSION_CHANGE_GROUP',0,1),
('SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP',0,1)

/*
SCRIPT TO CREATE THE PROCEDURE FOR ADD MISSING DATABASE AUDIT GROUP
*/

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_ADDMISSING_DBAUDITGRP]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_ADDMISSING_DBAUDITGRP]
GO

CREATE PROCEDURE [dbo].[USR_ADDMISSING_DBAUDITGRP] AS    
SET NOCOUNT ON    
SET ANSI_NULLS  OFF    
SELECT IDENTITY(INT, 1,1) AS ID_NUM, NAME INTO #DBS     
FROM sys.databases WHERE NAME NOT IN ('master','tempdb','model','msdb') AND STATE=0 AND is_read_only <> 1     
DECLARE @CT INT    
DECLARE @CT1 AS INT    
DECLARE @CNT AS INT    
DECLARE @CNT1 AS INT    
DECLARE @DBNAME VARCHAR(100)    
DECLARE @INS VARCHAR(1000)    
DECLARE @command VARCHAR(1000)    
DECLARE @CMD VARCHAR(1000)    
  
SET @CT=1    
SELECT @CT1=COUNT(1) FROM #DBS    
WHILE @CT<=@CT1    
BEGIN    
 SELECT @DBNAME=NAME FROM #DBS WHERE ID_NUM=@CT    
 --SET @CMD='USE ' + @DBNAME   
 --EXEC(@CMD)  
 
 SELECT IDENTITY(INT, 1,1) AS NUM,AUDIT_ACTION_NAME  INTO #INS        
 FROM master.dbo.USR_DBAUDITGRP WHERE IS_GROUP=1       
 AND AUDIT_ACTION_NAME NOT IN (SELECT AUDIT_ACTION_NAME FROM master.dbo.USR_USERDBSSPEC WHERE SUBSTRING(NAME, 1,  LEN(NAME) - 13) =@DBNAME)      
 SELECT @CNT1=COUNT(1) FROM #INS    
 SET @CMD= 'USE [' + @DBNAME +'];' + ' ALTER DATABASE AUDIT SPECIFICATION ['+@DBNAME+'_DB_MGMT_SPEC]  WITH (STATE=OFF) '     
 EXEC (@CMD)    
 SET @CNT=1  
     
 WHILE @CNT<=@CNT1    
 BEGIN    
   SELECT @INS=AUDIT_ACTION_NAME FROM #INS WHERE NUM=@CNT  
   SET @command= 'USE [' + @DBNAME +'];' + ' ALTER DATABASE AUDIT SPECIFICATION ['+@DBNAME+'_DB_MGMT_SPEC]'+    
   ' ADD ('+ @INS + ')'    
   EXEC (@command);    
     SELECT @CNT=@CNT+1    
 END        
    DROP TABLE #INS    
    SET @CT=@CT+1    
    SET @CMD=''
    SET @CMD= 'USE [' + @DBNAME +'];' + ' ALTER DATABASE AUDIT SPECIFICATION ['+@DBNAME+'_DB_MGMT_SPEC]  WITH (STATE=ON) '     
    EXEC (@CMD)   
END  
GO

/*
SCRIPT TO CREATE THE PROCEDURE FOR ADD MISSING SERVER AUDIT GROUP
*/

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_ADDMISSING_SRAUDITGRP]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_ADDMISSING_SRAUDITGRP]
GO

CREATE PROCEDURE [dbo].[USR_ADDMISSING_SRAUDITGRP]
AS 

DECLARE @AANAME VARCHAR(50)
DECLARE @command VARCHAR(MAX)

DECLARE C1 CURSOR FOR SELECT AUDIT_ACTION_NAME FROM USR_SERVERAUDITGRP
WHERE AUDIT_ACTION_NAME NOT IN (SELECT AUDIT_ACTION_NAME FROM sys.server_audit_specification_details)

OPEN C1

FETCH NEXT FROM C1 INTO @AANAME

-- TO DISABLE
ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
WITH (STATE=OFF);

WHILE @@FETCH_STATUS = 0

BEGIN

SET @command= 'ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]'+
' ADD (' + @AANAME + ')'
EXECUTE (@command);

FETCH NEXT FROM C1 INTO @AANAME

END

CLOSE C1

DEALLOCATE C1

-- TO ENABLE
ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
WITH (STATE=ON);
GO

/*
SCRIPT TO CREATE THE PROCEDURE TO ENABLE THE AUDITING FOR THE NEW DATABASES
*/

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_AUDITENABLE_NEWDB]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_AUDITENABLE_NEWDB]
GO

CREATE PROCEDURE [dbo].[USR_AUDITENABLE_NEWDB]
AS

DECLARE C1 CURSOR FOR 
SELECT NAME FROM sys.databases WHERE NAME NOT IN 
(SELECT SUBSTRING(NAME, 1,  LEN(NAME) - 13) FROM master.dbo.USR_USERDBSSPEC ) AND 
NAME NOT IN ('master','tempdb','model','msdb') AND STATE=0
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(2000)

OPEN C1

FETCH NEXT FROM C1 INTO @DBNAME

WHILE @@FETCH_STATUS = 0

BEGIN

SET @command= 'USE [' + @DBNAME +'];' + ' CREATE DATABASE AUDIT SPECIFICATION ['+@DBNAME+ '_DB_MGMT_SPEC]'+
' FOR SERVER AUDIT [SQL_NATIVE_AUDIT]' +
' ADD (AUDIT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),'+
' ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP),'+
' ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP),'+
' ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),'+
' ADD (DATABASE_PERMISSION_CHANGE_GROUP),'+
' ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_accessadmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_datawriter]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_ddladmin]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_owner]),'+
--' ADD (INSERT, DELETE, UPDATE ON  DATABASE ::[' + @DBNAME + '] BY [db_security_admin])'+
' WITH (STATE = ON);' 
EXECUTE (@command);

FETCH NEXT FROM C1 INTO @DBNAME

END

CLOSE C1

DEALLOCATE C1
GO

/*
SCRIPT TO CREATE THE TABLE TO STORE THE  MISSING DATABASE AUDIT GROUP ON EACH DATABASE
*/

USE master 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_USERDBSSPEC]') AND TYPE IN (N'U', N'PC'))
DROP TABLE [dbo].[USR_USERDBSSPEC]
GO

CREATE TABLE master.dbo.USR_USERDBSSPEC (
NAME NVARCHAR(128) NULL,
AUDIT_ACTION_NAME NVARCHAR(60) NULL,
AUDITED_PRINCIPAL_ID INT NULL,
IS_GROUP BIT)

GO

/*
SCRIPT TO CREATE THE PROCEDURE TO ARCHIVE LOGS FROM WINDOWS APPLICATION LOG
*/
USE master 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_ARCHIVE_LOGS]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_ARCHIVE_LOGS]
GO


CREATE PROCEDURE [dbo].[USR_ARCHIVE_LOGS] (@SOURCEDIR VARCHAR(1024), @SOURCEFILE VARCHAR(512), @DAYSTOKEEP INT)
-- EXEC master.DBO.USR_ADMIN_DELETE_FILES_BY_DATE @SOURCEDIR = 'E:\SQLNATIVEAUDIT\<<SERVERNAME>>\'
--        , @SOURCEFILE = 'SQL_NATIVE_*'
--        , @DAYSTOKEEP = 7

AS

SET NOCOUNT ON

DECLARE @CURRENTFILEDATE CHAR(10)
 , @OLDFILEDATE CHAR(10)
 , @SOURCEDIRFOR VARCHAR(255)
 , @FILENAME VARCHAR(512)
 , @DYNDELETE VARCHAR(512)
 , @PROCESSNAME VARCHAR(150)
 , @OSVERSION DECIMAL(3,1)
 , @ERROR INT
 , @CURRENTDATE	VARCHAR(8)
 , @ALOG VARCHAR(512)

-- SAVE APPLICATION LOG EVENTS FROM LAST 24 HOURS
SET @CURRENTDATE = (SELECT CONVERT(VARCHAR,YEAR(GETDATE())) + CONVERT(VARCHAR,MONTH(GETDATE())) + CONVERT(VARCHAR,DAY(GETDATE())))
SET @ALOG = 'wevtutil qe Application  /rd:true /f:text /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]" >> '+@SOURCEDIR+'APPLICATION_LOG_'+@CURRENTDATE+'.log'
EXEC master..xp_cmdshell @ALOG


SET @PROCESSNAME = 'USR_ADMIN_DELETE_FILES_BY_DATE - [' + @SOURCEFILE + ']'
SET @CURRENTFILEDATE = CONVERT(CHAR(10),GETDATE(),121)
SET @OLDFILEDATE = CONVERT(CHAR(10),DATEADD(DD,-@DAYSTOKEEP,@CURRENTFILEDATE),121)
SET @SOURCEDIRFOR = 'FOR %I IN ("' + @SOURCEDIR + @SOURCEFILE + '") DO @ECHO %~NXTI'
SET @ERROR = 0


-- GET WINDOWS OS VERSION INFO FOR PROPER OSVER STATEMENT BLOCK EXEC.
CREATE TABLE #_OSVERSION
 ( [INDEX] INT
 , [NAME] VARCHAR(255)
 , [INTERNAL_VALUE] VARCHAR(255)
 , [CHARACTER_VALUE] VARCHAR(255) )

INSERT INTO #_OSVERSION
EXEC master..xp_msver 'WINDOWSVERSION'

SET @OSVERSION = (SELECT SUBSTRING([CHARACTER_VALUE],1,3) FROM #_OSVERSION)

-- START TEMP TABLE POPULATION(S).
CREATE TABLE #_FILE_DETAILS_01
 ( IDENT INT IDENTITY(1,1)
 , OUTPUT VARCHAR(512) )

INSERT INTO #_FILE_DETAILS_01
 EXEC master..xp_cmdshell @SOURCEDIRFOR

CREATE TABLE #_FILE_DETAILS_02
 (IDENT INT
 , [TIMESTAMP] DATETIME
 , [FILENAME] VARCHAR(255) )

-- OS VERSION SPECIFICS.
IF @OSVERSION = '5.0'
 BEGIN -- EXEC WINDOWS 2000 VERSION.
  INSERT INTO #_FILE_DETAILS_02
   SELECT IDENT
    , CONVERT(DATETIME, LEFT(CAST(SUBSTRING([OUTPUT],1,8) AS DATETIME),12)) AS [TIMESTAMP]
    , SUBSTRING([OUTPUT],17,255) AS [FILENAME]
    FROM #_FILE_DETAILS_01

   WHERE [OUTPUT] IS NOT NULL
   ORDER BY IDENT
 END

IF @OSVERSION = '5.1'
 BEGIN -- EXEC WINDOWS XP VERSION.
  INSERT INTO #_FILE_DETAILS_02
   SELECT IDENT
    , CONVERT(CHAR(10), SUBSTRING([OUTPUT],1,10), 121) AS [TIMESTAMP]
    , SUBSTRING([OUTPUT],21,255) AS [FILENAME]
    FROM #_FILE_DETAILS_01
 
   WHERE [OUTPUT] IS NOT NULL
   ORDER BY IDENT
 END

IF @OSVERSION = '5.2'
 BEGIN -- EXEC WINDOWS 2003 VERSION.
  INSERT INTO #_FILE_DETAILS_02
   SELECT IDENT
    , CONVERT(CHAR(10), SUBSTRING([OUTPUT],1,10), 121) AS [TIMESTAMP]
    , SUBSTRING([OUTPUT],21,255) AS [FILENAME]
    FROM #_FILE_DETAILS_01
 
   WHERE [OUTPUT] IS NOT NULL
   ORDER BY IDENT
 END

IF @OSVERSION = '6.0'
 BEGIN -- EXEC WINDOWS 2008 VERSION.
  INSERT INTO #_FILE_DETAILS_02
   SELECT IDENT
    , CONVERT(CHAR(10), SUBSTRING([OUTPUT],1,10), 121) AS [TIMESTAMP]
    , SUBSTRING([OUTPUT],21,255) AS [FILENAME]
    FROM #_FILE_DETAILS_01
 
   WHERE [OUTPUT] IS NOT NULL
   ORDER BY IDENT
 END

IF @OSVERSION = '6.1'
 BEGIN -- EXEC WINDOWS 2008 R2 VERSION.
  INSERT INTO #_FILE_DETAILS_02
   SELECT IDENT
    , CONVERT(CHAR(10), SUBSTRING([OUTPUT],1,10), 121) AS [TIMESTAMP]
    , SUBSTRING([OUTPUT],21,255) AS [FILENAME]
    FROM #_FILE_DETAILS_01
 
   WHERE [OUTPUT] IS NOT NULL
   ORDER BY IDENT
 END

-- START DELETE OPS CURSOR.
DECLARE CURDELFILE CURSOR
READ_ONLY
FOR

 SELECT [FILENAME]
  FROM #_FILE_DETAILS_02
 WHERE [TIMESTAMP] <= @OLDFILEDATE

OPEN CURDELFILE

FETCH NEXT FROM CURDELFILE INTO @FILENAME
WHILE (@@FETCH_STATUS <> -1)
BEGIN
 IF (@@FETCH_STATUS <> -2)
 BEGIN

  SET @DYNDELETE = 'DEL /Q "' + @SOURCEDIR + @FILENAME + '"'

  EXEC master..xp_cmdshell @DYNDELETE

 END
 FETCH NEXT FROM CURDELFILE INTO @FILENAME
END

CLOSE CURDELFILE
DEALLOCATE CURDELFILE

DROP TABLE #_OSVERSION
DROP TABLE #_FILE_DETAILS_01
DROP TABLE #_FILE_DETAILS_02

GO

/*
SCRIPT TO CREATE THE PROCEDURE TO CAPTURE MISSING DATABASE AUDIT GROUP ON EACH DATABASE
*/

USE [master]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[USR_MISSINGDBAUDITGRP]') AND TYPE IN (N'P', N'PC'))
DROP PROCEDURE [dbo].[USR_MISSINGDBAUDITGRP]
GO

CREATE PROCEDURE [dbo].[USR_MISSINGDBAUDITGRP]
AS 

TRUNCATE TABLE master.dbo.USR_USERDBSSPEC;

DECLARE C1 CURSOR FOR SELECT NAME FROM sys.databases WHERE NAME NOT IN ('master','model','msdb','tempdb') AND STATE=0 
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(2000)

OPEN C1

FETCH NEXT FROM C1 INTO @DBNAME

WHILE @@FETCH_STATUS = 0

BEGIN

SET @command= 'USE ['+ @DBNAME +'];' + 'INSERT INTO master.dbo.USR_USERDBSSPEC ' +
 'SELECT name, audit_action_name, audited_principal_id, is_group '+ 
 'FROM sys.database_audit_specification_details, sys.database_audit_specifications ' + 
 'WHERE sys.database_audit_specification_details.database_specification_id = sys.database_audit_specifications.database_specification_id'
--PRINT (@command);
EXECUTE (@command);

FETCH NEXT FROM C1 INTO @DBNAME

END

CLOSE C1

DEALLOCATE C1
GO
SELECT * FROM master.dbo.USR_USERDBSSPEC
GO

-- JOBS CREATION STEPS

USE [msdb]
GO

/****** OBJECT:  JOB [SQLNATIVEAUDIT_DISABLE_JOB]    SCRIPT DATE: 04/24/2012 15:03:12 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'SQLNATIVEAUDIT_DISABLE_JOB')
EXEC msdb.dbo.sp_delete_job @job_name=N'SQLNATIVEAUDIT_DISABLE_JOB', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** OBJECT:  JOB [SQLNATIVEAUDIT_DISABLE_JOB]    SCRIPT DATE: 04/24/2012 15:03:12 ******/
BEGIN TRANSACTION
DECLARE @RETURNCODE INT
SELECT @RETURNCODE = 0
/****** OBJECT:  JOBCATEGORY [[Uncategorized (Local)]]]    SCRIPT DATE: 04/24/2012 15:03:12 ******/
IF NOT EXISTS (SELECT * FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @RETURNCODE = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK

END

DECLARE @JOBID BINARY(16)
EXEC @RETURNCODE =  msdb.dbo.sp_add_job @job_name=N'SQLNATIVEAUDIT_DISABLE_JOB', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'THE JOB IS TO DISABLE THE SQL SERVER 2008 NATIVE AUDIT ON THE SERVER.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @JOBID OUTPUT
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
/****** OBJECT:  STEP [DISABLE_STEP]    SCRIPT DATE: 04/24/2012 15:03:13 ******/
EXEC @RETURNCODE = msdb.dbo.sp_add_jobstep @job_id=@JOBID, @step_name=N'DISABLE_STEP', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*
SCRIPT TO DISABLE THE SQL SERVER 2008 NATIVE AUDITING FEATURE
*/

/* 
TO DISABLE THE DATABASE AUDIT SPECIFICATIONS EVENTS
*/

DECLARE C1 CURSOR FOR SELECT NAME FROM sys.databases WHERE NAME NOT IN (''master'',''model'',''msdb'',''tempdb'') 
AND STATE = 0  
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(2000)

OPEN C1

FETCH NEXT FROM C1 INTO @DBNAME

WHILE @@FETCH_STATUS = 0

BEGIN

SET @command= ''USE ['' + @DBNAME +''];'' + '' ALTER DATABASE AUDIT SPECIFICATION [''+@DBNAME+ ''_DB_MGMT_SPEC]''+
'' WITH (STATE = OFF);'' 
--PRINT (@command);
EXECUTE (@command);

FETCH NEXT FROM C1 INTO @DBNAME

END

CLOSE C1

DEALLOCATE C1

GO

USE [master]
GO

-- TO DISABLE THE SQL NATIVE AUDITING

ALTER SERVER AUDIT [SQL_NATIVE_AUDIT]
WITH (STATE = OFF)

-- TO DISABLE THE SERVER AUDIT SPECIFICATION EVENTS

ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
WITH (STATE = OFF)

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
EXEC @RETURNCODE = msdb.dbo.sp_update_job @job_id = @JOBID, @start_step_id = 1
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
EXEC @RETURNCODE = msdb.dbo.sp_add_jobserver @job_id = @JOBID, @server_name = N'(LOCAL)'
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
COMMIT TRANSACTION
GOTO ENDSAVE
QUITWITHROLLBACK:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
ENDSAVE:

GO


-- SQLNATIVEAUDIT_ENABLE_JOB - JOB CREATION SCRIPT

USE [msdb]
GO

/****** OBJECT:  JOB [SQLNATIVEAUDIT_ENABLE_JOB]    SCRIPT DATE: 04/24/2012 15:04:22 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'SQLNATIVEAUDIT_ENABLE_JOB')
EXEC msdb.dbo.sp_delete_job @job_name=N'SQLNATIVEAUDIT_ENABLE_JOB', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** OBJECT:  JOB [SQLNATIVEAUDIT_ENABLE_JOB]    SCRIPT DATE: 04/24/2012 15:04:22 ******/
BEGIN TRANSACTION
DECLARE @RETURNCODE INT
SELECT @RETURNCODE = 0
/****** OBJECT:  JOBCATEGORY [[Uncategorized (Local)]]]    SCRIPT DATE: 04/24/2012 15:04:22 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @RETURNCODE = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK

END

DECLARE @JOBID BINARY(16)
EXEC @RETURNCODE =  msdb.dbo.sp_add_job @job_name=N'SQLNATIVEAUDIT_ENABLE_JOB', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'THE JOB IS TO ENABLE THE SQL SERVER 2008 NATIVE AUDIT ON THE SERVER.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @JOBID OUTPUT
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
/****** OBJECT:  STEP [ENABLE_STEP]    SCRIPT DATE: 04/24/2012 15:04:22 ******/
EXEC @RETURNCODE = msdb.dbo.sp_add_jobstep @job_id=@JOBID, @step_name=N'ENABLE_STEP', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*
SCRIPT TO ENABLE THE SQL SERVER 2008 NATIVE AUDITING FEATURE
*/

USE [master]
GO

-- TO ENABLE THE SQL NATIVE AUDITING

ALTER SERVER AUDIT [SQL_NATIVE_AUDIT]
WITH (STATE = ON)

-- TO ENABLE THE SERVER AUDIT SPECIFICATION EVENTS

ALTER SERVER AUDIT SPECIFICATION [SERVER_MGMT_SPEC]
WITH (STATE = ON)

/* 
TO ENABLE THE DATABASE AUDIT SPECIFICATIONS EVENTS
*/

DECLARE C1 CURSOR FOR SELECT NAME FROM sys.databases WHERE NAME NOT IN (''master'',''model'',''msdb'',''tempdb'') 
AND STATE = 0  
DECLARE @DBNAME VARCHAR(50)
DECLARE @command VARCHAR(2000)

OPEN C1

FETCH NEXT FROM C1 INTO @DBNAME

WHILE @@FETCH_STATUS = 0

BEGIN

SET @command= ''USE ['' + @DBNAME +''];'' + '' ALTER DATABASE AUDIT SPECIFICATION [''+@DBNAME+ ''_DB_MGMT_SPEC]''+
'' WITH (STATE = ON);'' 
--PRINT (@command);
EXECUTE (@command);

FETCH NEXT FROM C1 INTO @DBNAME

END

CLOSE C1

DEALLOCATE C1

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
EXEC @RETURNCODE = msdb.dbo.sp_update_job @job_id = @JOBID, @start_step_id = 1
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
EXEC @RETURNCODE = msdb.dbo.sp_add_jobserver @job_id = @JOBID, @server_name = N'(LOCAL)'
IF (@@ERROR <> 0 OR @RETURNCODE <> 0) GOTO QUITWITHROLLBACK
COMMIT TRANSACTION
GOTO ENDSAVE
QUITWITHROLLBACK:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
ENDSAVE:
GO

-- SQLNATVIEAUDITJOB - JOB CREATION SCRIPT
IF  EXISTS (SELECT name FROM msdb.dbo.sysjobs_view WHERE name = N'SQLNATIVEAUDITJOB')
EXEC msdb.dbo.sp_delete_job @job_name=N'SQLNATIVEAUDITJOB', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [SQLNATVIEAUDITJOB]    Script Date: 09/25/2013 11:53:12 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 09/25/2013 11:53:13 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLNATIVEAUDITJOB', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'SQL AUDIT JOB TO ENABLE, DISABLE, ENABLE AUDIT FOR NEW DB, ETC.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MISSINGDBAUDITGRP]    Script Date: 09/25/2013 11:53:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MISSINGDBAUDITGRP', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC USR_MISSINGDBAUDITGRP', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AUDITENABLE_NEWDB_STEP]    Script Date: 09/25/2013 11:53:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AUDITENABLE_NEWDB_STEP', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC USR_AUDITENABLE_NEWDB', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MISSINGSERVERAUDIT_STEP]    Script Date: 09/25/2013 11:53:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MISSINGSERVERAUDIT_STEP', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC USR_ADDMISSING_SRAUDITGRP', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ADDMISSINGDBAUDITGRP_STEP]    Script Date: 09/25/2013 11:53:14 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ADDMISSINGDBAUDITGRP_STEP', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=5, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC USR_ADDMISSING_DBAUDITGRP', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ARCHIVEAUDITLOGS]    Script Date: 09/25/2013 11:53:14 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ARCHIVEAUDITLOGS', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC master..USR_ARCHIVE_LOGS @SOURCEDIR = ''D:\SQLNativeAudit\'', @SOURCEFILE = ''APPLICATION_LOG_*'', @DAYSTOKEEP = 7', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SCH', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20111018, 
		@active_end_date=99991231, 
		@active_start_time=1, 
		@active_end_time=235959, 
		@schedule_uid=N'740bb903-a39b-4b7a-a2e8-65af9c385b0b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO