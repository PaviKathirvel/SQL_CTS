USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_CFG_BLACKOUT] Version 1.0   Script Date: 9/16/2014 4:28:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_CFG_BLACKOUT](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[From_Date] [datetime] NOT NULL,
	[To_Date] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


