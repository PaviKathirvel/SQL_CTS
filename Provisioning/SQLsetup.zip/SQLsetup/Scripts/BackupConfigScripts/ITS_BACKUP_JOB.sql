USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_BACKUP_JOB]   Version 1.0 Script Date: 9/16/2014 4:34:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_BACKUP_JOB](
	[ServerName] [varchar](100) NULL,
	[InstanceName] [varchar](100) NULL,
	[DatabaseName] [varchar](100) NULL,
	[BackupType] [varchar](15) NULL,
	[BackupToDisk] [varchar](5) NULL,
	[BackupToTape] [varchar](5) NULL,
	[DiskBkpStartTime] [datetime] NULL,
	[DiskBkpEndTime] [datetime] NULL,
	[TapeBkpStartTime] [datetime] NULL,
	[TapeBkpEndTime] [datetime] NULL,
	[BkpFileName] [varchar](2500) NULL,
	[BkpFileSizeMB] [int] NULL,
	[JobName] [varchar](25) NULL,
	[DiskSync] [varchar](3) NULL,
	[TapeSync] [varchar](3) NULL,
	[ScriptVersion] [varchar](5) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


