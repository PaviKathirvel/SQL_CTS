USE [msdb]
GO

/****** Object:  Job [ITSSQL_MetaData]    Script Date: 9/23/2014 5:56:51 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/23/2014 5:56:51 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_MetaData', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_MetaData]    Script Date: 9/23/2014 5:56:51 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_MetaData', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'###=============================================================================================================================###
###-----------------------------------------------------------------------------------------------------------------------------###
### <Script>															###
### <Author>	Atul Patil/Praneet Kumar</Author>										###
### <Description> export user database metadata, backup and copy system backup files to tape, write info to centralise server </Description>	###
### <Usage>	ITSSQL_Backup.ps1 ''FULL|DIFF|LOG'' [-dbnames "dbname1<,dbname1....>]	</Usage>				###
### </Script>															###
###-----------------------------------------------------------------------------------------------------------------------------###
###------Praneet : Modified step to script out Logins and Users at server Level and inserting meta objects data in Local table--###
###================================================================================================================a=============###


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null



##======================================================================================================================================##
## Change Variables values in below section				    								##
##======================================================================================================================================##
$DBWindowsServerName = $env:computername	##provide Windows cluster server name in case of cluster else provide windows server name 
$DBServerInstanceName = "$(ESCAPE_DQUOTE(SRVR))" ##Provide the DB Server Instance Name
$databasebackupPath = "E:\Backup\Meta" 	##provide database backup path where actual backups will be done
$bpbackupPath = Get-WMIObject Win32_LogicalDisk -filter "DriveType = 3" | Select-Object DeviceID | ForEach-Object {Get-Childitem ($_.DeviceID + "\") -include bpbackup.exe -recurse} 		##search bpbackup file and provide the exe location
$NBUPolicyName = "ITS-SQL-D2T"	##Name of netbackup policy, used for writing backup file from disk to tape
$NBUschedulename = "Backup-LAN-ZONE1"		##Name of netbackup schedule used for writing backup file from disk to tape	
##======================================================================================================================================##
## End of Variable section						    								##
##======================================================================================================================================##

$exitcode = 0
$Days = "7"						    
$ScriptVersion = ''1.0''
$ComplianceInstanceName = "ITSUSTDCWVM525\PRANEET_SQL2012" ##central repository        
$ComplianceDb = "ComplianceDB" ##central repository database                
$JobName = ''ITSSQL_MetaData''

##check if backup path is valid and ends with \, if not add \ to the backup path
$Chkdbpath = $databasebackupPath.EndsWith("\")
if($Chkdbpath -ne "True") {$databasebackupPath = $databasebackupPath + "\"}

## create error log file
$errorlogPath = $databasebackupPath + "backuperrorlog\"
$errorlogfile = $errorlogPath + "backuperrorlog-" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".log"
$errorlogfiletemp = $errorlogPath + "backuperrorlogtemp.log"
if(!(Test-Path -Path $errorlogPath)) { new-item -Path $errorlogPath �itemtype directory }
if(!(Test-Path -Path $errorlogfile)) { new-item -Path $errorlogfile �itemtype file }

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{
	"ITSSQL_BackupJob failed. Database backup path no provided"  >> $errorlogfile
	$exitcode = 99	
	EXIT $exitcode
}

$pos = $ComplianceInstanceName.IndexOf(",")
if($pos -eq -1) { $ComplianceInstance = $ComplianceInstanceName } else { $ComplianceInstance = $ComplianceInstanceName.Substring(0, $pos) }
$pos = $DBServerInstanceName.IndexOf(",")
if($pos -eq -1) { $DBServerinstance = $DBServerInstanceName } else { $DBServerinstance = $DBServerInstanceName.Substring(0, $pos) }

##crearing complaince DB and loca;l Database server connectionstrings
$ComplinaceConnString = "Server=$ComplianceInstanceName;Database=$ComplianceDb;Integrated Security=True;"
$DBServerConnString = "Server=$DBServerinstanceName;Database=msdb;Integrated Security=true;"


$srv = new-object "Microsoft.SqlServer.Management.SMO.Server" $DBServerinstance
$srv.SetDefaultInitFields([Microsoft.SqlServer.Management.SMO.View], "IsSystemObject")
$db = New-Object "Microsoft.SqlServer.Management.SMO.Database"


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 1: Copy ITS_CFG_BLACKOUT table from ComplainceDB to DBServer MSDB    					##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

Function copy_ITS_CFG_BLACKOUT()
{
##test complainace DB connection by executing use MSDB command, before start copy operation
Sqlcmd -S $ComplianceInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp



if ($lastexitcode -eq 1)
{
	"Copy of table ITS_CFG_BLACKOUT from ComplainceDB from server $ComplianceInstanceName to $DBServerInstanceName failed. Error connection $ComplianceInstanceName " >> $errorlogfile
	"ITSSQL_BackupJob failed. Job ITSSQL_Backup failed at Step 1"  >> $errorlogfile
	
}
ELSE
{
	##test local databse DB connection by executing use MSDB command, before start copy operation
	Sqlcmd -S $DBServerInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp 
	if ($lastexitcode -eq 1)
	{
		
		"Copy of table ITS_CFG_BLACKOUT from ComplainceDB from server $ComplianceInstanceName to $DBServerInstanceName failed. Error connection $DBServerInstanceName " >> $errorlogfile
		"Job ITSSQL_MetaData failed at Step 1" >> $errorlogfile
		$exitcode = 99
	}
	else
	{
		##copy all valid entried from centralise database for current database server and instance into local veriable
		$query = "select * from ITS_CFG_BLACKOUT where upper(ServerName) = upper(''$DBWindowsServerName'') and upper(InstanceName) = upper(''$DBServerInstanceName'') and GETDATE() >= From_Date and GETDATE() <= To_Date"


		$da = New-Object System.Data.SqlClient.SqlDataAdapter ($query,$ComplinaceConnString)
		$dt = New-Object System.Data.DataTable
		$da.fill($dt)

		##truncate local ITS_BLACKOUT_TABLE in MSDB
		$TruncateSql = "TRUNCATE TABLE ITS_CFG_BLACKOUT" 
		Sqlcmd -S $DBServerInstanceName -d msdb -Q $TruncateSql -o $errorlogfiletemp 

		##write blackout information to local MSDB selected earlier
		$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $DBServerConnString
		$bulkCopy.DestinationTableName = "ITS_CFG_BLACKOUT"
		$bulkCopy.WriteToServer($dt)
	}
}
}




##======================================================================================================================================##    

##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 2: Copy ITS_master_backupinfo table from ComplainceDB to DBServer MSDB    					##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##




Function copy_ITS_master_backupinfo()
{
##test complainace DB connection by executing use MSDB command, before start copy operation
Sqlcmd -S $ComplianceInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp

if ($lastexitcode -eq 1)
{
	"Copy of table ITS_master_backupinfo from ComplainceDB from server $ComplianceInstanceName to $DBServerInstanceName failed. Error connection $ComplianceInstanceName " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 2" >> $errorlogfile
	
}
ELSE
{
	##test local databse DB connection by executing use MSDB command, before start copy operation
	Sqlcmd -S $DBServerInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp
	if ($lastexitcode -eq 1)
	{
		"Copy of table ITS_master_backupinfo from ComplainceDB from server $ComplianceInstanceName to $DBServerInstanceName failed. Error connection 

$DBServerInstanceName " >> $errorlogfile
		"Job ITSSQL_MetaData failed at Step 2" >> $errorlogfile
		$exitcode = 99
	}
	else
	{
		##copy all valid entried from centralise database for current database server and instance into local veriable
		$query = "select * from ITS_master_backupinfo where ServerName = ''$DBWindowsServerName'' and InstanceName = ''$DBServerInstanceName'' and BackupType = ''METADATA'' "
		$da = New-Object System.Data.SqlClient.SqlDataAdapter ($query,$ComplinaceConnString)
		$dt = New-Object System.Data.DataTable
		$da.fill($dt)

		##truncate local ITS_BLACKOUT_TABLE in MSDB
		$TruncateSql = "TRUNCATE TABLE ITS_master_backupinfo" 
		Sqlcmd -S $DBServerInstanceName -d msdb -Q $TruncateSql -o $errorlogfiletemp

		##write blackout information to local MSDB selected earlier
		$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $DBServerConnString
		$bulkCopy.DestinationTableName = "ITS_master_backupinfo"
		$bulkCopy.WriteToServer($dt)
	}
}
}

##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 		Step 3: Execute Full backup for system database and generate metadata for user databases				##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
try
{
Function metadatabackup()
{
##check if entry is present in blackout table. If yes execute the code else exit with error
$query21 = "SELECT DatabaseName FROM ITS_master_backupinfo WHERE upper(BackupType) = ''METADATA'' and upper(DatabaseName) =''ALL''"

$da21 = New-Object System.Data.SqlClient.SqlDataAdapter ($query21,$DBServerConnString)
$dt21 = New-Object System.Data.DataTable
$da21.fill($dt21)

if($dt21.Rows.Count -eq 0)
{
	"Metadata entry for Database Instance: $DBServerInstanceName not found in complaince DB: $ComplianceInstanceName in table ITS_CFG_BLACKOUT" >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 3" >> $errorlogfile
	$exitcode = 99
}
else 
{

	Sqlcmd -S $DBServerInstanceName -d msdb -Q ":EXIT(exec msdb..ITSSQL_DB_FULL_BACKUP_DEV 

''$databasebackupPath'',''$DBWindowsServerName'',''$DBServerInstanceName'',''SYSTEM_ALL'')" -o $errorlogfiletemp

	if ($lastexitcode -eq 1)
	{
		"Disk Backup for System databases failed." >> $errorlogfile
		"Job ITSSQL_MetaDatafailed at Step 3" >> $errorlogfile
		$exitcode = 99
	}


	$scr = New-Object "Microsoft.sqlServer.Management.Smo.Scripter"
		       	$deptype = New-Object "Microsoft.sqlServer.Management.Smo.DependencyType"
        		$scr.Server = $srv
       			$options = New-Object "Microsoft.sqlServer.Management.SMO.ScriptingOptions"
	        	$options.AllowSystemObjects = $false
        		$options.IncludeDatabaseContext = $true
        		$options.IncludeIfNotExists = $true
	        	$options.ClusteredIndexes = $true
        		$options.Default = $true
        		$options.DriAll = $true
	        	$options.Indexes = $true
        		$options.NonClusteredIndexes = $true
        		$options.IncludeHeaders = $true
	        	$options.ToFileOnly = $true
        		$options.AppendToFile = $true
        		#Set options for SMO.Scripter
	        	$scr.Options = $options

	$dbs=$srv.Databases 


$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


	foreach ($db in $dbs)
	{
		if (($db.name -ne "tempdb") -and ($db.name -ne "master") -and ($db.name -ne "model") -and ($db.name -ne "msdb"))
		{
       			

			$dbval = $db.name

$query24 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date"
		$da24 = New-Object System.Data.SqlClient.SqlDataAdapter ($query24,$DBServerConnString)
		$dt24 = New-Object System.Data.DataTable
		$da24.fill($dt24)


foreach ($Row in $dt24.Rows)
	{
		
	if ($db.name -eq $Row[0]) 
	{
	$dbval=" "
	}
	}
       		



			if ($db.name -eq $dbval)
			{

			$destinationFolder = $databasebackupPath + $dbval+ "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}

			

			#Tables
			$options.FileName = $destinationFolder + $db.name + "_Tables_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
	        	$tb = $db.Tables | where {$_.IsSystemObject -eq $false}
	        	if ($tb -ne $null)
        		{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
			        $scr.Script($tb)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}

			#Triggers
        		$options.FileName = $destinationFolder + $db.name + "_Triggers_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		foreach($tables in $db.Tables | where {$_.IsSystemObject -eq $false})
        		{
				if($tables.Triggers -ne $null)
				{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            			foreach($trigger in $tables.Triggers)
            			{
				
                			$scr.Script($trigger)
					
					
					
            			}
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
				$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
				,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
				,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
				''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"
	
				Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				}
        		}
			

			#Functions
        		$options.FileName = $destinationFolder + $db.name + "_Functions_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		$UserDefinedFunctions = $db.UserDefinedFunctions | where {$_.IsSystemObject -eq $false}
        		if ($UserDefinedFunctions -ne $null)
        		{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            			$scr.Script($UserDefinedFunctions)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 

				
        		}

			#StoredProcedures
	        	$options.FileName = $destinationFolder + $db.name + "_StoredProcedures_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $StoredProcedures = $db.StoredProcedures | where {$_.IsSystemObject -eq $false}
        		if ($StoredProcedures -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($StoredProcedures)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
			
			#Users
			$options.FileName = $destinationFolder + $db.name + "_Users_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Users = $db.Users | where {$_.IsSystemObject -eq $false}
        		if ($Users -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Users)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7

			$query25="select max(TapeBkpEndTime) from ITS_Backup_job where DiskSync=''Y'' and (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''$dbval'' 
			and BackupType=''METADATA''"

			$da25 = New-Object System.Data.SqlClient.SqlDataAdapter ($query25,$DBServerConnString)
			$dt25 = New-Object System.Data.DataTable
			$da25.fill($dt25)


			foreach ($Row in $dt25.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}
			
			}
			
			
			
			
		
 
		}

	
	}


			
			$destinationFolder = $databasebackupPath + "Logins" + "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}
			$options.FileName = $destinationFolder +  "Logins_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Logins = $srv.Logins | where {$_.IsSystemObject -eq $false}
        		if ($Logins -ne $null)
	        	{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Logins)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''Logins'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}


			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7
			
			$query26="select max(TapeBkpEndTime) from ITS_Backup_job where DiskSync=''Y'' and (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''Logins'' 
			and BackupType=''METADATA''"

			$da26 = New-Object System.Data.SqlClient.SqlDataAdapter ($query26,$DBServerConnString)
			$dt26 = New-Object System.Data.DataTable
			$da26.fill($dt26)


			foreach ($Row in $dt26.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}

			

			
			
			$destinationFolder = $databasebackupPath + "Roles" + "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}			
			$options.FileName = $destinationFolder + $DBServerinstance + "_Roles_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Roles = $srv.Roles | where {$_.IsSystemObject -eq $false}
        		if ($Roles -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Roles)
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
		
			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7

			
			$query27="select max(TapeBkpEndTime) from ITS_Backup_job where DiskSync=''Y'' and (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''Roles''
			and BackupType=''METADATA''"

			$da27 = New-Object System.Data.SqlClient.SqlDataAdapter ($query27,$DBServerConnString)
			$dt27 = New-Object System.Data.DataTable
			$da27.fill($dt27)


			foreach ($Row in $dt27.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}
			

		
		
		


		
}
}
}
}
catch
{
throw $_
}


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 4: Below code will write backup information from local MSDB to centralise database				##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

Function diskbackupinfosync()
{

$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


	Sqlcmd -S $DBServerInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp
	if ($lastexitcode -eq 1)
	{
		"Disk to Tape backup information update from server: $DBServerInstanceName  to ComplainceDB: $ComplianceInstanceName failed. Error connection 

$DBServerInstanceName " >> $errorlogfile
		"Job ITSSQL_MetaData failed at Step 4" >> $errorlogfile
		$exitcode = 99
	}
	ELSE
	{

		$query3 = "SELECT 

ServerName,InstanceName,DatabaseName,BackupType,BackupToDisk,BackupToTape,DiskBkpStartTime,DiskBkpEndTime,TapeBkpStartTime,TapeBkpEndTime,BkpFileName,BkpFileSizeMB,
JobName,''Y'',TapeSync,ScriptVersion from ITS_BACKUP_JOB where upper(DiskSync) = ''N'' and upper(JobName) in (''ITSSQL_MetaData'')"
		$da3 = New-Object System.Data.SqlClient.SqlDataAdapter ($query3,$DBServerConnString)
		$dt3 = New-Object System.Data.DataTable
		$da3.fill($dt3)
		
		$filestring = ""
		foreach ($Row in $dt3.Rows)
		{
			
			$filestring= $filestring + $Row.Item(10) + "'',''" 
		}

		$filestring= $filestring.Substring(0,$filestring.Length-3) 

		Sqlcmd -S $ComplianceInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp

		if ($lastexitcode -eq 1)
		{
	"Disk backup information update from server: $DBServerInstanceName  to ComplainceDB: $ComplianceInstanceName failed. Error connection 
$ComplianceInstanceName " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 4" >> $errorlogfile
	
	}
	ELSE
	{

		$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $ComplinaceConnString
		$bulkCopy.DestinationTableName = "ITS_BACKUP_JOB"
		$bulkCopy.WriteToServer($dt3)
	}

		$updateSql = "update ITS_BACKUP_JOB set DiskSync=''Y'' where BkpFileName in (''$filestring'')"
		Sqlcmd -S $DBServerInstanceName -d msdb -Q $updateSql -o $errorlogfiletemp
	}

}

}
##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 5: Copy Backup Files from disk to Tape									##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
Function disktotapecopy()
{

$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


Sqlcmd -S $DBServerInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp
if ($lastexitcode -eq 1)
{
	"Disk to Tape backup information update from server: $DBServerInstanceName  to ComplainceDB: $ComplianceInstanceName failed. Error connection 

$DBServerInstanceName " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 5" >> $errorlogfile
	$exitcode = 99
}
else
{
	$query4 = "SELECT BkpFileName from ITS_BACKUP_JOB where upper(ServerName) = upper(''$DBWindowsServerName'') and upper(InstanceName) =upper

(''$DBServerInstanceName'') and upper(JobName) in (''ITSSQL_MetaData'') and upper(DiskSync) = ''Y'' and upper(BackupToTape) in (''N'',''F'')"
	$da4 = New-Object System.Data.SqlClient.SqlDataAdapter ($query4,$DBServerConnString)
	$dt4 = New-Object System.Data.DataTable
	$da4.fill($dt4)

	foreach ($Row in $dt4.Rows)
	{
		$bkpFileName = $Row[0]

		$TapeBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
		$cmd = "$bpbackupPath -p `"$NBUPolicyName`" -s `"$NBUschedulename`" -w `"$bkpFileName`""

		& cmd.exe /c $cmd

		if ($lastexitcode -ne 0)
		{
			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
			"Tape backup failed for file $bkpFileName on server $DBServerInstanceName" >> $errorlogfile
			"Job ITSSQL_Backup failed at Step 5. Disk to tape copy failed for file $bkpFileName" >> $errorlogfile
			$exitcode = 99
			
			$updateSql = "update ITS_BACKUP_JOB set BackupToTape=''F'', TapeBkpStartTime = ''$TapeBkpStartTime'', TapeBkpEndTime = ''$TapeBkpEndTime'' where 

BkpFileName = ''$bkpFileName''"
			Sqlcmd -S $DBServerInstanceName -d msdb -Q $updateSql -o $errorlogfiletemp
			
		}
		ELSE
		{
			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

			"Tape backup successfully for file $bkpFileName on server $DBServerInstanceName" >> $errorlogfile

			$updateSql = "update ITS_BACKUP_JOB set BackupToTape=''Y'', TapeBkpStartTime = ''$TapeBkpStartTime'', TapeBkpEndTime = ''$TapeBkpEndTime'' where 

BkpFileName = ''$bkpFileName''"
			Sqlcmd -S $DBServerInstanceName -d msdb -Q $updateSql -o $errorlogfiletemp
		}
	}
}
}

}

##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 6: Below code will write backup information from local MSDB to centralise database				##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

Function tapebackupinfosync()
{

$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


	Sqlcmd -S $DBServerInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp
	if ($lastexitcode -eq 1)
	{
		"Disk to Tape backup information update from server: $DBServerInstanceName  to ComplainceDB: $ComplianceInstanceName failed. Error connection 

$DBServerInstanceName " >> $errorlogfile
		"Job ITSSQL_MetaData failed at Step 6" >> $errorlogfile
		$exitcode = 99
	}
	ELSE
	{

		$query5 = "SELECT 

ServerName,InstanceName,DatabaseName,BackupType,BackupToDisk,BackupToTape,DiskBkpStartTime,DiskBkpEndTime,TapeBkpStartTime,TapeBkpEndTime,BkpFileName,BkpFileSizeMB,
JobName,DiskSync,''Y'',ScriptVersion from ITS_BACKUP_JOB where upper(BackupToTape) in (''Y'',''F'') and upper(TapeSync) = ''N'' and upper(JobName) in 

(''ITSSQL_MetaData'')"
		$da5 = New-Object System.Data.SqlClient.SqlDataAdapter ($query5,$DBServerConnString)
		$dt5 = New-Object System.Data.DataTable
		$da5.fill($dt5)
		
		$filestring = ""

		foreach ($Row in $dt5.Rows)
		{
			$filestring= $filestring + $Row.Item(10) + "'',''"
		}

		$filestring = $filestring.Substring(0,$filestring.Length-3)

		$deleteSql = "delete from ITS_BACKUP_JOB where BkpFileName in (''$filestring'') and ServerName =''$DBWindowsServerName'' and InstanceName 

=''$DBServerInstanceName''"

		Sqlcmd -S $ComplianceInstanceName -d msdb -Q "use msdb" -o $errorlogfiletemp

		if ($lastexitcode -eq 1)
		{
	"Disk to Tape backup information update from server: $DBServerInstanceName  to ComplainceDB: $ComplianceInstanceName failed. Error connection 
$ComplianceInstanceName " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 6" >> $errorlogfile
	
		}
		ELSE
		{
		
		Sqlcmd -S $ComplianceInstanceName -d $ComplianceDb -Q $deleteSql -o $errorlogfiletemp

		$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $ComplinaceConnString
		$bulkCopy.DestinationTableName = "ITS_BACKUP_JOB"
		$bulkCopy.WriteToServer($dt5)
		}

		$updateSql = "update ITS_BACKUP_JOB set TapeSync=''Y'' where upper(BackupToTape) = ''Y'' and BkpFileName in (''$filestring'') and ServerName 

=''$DBWindowsServerName'' and InstanceName =''$DBServerInstanceName''"
		Sqlcmd -S $DBServerInstanceName -d msdb -Q $updateSql -o $errorlogfiletemp
	}
}


##Clear error log folder to delete older than 90 days log
$errlogdeletepath = $errorlogPath + "*"
$DateToDelete = -90
Get-ChildItem $errlogdeletepath -Recurse -include *.log | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force


}

##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Main body													##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

copy_ITS_CFG_BLACKOUT
copy_ITS_master_backupinfo
metadatabackup
diskbackupinfosync
disktotapecopy
tapebackupinfosync
EXIT $exitcode', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'Bkp_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ITSSQL_MetaData', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140923, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959, 
		@schedule_uid=N'ba959b30-2eb7-4310-bad7-4fdd7dcfd857'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


