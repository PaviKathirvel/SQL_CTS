/**********************************************************************************************
Script Name: sddc_sql_VCACGroup_addition.sql
Description: Grant sysadmin access to VCAC group
**********************************************************************************************
Version				Date			Author			Reason For Change
1.0				05/20/2014		Jay			New Script
**********************************************************************************************/

SET NOCOUNT ON

DECLARE @vcacgroup nvarchar(100)
DECLARE @sql nvarchar(500)

SET @vcacgroup = 'NA\Admin_pkuma10'

IF NOT EXISTS (select * from sys.syslogins where loginname in (@vcacgroup))

BEGIN

  SET @sql = ''
  SET @sql = 'CREATE LOGIN ' + QUOTENAME(@vcacgroup) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'

  EXEC sp_executesql @sql

  SET @sql = ''
  SET @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@vcacgroup,'''') + ', @rolename = ' + quotename('sysadmin','''')

  EXEC sp_executesql @sql

END



