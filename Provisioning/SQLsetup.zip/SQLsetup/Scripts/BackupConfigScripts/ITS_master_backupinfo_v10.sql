USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_master_backupinfo]    Version 1.0 Script Date: 9/16/2014 4:17:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_master_backupinfo](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[ScheduledateTime] [varchar](100) NULL,
	[BackupType] [varchar](3000) NOT NULL,
 CONSTRAINT [Ser_Inst_DB] PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC,
	[InstanceName] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [msdb]
GO
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (cast(SERVERPROPERTY('machinename') as nvarchar)
           ,cast(SERVERPROPERTY('machinename') as nvarchar)
           ,'ALL'
           ,Null
           ,'TAPE') 

SET ANSI_PADDING OFF
GO





