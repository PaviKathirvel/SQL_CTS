###=============================================================================================================================###
###-----------------------------------------------------------------------------------------------------------------------------###
### <Script>															###
### <Author>	Atul Patil/Praneet Kumar</Author>										###
### <Description> Metadata backup for SQL2005 databases </Description>								###
### <Version> 3.0 : Put all scripted-out files into single folder and push this single folder to tape </Version>		###
### <Version> 3.0 : Add a separate row in ITS_BACKUP_JOB to represent OFFLINE Database </Version>				###
### <Version> 3.0 : Create files in D:\METADATA folder if default backup path is not available in registry </Version>		###
### <Usage>	ITSSQL_Backup.ps1 'FULL|DIFF|LOG' [-dbnames "dbname1<,dbname1....>]	</Usage>				###
### </Script>															###
###-----------------------------------------------------------------------------------------------------------------------------###
###------Praneet : Modified step to script out Logins and Users at server Level and inserting meta objects data in Local table--###
###================================================================================================================a=============###


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null



##======================================================================================================================================##
## Change Variables values in below section				    								##
##======================================================================================================================================##
$DBWindowsServerName = $env:computername	##provide Windows cluster server name in case of cluster else provide windows server name 

# $bpbackupPath = Get-WMIObject Win32_LogicalDisk -filter "DriveType = 3" | 
# Select-Object DeviceID | 
# ForEach-Object {Get-Childitem ($_.DeviceID + "\") -include bpbackup.exe -recurse -ErrorAction SilentlyContinue} 		

$NBUreg= Get-ItemProperty �HKLM:\Software\Veritas\NetBackup\CurrentVersion�
$NBUfolder = $NBUreg.INSTALLDIR
$bpbackupPath = Get-ChildItem -Path $NBUfolder -Filter bpbackup.exe -Recurse | ForEach-Object {$_.FullName}

$NBUPolicyName = "ITS-SQL-D2T"	##Name of netbackup policy, used for writing backup file from disk to tape
$NBUschedulename = "Backup-LAN-Dev"		##Name of netbackup schedule used for writing backup file from disk to tape	
##======================================================================================================================================##
## End of Variable section						    								##
##======================================================================================================================================##

$fso = New-Object -ComObject Scripting.FileSystemObject
$bpbackupPath = $fso.GetFile($bpbackupPath).ShortPath
$CompName = $env:computername

$exitcode = 0
$Days = "7"						    
$ScriptVersion = '3.0'
$JobName = 'ITSSQL_MetaData'

#-------------- Get instance name ---------------------

$cs = Get-WmiObject -Class Win32_SystemServices -ComputerName $env:computername
IF ($cs | select PartComponent | where {$_ -like "*ClusSvc*"}) 
{ 
  $IsClus = "YES" 
}

ELSE 
{ 
   $IsClus = "NO"
}


$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances

FOREACH ($inst in $instances)
    {
         $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
         $test= (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion

         IF ($test.StartsWith(9) -eq 'True')
         {
          IF ($inst -eq 'MSSQLServer')
           {

                IF ($IsClus -eq "YES")
                  {
                     $virtualName = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName
                       $DBServerInstance = $virtualName
                  }
                 ELSE
                  {
                       $DBServerInstance = $env:computername
                  }

           }

          ELSE

           {
                IF ($IsClus -eq "YES")
                  {
                     $virtualName = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Cluster").ClusterName
                      $DBServerInstance = $virtualName+'\'+$inst
                  }
                 ELSE
                  {
                       $DBServerInstance = $env:computername+'\'+$inst
                   }

           }

         }
      }
 

# $databasebackupPath = "F:\METADATA\"	#Ignore this path as 

If (Test-Path ("HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer"))

{
  $databasebackupPath = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
  $databasebackupPath = $databasebackupPath + "\"
}

ELSE

{

  If (!(Test-Path D:\METADATA))

   {
     mkdir "D:\METADATA"
     $databasebackupPath = "D:\METADATA\"
   }

}


If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
$err ="Job Name:ITSSQL_MetaData
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstance
Error Description:Either SQLAgent service account is Not a local admin or Restart of SQL Agent not done after adding it to local admin"
$log = New-Object System.Diagnostics.EventLog('Application')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,104,1)
$exitcode = 99	
EXIT $exitcode    
}

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{

$err = "Job Name:ITSSQL_MetaData
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstance
Error Description:Database backup path not provided"
$log = New-Object System.Diagnostics.EventLog('Application')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,104,1)
$exitcode = 99	
EXIT $exitcode
}

##check if backup path is valid and ends with \, if not add \ to the backup path
$Chkdbpath = $databasebackupPath.EndsWith("\")
if($Chkdbpath -ne "True") {$databasebackupPath = $databasebackupPath + "\"}

## create error log file
$errorlogPath = $databasebackupPath + "backuperrorlog\"
$errorlogfile = $errorlogPath + "backuperrorlog-" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".log"
$errorlogfiletemp = $errorlogPath + "backuperrorlogtemp.log"
if(!(Test-Path -Path $errorlogPath)) { new-item -Path $errorlogPath �itemtype directory }
if(!(Test-Path -Path $errorlogfile)) { new-item -Path $errorlogfile �itemtype file }

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{
	"ITSSQL_BackupJob failed. Database backup path no provided"  >> $errorlogfile
	$exitcode = 99	
	EXIT $exitcode
}


$DBServerConnString = "Server=$DBServerinstance;Database=msdb;Integrated Security=true;"

$srv = new-object "Microsoft.SqlServer.Management.SMO.Server" $DBServerinstance
$srv.SetDefaultInitFields([Microsoft.SqlServer.Management.SMO.View], "IsSystemObject")
$db = New-Object "Microsoft.SqlServer.Management.SMO.Database"


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 		Step 1: Execute Full backup for system database and generate metadata for user databases				##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
try
{
Function metadatabackup()
{

$query21 = "SELECT DatabaseName FROM ITS_master_backupinfo WHERE upper(BackupType) = 'METADATA' and upper(DatabaseName) ='ALL'"

$da21 = New-Object System.Data.SqlClient.SqlDataAdapter ($query21,$DBServerConnString)
$dt21 = New-Object System.Data.DataTable
$da21.fill($dt21)


IF($dt21.Rows.Count -eq 0)
 {
	$err = "Job Name:ITSSQL_MetaData
	BackupType:$BackupType
	Server:$DBWindowsServerName
	Instance:$DBServerInstance
	Error Description:Either database is blackout or no entry for Meta Backup found in ITS_Master_Backupinfo"
	$log = New-Object System.Diagnostics.EventLog('Application')
	$log.set_source("JNJ SQL Backup")
	$infoevent=[System.Diagnostics.EventLogEntryType]::Error
	$log.WriteEntry($err,$infoevent,101,1)

	"Metadata entry for Database Instance: $DBServerInstance not found " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 1" >> $errorlogfile
	
	$exitcode = 99	
	EXIT $exitcode
 }
ELSE 
 {

	Sqlcmd -S $DBServerInstance -d msdb -Q ":EXIT(exec msdb..ITSSQL_DB_FULL_BACKUP_DEV '$databasebackupPath','$DBWindowsServerName','$DBServerInstance','SYSTEM_ALL')" -o $errorlogfiletemp

	if ($lastexitcode -eq 1)
	{

		$err = "Job Name:ITSSQL_MetaData
		BackupType:$BackupType
		Server:$DBWindowsServerName
		Instance:$DBServerInstance
		Error Description: Disk Backup for System databases failed on server $DBServerInstance"
		$log = New-Object System.Diagnostics.EventLog('Application')
		$log.set_source("JNJ SQL Backup")
		$infoevent=[System.Diagnostics.EventLogEntryType]::Error
		$log.WriteEntry($err,$infoevent,104,1)

		"Disk Backup for System databases failed." >> $errorlogfile
		"Job ITSSQL_MetaDatafailed at Step 1" >> $errorlogfile
		$exitcode = 99
	}


	$scr = New-Object "Microsoft.sqlServer.Management.Smo.Scripter"
		       	$deptype = New-Object "Microsoft.sqlServer.Management.Smo.DependencyType"
        		$scr.Server = $srv
       			$options = New-Object "Microsoft.sqlServer.Management.SMO.ScriptingOptions"
	        	$options.AllowSystemObjects = $false
        		$options.IncludeDatabaseContext = $true
        		$options.IncludeIfNotExists = $true
	        	$options.ClusteredIndexes = $true
        		$options.Default = $true
        		$options.DriAll = $true
	        	$options.Indexes = $true
        		$options.NonClusteredIndexes = $true
        		$options.IncludeHeaders = $true
	        	$options.ToFileOnly = $true
        		$options.AppendToFile = $true
        		#Set options for SMO.Scripter
	        	$scr.Options = $options

	$dbs=$srv.Databases 


$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = 'ALL'"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


	foreach ($db in $dbs)
	{
		if (($db.name -ne "tempdb") -and ($db.name -ne "master") -and ($db.name -ne "model") -and ($db.name -ne "msdb"))
		{

			$dbval = $db.name
			$dbOrigVal = $db.name

$query24 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date"
		$da24 = New-Object System.Data.SqlClient.SqlDataAdapter ($query24,$DBServerConnString)
		$dt24 = New-Object System.Data.DataTable
		$da24.fill($dt24)


foreach ($Row in $dt24.Rows)
	{
		
	if ($db.name -eq $Row[0]) 
	{
	$dbval=" "
	}
	}
  
  			If (!($db.IsAccessible))
			{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values ('$DBWindowsServerName','$DBServerInstance','$dbOrigVal','METADATA','NA','NA',
			'$DiskBkpStartTime','$DiskBkpEndTime',NULL,NULL,'OFFLINE',NULL,'ITSSQL_MetaData','N','N','$ScriptVersion')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql

			}
  
  
			if (($db.name -eq $dbval) -and ($db.IsAccessible))
			{

$dbval = $db.name -replace " ",""

			$destinationFolder = $databasebackupPath + $dbval+ "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}

$dbf = $db.name -replace " ",""			

			#DB Structure
				$FName = $destinationFolder + $dbf + "_DBStructure_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$dbs[$dbOrigVal].Script() | Out-File $FName
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

			#Tables
				$options.FileName = $destinationFolder + $dbf + "_Tables_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
	        	$tb = $db.Tables | where {$_.IsSystemObject -eq $false}
	        	if ($tb -ne $null)
        		{
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
			        $scr.Script($tb)
					$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
					$scriptbkp=$options.FileName
        		}

			#Triggers
        		$options.FileName = $destinationFolder + $dbf + "_Triggers_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		foreach($tables in $db.Tables | where {$_.IsSystemObject -eq $false})
        		{
					if($tables.Triggers -ne $null)
					  {
						$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            			foreach($trigger in $tables.Triggers)
            			  {
                			$scr.Script($trigger)
            			  }
							$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
							$scriptbkp=$options.FileName
	  				  }
        		}
			

			#Functions
        		$options.FileName = $destinationFolder + $dbf + "_Functions_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		$UserDefinedFunctions = $db.UserDefinedFunctions | where {$_.IsSystemObject -eq $false -and -not $_.IsEncrypted}
        		if ($UserDefinedFunctions -ne $null)
        		  {
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            		$scr.Script($UserDefinedFunctions)
					$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
					$scriptbkp=$options.FileName
        		  }

			#StoredProcedures
	        	$options.FileName = $destinationFolder + $dbf + "_StoredProcedures_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $StoredProcedures = $db.StoredProcedures | where {$_.IsSystemObject -eq $false -and -not $_.IsEncrypted}
        		if ($StoredProcedures -ne $null)
	        	  {
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
					$scr.Script($StoredProcedures)
					$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
					$scriptbkp=$options.FileName
        		  }
			
			
			#Users
				$options.FileName = $destinationFolder + $dbf + "_Users_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Users = $db.Users | where {$_.IsSystemObject -eq $false}
        		if ($Users -ne $null)
	        	  {
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
					$scr.Script($Users)
					$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
					$scriptbkp=$options.FileName
        		  }

			#Roles
				$destinationFolder = $databasebackupPath + "Roles" + "\"
				if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}			
				$options.FileName = $destinationFolder + $DBServerinstance + "_Roles_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Roles = $srv.Roles | where {$_.IsSystemObject -eq $false}
        		if ($Roles -ne $null)
	        	{
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
					$scr.Script($Roles)
					$scriptbkp=$options.FileName
        		}

			}
			

		}

	}
			#Logins
				$destinationFolder = $databasebackupPath + "Logins" + "\"
				if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}
				$options.FileName = $destinationFolder +  "Logins_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Logins = $srv.Logins | where {$_.IsSystemObject -eq $false}
        		IF ($Logins -ne $null)
	        	  {
					$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
					$scr.Script($Logins)
					$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
					$scriptbkp=$options.FileName
        		  }


				
  }
 }
#---------------- Zip all folders ----------------------

$InstFolderTime = "$CompName"+"-"+"$inst"+"_"+(Get-Date).tostring("MM-dd-yyyy-hh-mm-ss")
  	mkdir "$databasebackupPath$InstFolderTime"
$source = "$databasebackupPath"
$dest = "$databasebackupPath$InstFolderTime" + ".cab"

$exclude = @("$InstFolderTime","SystemDBBackupBeforeSP","SystemBackup","backuperrorlog","master","model","msdb","*.cab")
C:
Get-ChildItem $source -Exclude $exclude | Move-Item -Destination $dest

#---------------- End of zip all folders -------------

			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values ('$DBWindowsServerName','$DBServerInstance','ALLDatabases','METADATA','Y','N',
			'$DiskBkpStartTime','$DiskBkpEndTime',NULL,NULL,'$dest',NULL,'ITSSQL_MetaData','N','N','$ScriptVersion')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
 
#--------------- Purge older .cab files --------------
			
			$deletepath =  $databasebackupPath + "*"
			$DateToDelete = -7

			$query25="SELECT MAX(TapeBkpEndTime) FROM ITS_Backup_job WHERE (BackupToTape='Y') AND BackupType='METADATA'"

			$da25 = New-Object System.Data.SqlClient.SqlDataAdapter ($query25,$DBServerConnString)
			$dt25 = New-Object System.Data.DataTable
			$da25.fill($dt25)

				foreach ($Row in $dt25.Rows)
				 {
					$latedate= $Row[0]
				 }
					If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
					  {
						Get-ChildItem $deletepath -Recurse -include *.cab | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
					  }

#--------------- End of purge -------------------------
			

} #End of function metadatabackup
} #End of try block
catch
{
throw $_
}




##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 2: Copy Backup Files from disk to Tape									##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
Function disktotapecopy()
{

$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = 'ALL'"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


Sqlcmd -S $DBServerInstance -d msdb -Q "use msdb" -o $errorlogfiletemp
if ($lastexitcode -eq 1)
{
	" Error connection $DBServerInstance " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 2" >> $errorlogfile
	$exitcode = 99
}
else
{
	$query4 = "SELECT BkpFileName from ITS_BACKUP_JOB where upper(ServerName) = upper('$DBWindowsServerName') and upper(InstanceName) =upper

('$DBServerInstance') and upper(JobName) in ('ITSSQL_MetaData') and upper(BackupToTape) in ('N','F')"
	$da4 = New-Object System.Data.SqlClient.SqlDataAdapter ($query4,$DBServerConnString)
	$dt4 = New-Object System.Data.DataTable
	$da4.fill($dt4)

	foreach ($Row in $dt4.Rows)
	{
		$bkpFileName = $Row[0]

		If (Test-Path $bkpFileName)
			{

		$TapeBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
		$cmd = "$bpbackupPath -p `"$NBUPolicyName`" -s `"$NBUschedulename`" -w `"$bkpFileName`""

		& cmd.exe /c $cmd

		if ($lastexitcode -ne 0)
		{

		

		$err = "Job Name:ITSSQL_MetaData
		BackupType:$BackupType
		Server:$DBWindowsServerName
		Instance:$DBServerInstance
		Error Description: Disk to tape copy failed for file $bkpFileName on server $DBServerInstance"
		$log = New-Object System.Diagnostics.EventLog('Application')
		$log.set_source("JNJ SQL Backup")
		$infoevent=[System.Diagnostics.EventLogEntryType]::Error
		$log.WriteEntry($err,$infoevent,104,1)


			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
			"Tape backup failed for file $bkpFileName on server $DBServerInstance" >> $errorlogfile
			"Job ITSSQL_MetaData failed at Step 2. Disk to tape copy failed for file $bkpFileName" >> $errorlogfile
			$exitcode = 99
			
			$updateSql = "update ITS_BACKUP_JOB set BackupToTape='F', TapeBkpStartTime = '$TapeBkpStartTime', TapeBkpEndTime = '$TapeBkpEndTime' where 

BkpFileName = '$bkpFileName'"
			Sqlcmd -S $DBServerInstance -d msdb -Q $updateSql -o $errorlogfiletemp
			
		}
		ELSE
		{
			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

			"Tape backup successful for file $bkpFileName on server $DBServerInstance" >> $errorlogfile

			$updateSql = "update ITS_BACKUP_JOB set BackupToTape='Y', TapeBkpStartTime = '$TapeBkpStartTime', TapeBkpEndTime = '$TapeBkpEndTime' where 

BkpFileName = '$bkpFileName'"
			Sqlcmd -S $DBServerInstance -d msdb -Q $updateSql -o $errorlogfiletemp
		}
			}
	}
}
}





##Clear error log folder to delete older than 90 days log
$errlogdeletepath = $errorlogPath + "*"
$DateToDelete = -90
Get-ChildItem $errlogdeletepath -Recurse -include *.log | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force

}


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Main body													##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

metadatabackup
disktotapecopy

EXIT $exitcode