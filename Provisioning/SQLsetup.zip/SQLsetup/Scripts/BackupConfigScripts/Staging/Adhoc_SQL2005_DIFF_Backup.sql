
USE [msdb]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'ITS_adhoc_backupinfo' and type = 'u')
    DROP TABLE ITS_adhoc_backupinfo

/****** Object:  Table [dbo].[ITS_adhoc_backupinfo]    Version 1.0 Script Date: 9/13/2016 4:17:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_adhoc_backupinfo](
	[ServerName] [varchar](50) NOT NULL,
	[InstanceName] [varchar](50) NOT NULL,
	[DatabaseName] [varchar](2000) NOT NULL,
	[ScheduledateTime] [varchar](100) NULL,
	[BackupType] [varchar](20) NOT NULL,
 CONSTRAINT [Ser_Inst_DB_2] PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC,
	[InstanceName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [msdb]
GO
INSERT INTO [dbo].[ITS_adhoc_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
(
		   Convert(Varchar(50),SERVERPROPERTY('machinename')),
		    Convert(Varchar(50),SERVERPROPERTY('ServerName'))
           ,'ALL'
           ,Null
           ,'TAPE') 

SET ANSI_PADDING OFF
GO


/************************ ADHOC Backup JObs *********************************/
USE [msdb]
GO
/****** Object:  Job [ITSSQL_Adhoc_DirectTape_DIFF]    Script Date: 05/13/2015 14:56:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/13/2015 14:56:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_Adhoc_DirectTape_DIFF', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Version 1.0
ITSSQL_Adhoc_DirectTape_DIFF_2005',
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_Adhoc_DirectTape_FULL]    Script Date: 05/13/2015 14:56:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_Adhoc_DirectTape_DIFF', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2,
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'"C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -File "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\BackupConfigScripts\Staging\SQL2005_Adhoc_DIRECTTAPE_DIFF.ps1"', 
		@flags=0

IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_BACKUP_JOB]    Script Date: 2/26/2015 8:31:05 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_BACKUP_JOB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId,
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=2, 
		@notify_level_page=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
