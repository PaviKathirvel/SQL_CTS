-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_master_backupinfo give four parameters ServerName InstanceName DatabaseName Schedule BackupType
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_masterbackup_entry') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_masterbackup_entry
Go
Create procedure usp_masterbackup_entry
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@ScheduledateTime [varchar](100),
@BackupType [varchar](3000)
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName 
           ,@ScheduledateTime
           ,@BackupType) 

END 
GO
