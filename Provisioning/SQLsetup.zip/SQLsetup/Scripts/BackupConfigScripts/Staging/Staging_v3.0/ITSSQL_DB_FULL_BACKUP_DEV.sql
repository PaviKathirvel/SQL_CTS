USE [msdb]
GO

/****** Object:  StoredProcedure [dbo].[ITSSQL_DB_FULL_BACKUP_DEV]    Script Date: 04/28/2015 07:01:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











CREATE PROCEDURE [dbo].[ITSSQL_DB_FULL_BACKUP_DEV](@BackupFolder as VARCHAR(8000),@DBWindowsServerName as VARCHAR(8000),@DBServerInstanceName as VARCHAR(8000),@dbnamelist as VARCHAR(8000) = NULL) AS
DECLARE @Baksql VARCHAR(8000)                          --to store backup query
DECLARE @dbname VARCHAR(100)                        --will store database name in cursor
DECLARE @BAK_PATH VARCHAR(4000)                 --will hold path for backup flder + database name
DECLARE @ScriptVersion VARCHAR(100)
DECLARE @BkpFileName VARCHAR(4000)            --will hold path for backup flder + database name
DECLARE @BkpFileSizeMB int                                            --will hold backup file size
DEclare @BackupDate varchar(20)                           --will hold date in YYYYMMDD_HHMMSS format. will be appended in filename.
DEclare @DeleteDate datetime
DECLARE @DiskBkpStartTime datetime
DECLARE @DiskBkpEndTime datetime
declare @dbnametbl table(dbrow varchar(100))               --Will hold database names as rows provided in paramater dbnamelist
declare @mydb as varchar(100)                --string temp databasename for creating dbnametable from dbnamelist parameter
DECLARE @Restoresql VARCHAR(8000)                 --to store restore verifyonly query
DECLARE @dbBkpFileArray TABLE (idx int identity(1,1), dbBkpFilePath varchar(4000))     --to store filenames for restore verifyonly query
declare @restoreFilePath VARCHAR(4000)
DECLARE @ver nvarchar(128)                      ---to check the version to check the feasiblity of Backup Compression
DECLARE @edi nvarchar(128)						-----to check the edition to check the feasiblity of Backup Compression
DECLARE @latedate datetime						----- to check before deleting backup file if it has been taken to tape
DECLARE @RETURN VARCHAR(20)
SET @RETURN = 'SELECT 0'

/* CHECK BAKUP FOLDER PATH IS PROVIDED. EXIT WITH ERROR IF PATH IS NOT PROVIDED */
if (@BackupFolder = '')
begin
                Print ('ITSSQL_Metadata failed. Job ITSSQL_ITSSQL_MetaData at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. No database backup path provided.')
                SET @RETURN = 'SELECT 99'
                RETURN 1
end

/* SETTING UP VARIABLS USED IN THE SCRIPT */
SET @ScriptVersion = '3.0'
SET @DeleteDate = GETDATE()-6
SET @BackupDate =  REPLACE(REPLACE(REPLACE(CONVERT(VARCHAR,GETDATE(),120),'-',''),':',''),' ','_') -- 20110517_182551
SET @Baksql = ''

/* EXIT THE STORED PROCEDURE IF ENTRY "ALL" IS MADE IN DATABASES COLUMN IN ITS_CFG_BLACKOUT */
if 'ALL' in (select upper(DatabaseName) from ITS_CFG_BLACKOUT 
where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date)
RETURN 0

/* CREATE CURSOR FOR DATABSES FOR WHICH BACKUP HAS TO BE PERFORMED */
/* IF NO DBNAMELIST PARAMETERIF PROVIDED. CREATE DATABASE NAME CURSOR BY SELECTING DBNAMES FROM SYS.DATABASES
BLACKOUT DATABASES FROM ITS_CFG_BLACKOUT WILL BE EXCLUDED BY SUBQUERY */
IF (ltrim(rtrim(@dbnamelist)) = 'ALL')
BEGIN
                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR  
                SELECT name FROM sys.databases
                WHERE state_desc = 'ONLINE' -- Consider only databases which are online
                and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
                and source_database_id is NULL  --Exclude snapshot databases
                and upper(name) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  
                where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date) --Filtering datbases from blackout table
                --to exclude specific database add the databasenames here
END
ELSE IF (ltrim(rtrim(@dbnamelist)) = 'SYSTEM_ALL')
BEGIN
                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR  

SELECT name FROM sys.databases
WHERE state_desc = 'ONLINE' -- Consider only databases which are online
and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
and upper(name) in ('MASTER','MODEL','MSDB')  -- Exluding tempdb database
union 
SELECT name FROM sys.databases
WHERE state_desc = 'ONLINE' -- Consider only databases which are online
and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
and source_database_id is NULL  --Exclude snapshot databases
and is_distributor = '1'

                --to exclude specific database add the databasenames here
END
/* WHEN DBNAMELIST PARAMETERIF IS PROVIDED. CREATE DATABASE NAME CURSOR BY USING THE PARAMETER NAMES */
ELSE
BEGIN

/* INSERT PARAMETER LIST INTO TABLE @dbnametbl */
while (CHARINDEX(',',@dbnamelist) > 0)
                                begin
                                set @mydb = LEFT(@dbnamelist,CHARINDEX(',',@dbnamelist)-1)
                                set @dbnamelist =    SUBSTRING(@dbnamelist,CHARINDEX(',',@dbnamelist)+1,LEN(@dbnamelist) -  CHARINDEX(',',@dbnamelist)+1)      
                                insert into @dbnametbl(dbrow) select rtrim(ltrim(@mydb))
                                --select * from @mytbl  
                                end
                                insert into @dbnametbl(dbrow) select rtrim(ltrim(@dbnamelist))

                                /* CREATE CURSOR FOR DATABSES FOR WHICH BACKUP HAS TO BE PERFORMED */
                                /* SUBQUERY INSIDE THE QUERY WILL SELECT VALID ENTRIES IN ITS_CFG_BLACKOUT. THESE DATABASES WILL BE EXCLUDED FROM BACKUP OPERATION*/
                                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR 
                                select dbrow from @dbnametbl
                                
END
/* OPEN AND FETCH NEXT VALUE FROM CURSOR */
OPEN BackupCursor 
FETCH NEXT FROM BackupCursor INTO @dbname

                WHILE @@FETCH_STATUS = 0
                BEGIN

                SET @BAK_PATH = @BackupFolder + @dbname + '\'
                /* CREATE DATABASE SUBFOLDER IN BACKUP FOLDER PATH. THIS COMMAND WILL HAVE NO EFFECT IF FOLDER ALREDY EXISTS */
                EXECUTE master.dbo.xp_create_subdir @BAK_PATH 
                
                /* CREATE FULL BACKUP FILE PATH */
                SET @BkpFileName = @BackupFolder + @dbname + '\' + @dbname + '_FullBackup_'+@BackupDate+'.bak'
                
                /* CREATE DYNAMIC BACKUP QUERY  */
		
		/* Praneet - Added step to compress and take the Database Backup */
		
		If (@edi='Enterprise' and @ver=10) or (@ver>=11)
		Begin
		SET @Baksql = 'BACKUP DATABASE ['+@dbname+'] TO DISK = '''+@BkpFileName + ''' WITH Compression,INIT;'
		End
		Else
		Begin
		SET @Baksql = 'BACKUP DATABASE ['+@dbname+'] TO DISK = '''+@BkpFileName + ''' WITH INIT;'
		End

                SET @DiskBkpStartTime = GETDATE()
                
                /* EXECUTE BACKUP COMMAND */
                EXEC(@Baksql)
                
                /* IF BACKUP COMMAND IS SUCCESSFUL MAKE ENRTY IN TABLE ITS_BACKUP_JOB ON LOCAL MSDB DATABASE */
                if (@@ERROR = 0)
                BEGIN
                                SET @DiskBkpEndTime = GETDATE()
                                
                                /* CREATE ARRAY OF BACKUP FILES. THIS ARRAY IS USED LATER FOR RESTORE VERIFYONLY COMMAND */ 
                                insert into @dbBkpFileArray (dbBkpFilePath) values (@BkpFileName)
                                
                                SET @BkpFileSizeMB = ( SELECT        (bs.backup_size/1024)/1024 
                                FROM  msdb..backupset bs INNER JOIN msdb..backupmediafamily bf
                                ON bf.media_set_id=bs.media_set_id
                                where bf.physical_device_name = @BkpFileName)
                
                                INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName]
                                ,[BackupType],[BackupToDisk],[BackupToTape]
                                ,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime]
                                ,[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
                                ,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (@DBWindowsServerName,@DBServerInstanceName,@dbname,'DISK_FULL','Y','N',
                                @DiskBkpStartTime,@DiskBkpEndTime,NULL,NULL,@BkpFileName,@BkpFileSizeMB,'ITSSQL_Metadata','N','N',@ScriptVersion)

                                /* DELETE OLD BACKUP FILES. NOTE: FILES ARE ONLY DELETE IF BACKUP IS SUCCESSFUL. */
				/* Praneet - Added step to check if Backup is taken on Tape then it has to be deleted */
				Set @latedate=(select max(TapeBkpEndTime) from ITS_Backup_job where DatabaseName=@dbname)
				If (@latedate<@DeleteDate)
				Begin
				Set @DeleteDate=@latedate
				End
				EXECUTE master.dbo.xp_delete_file 0,@BAK_PATH,N'bak',@DeleteDate,1
                               
                END
                /* IF BACKUP COMMAND IS UNSUCCESSFUL MAKE ENRTY IN TABLE ITS_BACKUP_JOB INDICATING BACKUP FAILED ON LOCAL MSDB DATABASE */
                Else
                BEGIN
                                SET @DiskBkpEndTime = GETDATE()
                
                                INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName]
                                ,[BackupType],[BackupToDisk],[BackupToTape]
                                ,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime]
                                ,[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
                                ,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (@DBWindowsServerName,@DBServerInstanceName,@dbname,'DISK_FULL','F','NA',
                                @DiskBkpStartTime,@DiskBkpEndTime,NULL,NULL,NULL,NULL,'ITSSQL_Metadata','N','NA',@ScriptVersion)

                                Print @@ERROR
                                Print 'ITSSQL_Metadata failed. Job ITSSQL_Metadata failed at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. Database Full backup failed for database ' + @dbname
                                SET @RETURN = 'SELECT 99'
                END

                FETCH NEXT FROM BackupCursor INTO @dbname 
END 

/* BELOW CODE WILL PERFOEM RESTORE VERIFYONLY FOR ALL BACKUP FILES CREATED ABOVE*/
declare @i int
declare @cnt int

select @i = min(idx) - 1, @cnt = max(idx) from @dbBkpFileArray

while @i < @cnt
begin
     select @i = @i + 1
                set @restoreFilePath = (select dbBkpFilePath from @dbBkpFileArray where idx = @i);
                set @Restoresql = 'restore verifyonly from disk = ''' + @restoreFilePath + ''''
     EXEC(@Restoresql)
                if (@@ERROR <> 0)
                BEGIN
								Print @@ERROR
                                Print 'ITSSQL_Metadata failed. Job ITSSQL_Metadata failed at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. Restore verifyonly failed for ' + @restoreFilePath
                                SET @RETURN = 'SELECT 99'
                END            
end

/* CLOSE AND DEALLOCATE THE CURSOR */
CLOSE BackupCursor
DEALLOCATE BackupCursor

EXEC(@RETURN)











GO


