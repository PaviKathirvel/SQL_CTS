-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_CFG_BLACKOUT give four parameters ServerName InstanceName DatabaseName Schedule FromDate ToDate
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_blackout') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_blackout
Go
Create procedure usp_blackout
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@From_Date [datetime],
@To_Date [datetime]
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_CFG_BLACKOUT]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[From_Date]
           ,[To_Date])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName
           ,@From_Date
           ,@To_Date)
End
GO