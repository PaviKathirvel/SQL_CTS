
USE [msdb]
GO

/****** Object:  Job [ITSSQL_DirectTape_FULL]    Script Date: 2/26/2015 8:31:05 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 2/26/2015 8:31:05 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)


IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE (name = N'ITSSQL_DirectTape_FULL'))
BEGIN
    EXEC sp_delete_job 
    @job_name = N'ITSSQL_DirectTape_FULL'
END

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_DirectTape_FULL', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Version 3.0
ITSSQL_DirectTape_FULL', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_DirectTape_FULL]    Script Date: 2/26/2015 8:31:05 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_DirectTape_FULL', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'###=============================================================================================================================###
###-----------------------------------------------------------------------------------------------------------------------------###
### <Script>															###
### <Author>	Atul Patil/Praneet Kumar	</Author>									###
### <Description>Version 1.0	Backup database directly to Tape, write info to centralise server		</Description>	###
### <Usage>	ITSSQL_Backup.ps1 ''FULL|Differential|LOG'' [-dbnames "dbname1<,dbname1....>]	</Usage>			###
### </Script>															###
###-----------------------------------------------------------------------------------------------------------------------------###
###=============================================================================================================================###

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null

##======================================================================================================================================##
## Change Variables values in below section				    								##
##======================================================================================================================================##
$NBUCfg = Get-ItemProperty �HKLM:\Software\Veritas\NetBackup\CurrentVersion\Config�
$NBUMstSrv = $NBUCfg.server[0]
$s1 = "C:\SQLInstall_Logs"
$databasebackupPath = $s1 	##provide database backup path where actual backups will be done
$NBUServerName = $NBUMstSrv	##provide name of netbackup master server to which this database server is registered e.g. "itmpbus1.jnj.com"
$BackupType="Full" ##Provide Backup Type Full/Differential/Log
$DBWindowsServerName = $env:computername ##provide Windows cluster server name in case of cluster else provide windows server name 
$DBServerInstanceName = "$(ESCAPE_DQUOTE(SRVR))" ## DB Server InstanceName
# $dbbackexPath = Get-WMIObject Win32_LogicalDisk -filter "DriveType = 3" | Select-Object DeviceID | ForEach-Object {Get-Childitem ($_.DeviceID + "\") -include dbbackex.exe -recurse}

# ------- Get backup path from registry -------
$NBUreg= Get-ItemProperty �HKLM:\Software\Veritas\NetBackup\CurrentVersion�
$NBUfolder = $NBUreg.INSTALLDIR
$dbbackexPath = Get-ChildItem -Path $NBUfolder -Filter dbbackex.exe -Recurse | ForEach-Object {$_.FullName}

$NBUPolicyName = "ITS-MSSQL"	##Name of netbackup policy, used for writing backup directly to tape
##======================================================================================================================================##
## End of Variable section						    								##
##======================================================================================================================================##

$ScriptVersion = ''3.0''
$LocalMsdb = "msdb"
$exitcode = 0
$JobName = "ITSSQL_DirectTapeBackup"

$fso = New-Object -ComObject Scripting.FileSystemObject
$dbbackexPath = $fso.GetFile($dbbackexPath).ShortPath

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
$err ="Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Either SQLAgent service account is Not a local admin or Restart of SQL Agent not done after adding it to local admin"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode    
}

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{

$err = "Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Database backup path not provided"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode
}

##check if backup path is valid and ends with \, if not add \ to the backup path
$Chkdbpath = $databasebackupPath.EndsWith("\")
if($Chkdbpath -ne "True") {$databasebackupPath = $databasebackupPath + "\"}

## create error log file
$errorlogPath = $databasebackupPath + "backuperrorlog\"
$errorlogfile = $errorlogPath + "backuperrorlog-" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".log"
$errorlogfiletemp = $errorlogPath + "backuperrorlogtemp.log"
if(!(Test-Path -Path $errorlogPath)) { new-item -Path $errorlogPath �itemtype directory }
if(!(Test-Path -Path $errorlogfile)) { new-item -Path $errorlogfile �itemtype file }



##If no database backup paramenet is passed exit the code with error.
if (($BackupType -ne "full") -and ($BackupType -ne "Differential") -and ($BackupType -ne "log"))
{

	
$err = "Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Invalid backup parameter is passed. Expected values are full,Differential or log"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)

	"ITSSQL_BackupJob failed. Invalid backup parameter is passed. Expected values are full,Differential or log"  >> $errorlogfile
	$exitcode = 99	
	EXIT $exitcode
}
$BackupType = $BackupType.Trim()



##crearing local Database server connectionstrings
$DBServerConnString = "Server=$DBServerInstanceName;Database=msdb;Integrated Security=true;"




##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 1: Take Full/Differential/Log Tape Backup as per parameter passed  						##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

try
{
Function tapebackup()
{


$query30 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da30 = New-Object System.Data.SqlClient.SqlDataAdapter ($query30,$DBServerConnString)
		$dt30 = New-Object System.Data.DataTable
		$da30.fill($dt30)


if(($dt30.Rows.Count -ne 0))
{
$err = "Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Databases are blackout from backup"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode
}	

############### Get instance name ###############

$DBServerInstance = "$(ESCAPE_DQUOTE(SRVR))"
$CompName = $env:computername
$pos = $DBServerInstance.IndexOf("\")
$instName = $DBServerInstance.Substring($pos+1)

If ($DBServerInstance -eq $CompName)
{
  $instName = ''MSSQLSERVER''
}

################################################

if(($dt30.Rows.Count -eq 0))
{


##create bch folder. this folder will hold tape backups scripts. One file will be created for each database which will be called using Netbackup command
$bchDir = $databasebackupPath + "bch" + "\"

if(!(Test-Path -Path $bchDir))
{ new-item -Path $bchDir �itemtype directory }

$query1="select DatabaseName from ITS_master_backupinfo where upper(ServerName) = upper(''$DBWindowsServerName'') and upper(InstanceName) = upper(''$DBServerInstanceName'') and upper(BackupType) = ''TAPE'' and (upper(DatabaseName) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  where 
convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date))  "

$da1 = New-Object System.Data.SqlClient.SqlDataAdapter ($query1,$DBServerConnString)
$dt1 = New-Object System.Data.DataTable
$da1.fill($dt1)


if(($dt1.Rows.Count -eq 0))
{
$err = "Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Either database is blackout from DirectTape Backup or No entry for DirectTape Backup found in ITS_Master_Backup"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode
}


foreach ($Row in $dt1.Rows)
	{
		
		$dbnames = $Row[0]

$dbs = "$dbnames"
$dbs = $dbs -replace ",","'',''"
$dbs = $dbs -replace " ",""





	if($dbnames -eq "ALL")
	 
	{
		if($BackupType -eq "full")
		{
			$query22 = "SELECT name FROM sys.databases WHERE source_database_id is NULL AND upper(name) <> ''TEMPDB'' and 
(upper(name) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  where convert(smalldatetime,GETDATE()) >= From_Date and 
convert(smalldatetime,GETDATE()) <= To_Date))"
		}
		elseif($BackupType -eq "Differential")
		{
			$query22 = "SELECT name FROM sys.databases WHERE state_desc = ''ONLINE'' AND source_database_id is NULL AND upper(name) not in 

(''TEMPDB'') and (upper(name) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  where convert(smalldatetime,GETDATE()) >= From_Date and 
convert(smalldatetime,GETDATE()) <= To_Date)) "
		}
		elseif($BackupType -eq "log")
		{
			$query22 = "SELECT name FROM sys.databases WHERE state_desc = ''ONLINE'' AND source_database_id is NULL AND upper(name) not in 

(''TEMPDB'',''MASTER'') AND recovery_model <> 3 and (upper(name) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  where 
convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date))"
		}
	}


else
{
	if($BackupType -eq "full")
	{
		$query22 = "SELECT name FROM sys.databases WHERE source_database_id is NULL AND upper(name) <> ''TEMPDB'' and name in (''$dbnames'')"
	}
	elseif($BackupType -eq "Differential")
	{
		$query22 = "SELECT name FROM sys.databases WHERE state_desc = ''ONLINE'' AND source_database_id is NULL AND upper(name) not in (''TEMPDB'') and 

name in (''$dbnames'')"
	}
	elseif($BackupType -eq "log")
	{
		$query22 = "SELECT name FROM sys.databases WHERE state_desc = ''ONLINE'' AND source_database_id is NULL AND upper(name) not in (''TEMPDB'',''MASTER'') AND 

recovery_model <> 3 and name in (''$dbnames'')"
	}
}


$da22 = New-Object System.Data.SqlClient.SqlDataAdapter ($query22,$DBServerConnString)
$dt22 = New-Object System.Data.DataTable
$da22.fill($dt22)


if($dt22.Rows.Count -eq 0)
{
$err = "Job Name:ITSSQL_DirectTapeBackup
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstanceName
Error Description:Appropiate Tape entry Not found for$BackupType in ITS_master_backupinfo or it is blackout "
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode
}

if(($dt22.Rows.Count -eq 0) -and ($dbnames.length -eq 0))
{
	"Tape entry for Database Instance: $DBServerInstanceName not found in table ITS_master_backupinfo" >> $errorlogfile
	"ITSSQL_BackupJob failed. Job ITSSQL_DirectTapeBackup failed at Step 1" >> $errorlogfile
	$exitcode = 99
}

if($dt22.Rows.Count -ne 0)
{
	foreach ($Row in $dt22.Rows)
	{
		$rowvalue = $Row[0]
		$forcedBackupType = ""
############################################################################################################

		## check is Differentialrenetial backup can be taken
		if($BackupType -eq "Differential")
		{
			$query23 = "SELECT Differential_base_lsn FROM master.sys.master_files WHERE upper(name) = upper(''$rowvalue'') AND [type] = 0 AND [file_id] = 1"
		}
		elseif($BackupType -eq "log")
		{
			$query23 = "SELECT last_log_backup_lsn FROM sys.database_recovery_status drs inner join sys.databases dbs on drs.database_id =  dbs.database_id 

where upper(dbs.name) = upper(''$rowvalue'')"
		}

		if(($BackupType -eq "Differential") -or ($BackupType -eq "log"))
		{
			$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
			$dt23 = New-Object System.Data.DataTable
			$da23.fill($dt23)

			if($dt23.Rows.Count -ne 0)
			{
				foreach ($Row in $dt23.Rows)
				{
					$bkptest = "$Row[0]"
				}

				if($bkptest.length -eq 0)
				{
					"Differential or Transactional log cannot be taken for database $rowvalue. Full backup will be performed" >> $errorlogfile
					$forcedBackupType = "forced_fullbkp"
				}
			}
		}

				if(($BackupType -eq "Differential") -or ($BackupType -eq "log"))
		{

			$query36 = "SELECT s.database_name FROM msdb.dbo.backupset s INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id where upper(database_name) = upper(''$rowvalue'')"
			$da36 = New-Object System.Data.SqlClient.SqlDataAdapter ($query36,$DBServerConnString)
			$dt36 = New-Object System.Data.DataTable
			$da36.fill($dt36)

			if($dt36.Rows.Count -eq 0)
			{
				

					"Differential or Transactiol log cannot be taken for database $rowvalue. Full backup will be performed" >> $errorlogfile
					$forcedBackupType = "forced_fullbkp"
				
			}
		}

				if (($rowvalue -eq "master") -or ($rowvalue -eq "msdb") -or ($rowvalue -eq "model") -or ($rowvalue -eq "distribution"))
				{
				$forcedBackupType = "forced_fullbkp"
				}
				

########################################################################################################################################

		if(($BackupType -eq "full") -or ($forcedBackupType -eq "forced_fullbkp"))
			{
########################################################################################################################################
##do not alter this code 
$bchstring = "OPERATION BACKUP
DATABASE `"$rowvalue`"
SQLHOST `"$DBServerInstanceName`"
NBSERVER `"$NBUServerName`"
MAXTRANSFERSIZE 6
BLOCKSIZE 7
VDITIMEOUTSECONDS 1800
POLICY $NBUPolicyName
NUMBUFS 2
ENDOPER TRUE"
##do not alter this code end
########################################################################################################################################
			}
		elseif($BackupType -eq "Differential")
			{
########################################################################################################################################
##do not alter this code 
$bchstring = "OPERATION BACKUP
DATABASE `"$rowvalue`"
SQLHOST `"$DBServerInstanceName`"
NBSERVER `"$NBUServerName`"
DUMPOPTION INCREMENTAL
MAXTRANSFERSIZE 6
BLOCKSIZE 7
VDITIMEOUTSECONDS 1800
POLICY $NBUPolicyName
NUMBUFS 2
ENDOPER TRUE"
##do not alter this code end
########################################################################################################################################
			}
		elseif($BackupType -eq "log")
			{
########################################################################################################################################	
##do not alter this code 
$bchstring = "OPERATION BACKUP
DATABASE `"$rowvalue`"
SQLHOST `"$DBServerInstanceName`"
NBSERVER `"$NBUServerName`"
OBJECTTYPE TRXLOG
MAXTRANSFERSIZE 6
BLOCKSIZE 7
VDITIMEOUTSECONDS 1800
POLICY $NBUPolicyName
NUMBUFS 2
ENDOPER TRUE"
##do not alter this code end
########################################################################################################################################
			}
		else
			{
				"Error reading backup parameter. Backup parameter is: $BackupType" >> $errorlogfile
				$exitcode = 99
			}

$srv = new-object "Microsoft.SqlServer.Management.SMO.Server" $DBServerInstanceName
$AllDBs=$srv.Databases

foreach ($db in $AllDBs)
	{
		$onlineDB = $db.name
		"Database is $onlineDB" >> $errorlogfiletemp
			#-------------------- Add a row in ITS_BACKUP_JOB for offline databases --------------------
			IF ((!($db.IsAccessible)) -and ($onlineDB -eq $rowvalue))

			  {

				$OfflineStartTime = date -format "yyyyMMdd HH:mm:ss"

				$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
				,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
				,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstanceName'',''$rowvalue'',''$insertBkpVal'',''NA'',''NA'',
				 NULL,NULL,''$OfflineStartTime'',NULL,''OFFLINE'',NULL,''ITSSQL_DirectTapeBackup'',''NA'',''N'',''$ScriptVersion'')"

				Sqlcmd -S $DBServerInstanceName -d $LocalMsdb -Q $insertSql -o $errorlogfiletemp

			  }


		if ((($db.IsAccessible)) -and ($onlineDB -eq $rowvalue))
		{

			IF(($rowvalue -eq "master") -or ($rowvalue -eq "msdb") -or ($rowvalue -eq "model"))
			  {
			     $rowvalue_sysdbs = $rowvalue +"_"+ $instName
			     $rv = $rowvalue_sysdbs -replace " ",""
			  }
			 ELSE
			  {
				 $rv = $rowvalue -replace " ",""
			  }

		# ------- Add timestamp to bch file to prevent access denial for NBU exe ---------
		$bchfile = $bchDir + "__temp__" + $rv + "_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm-ss") + ".bch"
		$bchstring > $bchfile

		$Tapebkpcmd = "`"$dbbackexPath`" -f $bchfile -np"
		$TapeBkpStartTime = date -format "yyyyMMdd HH:mm:ss"

		& cmd /c $Tapebkpcmd

		$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

		if(($BackupType -eq "full") -or ($forcedBackupType -eq "forced_fullbkp"))
		{	
			$type = "D"	
			$insertBkpVal = "TAPE_FULL"
		}
		elseif($BackupType -eq "Differential")
		{	
			$type = "I"	
			$insertBkpVal = "TAPE_DIFF"
		}
		elseif($BackupType -eq "log")
		{
			$type = "L"	
			$insertBkpVal = "TAPE_LOG"
		}

		$query24 ="SELECT m.physical_device_name, CAST(CAST(s.backup_size / 1000000 AS INT) AS VARCHAR(14)) + '' '' + ''MB'' AS bkSize
		FROM msdb.dbo.backupset s INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
		WHERE s.database_name = ''$rowvalue'' and s.backup_start_date >= ''$TapeBkpStartTime'' and s.type = ''$type''
		ORDER BY backup_start_date DESC, backup_finish_date DESC"

		$da24 = New-Object System.Data.SqlClient.SqlDataAdapter ($query24,$DBServerConnString)
		$dt24 = New-Object System.Data.DataTable
		$da24.fill($dt24)

		if($dt24.Rows.Count -ne 0)
		{
			$BkpFileName = $dt24.Rows.Item(0).Item(0)
			$BkpFileSizeMB = $dt24.Rows.Item(0).Item(1)
			$BkpFileSizeMB = $BkpFileSizeMB.Substring(0,$BkpFileSizeMB.Length-3)

			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstanceName'',''$rowvalue'',''$insertBkpVal'',''NA'',''Y'',
			NULL,NULL,''$TapeBkpStartTime'',''$TapeBkpEndTime'',''$BkpFileName'',$BkpFileSizeMB,''ITSSQL_DirectTapeBackup'',''NA'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstanceName -d $LocalMsdb -Q $insertSql -o $errorlogfiletemp
		}
		else
		{
			$FileTimeStamp = date -format "yyyyMMdd_HHmmss"
			$BkpFileName = $rowvalue + "_" + $FileTimeStamp
	
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstanceName'',''$rowvalue'',''$insertBkpVal'',''NA'',''F'',
			NULL,NULL,''$TapeBkpStartTime'',''$TapeBkpEndTime'',''$BkpFileName'',NULL,''ITSSQL_DirectTapeBackup'',''NA'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstanceName -d $LocalMsdb -Q $insertSql -o $errorlogfiletemp

#------------- Capture error code from NBU Install folder -------------------

		$todaydate = get-date -format MMddyy	
		$todaydate = $todaydate + ".rpt"

		$NBUreg= Get-ItemProperty �HKLM:\Software\Veritas\NetBackup\CurrentVersion�
		$NBUfolder = $NBUreg.INSTALLDIR

		$file_txt = $NBUfolder + ''NetBackup\logs\mssql_backup_failures\'' + "$todaydate"

		IF (Test-Path $file_txt)

		{

		   [Array]$finds = Select-String -Path $file_txt -Pattern "STATUS "
 		   [int]$Last = $finds[-1].LineNumber

		  $StatusCode = ((Get-Content $file_txt)[$Last -1]).Substring(7)
		  $ErrorMsg = ((Get-Content $file_txt)[$Last]).Substring(7)

		  "Status code from NetBackup log folder is : $StatusCode" >> $errorlogfile
		  "Message from NetBackup log folder is : $ErrorMsg" >> $errorlogfile
		  "" >> $errorlogfile

			IF (("230", "236", "239", "245", "246", "247", "248") -contains ($StatusCode))
			  {
				$err = "Job Name:ITSSQL_DirectTapeBackup
				BackupType:$BackupType
				Server:$DBWindowsServerName
				Instance:$DBServerInstanceName
				Error Description:$BackupType backup for database $rowvalue on $DBServerInstanceName failed due to policy related error"
				$log = New-Object System.Diagnostics.EventLog(''Application'')
				$log.set_source("JNJ SQL Backup")
				$infoevent=[System.Diagnostics.EventLogEntryType]::Error
				$log.WriteEntry($err,$infoevent,101,1)
				
				# Stop further looping and backing up of remaining databases and exit out
				EXIT 99
			  }

			ELSEIF (("237", "240", "241") -contains ($StatusCode))
			  
			  {
				$err = "Job Name:ITSSQL_DirectTapeBackup
				BackupType:$BackupType
				Server:$DBWindowsServerName
				Instance:$DBServerInstanceName
				Error Description:$BackupType backup for database $rowvalue on $DBServerInstanceName failed due to schedule related error"
				$log = New-Object System.Diagnostics.EventLog(''Application'')
				$log.set_source("JNJ SQL Backup")
				$infoevent=[System.Diagnostics.EventLogEntryType]::Error
				$log.WriteEntry($err,$infoevent,101,1)

				# Stop further looping and backing up of remaining databases and exit out
				EXIT 99
			  }
	
		"$BackupType Tape backup failed for database $rowvalue " >> $errorlogfile
		"ITSSQL_BackupJob failed. Job ITSSQL_DirectTapeBackup failed at Step 1" >> $errorlogfile

		}

	    }


		}	#--------------- End of if ((($db.IsAccessible)) -and ($onlineDB -eq $rowvalue)) ----------------------------

	}		#------------------------------ End of loop foreach ($db in $AllDBs) ------------------------------


	}
}
}
}
##Clear error log folder to delete older than 90 days log
$errlogdeletepath = $errorlogPath + "*"
$DateToDelete = -90
Get-ChildItem $errlogdeletepath -Recurse -include *.log | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force

##Clear bch folder to delete files older than 15 days log
$days = (Get-Date).AddDays(-7)
$path = "C:\SQLInstall_Logs\bch"
Get-ChildItem -Path $path -Recurse -Force | Where-Object { !$_.PSIsContainer -and $_.CreationTime -lt $days } | Remove-Item -Force

}
}
catch
{
throw $_
}




##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Main body													##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##


tapebackup
EXIT $exitcode', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_BACKUP_JOB]    Script Date: 2/26/2015 8:31:05 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_BACKUP_JOB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
DECLARE @sname varchar(59)
set @sname = Right(@@SERVERNAME,1)
If (@sname = '0')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_0', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'd4bc15c3-0a5e-448f-8b3a-914da1400020'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '1')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_1', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b1e490f9-2a63-4d42-81c5-41cd4156cac3'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '2')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_2', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=4, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'6642f0b4-be51-4ff0-8109-242a46719a9d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '3')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_3', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=8, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'ad7cb2fe-3123-4011-b667-a15b95c2353c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '4')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_4', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=16, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959, 
		@schedule_uid=N'76fa4890-9218-4dd0-a786-e9e7fab24f59'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '5')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_5', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'4e1b2130-08d8-4094-b1e3-69f1cb645177'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '6')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_6', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=170000, 
		@active_end_time=235959, 
		@schedule_uid=N'36cc0024-8085-400a-97cc-8b59a1c81afb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '7')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_7', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=4, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'96411b42-174c-4709-af47-4c7aa893b672'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname = '8')
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_8', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=8, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'15ee15af-9eb2-4e18-ac57-3919d1a24855'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End
If (@sname Not IN ('0','1','2','3','4','5','6','7','8'))
Begin
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server_9', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=16, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151013, 
		@active_end_date=99991231, 
		@active_start_time=200000, 
		@active_end_time=235959, 
		@schedule_uid=N'03044533-a42b-4abd-8af9-763d465e43a2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
End

EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId,
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=2, 
		@notify_level_page=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

