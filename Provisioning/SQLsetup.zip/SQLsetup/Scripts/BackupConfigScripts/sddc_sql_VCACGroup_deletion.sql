/**********************************************************************************************
Script Name: sddc_sql_VCACGroup_deletion.sql

**********************************************************************************************
Version				Date			Author			Reason For Change
1.0				09/24/2015		Jay			New Script
**********************************************************************************************/

/*Revoke sysadmin access to VCAC group*/

USE [master]
GO

DROP LOGIN [NA\Admin_pkuma10]
GO

