USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FullDatabaseBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'FullDatabaseBackupMaintenance.Subplan_1',
    @description = N'FullDatabaseBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;


USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DiffDatabaseBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'DiffDatabaseBackupMaintenance.Subplan_1',
    @description = N'DiffDatabaseBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;


USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'TransactionLogBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'TransactionLogBackupMaintenance.Subplan_1',
    @description = N'TransactionLogBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;

USE [msdb]
GO

/****** Object:  Job [ITSSQL_MetaData]    Script Date: 08/24/2015 11:45:11 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 08/24/2015 11:45:11 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_MetaData', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_MetaData]    Script Date: 08/24/2015 11:45:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_MetaData', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'###=============================================================================================================================###
###-----------------------------------------------------------------------------------------------------------------------------###
### <Script>															###
### <Author>	Atul Patil/Praneet Kumar</Author>										###
### <Description> export user database metadata, backup and copy system backup files to tape, write info to centralise server </Description>	###
### <Usage>	ITSSQL_Backup.ps1 ''FULL|DIFF|LOG'' [-dbnames "dbname1<,dbname1....>]	</Usage>				###
### </Script>															###
###-----------------------------------------------------------------------------------------------------------------------------###
###------Praneet : Modified step to script out Logins and Users at server Level and inserting meta objects data in Local table--###
###================================================================================================================a=============###


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | out-null



##======================================================================================================================================##
## Change Variables values in below section				    								##
##======================================================================================================================================##
$DBWindowsServerName = $env:computername	##provide Windows cluster server name in case of cluster else provide windows server name 
$DBServerInstance = "$(ESCAPE_DQUOTE(SRVR))" ##Provide the DB Server Instance Name
$bpbackupPath = Get-WMIObject Win32_LogicalDisk -filter "DriveType = 3" | 
Select-Object DeviceID | 
ForEach-Object {Get-Childitem ($_.DeviceID + "\") -include bpbackup.exe -recurse -ErrorAction SilentlyContinue} 		
$NBUPolicyName = "ITS-SQL-D2T"	##Name of netbackup policy, used for writing backup file from disk to tape
$NBUschedulename = "Backup-LAN-Dev"		##Name of netbackup schedule used for writing backup file from disk to tape	
##======================================================================================================================================##
## End of Variable section						    								##
##======================================================================================================================================##

$exitcode = 0
$Days = "7"						    
$ScriptVersion = ''1.0''
$JobName = ''ITSSQL_MetaData''
$BackupType = ''METADATA''

$instances = (get-itemproperty ''HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server'').InstalledInstances
 foreach ($inst in $instances)
        {
         $p = (Get-ItemProperty ''HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'').$inst
         $test= (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer\CurrentVersion").CurrentVersion
         If ($test.StartsWith(11) -eq ''True'')
         {
         if ($inst -eq ''MSSQLServer'')
         	{
         $DBServerInstance = $env:computername
         	}
         else
        	{
         $DBServerInstance = $env:computername+''\''+$inst
         	}
	 $databasebackupPath = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").BackupDirectory
	 $databasebackupPath = $databasebackupPath + "\"
         }
        }

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
$err ="Job Name:ITSSQL_MetaData
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstance
Error Description:Either SQLAgent service account is Not a local admin or Restart of SQL Agent not done after adding it to local admin"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,104,1)
$exitcode = 99	
EXIT $exitcode    
}

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{

$err = "Job Name:ITSSQL_MetaData
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstance
Error Description:Database backup path not provided"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,104,1)
$exitcode = 99	
EXIT $exitcode
}

##check if backup path is valid and ends with \, if not add \ to the backup path
##$Chkdbpath = $databasebackupPath.EndsWith("\")
##if($Chkdbpath -ne "True") {$databasebackupPath = $databasebackupPath + "\"}

## create error log file
$errorlogPath = $databasebackupPath + "backuperrorlog\"
$errorlogfile = $errorlogPath + "backuperrorlog-" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".log"
$errorlogfiletemp = $errorlogPath + "backuperrorlogtemp.log"
if(!(Test-Path -Path $errorlogPath)) { new-item -Path $errorlogPath �itemtype directory }
if(!(Test-Path -Path $errorlogfile)) { new-item -Path $errorlogfile �itemtype file }

##If no database backup path is not passed exit the code with error.
if($databasebackupPath.length -eq 0)
{
	"ITSSQL_BackupJob failed. Database backup path no provided"  >> $errorlogfile
	$exitcode = 99	
	EXIT $exitcode
}




$DBServerConnString = "Server=$DBServerinstance;Database=msdb;Integrated Security=true;"


$srv = new-object "Microsoft.SqlServer.Management.SMO.Server" $DBServerinstance
$srv.SetDefaultInitFields([Microsoft.SqlServer.Management.SMO.View], "IsSystemObject")
$db = New-Object "Microsoft.SqlServer.Management.SMO.Database"


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 		Step 1: Execute Full backup for system database and generate metadata for user databases				##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
try
{
Function metadatabackup()
{

$query21 = "SELECT DatabaseName FROM ITS_master_backupinfo WHERE upper(BackupType) = ''METADATA'' and upper(DatabaseName) =''ALL''"

$da21 = New-Object System.Data.SqlClient.SqlDataAdapter ($query21,$DBServerConnString)
$dt21 = New-Object System.Data.DataTable
$da21.fill($dt21)



if(($dt21.Rows.Count -eq 0))
{
$err = "Job Name:ITSSQL_MetaData
BackupType:$BackupType
Server:$DBWindowsServerName
Instance:$DBServerInstance
Error Description:Either database is blackout or No entry for Meta Backup found in ITS_Master_Backupinfo"
$log = New-Object System.Diagnostics.EventLog(''Application'')
$log.set_source("JNJ SQL Backup")
$infoevent=[System.Diagnostics.EventLogEntryType]::Error
$log.WriteEntry($err,$infoevent,101,1)
$exitcode = 99	
EXIT $exitcode
}



if($dt21.Rows.Count -eq 0)
{
	"Metadata entry for Database Instance: $DBServerInstance not found " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 1" >> $errorlogfile
	$exitcode = 99
}
else 
{

	Sqlcmd -S $DBServerInstance -d msdb -Q ":EXIT(exec msdb..ITSSQL_DB_FULL_BACKUP_DEV 

''$databasebackupPath'',''$DBWindowsServerName'',''$DBServerInstance'',''SYSTEM_ALL'')" -o $errorlogfiletemp

	if ($lastexitcode -eq 1)
	{


		$err = "Job Name:ITSSQL_MetaData
		BackupType:$BackupType
		Server:$DBWindowsServerName
		Instance:$DBServerInstance
		Error Description: Disk Backup for System databases failed on server $DBServerInstance"
		$log = New-Object System.Diagnostics.EventLog(''Application'')
		$log.set_source("JNJ SQL Backup")
		$infoevent=[System.Diagnostics.EventLogEntryType]::Error
		$log.WriteEntry($err,$infoevent,104,1)

		"Disk Backup for System databases failed." >> $errorlogfile
		"Job ITSSQL_MetaDatafailed at Step 1" >> $errorlogfile
		$exitcode = 99
	}


	$scr = New-Object "Microsoft.sqlServer.Management.Smo.Scripter"
		       	$deptype = New-Object "Microsoft.sqlServer.Management.Smo.DependencyType"
        		$scr.Server = $srv
       			$options = New-Object "Microsoft.sqlServer.Management.SMO.ScriptingOptions"
	        	$options.AllowSystemObjects = $false
        		$options.IncludeDatabaseContext = $true
        		$options.IncludeIfNotExists = $true
	        	$options.ClusteredIndexes = $true
        		$options.Default = $true
        		$options.DriAll = $true
	        	$options.Indexes = $true
        		$options.NonClusteredIndexes = $true
        		$options.IncludeHeaders = $true
	        	$options.ToFileOnly = $true
        		$options.AppendToFile = $true
        		#Set options for SMO.Scripter
	        	$scr.Options = $options

	$dbs=$srv.Databases 


$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


	foreach ($db in $dbs)
	{
		if (($db.name -ne "tempdb") -and ($db.name -ne "master") -and ($db.name -ne "model") -and ($db.name -ne "msdb"))
		{
       			

			$dbval = $db.name

$query24 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date"
		$da24 = New-Object System.Data.SqlClient.SqlDataAdapter ($query24,$DBServerConnString)
		$dt24 = New-Object System.Data.DataTable
		$da24.fill($dt24)


foreach ($Row in $dt24.Rows)
	{
		
	if ($db.name -eq $Row[0]) 
	{
	$dbval=" "
	}
	}
       		



			if ($db.name -eq $dbval)
			{

			$destinationFolder = $databasebackupPath + $dbval+ "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}

			

			#Tables
			$options.FileName = $destinationFolder + $db.name + "_Tables_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
	        	$tb = $db.Tables | where {$_.IsSystemObject -eq $false}
	        	if ($tb -ne $null)
        		{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
			        $scr.Script($tb)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}

			#Triggers
        		$options.FileName = $destinationFolder + $db.name + "_Triggers_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		foreach($tables in $db.Tables | where {$_.IsSystemObject -eq $false})
        		{
				if($tables.Triggers -ne $null)
				{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            			foreach($trigger in $tables.Triggers)
            			{
				
                			$scr.Script($trigger)
					
					
					
            			}
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
				$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
				,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
				,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values 

(''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
				''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"
	
				Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				}
        		}
			

			#Functions
        		$options.FileName = $destinationFolder + $db.name + "_Functions_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
        		$UserDefinedFunctions = $db.UserDefinedFunctions | where {$_.IsSystemObject -eq $false}
        		if ($UserDefinedFunctions -ne $null)
        		{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
            			$scr.Script($UserDefinedFunctions)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 

				
        		}

			#StoredProcedures
	        	$options.FileName = $destinationFolder + $db.name + "_StoredProcedures_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $StoredProcedures = $db.StoredProcedures | where {$_.IsSystemObject -eq $false}
        		if ($StoredProcedures -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($StoredProcedures)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
			
			#Users
			$options.FileName = $destinationFolder + $db.name + "_Users_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Users = $db.Users | where {$_.IsSystemObject -eq $false}
        		if ($Users -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Users)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7

			$query25="select max(TapeBkpEndTime) from ITS_Backup_job where (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''$dbval'' 
			and BackupType=''METADATA''"

			$da25 = New-Object System.Data.SqlClient.SqlDataAdapter ($query25,$DBServerConnString)
			$dt25 = New-Object System.Data.DataTable
			$da25.fill($dt25)


			foreach ($Row in $dt25.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}
			
			}
			
			
			
			
		
 
		}

	
	}


			
			$destinationFolder = $databasebackupPath + "Logins" + "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}
			$options.FileName = $destinationFolder +  "Logins_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Logins = $srv.Logins | where {$_.IsSystemObject -eq $false}
        		if ($Logins -ne $null)
	        	{
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Logins)
				$DiskBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''Logins'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}


			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7
			
			$query26="select max(TapeBkpEndTime) from ITS_Backup_job where (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''Logins'' and 		

			BackupType=''METADATA''"

			$da26 = New-Object System.Data.SqlClient.SqlDataAdapter ($query26,$DBServerConnString)
			$dt26 = New-Object System.Data.DataTable
			$da26.fill($dt26)


			foreach ($Row in $dt26.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}

			

			
			
			$destinationFolder = $databasebackupPath + "Roles" + "\"
			if (!(Test-Path -path $destinationFolder)) {New-Item $destinationFolder -Type Directory}			
			$options.FileName = $destinationFolder + $DBServerinstance + "_Roles_Script_" + (Get-Date).tostring("MM-dd-yyyy-hh-mm") + ".sql"
		        $Roles = $srv.Roles | where {$_.IsSystemObject -eq $false}
        		if ($Roles -ne $null)
	        	{
				
				$DiskBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
				$scr.Script($Roles)
				$scriptbkp=$options.FileName
			$insertSql = "INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName],[BackupType],[BackupToDisk],[BackupToTape]
			,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime],[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
			,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (''$DBWindowsServerName'',''$DBServerInstance'',''$dbval'',''METADATA'',''Y'',''N'',
			''$DiskBkpStartTime'',''$DiskBkpEndTime'',NULL,NULL,''$scriptbkp'',NULL,''ITSSQL_MetaData'',''N'',''N'',''$ScriptVersion'')"

			Sqlcmd -S $DBServerInstance -d msdb -Q $insertSql 
				
        		}
			
		
			$deletepath =  $destinationFolder + "*"
			$DateToDelete = -7

			
			$query27="select max(TapeBkpEndTime) from ITS_Backup_job where (TapeSync=''Y'' or TapeSync=''NA'') and DatabaseName=''Roles''
			and BackupType=''METADATA''"

			$da27 = New-Object System.Data.SqlClient.SqlDataAdapter ($query27,$DBServerConnString)
			$dt27 = New-Object System.Data.DataTable
			$da27.fill($dt27)


			foreach ($Row in $dt27.Rows)
			{
			$latedate= $Row[0]
		
			}
			If ("$latedate" -gt ((Get-Date).AddDays($DateToDelete)))
			{
			Get-ChildItem $deletepath -Recurse -include *.sql | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force
			}
			

		
		
		


		
}
}
}
}
catch
{
throw $_
}



##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Step 2: Copy Backup Files from disk to Tape									##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##
Function disktotapecopy()
{

$query23 = "SELECT DatabaseName FROM ITS_CFG_BLACKOUT where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <=To_Date and 
	   upper(DatabaseName) = ''ALL''"
		$da23 = New-Object System.Data.SqlClient.SqlDataAdapter ($query23,$DBServerConnString)
		$dt23 = New-Object System.Data.DataTable
		$da23.fill($dt23)	


if(($dt23.Rows.Count -eq 0))
{


Sqlcmd -S $DBServerInstance -d msdb -Q "use msdb" -o $errorlogfiletemp
if ($lastexitcode -eq 1)
{
	" Error connection $DBServerInstance " >> $errorlogfile
	"Job ITSSQL_MetaData failed at Step 2" >> $errorlogfile
	$exitcode = 99
}
else
{
	$query4 = "SELECT BkpFileName from ITS_BACKUP_JOB where upper(ServerName) = upper(''$DBWindowsServerName'') and upper(InstanceName) =upper

(''$DBServerInstance'') and upper(JobName) in (''ITSSQL_MetaData'') and upper(BackupToTape) in (''N'',''F'')"
	$da4 = New-Object System.Data.SqlClient.SqlDataAdapter ($query4,$DBServerConnString)
	$dt4 = New-Object System.Data.DataTable
	$da4.fill($dt4)

	foreach ($Row in $dt4.Rows)
	{
		$bkpFileName = $Row[0]

		$TapeBkpStartTime = date -format "yyyyMMdd HH:mm:ss"
		$cmd = "$bpbackupPath -p `"$NBUPolicyName`" -s `"$NBUschedulename`" -w `"$bkpFileName`""

		& cmd.exe /c $cmd

		if ($lastexitcode -ne 0)
		{

		

		$err = "Job Name:ITSSQL_MetaData
		BackupType:$BackupType
		Server:$DBWindowsServerName
		Instance:$DBServerInstance
		Error Description: Disk to tape copy failed for file $bkpFileName on server $DBServerInstance"
		$log = New-Object System.Diagnostics.EventLog(''Application'')
		$log.set_source("JNJ SQL Backup")
		$infoevent=[System.Diagnostics.EventLogEntryType]::Error
		$log.WriteEntry($err,$infoevent,104,1)


			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"
			"Tape backup failed for file $bkpFileName on server $DBServerInstance" >> $errorlogfile
			"Job ITSSQL_MetaData failed at Step 2. Disk to tape copy failed for file $bkpFileName" >> $errorlogfile
			$exitcode = 99
			
			$updateSql = "update ITS_BACKUP_JOB set BackupToTape=''F'', TapeBkpStartTime = ''$TapeBkpStartTime'', TapeBkpEndTime = ''$TapeBkpEndTime'' 

where 

BkpFileName = ''$bkpFileName''"
			Sqlcmd -S $DBServerInstance -d msdb -Q $updateSql -o $errorlogfiletemp
			
		}
		ELSE
		{
			$TapeBkpEndTime = date -format "yyyyMMdd HH:mm:ss"

			"Tape backup successfully for file $bkpFileName on server $DBServerInstance" >> $errorlogfile

			$updateSql = "update ITS_BACKUP_JOB set BackupToTape=''Y'', TapeBkpStartTime = ''$TapeBkpStartTime'', TapeBkpEndTime = ''$TapeBkpEndTime'' 

where 

BkpFileName = ''$bkpFileName''"
			Sqlcmd -S $DBServerInstance -d msdb -Q $updateSql -o $errorlogfiletemp
		}
	}
}
}





##Clear error log folder to delete older than 90 days log
$errlogdeletepath = $errorlogPath + "*"
$DateToDelete = -90
Get-ChildItem $errlogdeletepath -Recurse -include *.log | Where {$_.creationtime -lt (Get-Date).AddDays($DateToDelete)} | Remove-Item -Force

}


##======================================================================================================================================##
##--------------------------------------------------------------------------------------------------------------------------------------##
## 			Main body													##
##--------------------------------------------------------------------------------------------------------------------------------------##
##======================================================================================================================================##

metadatabackup
disktotapecopy

EXIT $exitcode', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_BACKUP_JOB]    Script Date: 08/24/2015 11:45:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_BACKUP_JOB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ITSSQL_METADATA', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=20, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150724, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'6f46d381-a2fb-451a-8cc0-43a1f8501703'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO







USE [msdb]
GO

/****** Object:  StoredProcedure [dbo].[ITSSQL_DB_FULL_BACKUP_DEV]    Script Date: 04/28/2015 07:01:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











CREATE PROCEDURE [dbo].[ITSSQL_DB_FULL_BACKUP_DEV](@BackupFolder as VARCHAR(8000),@DBWindowsServerName as VARCHAR(8000),@DBServerInstanceName as VARCHAR(8000),@dbnamelist as VARCHAR(8000) = NULL) AS
DECLARE @Baksql VARCHAR(8000)                          --to store backup query
DECLARE @dbname VARCHAR(100)                        --will store database name in cursor
DECLARE @BAK_PATH VARCHAR(4000)                 --will hold path for backup flder + database name
DECLARE @ScriptVersion VARCHAR(100)
DECLARE @BkpFileName VARCHAR(4000)            --will hold path for backup flder + database name
DECLARE @BkpFileSizeMB int                                            --will hold backup file size
DEclare @BackupDate varchar(20)                           --will hold date in YYYYMMDD_HHMMSS format. will be appended in filename.
DEclare @DeleteDate datetime
DECLARE @DiskBkpStartTime datetime
DECLARE @DiskBkpEndTime datetime
declare @dbnametbl table(dbrow varchar(100))               --Will hold database names as rows provided in paramater dbnamelist
declare @mydb as varchar(100)                --string temp databasename for creating dbnametable from dbnamelist parameter
DECLARE @Restoresql VARCHAR(8000)                 --to store restore verifyonly query
DECLARE @dbBkpFileArray TABLE (idx int identity(1,1), dbBkpFilePath varchar(4000))     --to store filenames for restore verifyonly query
declare @restoreFilePath VARCHAR(4000)
DECLARE @ver nvarchar(128)                      ---to check the version to check the feasiblity of Backup Compression
DECLARE @edi nvarchar(128)						-----to check the edition to check the feasiblity of Backup Compression
DECLARE @latedate datetime						----- to check before deleting backup file if it has been taken to tape
DECLARE @RETURN VARCHAR(20)
SET @RETURN = 'SELECT 0'

/* CHECK BAKUP FOLDER PATH IS PROVIDED. EXIT WITH ERROR IF PATH IS NOT PROVIDED */
if (@BackupFolder = '')
begin
                Print ('ITSSQL_Metadata failed. Job ITSSQL_ITSSQL_MetaData at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. No database backup path provided.')
                SET @RETURN = 'SELECT 99'
                RETURN 1
end

/* SETTING UP VARIABLS USED IN THE SCRIPT */
SET @ScriptVersion = '1.0'
SET @DeleteDate = GETDATE()-6
SET @BackupDate =  REPLACE(REPLACE(REPLACE(CONVERT(VARCHAR,GETDATE(),120),'-',''),':',''),' ','_') -- 20110517_182551
SET @Baksql = ''

/* EXIT THE STORED PROCEDURE IF ENTRY "ALL" IS MADE IN DATABASES COLUMN IN ITS_CFG_BLACKOUT */
if 'ALL' in (select upper(DatabaseName) from ITS_CFG_BLACKOUT 
where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date)
RETURN 0

/* CREATE CURSOR FOR DATABSES FOR WHICH BACKUP HAS TO BE PERFORMED */
/* IF NO DBNAMELIST PARAMETERIF PROVIDED. CREATE DATABASE NAME CURSOR BY SELECTING DBNAMES FROM SYS.DATABASES
BLACKOUT DATABASES FROM ITS_CFG_BLACKOUT WILL BE EXCLUDED BY SUBQUERY */
IF (ltrim(rtrim(@dbnamelist)) = 'ALL')
BEGIN
                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR  
                SELECT name FROM sys.databases
                WHERE state_desc = 'ONLINE' -- Consider only databases which are online
                and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
                and source_database_id is NULL  --Exclude snapshot databases
                and upper(name) not in (select upper(DatabaseName) from ITS_CFG_BLACKOUT  
                where convert(smalldatetime,GETDATE()) >= From_Date and convert(smalldatetime,GETDATE()) <= To_Date) --Filtering datbases from blackout table
                --to exclude specific database add the databasenames here
END
ELSE IF (ltrim(rtrim(@dbnamelist)) = 'SYSTEM_ALL')
BEGIN
                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR  

SELECT name FROM sys.databases
WHERE state_desc = 'ONLINE' -- Consider only databases which are online
and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
and upper(name) in ('MASTER','MODEL','MSDB')  -- Exluding tempdb database
union 
SELECT name FROM sys.databases
WHERE state_desc = 'ONLINE' -- Consider only databases which are online
and upper(name) <> 'TEMPDB'  -- Exluding tempdb database
and source_database_id is NULL  --Exclude snapshot databases
and is_distributor = '1'

                --to exclude specific database add the databasenames here
END
/* WHEN DBNAMELIST PARAMETERIF IS PROVIDED. CREATE DATABASE NAME CURSOR BY USING THE PARAMETER NAMES */
ELSE
BEGIN

/* INSERT PARAMETER LIST INTO TABLE @dbnametbl */
while (CHARINDEX(',',@dbnamelist) > 0)
                                begin
                                set @mydb = LEFT(@dbnamelist,CHARINDEX(',',@dbnamelist)-1)
                                set @dbnamelist =    SUBSTRING(@dbnamelist,CHARINDEX(',',@dbnamelist)+1,LEN(@dbnamelist) -  CHARINDEX(',',@dbnamelist)+1)      
                                insert into @dbnametbl(dbrow) select rtrim(ltrim(@mydb))
                                --select * from @mytbl  
                                end
                                insert into @dbnametbl(dbrow) select rtrim(ltrim(@dbnamelist))

                                /* CREATE CURSOR FOR DATABSES FOR WHICH BACKUP HAS TO BE PERFORMED */
                                /* SUBQUERY INSIDE THE QUERY WILL SELECT VALID ENTRIES IN ITS_CFG_BLACKOUT. THESE DATABASES WILL BE EXCLUDED FROM BACKUP OPERATION*/
                                DECLARE BackupCursor CURSOR FAST_FORWARD READ_ONLY FOR 
                                select dbrow from @dbnametbl
                                
END
/* OPEN AND FETCH NEXT VALUE FROM CURSOR */
OPEN BackupCursor 
FETCH NEXT FROM BackupCursor INTO @dbname

                WHILE @@FETCH_STATUS = 0
                BEGIN

                SET @BAK_PATH = @BackupFolder + @dbname + '\'
                /* CREATE DATABASE SUBFOLDER IN BACKUP FOLDER PATH. THIS COMMAND WILL HAVE NO EFFECT IF FOLDER ALREDY EXISTS */
                EXECUTE master.dbo.xp_create_subdir @BAK_PATH 
                
                /* CREATE FULL BACKUP FILE PATH */
                SET @BkpFileName = @BackupFolder + @dbname + '\' + @dbname + '_FullBackup_'+@BackupDate+'.bak'
                
                /* CREATE DYNAMIC BACKUP QUERY  */
		
		/* Praneet - Added step to compress and take the Database Backup */
		
		If (@edi='Enterprise' and @ver=10) or (@ver>=11)
		Begin
		SET @Baksql = 'BACKUP DATABASE ['+@dbname+'] TO DISK = '''+@BkpFileName + ''' WITH Compression,INIT;'
		End
		Else
		Begin
		SET @Baksql = 'BACKUP DATABASE ['+@dbname+'] TO DISK = '''+@BkpFileName + ''' WITH INIT;'
		End

                SET @DiskBkpStartTime = GETDATE()
                
                /* EXECUTE BACKUP COMMAND */
                EXEC(@Baksql)
                
                /* IF BACKUP COMMAND IS SUCCESSFUL MAKE ENRTY IN TABLE ITS_BACKUP_JOB ON LOCAL MSDB DATABASE */
                if (@@ERROR = 0)
                BEGIN
                                SET @DiskBkpEndTime = GETDATE()
                                
                                /* CREATE ARRAY OF BACKUP FILES. THIS ARRAY IS USED LATER FOR RESTORE VERIFYONLY COMMAND */ 
                                insert into @dbBkpFileArray (dbBkpFilePath) values (@BkpFileName)
                                
                                SET @BkpFileSizeMB = ( SELECT        (bs.backup_size/1024)/1024 
                                FROM  msdb..backupset bs INNER JOIN msdb..backupmediafamily bf
                                ON bf.media_set_id=bs.media_set_id
                                where bf.physical_device_name = @BkpFileName)
                
                                INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName]
                                ,[BackupType],[BackupToDisk],[BackupToTape]
                                ,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime]
                                ,[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
                                ,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (@DBWindowsServerName,@DBServerInstanceName,@dbname,'DISK_FULL','Y','N',
                                @DiskBkpStartTime,@DiskBkpEndTime,NULL,NULL,@BkpFileName,@BkpFileSizeMB,'ITSSQL_Metadata','N','N',@ScriptVersion)

                                /* DELETE OLD BACKUP FILES. NOTE: FILES ARE ONLY DELETE IF BACKUP IS SUCCESSFUL. */
				/* Praneet - Added step to check if Backup is taken on Tape then it has to be deleted */
				Set @latedate=(select max(TapeBkpEndTime) from ITS_Backup_job where DatabaseName=@dbname)
				If (@latedate<@DeleteDate)
				Begin
				Set @DeleteDate=@latedate
				End
				EXECUTE master.dbo.xp_delete_file 0,@BAK_PATH,N'bak',@DeleteDate,1
                               
                END
                /* IF BACKUP COMMAND IS UNSUCCESSFUL MAKE ENRTY IN TABLE ITS_BACKUP_JOB INDICATING BACKUP FAILED ON LOCAL MSDB DATABASE */
                Else
                BEGIN
                                SET @DiskBkpEndTime = GETDATE()
                
                                INSERT INTO ITS_BACKUP_JOB([ServerName],[InstanceName],[DatabaseName]
                                ,[BackupType],[BackupToDisk],[BackupToTape]
                                ,[DiskBkpStartTime],[DiskBkpEndTime],[TapeBkpStartTime]
                                ,[TapeBkpEndTime],[BkpFileName],[BkpFileSizeMB]
                                ,[JobName],[DiskSync],[TapeSync],[ScriptVersion]) values (@DBWindowsServerName,@DBServerInstanceName,@dbname,'DISK_FULL','F','NA',
                                @DiskBkpStartTime,@DiskBkpEndTime,NULL,NULL,NULL,NULL,'ITSSQL_Metadata','N','NA',@ScriptVersion)

                                Print @@ERROR
                                Print 'ITSSQL_Metadata failed. Job ITSSQL_Metadata failed at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. Database Full backup failed for database ' + @dbname
                                SET @RETURN = 'SELECT 99'
                END

                FETCH NEXT FROM BackupCursor INTO @dbname 
END 

/* BELOW CODE WILL PERFOEM RESTORE VERIFYONLY FOR ALL BACKUP FILES CREATED ABOVE*/
declare @i int
declare @cnt int

select @i = min(idx) - 1, @cnt = max(idx) from @dbBkpFileArray

while @i < @cnt
begin
     select @i = @i + 1
                set @restoreFilePath = (select dbBkpFilePath from @dbBkpFileArray where idx = @i);
                set @Restoresql = 'restore verifyonly from disk = ''' + @restoreFilePath + ''''
     EXEC(@Restoresql)
                if (@@ERROR <> 0)
                BEGIN
								Print @@ERROR
                                Print 'ITSSQL_Metadata failed. Job ITSSQL_Metadata failed at Step 1. Stored procedure ITSSQL_DB_FULL_BACKUP_DEV failed. Restore verifyonly failed for ' + @restoreFilePath
                                SET @RETURN = 'SELECT 99'
                END            
end

/* CLOSE AND DEALLOCATE THE CURSOR */
CLOSE BackupCursor
DEALLOCATE BackupCursor

EXEC(@RETURN)











GO


USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_master_backupinfo]    Version 1.0 Script Date: 9/16/2014 4:17:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_master_backupinfo](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[ScheduledateTime] [varchar](100) NULL,
	[BackupType] [varchar](3000) NOT NULL,
 CONSTRAINT [Ser_Inst_DB] PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC,
	[InstanceName] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [msdb]
GO
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (cast(SERVERPROPERTY('machinename') as nvarchar)
           ,cast(SERVERPROPERTY('ServerName') as nvarchar)
           ,'ALL'
           ,Null
           ,'METADATA') 

SET ANSI_PADDING OFF
GO



USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_CFG_BLACKOUT] Version 1.0   Script Date: 9/16/2014 4:28:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_CFG_BLACKOUT](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[From_Date] [datetime] NOT NULL,
	[To_Date] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_BACKUP_JOB]   Version 1.0 Script Date: 9/16/2014 4:34:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_BACKUP_JOB](
	[ServerName] [varchar](100) NULL,
	[InstanceName] [varchar](100) NULL,
	[DatabaseName] [varchar](100) NULL,
	[BackupType] [varchar](15) NULL,
	[BackupToDisk] [varchar](5) NULL,
	[BackupToTape] [varchar](5) NULL,
	[DiskBkpStartTime] [datetime] NULL,
	[DiskBkpEndTime] [datetime] NULL,
	[TapeBkpStartTime] [datetime] NULL,
	[TapeBkpEndTime] [datetime] NULL,
	[BkpFileName] [varchar](2500) NULL,
	[BkpFileSizeMB] [int] NULL,
	[JobName] [varchar](25) NULL,
	[DiskSync] [varchar](3) NULL,
	[TapeSync] [varchar](3) NULL,
	[ScriptVersion] [varchar](5) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO




USE [msdb]
GO

/****** Object:  Table [dbo].[Audit_blackout]    Script Date: 4/15/2015 11:41:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Audit_blackout](
                [ServerName] [varchar](100) NOT NULL,
                [InstanceName] [varchar](100) NOT NULL,
                [DatabaseName] [varchar](100) NOT NULL,
                [From_Date] [datetime] NOT NULL,
                [To_Date] [datetime] NOT NULL,
                [UpdateDate] [datetime] NULL,
                [UserName] [varchar](128) NULL,
                [type] [varchar](10) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO

/****** Object:  Trigger [dbo].[AuditTrigger]    Script Date: 4/15/2015 11:40:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[AuditTrigger] on [dbo].[ITS_CFG_BLACKOUT] for insert, update, delete
AS
declare @type varchar(1) ,
                @UpdateDate datetime ,
                @UserName varchar(128)
                if exists (select * from inserted)
                                if exists (select * from deleted)
                                select @Type = 'U'
                                else
                                select @Type = 'I'
                                else
                                select @Type = 'D'

                select    @UpdateDate = getdate(), @UserName = system_user
                                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_new'
                from inserted
                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_old'
                from deleted

GO


-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_CFG_BLACKOUT give four parameters ServerName InstanceName DatabaseName Schedule FromDate ToDate
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_blackout') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_blackout
Go
Create procedure usp_blackout
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@From_Date [datetime],
@To_Date [datetime]
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_CFG_BLACKOUT]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[From_Date]
           ,[To_Date])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName
           ,@From_Date
           ,@To_Date)
End
GO

-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_master_backupinfo give four parameters ServerName InstanceName DatabaseName Schedule BackupType
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_masterbackup_entry') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_masterbackup_entry
Go
Create procedure usp_masterbackup_entry
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@ScheduledateTime [varchar](100),
@BackupType [varchar](3000)
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName 
           ,@ScheduledateTime
           ,@BackupType) 

END 
GO








