USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FullDatabaseBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'FullDatabaseBackupMaintenance.Subplan_1',
    @description = N'FullDatabaseBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;


USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DiffDatabaseBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'DiffDatabaseBackupMaintenance.Subplan_1',
    @description = N'DiffDatabaseBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;


USE msdb 
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'TransactionLogBackupMaintenance.Subplan_1')

EXEC dbo.sp_update_job
    @job_name = N'TransactionLogBackupMaintenance.Subplan_1',
    @description = N'TransactionLogBackupMaintenance.Subplan_1 disabled',
    @enabled = 0 ;


USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_master_backupinfo]    Version 1.0 Script Date: 9/16/2014 4:17:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_master_backupinfo](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[ScheduledateTime] [varchar](100) NULL,
	[BackupType] [varchar](3000) NOT NULL,
 CONSTRAINT [Ser_Inst_DB] PRIMARY KEY CLUSTERED 
(
	[ServerName] ASC,
	[InstanceName] ASC,
	[DatabaseName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [msdb]
GO
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (cast(SERVERPROPERTY('machinename') as nvarchar)
           ,cast(SERVERPROPERTY('ServerName') as nvarchar)
           ,'ALL'
           ,Null
           ,'TAPE') 

SET ANSI_PADDING OFF
GO





USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_CFG_BLACKOUT] Version 1.0   Script Date: 9/16/2014 4:28:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_CFG_BLACKOUT](
	[ServerName] [varchar](100) NOT NULL,
	[InstanceName] [varchar](100) NOT NULL,
	[DatabaseName] [varchar](100) NOT NULL,
	[From_Date] [datetime] NOT NULL,
	[To_Date] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO

/****** Object:  Table [dbo].[ITS_BACKUP_JOB]   Version 1.0 Script Date: 9/16/2014 4:34:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ITS_BACKUP_JOB](
	[ServerName] [varchar](100) NULL,
	[InstanceName] [varchar](100) NULL,
	[DatabaseName] [varchar](100) NULL,
	[BackupType] [varchar](15) NULL,
	[BackupToDisk] [varchar](5) NULL,
	[BackupToTape] [varchar](5) NULL,
	[DiskBkpStartTime] [datetime] NULL,
	[DiskBkpEndTime] [datetime] NULL,
	[TapeBkpStartTime] [datetime] NULL,
	[TapeBkpEndTime] [datetime] NULL,
	[BkpFileName] [varchar](2500) NULL,
	[BkpFileSizeMB] [int] NULL,
	[JobName] [varchar](25) NULL,
	[DiskSync] [varchar](3) NULL,
	[TapeSync] [varchar](3) NULL,
	[ScriptVersion] [varchar](5) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO
/****** Object:  Job [ITSSQL_DirectTape_Full]    Script Date: 05/13/2015 14:56:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/13/2015 14:56:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_DirectTape_Full', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_DirectTape_Full]    Script Date: 05/13/2015 14:56:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_DirectTape_Full', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'"C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -File "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\BackupConfigScripts\SQL2005_DIRECTTAPE_Full.ps1"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_Backup_Job]    Script Date: 05/13/2015 14:56:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_Backup_Job', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Full Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150513, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:


USE [msdb]
GO
/****** Object:  Job [ITSSQL_DirectTape_DIFF]    Script Date: 05/13/2015 09:33:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/13/2015 09:33:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_DirectTape_DIFF', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_DirectTape_DIFF]    Script Date: 05/13/2015 09:33:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_DirectTape_DIFF', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'"C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -File "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\BackupConfigScripts\SQL2005_DIRECTTAPE_DIFF.ps1"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_Backup_Job]    Script Date: 05/13/2015 09:33:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_Backup_Job', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Differential Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=125, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150513, 
		@active_end_date=99991231, 
		@active_start_time=210000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

USE [msdb]
GO
/****** Object:  Job [ITSSQL_DirectTape_Log]    Script Date: 05/13/2015 09:47:50 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 05/13/2015 09:47:50 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ITSSQL_DirectTape_Log', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ITSSQL_DirectTape_Log]    Script Date: 05/13/2015 09:47:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ITSSQL_DirectTape_Log', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'"C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -File "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\BackupConfigScripts\SQL2005_DIRECTTAPE_Log.ps1"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge ITS_Backup_Job]    Script Date: 05/13/2015 09:47:50 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge ITS_Backup_Job', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from ITS_BACKUP_JOB where TapeBkpStartTime < GETDATE()-180', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Log Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150513, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:






USE [msdb]
GO

/****** Object:  Table [dbo].[Audit_blackout]    Script Date: 4/15/2015 11:41:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Audit_blackout](
                [ServerName] [varchar](100) NOT NULL,
                [InstanceName] [varchar](100) NOT NULL,
                [DatabaseName] [varchar](100) NOT NULL,
                [From_Date] [datetime] NOT NULL,
                [To_Date] [datetime] NOT NULL,
                [UpdateDate] [datetime] NULL,
                [UserName] [varchar](128) NULL,
                [type] [varchar](10) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO

/****** Object:  Trigger [dbo].[AuditTrigger]    Script Date: 4/15/2015 11:40:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[AuditTrigger] on [dbo].[ITS_CFG_BLACKOUT] for insert, update, delete
AS
declare @type varchar(1) ,
                @UpdateDate datetime ,
                @UserName varchar(128)
                if exists (select * from inserted)
                                if exists (select * from deleted)
                                select @Type = 'U'
                                else
                                select @Type = 'I'
                                else
                                select @Type = 'D'

                select    @UpdateDate = getdate(), @UserName = system_user
                                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_new'
                from inserted
                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_old'
                from deleted

GO



-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_master_backupinfo give four parameters ServerName InstanceName DatabaseName Schedule BackupType
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_masterbackup_entry') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_masterbackup_entry
Go
Create procedure usp_masterbackup_entry
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@ScheduledateTime [varchar](100),
@BackupType [varchar](3000)
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_master_backupinfo]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[ScheduledateTime]
           ,[BackupType])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName 
           ,@ScheduledateTime
           ,@BackupType) 

END 
GO


-- =======================================================================================================================================
-- Author :Praneet Kumar		
-- Create date: 24thSep14 Version 1.0
-- Description:	While inserting data in ITS_CFG_BLACKOUT give four parameters ServerName InstanceName DatabaseName Schedule FromDate ToDate
-- =======================================================================================================================================
Use [msdb]
IF ( OBJECT_ID('dbo.usp_blackout') IS NOT NULL ) 
DROP PROCEDURE dbo.usp_blackout
Go
Create procedure usp_blackout
@ServerName [varchar](100) ,
@InstanceName [varchar](100),
@DatabaseName [varchar](100),
@From_Date [datetime],
@To_Date [datetime]
AS 
BEGIN 
     SET NOCOUNT ON
INSERT INTO [dbo].[ITS_CFG_BLACKOUT]
           ([ServerName]
           ,[InstanceName]
           ,[DatabaseName]
           ,[From_Date]
           ,[To_Date])
     VALUES
           (@ServerName
           ,@InstanceName
           ,@DatabaseName
           ,@From_Date
           ,@To_Date)
End








