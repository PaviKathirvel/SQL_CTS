

USE [msdb]
GO

/****** Object:  Table [dbo].[Audit_blackout]    Script Date: 4/15/2015 11:41:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Audit_blackout](
                [ServerName] [varchar](100) NOT NULL,
                [InstanceName] [varchar](100) NOT NULL,
                [DatabaseName] [varchar](100) NOT NULL,
                [From_Date] [datetime] NOT NULL,
                [To_Date] [datetime] NOT NULL,
                [UpdateDate] [datetime] NULL,
                [UserName] [varchar](128) NULL,
                [type] [varchar](10) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [msdb]
GO

/****** Object:  Trigger [dbo].[AuditTrigger]    Script Date: 4/15/2015 11:40:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[AuditTrigger] on [dbo].[ITS_CFG_BLACKOUT] for insert, update, delete
AS
declare @type varchar(1) ,
                @UpdateDate datetime ,
                @UserName varchar(128)
                if exists (select * from inserted)
                                if exists (select * from deleted)
                                select @Type = 'U'
                                else
                                select @Type = 'I'
                                else
                                select @Type = 'D'

                select    @UpdateDate = getdate(), @UserName = system_user
                                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_new'
                from inserted
                
                insert    Audit_blackout(ServerName,InstanceName, DatabaseName,From_Date,To_Date,UpdateDate,UserName,type)
                select    ServerName,InstanceName, DatabaseName,From_Date,To_Date,@UpdateDate,@UserName,@type + '_old'
                from deleted

GO


