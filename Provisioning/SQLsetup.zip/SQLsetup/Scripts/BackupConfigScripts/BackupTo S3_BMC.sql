
/* Backup to S3 storage Location 
###################################################################################################
ScriptName = "Backup To S3_BMC.sql"
Scriptver = "1.0"
Description: Description: Moving backups to S3 from Disk for AWS EC2s
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			06/10/2020	Sanjiv		New Script
**********************************************************************************************************/

USE [msdb]
GO

/****** Object:  Job [TransactionLogBackupMaintenancePlan.Subplan_1]  ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
DECLARE @jobId BINARY(16)
DECLARE @SvrName Varchar(20)

Select @SvrName = @@SERVERNAME
Select @jobId = job_id from msdb.dbo.sysjobs where [name] like 'TransactionLogBackupMaintenance.Subplan_1' and enabled = 1 
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Copy Backup to S3]    Script Date: 10/5/2020 10:30:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Copy Backup to S3', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
#-----------------------SQL BACKUP Copy ---------------------#
$AV_Zone = (Get-EC2AvailabilityZone).RegionName
$Bucket_Name = ''itx-bmc-ec2dbbackup-''+$AV_Zone[0]
$HOSTNAME = $env:computername
$HOSTNAME = $HOSTNAME + ''.jnj.com''
$ID = (Get-EC2Tag | Where-Object {$_.Key -eq ''Hostname'' -and $_.Value -eq $HOSTNAME})
$App = (Get-EC2Tag | Where-Object {$_.ResourceId -eq $ID.ResourceId -and $_.Key -eq ''Application''})
$tag = $App.Value
$sourcelocation =  (Get-ItemProperty ''HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQLServer'').BackupDirectory
Set-AWSCredential -AccessKey AKIAVM4FQAMRPI7VJBJP -SecretKey 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 -StoreAs default
Write-S3Object -BucketName $Bucket_Name  -Folder $sourcelocation -KeyPrefix $HOSTNAME\Backup -TagSet @{Key="Application";Value="$tag"} -ServerSideEncryption AES256 -Recurse
#----------------------EndOfScript-------------------------------------#
', 
		@database_name=N'master', 
		@flags=0
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

/* Update Step 1 to continue to Next step on successful execution */
EXEC msdb.dbo.sp_update_jobstep @job_id=@jobId, @step_id=1 , 
		@on_success_action=3 
		
go
GO

/************************************************************************************************/
