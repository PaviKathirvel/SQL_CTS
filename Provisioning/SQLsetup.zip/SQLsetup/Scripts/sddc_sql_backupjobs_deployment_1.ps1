###################################################################################################
$ScriptName = "sddc_sql_backupjobs_deployment.PS1"
$Scriptver = "4.0"
#Description: Description: Backup jobs deployment for adhoc requests on SDDC setup only
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			30/05/2015	Jay Sangam	New Script

###################################################################################################

####
#*********** Lab DML************* 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML'

$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl

#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'								
#$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\Development\Release_BatchNamedInstance'		Delete this later
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
#####
$BatchOutput3 = "C:\IQOQ\Status.txt"

$sqlv = $args[0]
$InstName = $args[1]
$Env = $args[2]
$Env = "PROD"


IF (($sqlv -ne "SQL2008") -and ($sqlv -ne "SQL2012"))
{
Write-Host ""
Write-Host "SQL build version not Valid. Please pass SQL2008 or SQL2012 as 2nd parameter" -f red
Write-Host ""
Exit 0
}

IF ($InstName -eq $null)
{
Write-Host ""
Write-Host "Please pass a valid SQL2012 or SQL2008 instance name as parameter" -f red
Write-Host ""
Exit 0
}

IF (($Env -ne "DEV") -and ($Env -ne "QA") -and ($Env -ne "PROD"))
{
Write-Host ""
Write-Host "Environment not Valid. Pass DEV or QA or PROD as 3rd parameter" -f red
Write-Host ""

Exit 0
}

#------------------------ Check if valid instance name is being passed --------------------------------------

$instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
IF ($instances -notcontains $InstName)
{
Write-Host ""
#Write-Host "Instance $InstName not found. Pass a valid instance name" -f red	Un-comment later for named instance installs.
Write-Host "Instance $InstName not found. Pass a valid instance name" -f red		#Delete this line later for named instance installs.
Write-Host ""
Exit 0
}

#------------------- Check if instance name really belongs to the SQLVersion passed as parameter ---------------------------

   $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName

   $ver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version

   $build = $ver.substring(0,2)

   Write-Host "Build no. is $build"

If (($build -eq "11") -and ($sqlv -ne "SQL2012"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}

If (($build -eq "10") -and ($sqlv -ne "SQL2008"))
{
Write-Host ""
Write-host "Instance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
Write-Host ""
EXIT 0
}


#*********************************** Start of Post installation function ***********************************#

FUNCTION sddc_sql_backupjobs_deployment($IDMLLOC, $sqlversion, $iName, $Envr)  
{

If (!(Test-Path C:\SQLInstall_Logs))
{
mkdir "C:\SQLInstall_Logs"
}

$Time = get-date -Uformat "%Y%m%d%H%M"
$Log = "C:\SQLInstall_Logs\sddc_sql_backupjobs_deployment_$Time.txt"
$LogFilePath = "C:\SQLInstall_Logs\sddc_sql_backupjobs_deployment_SQLLog_$Time.txt"
$M_Plans_sql = $IDMLLOC + "\Scripts"

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log
"Execution String: $ScriptName $sqlversion $iName $Envr" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')

IF ($iName -eq "MSSQLSERVER")
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Final_Status_Error = 0
}
ELSE
{
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name + "\" + $iName
$Final_Status_Error = 0
}

  $fso = New-Object -ComObject Scripting.FileSystemObject

  IF ($sqlversion -eq "SQL2012")
  {
   $M_Plans = $IDMLLOC + "\ConfigFiles"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
  }

  ELSEIF ($sqlversion -eq "SQL2008")

  {
   $M_Plans = $IDMLLOC + "\SSIS_2008"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\100\Tools\Setup").SQLPath).ShortPath
  }

  ELSEIF ($sqlversion -eq "SQL2005")

  {

   $M_Plans = $IDMLLOC + "\SSIS_2005"
   $DTSFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\DTS\Setup").SQLPath).ShortPath
   $ToolsFolder=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\90\Tools\Setup").SQLPath).ShortPath
  }

#--------------------------------- Backup Jobs Deployment ---------------------------------#
Write-Host "-------"
"-------" >> $Log

If (Test-Path C:\SSISPackages) { Remove-Item C:\SSISPackages\* -recurse } else { mkdir "C:\SSISPackages" }

<#
#--------- Copying the 110 folder contents from DML in case if 110 folder was deleted locally during previous uninstallation --------------------

if((Test-Path D:\MSSQL2012\110) -eq 0)
{
$DTSPath = $IDMLLOC + '\110\DTS\*'
$ToolsPath = $IDMLLOC + '\110\Tools\*'
mkdir "D:\MSSQL2012\110\DTS"
mkdir "D:\MSSQL2012\110\Tools"
Copy-Item $DTSPath D:\MSSQL2012\110\DTS -recurse
Copy-Item $ToolsPath D:\MSSQL2012\110\Tools -recurse
}

#>

If (Test-Path C:\SQLInstall_Logs\BackupConfigLogs) { Remove-Item C:\SQLInstall_Logs\BackupConfigLogs\* -recurse } else { mkdir "C:\SQLInstall_Logs\BackupConfigLogs" }

$BKScriptsPath = $IDMLLOC + '\Scripts\BackupConfigScripts'	

$ScriptsPath = $IDMLLOC + '\Scripts'

$LogPath = 'C:\SQLInstall_Logs\BackupConfigLogs'

IF ($Envr -eq "DEV")

 {

 Write-Host "Backup Jobs Deployment - For DEV environment"
 Write-host ""
"Backup Jobs Deployment" >> $Log
"" >> $Log

 $bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo_meta.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
 $bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
 $bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
 $bkp_sp = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_DB_FULL_BACKUP_DEV.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 $bkp_dev = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
 $bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
 $bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
 $bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"


& cmd.exe /c $bkp_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_sp | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create stored procedure ITSSQL_DB_FULL_BACKUP_DEV : " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_dev | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create ITSSQL_MetaData job : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create ITSSQL_MetaData job : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_10 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_11 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_12 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Success" -f green
}


 }
 
 ELSE
 
 {

Write-Host "Backup Jobs Deployment - For PROD/QA environment"
Write-Host ""
"Backup Jobs Deployment" >> $Log
"" >> $Log

$bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
$bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
$bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"

$bkp_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Full_Backup.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
$bkp_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Diff_Backup.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
$bkp_8 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Log_Backup.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"

# $bkp_9 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
$bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
$bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
$bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"

& cmd.exe /c $bkp_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_MASTER_BACKUPINFO : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_CFG_BLACKOUT : " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Table ITS_BACKUP_JOB : " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_6 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Full backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Full backup job: " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_7 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Differential backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "ITS Backup process - Create Differential backup job: " -f white -nonewline; Write-Host "Success" -f green
}


& cmd.exe /c $bkp_8 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Transaction log backup job: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Transaction log backup job: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_10 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_blackout: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_11 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Stored Procedure usp_masterbackup_entry: " -f white -nonewline; Write-Host "Success" -f green
}

& cmd.exe /c $bkp_12 | out-null

if ($lastexitcode -eq 1)
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Failed" -f red
	$Final_Status_Error = 1

}
ELSE
{
	Write-Host "ITS Backup process - Create Trigger ITS_Audit_Trigger: " -f white -nonewline; Write-Host "Success" -f green
}

}




#---------------------------------- End of Backup Jobs Deployment --------------------------------

#---------------------------------- Integrity & Optimization --------------------------------


$Jobs = $svr.JobServer.Jobs

    foreach($Job in $Jobs)
{

        if([string]$Job -eq "DataIntegrityAndOptimizationMaintenance.SubPlan_1")

    {
	    Write-Host ""
            Write-Host "DataIntegrityAndOptimizationMaintenance.Subplan_1 job already exists on this server instance"
	    Write-Host ""

	    "" >> $Log
            "DataIntegrityAndOptimizationMaintenance.Subplan_1 job already exists on this server instance" >> $Log
	    "" >> $Log

		IF ($Final_Status_Error -eq 1)
		{
		  Write-Host ""
		  Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
		  "FINAL STATUS = FAILED" >> $Log
		  Write-Host "Please review the verification steps and address the failed step"
		  "Please review the verification steps and address the failed step" >> $Log

		  Write-Host "###################################################################################################"
		  "###################################################################################################" >> $Log
		  Exit 1
		}

		ELSE

		{
		  Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
		  "FINAL STATUS = SUCCESS" >> $Log
		  "SUCCESS" > $BatchOutput3
		  Write-Host "###################################################################################################"
		  "###################################################################################################" >> $Log
		  Exit 0
		}


    }

}

IF ($sqlversion -eq "SQL2012")

{

Copy-Item $M_Plans\DataIntegrityAndOptimizationMaintenance.dtsx C:\SSISPackages
$path1 = 'C:\SSISPackages\DataIntegrityAndOptimizationMaintenance.dtsx'

$NewLogPath1 = "D:\MSSQL2012\MSSQL11."+$iName+"\MSSQL\Log"
$NewConnString1 = "Data Source="+$($Inst_Name)+";Integrated Security=True;Pooling=False;MultipleActiveResultSets=False;Packet Size=4096;Application Name='Microsoft SQL Server Management Studio';"

$xml1 = [xml](Get-Content $path1)
$node1 = $xml1.Executable.ConnectionManagers.ConnectionManager.ObjectData.ConnectionManager
$node1.ConnectionString = $NewConnString1
$node8a = $xml1.Executable.Variables.Variable | where {$_.ObjectName -eq "TextReportPath"}
$node8b = $node8a.VariableValue
$node8b."#text" = $NewLogPath1
$node9a = $xml1.Executable.Executables.Executable | where {$_.refID -like 'Package\Reporting*'}
$node9b = $node9a.ObjectData.SqlTaskData
$node9b.Path = $NewLogPath1
$xml1.Save($path1)

#$cmd_1 = $IDMLLOC + "\110\DTS\Binn\dtutil.exe /FILE $M_Plans\DataIntegrityAndOptimizationMaintenance.dtsx /DestServer $Inst_Name /COPY SQL;""\Maintenance Plans\DataIntegrityAndOptimizationMaintenance"" && exit 0 || exit 1"
$cmd_1 = "D:\MSSQL2012\110\DTS\Binn\dtutil.exe /FILE C:\SSISPackages\DataIntegrityAndOptimizationMaintenance.dtsx /DestServer $Inst_Name /COPY SQL;""\Maintenance Plans\DataIntegrityAndOptimizationMaintenance"" && exit 0 || exit 1"

& cmd.exe /c $cmd_1 | out-null
if ($lastexitcode -eq 1)
{
	
	Write-Host ""
	Write-Host "Data Integrity and Optimization Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Failed" -f red
	"Data Integrity and Optimization Maintenance Plan Deployment: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host ""
	Write-Host "Data Integrity and Optimization Maintenance Plan Deployment: " -f white -nonewline; Write-Host "Success" -f green
	"Data Integrity and Optimization Maintenance Plan Deployment: Success" >> $Log
}


}

Write-Host "-------"
"-------" >> $Log



#--------------------------------- Script Execution for Post Installation Configuration ---------------------------------#

IF ($sqlversion -eq "SQL2012")
{

Write-Host "-------"
"-------" >> $Log
Write-Host "Script Execution for Post Installation Configuration"
"Script Execution of Post Installation Configuration" >> $Log

 $cmd_5 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\sddc_sql_Post_Installation_sddc.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2012PostInstallSQL.txt -x && exit 0 || exit 1"

 & cmd.exe /c $cmd_5 | out-null

 IF ($lastexitcode -eq 1)
  {
	Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Failed" -f red
	"Script Execution of Post Installation Configuration: Failed" >> $Log
	$Final_Status_Error = 1
  }

   ELSE

  {
	Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Success" -f green
	"Script Execution of Post Installation Configuration: Success" >> $Log
  }

}

Write-Host "-------"
"-------" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
IF ($Final_Status_Error -eq 1)
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"FINAL STATUS = FAILED" >> $Log
Write-Host "Please review the verification steps and address the failed step"
"Please review the verification steps and address the failed step" >> $Log
"FAILED" > $BatchOutput3
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
"FINAL STATUS = SUCCESS" >> $Log
"SUCCESS" > $BatchOutput3
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}



}

#*********************************** End of Post installation function ***********************************#


#--------- Start POST install configuration ---------#

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1
$ipAddressParts = $GetIp.Split('.') 

[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 

	sddc_sql_backupjobs_deployment $LabSQLDML $sqlv $InstName $Env

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 223) 
 { 

	sddc_sql_backupjobs_deployment $NASQLDML $sqlv $InstName $Env
 }
}

#--------- End POST install configuration ---------#

