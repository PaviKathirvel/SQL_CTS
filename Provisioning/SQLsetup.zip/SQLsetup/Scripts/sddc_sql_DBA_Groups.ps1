###################################################################################################
$ScriptName = "sddc_sql_DBA_Groups.PS1"
$Scriptver = "1.0"
#Description: Automated process to request DBA Groups in IDMS
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			07/23/2014	Bruno Campos	New Script
###################################################################################################

$Time = get-date -Uformat "%Y%m%d%H%M"
################External Files##########################
If (!(Test-Path C:\TEMP))
{
mkdir "C:\TEMP"
}

$Log = "C:\TEMP\sddc_sql_DBA_Groups_$Time.txt"
########################################################

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
$Final_Status_Error = 0
$WWID = $args[0]

Function Error
{
Exit 1
Break
}

################Checking WWID##########################
IF ($WWID -eq $null)
{
Write-Host "WWID not Provide. Please provide the WWID of the Group Owner"
"WWID not Provide. Please provide the WWID of the Group Owner" >> $Log
Error
}

##########Verify if AD Group already exists#############
$AD_GROUP = "ITS-EP-SQL-$HostName-DEFAULT-DBA-Temp"
$Searcher = New-Object DirectoryServices.DirectorySearcher
$GroupS = "(&(objectCategory=Group)(anr=$AD_GROUP))"
$Searcher.Filter = $GroupS
$Searcher.SearchRoot = 'LDAP://DC=jnj,DC=com'
$Result = $Searcher.FindOne()
IF( $Result -ne $null)
{
Write-Host "AD Group $AD_Group already exists."
"AD Group $AD_Group already exists." >> $Log
Exit 1
}

################Generating CSV File##########################

$Time_2 = get-date -Uformat "%Y%m%d_%H%M%S"
$Source = "C:\Temp\OPC.CreateSQLDBAGroups.$Time_2.$HostName-DEFAULT.csv"
Write-Host "CSV File Created: $Source"
"CSV File Created: $Source" >> $Log
Write-Host "CSV File created with the string below:"
"CSV File created with the string below:" >> $Log
Write-Host "cn=SA-ITS-SQL-Provision,ou=NSACCOUNTS,ou=VAULT,o=JNJ:Bulk Load from OPCx DB Auto-Provisioning:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj:$Hostname-DEFAULT:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj"
"cn=SA-ITS-SQL-Provision,ou=NSACCOUNTS,ou=VAULT,o=JNJ:Bulk Load from OPCx DB Auto-Provisioning:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj:$Hostname-DEFAULT:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj" >> $Log
"cn=SA-ITS-SQL-Provision,ou=NSACCOUNTS,ou=VAULT,o=JNJ:Bulk Load from OPCx DB Auto-Provisioning:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj:$Hostname-DEFAULT:::cn=$WWID,ou=internal,ou=people,ou=vault,o=jnj" | out-file -encoding ASCII $Source 

################Copy CSV File to IDMS Folder##########################
$Dest = "\\itsusraw00671.jnj.com\Bulk-Incoming"

Copy-Item $Source $Dest

if ($error[0])
{
Write-Host "Copy of the CSV file to $Dest : " -f white -nonewline; Write-Host "Failed" -f red
"Copy of the CSV file to $Dest : Failed" >> $Log
$Final_Status_Error = 1
$error.clear()
}
ELSE
{
Write-Host "Copy of the CSV file to $Dest : " -f white -nonewline; Write-Host "Success" -f green
"Copy of the CSV file to $Dest : Success" >> $Log
}
Write-Host ""
"" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
IF ($Final_Status_Error -eq 1)
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"FINAL STATUS = FAILED" >> $Log
Write-Host "Please review the verification steps and address the failed step"
"Please review the verification steps and address the failed step" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
exit 1
}
ELSE
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCESS" -f green
"FINAL STATUS = SUCESS" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}