$disk = Get-WmiObject Win32_LogicalDisk -ComputerName $env:COMPUTERNAME -Filter "DeviceID='H:'" |
Foreach-Object {((($_.Size/1024)/1024)/1024)}

$disk2 = [math]::Floor($disk)
return $disk2