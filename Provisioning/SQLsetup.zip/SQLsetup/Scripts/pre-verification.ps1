###################################################################################################
$ScriptName = "pre-verification.ps1"
$Scriptver = "2.0"
#Description: Description: Pre-implementation script for onedb and multipledb database refresh.
#Example:- pre-verification.ps1 CHG000010331101 APP000010012177  multiple 2 itssusrawsp00424 test,testdb itsusrawsp00423 test1,test2
###################################################################################################
#Version Author		Reason for Change
###################################################################################################
#1.0	Kishore 	New Script
#2.0	Sanjiv		NAS Modification 
###################################################################################################
$RFC = $args[0]
$AppName = $args[1]
$RefreshType = $args[2]
$DBNumber = $args[3]
$SOURCE = $args[4]
$sdb = $args[5]
$TARGET = $args[6]
$Tdb = $args[7]

IF (($RFC -eq $null) -or ($AppName -eq $null) )
{
Write-host ""
Write-Host "Pass RFC as 1st parameter and AppName as 2nd parameter " -f red
Write-host ""
EXIT
}



IF (($SOURCE -eq $null) -or ($sdb -eq $null))
{
Write-host ""
Write-Host "Pass Sourceserver as 4th parameter and Source databasename as 5th parameter" -f red
Write-host ""
EXIT
}

IF (($TARGET -eq $null) -or ($Tdb -eq $null))
{
Write-host ""
Write-Host "Pass Targetserver as 5th parameter and Target databasename as 6th parameter" -f red
Write-host ""
EXIT
}

<#
$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1


# Split the address into its parts by using the dot ('.')
$ipAddressParts = $GetIp.Split('.') 

$EMEApath = "\\ITSBEBESDNA008\sqldbrefresh_be\REFRESH\"
$NApath = "\\ITSUSRASDNA010\sqldbrefresh_ra\REFRESH\" 
$ASPACpath = "\\ITSSGSGSDNA013\sqldbrefresh_sg\REFRESH\"


[int] $IpPartsIdentifier1 = $ipAddressParts[0]
[int] $IpPartsIdentifier2 = $ipAddressParts[1]
[int] $IpPartsIdentifier3 = $ipAddressParts[2] 

IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

        echo $IpPartsIdentifier2
	$location =  "on NA Server"
        
    	$NApath
	
 }
 ELSEIF ($IpPartsIdentifier2 -ge 128 -and $IpPartsIdentifier2 -le 191) 
 { 	
	$location = "on EMEA Server"
    	$EMEApath

 }
 ELSEIF ($IpPartsIdentifier2 -ge 192 -and $IpPartsIdentifier2 -le 223) 
 { 	
        echo $IpPartsIdentifier2 
        $location = "on ASPAC Server"
        echo $location
    	$ASPACpath

 }
 ELSE 
 {
 	 $location = "Server location is unknown"
	 Exit 0
 }

}

$SBpath = "\\ITSSGSGSDNA013\sqldbrefresh_sg\REFRESH\" 
$SBpath = "\\ITSUSRASDNA010\sqldbrefresh_ra\REFRESH\" 
$SBpath = "\\ITSBEBESDNA008\sqldbrefresh_be\REFRESH\" 
$datetime = get-date -uformat "%Y-%m-%d@%H-%M-%S"
if($location -eq "on ASPAC Server")
{
  $SBpath = $ASPACpath+"\$RFC"+"_"+$datetime
  Get-ChildItem -Path $SBpath -Recurse| ?{$_.CreationTime -lt (get-date).AddDays(-3)}| Foreach-object {Remove-item -Recurse -path $_.FullName }
  echo $sbpath
  echo $tbpath
}

elseif($location -eq "on EMEA Server")
{
  $SBpath = $EMEApath+"\$RFC"+"_"+$datetime
  Get-ChildItem -Path $SBpath -Recurse| ?{$_.CreationTime -lt (get-date).AddDays(-3)}| Foreach-object {Remove-item -Recurse -path $_.FullName }
  echo $sbpath
  echo $tbpath
}

elseif($location -eq "on NA Server")
{
  $SBpath = $NApath+"\$RFC"+"_"+$datetime
  Get-ChildItem -Path $SBpath -Recurse| ?{$_.CreationTime -lt (get-date).AddDays(-3)}| Foreach-object {Remove-item -Recurse -path $_.FullName }
  echo $tbpath
  echo $sbpath
}
#>

#To check Log Folder
$logfileFolder = $env:SystemDrive+"\DBRefreshlogs"
#echo$logfileFolder

$FolderCheck = test-path $logfileFolder
if (-Not($FolderCheck)) {
                New-Item $logfileFolder -type directory
               
}else{
                Write-host "the log folder exist"
}
"`n"
"`n"

$date =  get-date -uFormat "%m%d%Y%H%MS"

#To Create Logfile
$logfileFolder1 = $logfileFolder+"\$date"+"\$SOURCE"+"\$RFC"

$FolderCheck = test-path $logfileFolder1
if (-Not($FolderCheck)) {
                New-Item $logfileFolder1 -type directory
   $logfile =$logfileFolder1 + "\Precheck_Logfile.txt"
                if (-Not (test-Path $logfile)) {New-Item $logfile -type File}
                else {
   $logfile =$logfileFolder1 + "\Precheck_Logfile.txt"
                                if (-Not (test-Path $logfile)) {New-Item $logfile -type File}
                                }
                }else{
                #Write-host "the log file created"

$logfile =$logfileFolder1 + "\Precheck_Logfile.txt"
if (-Not (test-Path $logfile)) {New-Item $logfile -type File}
$logfilefoldercheck = "the log file created"
}

IF(($DBNumber -eq "1") -and ($RefreshType -eq "single"))
{


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$SOURCE")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'
$db = $srv.Databases.Item("$sdb")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"

write-output "Pre-check DBRefresh\Clone Summary " >> $logfile
write-output *************************************************************** >> $logfile
"`n"
write-output *************************************************************** >> $logfile
write-output Sourceserver:$source >> $logfile
write-output SourceDatabase:$sdb >> $logfile
write-output *************************************************************** >> $logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db.LogFiles)
{
   $Slogfilesize = $lf.size 
   write-output Sourcelogfilesize:$Slogfilesize >> $logfile
   
}

Foreach ($lf1 in $db.FileGroups)
{
 $Sdatafilesize = $lf1.size
 write-output Sourcedatafilesize:$Sdatafilesize >> $logfile

}

$Sdatabasefilesize =($db.LogFiles + $db.FileGroups| Measure-Object -Sum size).sum  
write-output Sourcedatabasefilesize:$Sdatabasefilesize >> $logfile

#$SLogdrivediskspace = ((get-disk -number 4 | select size).size /1GB) 
#write-output SourceLogdrivediskspace:$SLogdrivediskspace >> $logfile

$SDatabasestatus = $db.isaccessible
write-output  SourceDatabaseStatus:$SDatabasestatus >>$logfile

$SDBSize = $db.Size
write-output Sourcedbsize:$SDBSize  >>$logfile

$SCollation = $db.Collation
write-output SourceCollation:$SCollation >>$logfile

$SDatabaseEncrypted = $db.EncryptionEnabled
write-output SourceDatbaseencrypted:$SDatabaseEncrypted  >>$logfile

$SAlwaysOn = $db.AvailabilityDatabaseSynchronizationState
write-output SourceDatabaseAlwayson:$SAlwaysOn >>$logfile

$SAlwaysonGroupName = $db.AvailabilityGroupName
write-output SourceDatabasealwaysongroupname:$SAlwaysonGroupName >>$logfile





[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("$target")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db1 = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'
$db1 = $srv1.Databases.Item("$tdb")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"
write-output *************************************************************** >> $logfile
write-output Tagretserver:$target >> $logfile
write-output TagretDatabase:$tdb >> $logfile
write-output *************************************************************** >> $logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db1.LogFiles)
{
   $Targetlogfilesize = $lf.size 
   write-output Targetlogfilesize:$Targetlogfilesize >> $logfile
   
}

Foreach ($lf1 in $db1.FileGroups)
{
 $Targetdatafilesize = $lf1.size
 write-output Targetdatafilesize:$Targetdatafilesize >> $logfile

}

$Targetdatabasefilesize =($db1.LogFiles + $db1.FileGroups| Measure-Object -Sum size).sum  
write-output Targetdatabasefilesize:$Targetdatabasefilesize >> $logfile

$Targetdrivediskspacelog = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspacelog:$Targetdrivediskspacelog >> $logfile
#((get-disk -number 4 | select size).size /1MB) 

$Targetdrivediskspacedata = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'f:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspacedata:$Targetdrivediskspacedata >> $logfile

$TargetDatabasestatus = $db1.isaccessible
write-output  TargetDatabaseStatus:$TargetDatabasestatus >>$logfile

$TargetDBSize = $db1.Size
write-output Targetdbsize:$TargetDBSize  >>$logfile

$dba = $db1.recoverymodel
write-output $dba | out-file "c:\dba.txt"

$TargetCollation = $db1.Collation
write-output TargetCollation:$TargetCollation >>$logfile

$TargetDatabaseEncrypted = $db1.EncryptionEnabled
write-output TargetDatbaseencrypted:$TargetDatabaseEncrypted  >>$logfile

$TargetAlwaysOn = $db1.AvailabilityDatabaseSynchronizationState
write-output TargetDatabaseAlwayson:$TargetAlwaysOn >>$logfile

$TargetAlwaysonGroupName = $db1.AvailabilityGroupName
write-output TargetDatabasealwaysongroupname:$TargetAlwaysonGroupName >>$logfile


<#
if((($TargetLogdrivediskspace - $SDBSize) -lt $TargetLogdrivediskspace) -and ($TargetCollation -eq $scollation) -and ($SDatabasestatus -eq 'true') -and                   ($TargetDatabasestatus -eq 'true') -and ($SAlwaysOn -notmatch 's') -and ($TargetAlwaysOn -notmatch 's')) 
    {
     write-host "pass"
    }
else
   {
    write-host "fail"
   }

#>
"`n"
write-output *************************************************************** >> $logfile
write-output "Pre-check status Summary " >> $logfile
write-output *************************************************************** >> $logfile

if((($Targetdrivediskspacelog - $SDBSize) -lt $Targetdrivediskspacelog) -and (($Targetdrivediskspacedata - $SDBSize) -lt $Targetdrivediskspacedata))
  {
    Write-output "Drive space is sufficent for restore: Success" >> $logfile
  }
else{
    write-output "Insufficent drive space: Fail" >> $logfile
  }
if($TargetCollation -eq $scollation)
  {
    write-output "Collation is matching: Success" >> $logfile
  }
else{
   write-output "Collation mismatch: Fail" >> $logfile
  }
if(($SDatabasestatus -eq 'true') -and  ($TargetDatabasestatus -eq 'true'))
  {
    write-output "Source and Target database are online: Success " >> $logfile
   }
else{
     write-output "Either source or target database is offline : Fail " >> $logfile
    }

if(($SAlwaysOn -notmatch 's') -and ($TargetAlwaysOn -notmatch 's'))
  {
   write-output "Alwayson is not available : Success " >> $logfile
  }
else{
   write-output "Alwayson is configured either on source or tagret server: Fail" >> $logfile
  }

if(($SDatabaseEncrypted -ne 'true') -and ($TargetDatabaseEncrypted -ne 'true'))
  {
    write-output "Database is not encrypted: Success" >> $logfile
  }
else{
    write-output "Either source or target database is encrypted: Fail" >> $logfile
  }


<#
$Result = Get-Content "\\ITSSGSGWSP00258\d$\kishore\log.txt"
Get-Content "\\ITSSGSGWSP00258\d$\kishore\log.txt" -wait |
ForEach-Object { 
foreach($word in $Result){
if($_  -match "Fail")
  {
   write-host "Precheck failed please check the$logfile for details" 
   write-output "Precheck failed please check the$logfile for details" >>$logfile 
   exit
 }
else{
    write-host "Precheck is success" 
    write-output "Precheck is success" >>$logfile 
    exit
}
}
}
#>

$statusfile = "\\$source\c$\SQLInstall_Logs\refresh\"

if((Test-Path $statusfile) -eq 0)
{
mkdir $statusfile 
}

$status200 = $statusfile +"\"+"$RFC-pre-verification-status.txt"

if (Test-Path $status200) {
  Remove-Item $status200
}

if($Result = Select-String -Path "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\Precheck_Logfile.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the $logfile for details" -f red
   write-output "###1" >> $status200
 }
else{
    write-host "Precheck is success" -f green
    write-output "###0" >> $status200
           
}




$NAS = "\\$source\c$\SQLInstall_Logs\refresh\"  

if((Test-Path $NAS) -eq 0)
{
mkdir $NAS
}

$C200log = $NAS +"\"+"$RFC-AUTOMATION_SDDC_TASK200.log"


if (Test-Path $C200log) {
  Remove-Item $C200log
}

if($Result = Select-String -Path "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\Precheck_Logfile.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the $logfile for details" -f red
   write-output "Precheck failed please check the $logfile  for details" >> $logfile
   $result.line >> $logfile
   write-output "*******************************************************" >> $C200log
   $result.line >> $C200log
   write-output "*******************************************************" >> $C200log
   write-output "Precheck failed:Return code 1" >> $C200log
   write-output "*******************************************************" >> $C200log
 }
else{
     write-host "Precheck is success" -f green
     write-output "*******************************************************" >> $C200log
      write-output "ChangeNumber : $rfc" >> $C200log
     write-output "Source server:$source" >> $C200log
     write-output "Target server:$target" >> $C200log
     write-output "Source database:$sdb" >> $C200log
     write-output "Target database:$tdb" >> $C200log
     write-output "*******************************************************" >> $C200log
     write-output "Databases is available in source and target instance" >> $C200log
     write-output "*******************************************************" >> $C200log
     write-output "Space availabile in the target server where the DB files are hosted" >> $C200log
     write-output "*******************************************************" >> $C200log
     write-output "Precheck is success:Return code 0" >> $C200log
     write-output "*******************************************************" >> $C200log
     write-output "Ready for DB Refresh" >> $C200log
     write-output "*******************************************************" >> $C200log
     write-output "Precheck is success">>$logfile
     write-output "Ready for DB Refresh" >>$logfile
        
}
}


IF(($RefreshType -eq "multiple") -and ($DBNumber -ge '2'))
{

write-host $DBNumber
write-host $sdb.count
echo $sdb

write-host $tdb.count
echo $tdb
<#
if(($DBNumber -eq $sdb.count) -and ($DBNumber -eq $tdb.count))
  {
     write-host "matching"
   } 
else
{
  write-host "Please select databases as per DBNumber"
  exit
}
#>
$check = "matching"

if($check -eq "matching")
{
 $dbname =$sdb.split(',')[0]
foreach($db1 in $dbname)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$SOURCE")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db1
$db = $srv.Databases.Item("$db1")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"

write-output "Pre-check DBRefresh\Clone Summary " >> $logfile
write-output *************************************************************** >> $logfile
"`n"
write-output *************************************************************** >> $logfile
write-output Sourceserver:$source >> $logfile
write-output SourceDatabse:$db >> $logfile
write-output *************************************************************** >> $logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db.LogFiles)
{
   $Slogfilesize = $lf.size 
   write-output Sourcelogfilesize:$Slogfilesize >> $logfile
   
}

Foreach ($lf1 in $db.FileGroups)
{
 $Sdatafilesize = $lf1.size
 write-output Sourcedatafilesize:$Sdatafilesize >> $logfile

}

$Sdatabasename = $db.name
write-output DatabaseName:$Sdatabasename >> $logfile

$Sdatabasefilesize =($db.LogFiles + $db.FileGroups| Measure-Object -Sum size).sum  
write-output Sourcedatabasefilesize:$Sdatabasefilesize >> $logfile

$SLogdrivediskspace = ((get-disk -number 4 | select size).size /1GB) 
write-output SourceLogdrivediskspace:$SLogdrivediskspace >> $logfile

$SDatabasestatus = $db.isaccessible
write-output  SourceDatabaseStatus:$SDatabasestatus >>$logfile

$SDBSize = $db.Size
write-output Sourcedbsize:$SDBSize  >>$logfile

$SCollation = $db.Collation
write-output SourceCollation:$SCollation >>$logfile

$SDatabaseEncrypted = $db.EncryptionEnabled
write-output SourceDatbaseencrypted:$SDatabaseEncrypted  >>$logfile

$SAlwaysOn = $db.AvailabilityDatabaseSynchronizationState
write-output SourceDatabaseAlwayson:$SAlwaysOn >>$logfile

$SAlwaysonGroupName = $db.AvailabilityGroupName
write-output SourceDatabasealwaysongroupname:$SAlwaysonGroupName >>$logfile

}

<#
$dbname =$sdb.split(",")[0]
foreach($db in $dbname)
{
    echo $db
     [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
     $s = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $source
     $db=$s.Databases.item($db)      
     $db | SELECT Name, Collation, isaccessible, EncryptionEnabled, AvailabilityDatabaseSynchronizationState, Size, SpaceAvailable >>$logfilefile
     
}
#>

$dbname1 =$tdb.split(',')[0]
foreach($db3 in $dbname1)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$target")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db3
$db2 = $srv.Databases.Item("$db3")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"

write-output "Pre-check DBRefresh\Clone Summary " >> $logfile
write-output *************************************************************** >> $logfile
"`n"
write-output *************************************************************** >> $logfile
write-output Targetserver:$Target >> $logfile
write-output TargetDatabase:$db2 >> $logfile
write-output *************************************************************** >> $logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db2.LogFiles)
{
   $Slogfilesize = $lf.size 
   write-output Sourcelogfilesize:$Slogfilesize >>$logfile
   
}

Foreach ($lf1 in $db2.FileGroups)
{
 $Sdatafilesize = $lf1.size
 write-output Sourcedatafilesize:$Sdatafilesize >>$logfile

}

$Targetdrivediskspace = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspace:$Targetdrivediskspace >>$logfile
#((get-disk -number 4 | select size).size /1MB) 

$TargetDatabasestatus = $db2.isaccessible
write-output  TargetDatabasestatus=$TargetDatabasestatus >>$logfile

$TargetDBSize = $db2.Size
write-output Targetdbsize:$TargetDBSize  >>$logfile

$dba = $db2.recoverymodel
write-output $dba | out-file "c:\dba.txt"

$TargetCollation = $db2.Collation
write-output TargetCollation:$TargetCollation >>$logfile	

$TargetDatabaseEncrypted = $db2.EncryptionEnabled
write-output TargetDatbaseencrypted:$TargetDatabaseEncrypted  >>$logfile

$TargetAlwaysOn = $db2.AvailabilityDatabaseSynchronizationState
write-output TargetDatabaseAlwayson:$TargetAlwaysOn >>$logfile

$TargetAlwaysonGroupName = $db2.AvailabilityGroupName
write-output TargetDatabasealwaysongroupname:$TargetAlwaysonGroupName >>$logfile

}

if(($Targetdrivediskspace - $SDBSize) -lt $Targetdrivediskspace) 
  {
    Write-output "Drive space is sufficent for restore: Success" >>$logfile
  }
else{
    write-output "Insufficent drive space: Fail" >>$logfile
  }
if($TargetCollation -eq $scollation)
  {
    write-output "Collation is matching: Success" >>$logfile
  }
else{
   write-output "Collation mismatch: Fail" >>$logfile 
  }
if(($SDatabasestatus -eq 'true') -and  ($TargetDatabasestatus -eq 'true'))
  {
    write-output "Source and Target database are online: Success " >>$logfile
   }
else{
     write-output "Either source or target database is offline : Fail " >>$logfile
    }

if(($SAlwaysOn -notmatch 's') -and ($TargetAlwaysOn -notmatch 's'))
  {
   write-output "Alwayson is not available : Success " >>$logfile
  }
else{
   write-output "Alwayson is configured either on source or tagret server: Fail" >>$logfile
  }

if(($SDatabaseEncrypted -ne 'true') -and ($TargetDatabaseEncrypted -ne 'true'))
  {
    write-output "Database is not encrypted: Success" >>$logfile
  }
else{
    write-output "Either source or target database is encrypted: Fail" >>$logfile
  }



if($Result = Select-String -Path "\\$source\c$\DBRefreshlogs\$source\$rfc\Precheck_Logfile.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the$logfile for details" -f red
   write-output "Precheck failed please check the $logfile  for details" >>$logfile 
   $result.line >>$logfile
 }
else{
    write-host "Precheck is success " -f green
    write-host "Sourceserver:$source" -f yellow
    write-host "Targetserver:$target" -f yellow
    write-host "SourceDatabase:$db1" -f yellow
    write-host "TargetDatabase:$db3" -f yellow
    write-output "Precheck is success for server $source on database $db1 and server $target on database $db3" >>$logfile 
    
}



$dbname1 =$sdb.split(',')[1]
foreach($db1 in $dbname1)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$SOURCE")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db1
$db = $srv.Databases.Item("$db1")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile
write-output *************************************************************** >>$logfile
"`n"
write-output *************************************************************** >>$logfile
write-output Sourceserver:$source >>$logfile
write-output SourceDatabse:$db >>$logfile
write-output *************************************************************** >>$logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db.LogFiles)
{
   $Slogfilesize1 = $lf.size 
   write-output Sourcelogfilesize1:$Slogfilesize1 >>$logfile
   
}

Foreach ($lf1 in $db.FileGroups)
{
 $Sdatafilesize1 = $lf1.size
 write-output Sourcedatafilesize1:$Sdatafilesize1 >>$logfile

}

$Sdatabasefilesize1 =($db.LogFiles + $db.FileGroups| Measure-Object -Sum size).sum  
write-output Sourcedatabasefilesize1:$Sdatabasefilesize1 >>$logfile

$SLogdrivediskspace1 = ((get-disk -number 4 | select size).size /1GB) 
write-output SourceLogdrivediskspace1:$SLogdrivediskspace1 >>$logfile

$SDatabasestatus1 = $db.isaccessible
write-output  SourceDatabaseStatus1:$SDatabasestatus1 >>$logfile

$SDBSize1 = $db.Size
write-output Sourcedbsize1:$SDBSize1  >>$logfile

$SCollation1 = $db.Collation
write-output SourceCollation1:$SCollation1 >>$logfile	

$SDatabaseEncrypted1 = $db.EncryptionEnabled
write-output SourceDatbaseencrypted1:$SDatabaseEncrypted1  >>$logfile

$SAlwaysOn1 = $db.AvailabilityDatabaseSynchronizationState
write-output SourceDatabaseAlwayson1:$SAlwaysOn1 >>$logfile

$SAlwaysonGroupName1 = $db.AvailabilityGroupName
write-output SourceDatabasealwaysongroupname1:$SAlwaysonGroupName1 >>$logfile

}

<#
$dbname =$sdb.split(",")[0]
foreach($db in $dbname)
{
    echo $db
     [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
     $s = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $source
     $db=$s.Databases.item($db)      
     $db | SELECT Name, Collation, isaccessible, EncryptionEnabled, AvailabilityDatabaseSynchronizationState, Size, SpaceAvailable >>$logfilefile
     
}
#>

$dbname1 =$tdb.split(',')[1]
foreach($db3 in $dbname1)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$target")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db3
$db2 = $srv.Databases.Item("$db3")
#$logfilefile = "\\ITSSGSGWSP00258\d$\kishore\log.txt"

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile
write-output *************************************************************** >>$logfile
"`n"
write-output *************************************************************** >>$logfile
write-output Targetserver:$Target >>$logfile
write-output TargetDatabase:$db2 >>$logfile
write-output *************************************************************** >>$logfile
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db2.LogFiles)
{
   $Tlogfilesize1= $lf.size 
   write-output Targetlogfilesize1:$Slogfilesize1 >>$logfile
   
}

Foreach ($lf1 in $db2.FileGroups)
{
 $Tdatafilesize1 = $lf1.size
 write-output Targetdatafilesize1:$Tdatafilesize1 >>$logfile

}

$Targetdrivediskspace1 = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspace1:$Targetdrivediskspace1 >>$logfile
#((get-disk -number 4 | select size).size /1MB) 

$TargetDatabasestatus1 = $db2.isaccessible
write-output  TargetDatabasestatus1=$TargetDatabasestatus1 >>$logfile

$TargetDBSize1 = $db2.Size
write-output Targetdbsize1:$TargetDBSize1  >>$logfile

$dba1 = $db2.recoverymodel
write-output $dba1 | out-file "c:\dba1.txt"

$TargetCollation1 = $db2.Collation
write-output TargetCollation1:$TargetCollation1 >>$logfile

$TargetDatabaseEncrypted1 = $db2.EncryptionEnabled
write-output TargetDatbaseencrypted1:$TargetDatabaseEncrypted1  >>$logfile

$TargetAlwaysOn1 = $db2.AvailabilityDatabaseSynchronizationState
write-output TargetDatabaseAlwayson1:$TargetAlwaysOn1 >>$logfile

$TargetAlwaysonGroupName1 = $db2.AvailabilityGroupName
write-output TargetDatabasealwaysongroupname1:$TargetAlwaysonGroupName1 >>$logfile

}

if(($Targetdrivediskspace1 - $SDBSize1) -lt $Targetdrivediskspace1) 
  {
    Write-output "Drive space is sufficent for restore: Success" >>$logfile
  }
else{
    write-output "Insufficent drive space: Fail" >>$logfile
  }
if($TargetCollation1 -eq $scollation1)
  {
    write-output "Collation is matching: Success" >>$logfile
  }
else{
   write-output "Collation mismatch: Fail" >>$logfile 
  }
if(($SDatabasestatus1 -eq 'true') -and  ($TargetDatabasestatus1 -eq 'true'))
  {
    write-output "Source and Target database are online: Success " >>$logfile
   }
else{
     write-output "Either source or target database is offline : Fail " >>$logfile
    }

if(($SAlwaysOn1 -notmatch 's') -and ($TargetAlwaysOn1 -notmatch 's'))
  {
   write-output "Alwayson is not available : Success " >>$logfile
  }
else{
   write-output "Alwayson is configured either on source or tagret server: Fail" >>$logfile
  }

if(($SDatabaseEncrypted1 -ne 'true') -and ($TargetDatabaseEncrypted1 -ne 'true'))
  {
    write-output "Database is not encrypted: Success" >>$logfile
  }
else{
    write-output "Either source or target database is encrypted: Fail" >>$logfile
  }


if($Result1 = Select-String -Path "\\$source\c$\DBRefreshlogs\$source\$rfc\Precheck_Logfile.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the$logfile for details" -f red
   write-output "Precheck failed please check the$logfile  for details" >>$logfile 
   $result1.line >>$logfile
 }
else{
    write-host "Precheck is success" -f green
    write-host "Sourceserver:$source" -f yellow
    write-host "Targetserver:$target" -f yellow
    write-host "SourceDatabase:$db1" -f yellow
    write-host "TargetDatabase:$db3" -f yellow
    write-output "Precheck is success for server $source on database $db1 and server $target on database $db3" >>$logfile 
    
}



$dbname =$sdb.split(',')[2]
foreach($db1 in $dbname)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$SOURCE")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db1
$db = $srv.Databases.Item("$db1")
$logfile1 = "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\Precheck_Logfile1.txt" 

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile1
write-output *************************************************************** >>$logfile1
"`n"
write-output *************************************************************** >>$logfile1
write-output Sourceserver:$source >>$logfile1
write-output SourceDatabase:$db >>$logfile1
write-output *************************************************************** >>$logfile1
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile1

Foreach ($lf in $db.LogFiles)
{
   $Slogfilesize2 = $lf.size 
   write-output Sourcelogfilesize2:$Slogfilesize2 >>$logfile1
   
}

Foreach ($lf1 in $db.FileGroups)
{
 $Sdatafilesize2 = $lf1.size
 write-output Sourcedatafilesize2:$Sdatafilesize2 >>$logfile1

}

$Sdatabasefilesize2 =($db.LogFiles + $db.FileGroups| Measure-Object -Sum size).sum  
write-output Sourcedatabasefilesize2:$Sdatabasefilesize2 >>$logfile1

$SLogdrivediskspace2 = ((get-disk -number 4 | select size).size /1GB) 
write-output SourceLogdrivediskspace2:$SLogdrivediskspace2 >>$logfile1

$SDatabasestatus2 = $db.isaccessible
write-output  SourceDatabaseStatus2:$SDatabasestatus2 >>$logfilefile1

$SDBSize2 = $db.Size
write-output Sourcedbsize2:$SDBSize2 >>$logfile1

$SCollation2 = $db.Collation
write-output SourceCollation2:$SCollation2 >>$logfile1	

$SDatabaseEncrypted2 = $db.EncryptionEnabled
write-output SourceDatbaseencrypted2:$SDatabaseEncrypted2  >>$logfile1

$SAlwaysOn2 = $db.AvailabilityDatabaseSynchronizationState
write-output SourceDatabaseAlwayson2:$SAlwaysOn2 >>$logfile1

$SAlwaysonGroupName2 = $db.AvailabilityGroupName
write-output SourceDatabasealwaysongroupname2:$SAlwaysonGroupName2 >>$logfile1

}

<#
$dbname =$sdb.split(",")[0]
foreach($db in $dbname)
{
    echo $db
     [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
     $s = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $source
     $db=$s.Databases.item($db)      
     $db | SELECT Name, Collation, isaccessible, EncryptionEnabled, AvailabilityDatabaseSynchronizationState, Size, SpaceAvailable >>$logfilefile
     
}
#>

$dbname1 =$tdb.split(',')[2]
foreach($db3 in $dbname1)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$target")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db3
$db2 = $srv.Databases.Item("$db3")
$logfile1 = "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\Precheck_Logfile1.txt"

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile1
write-output *************************************************************** >>$logfile1
"`n"
write-output *************************************************************** >>$logfile1
write-output Targetserver:$Target >>$logfile1
write-output TargetDatabase:$db2 >>$logfile1
write-output *************************************************************** >>$logfile1
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db2.LogFiles)
{
   $Tlogfilesize2= $lf.size 
   write-output Targetlogfilesize2:$Slogfilesize2 >>$logfile1
   
}

Foreach ($lf1 in $db2.FileGroups)
{
 $Tdatafilesize2 = $lf1.size
 write-output Targetdatafilesize2:$Tdatafilesize2 >>$logfile1

}

$Targetdrivediskspace2 = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspace2:$Targetdrivediskspace2 >>$logfile1
#((get-disk -number 4 | select size).size /1MB) 

$TargetDatabasestatus2 = $db2.isaccessible
write-output  TargetDatabasestatus2=$TargetDatabasestatus2 >>$logfile1

$TargetDBSize2 = $db2.Size
write-output Targetdbsize2:$TargetDBSize2  >>$logfile1

$TargetCollation2 = $db2.Collation
write-output TargetCollation2:$TargetCollation2 >>$logfile1	

$TargetDatabaseEncrypted2 = $db2.EncryptionEnabled
write-output TargetDatbaseencrypted2:$TargetDatabaseEncrypted2  >>$logfile1

$TargetAlwaysOn2 = $db2.AvailabilityDatabaseSynchronizationState
write-output TargetDatabaseAlwayson2:$TargetAlwaysOn2 >>$logfile1

$TargetAlwaysonGroupName2 = $db2.AvailabilityGroupName
write-output TargetDatabasealwaysongroupname2:$TargetAlwaysonGroupName2 >>$logfile1

}

if(($Targetdrivediskspace2 - $SDBSize2) -lt $Targetdrivediskspace2) 
  {
    Write-output "Drive space is sufficent for restore: Success" >>$logfile1
  }
else{
    write-output "Insufficent drive space: Fail" >>$logfile1
  }
if($TargetCollation2 -eq $scollation2)
  {
    write-output "Collation is matching: Success" >>$logfile1
  }
else{
   write-output "Collation mismatch: Fail" >>$logfile1
  }
if(($SDatabasestatus2 -eq 'true') -and  ($TargetDatabasestatus2 -eq 'true'))
  {
    write-output "Source and Target database are online: Success " >>$logfile1
   }
else{
     write-output "Either source or target database is offline : Fail " >>$logfile1
    }

if(($SAlwaysOn2 -notmatch 's') -and ($TargetAlwaysOn2 -notmatch 's'))
  {
   write-output "Alwayson is not available : Success " >>$logfile1
  }
else{
   write-output "Alwayson is configured either on source or tagret server: Fail" >>$logfile1
  }

if(($SDatabaseEncrypted2 -ne 'true') -and ($TargetDatabaseEncrypted2 -ne 'true'))
  {
    write-output "Database is not encrypted: Success" >>$logfile1
  }
else{
    write-output "Either source or target database is encrypted: Fail" >>$logfile1
  }


if($Result2 = Select-String -Path "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\Precheck_Logfile1.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the$logfile1 for details" -f red
   write-output "Precheck failed please check the$logfile1  for details" >>$logfile1 
   $result2.line >>$logfile1
 }
else{
    write-host "Precheck is success" -f green
    write-host "Sourceserver:$source" -f yellow
    write-host "Targetserver:$target" -f yellow
    write-host "SourceDatabase:$db1" -f yellow
    write-host "TargetDatabase:$db3" -f yellow
    write-output "Precheck is success for server $source on database $db1 and server $target on database $db3" >>$logfile1 
    
}




$dbname =$sdb.split(',')[3]
foreach($db1 in $dbname)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$SOURCE")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db1
$db = $srv.Databases.Item("$db1")
$logfile2 = "\\$source\c$\DBRefreshlogs\$source\$rfc\Precheck_Logfile2.txt" 

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile2
write-output *************************************************************** >>$logfile2
"`n"
write-output *************************************************************** >>$logfile2
write-output Sourceserver:$source >>$logfile2
write-output SourceDatabase:$db >>$logfile2
write-output *************************************************************** >>$logfile2
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile1

Foreach ($lf in $db.LogFiles)
{
   $Slogfilesize3 = $lf.size 
   write-output Sourcelogfilesize3:$Slogfilesize3 >>$logfile2
   
}

Foreach ($lf1 in $db.FileGroups)
{
 $Sdatafilesize3 = $lf1.size
 write-output Sourcedatafilesize3:$Sdatafilesize3 >>$logfile2

}

$Sdatabasefilesize3 =($db.LogFiles + $db.FileGroups| Measure-Object -Sum size).sum  
write-output Sourcedatabasefilesize3:$Sdatabasefilesize3 >>$logfile2

$SLogdrivediskspace3 = ((get-disk -number 4 | select size).size /1GB) 
write-output SourceLogdrivediskspace3:$SLogdrivediskspace3 >>$logfile2

$SDatabasestatus3 = $db.isaccessible
write-output  SourceDatabaseStatus3:$SDatabasestatus3 >>$logfile2

$SDBSize3 = $db.Size
write-output Sourcedbsize2:$SDBSize2 >>$logfile2

$SCollation3 = $db.Collation
write-output SourceCollation3:$SCollation3 >>$logfile2	

$SDatabaseEncrypted3 = $db.EncryptionEnabled
write-output SourceDatbaseencrypted3:$SDatabaseEncrypted3  >>$logfile2

$SAlwaysOn3 = $db.AvailabilityDatabaseSynchronizationState
write-output SourceDatabaseAlwayson3:$SAlwaysOn3 >>$logfile2

$SAlwaysonGroupName3 = $db.AvailabilityGroupName
write-output SourceDatabasealwaysongroupname3:$SAlwaysonGroupName3 >>$logfile2

}


$dbname1 =$tdb.split(',')[3]
foreach($db3 in $dbname1)
{
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("$target")
#$srv2 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03004")
#$srv1 = new-Object Microsoft.SqlServer.Management.Smo.Server("ITSUSRAWSP03021")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$ErrorActionPreference = 'SilentlyContinue'



echo $db3
$db2 = $srv.Databases.Item("$db3")
$logfile2 = "\\$source\c$\DBRefreshlogs\$source\$rfc\Precheck_Logfile2.txt"

write-output "Pre-check DBRefresh\Clone Summary " >>$logfile2
write-output *************************************************************** >>$logfile2
"`n"
write-output *************************************************************** >>$logfile2
write-output Targetserver:$Target >>$logfile2
write-output TargetDatabase:$db2 >>$logfile2
write-output *************************************************************** >>$logfile2
#Get-WmiObject -Class win32_logicaldisk -ComputerName "$SOURCE" -filter "deviceid= 'g:'" | ft pscomputername,DeviceID, @{Name="Free Disk #Space (GB)";e={$_.FreeSpace /1GB}}, @{Name="Total Disk Size (GB)";e={$_.Size /1GB}} -AutoSize >>$logfile

Foreach ($lf in $db2.LogFiles)
{
   $Tlogfilesize3= $lf.size 
   write-output Targetlogfilesize3:$Slogfilesize3 >>$logfile2
   
}

Foreach ($lf1 in $db2.FileGroups)
{
 $Tdatafilesize3 = $lf1.size
 write-output Targetdatafilesize3:$Tdatafilesize3 >>$logfile2

}

$Targetdrivediskspace3 = ((Get-WmiObject -Class win32_logicaldisk -ComputerName "$target" -filter "deviceid= 'g:'" | select freespace).freespace /1MB) 
write-output Targetdrivediskspace3:$Targetdrivediskspace3 >>$logfile2
#((get-disk -number 4 | select size).size /1MB) 

$TargetDatabasestatus3 = $db2.isaccessible
write-output  TargetDatabasestatus3=$TargetDatabasestatus3 >>$logfile2

$TargetDBSize3 = $db2.Size
write-output Targetdbsize3:$TargetDBSize3  >>$logfile2

$TargetCollation3 = $db2.Collation
write-output TargetCollation3:$TargetCollation3 >>$logfile2	

$TargetDatabaseEncrypted3 = $db2.EncryptionEnabled
write-output TargetDatbaseencrypted3:$TargetDatabaseEncrypted3  >>$logfile2

$TargetAlwaysOn3 = $db2.AvailabilityDatabaseSynchronizationState
write-output TargetDatabaseAlwayson3:$TargetAlwaysOn3 >>$logfile2

$TargetAlwaysonGroupName3 = $db2.AvailabilityGroupName
write-output TargetDatabasealwaysongroupname3:$TargetAlwaysonGroupName3 >>$logfile2

}

if(($Targetdrivediskspace3 - $SDBSize3) -lt $Targetdrivediskspace3) 
  {
    Write-output "Drive space is sufficent for restore: Success" >>$logfile2
  }
else{
    write-output "Insufficent drive space: Fail" >>$logfile2
  }
if($TargetCollation3 -eq $scollation3)
  {
    write-output "Collation is matching: Success" >>$logfile2
  }
else{
   write-output "Collation mismatch: Fail" >>$logfile2
  }
if(($SDatabasestatus3 -eq 'true') -and  ($TargetDatabasestatus3 -eq 'true'))
  {
    write-output "Source and Target database are online: Success " >>$logfile2
   }
else{
     write-output "Either source or target database is offline : Fail " >>$logfile2
    }

if(($SAlwaysOn3 -notmatch 's') -and ($TargetAlwaysOn3 -notmatch 's'))
  {
   write-output "Alwayson is not available : Success " >>$logfile2
  }
else{
   write-output "Alwayson is configured either on source or tagret server: Fail" >>$logfile2
  }

if(($SDatabaseEncrypted3 -ne 'true') -and ($TargetDatabaseEncrypted3 -ne 'true'))
  {
    write-output "Database is not encrypted: Success" >>$logfile2
  }
else{
    write-output "Either source or target database is encrypted: Fail" >>$logfile2
  }


if($Result3 = Select-String -Path "\\$source\c$\DBRefreshlogs\$source\$rfc\Precheck_Logfile2.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the$logfile1 for details" -f red
   write-output "Precheck failed please check the$logfile1  for details" >>$logfile1 
   $result2.line >>$logfile2
 }
else{
    write-host "Precheck is success" -f green
    write-host "Sourceserver:$source" -f yellow
    write-host "Targetserver:$target" -f yellow
    write-host "SourceDatabase:$db1" -f yellow
    write-host "TargetDatabase:$db3" -f yellow
    write-output "Precheck is success for server $source on database $db1 and server $target on database $db3" >>$logfile2 
    
}

$statusfile = "\\$source\c$\SQLInstall_Logs\refresh\"

if((Test-Path $statusfile) -eq 0)
{
mkdir $statusfile 
}

$status200 = $statusfile +"\"+"$RFC-pre-verification-status.txt"


if (Test-Path $status200) {
  Remove-Item $status200
}


if($Result = Select-String -Path "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\*.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the $logfile for details" -f red
   write-output "###1" >> $status200
 }
else{
    write-host "Precheck is success" -f green
    write-output "###0" >> $status200
           
}

$NAS = "\\$source\c$\SQLInstall_Logs\refresh\"  

if((Test-Path $NAS) -eq 0)
{
mkdir $NAS
}

$C200log = $NAS +"\"+"$RFC-AUTOMATION_SDDC_TASK200.log"

if (Test-Path $C200log) {
  Remove-Item $C200log
}

if($Result = Select-String -Path "\\$source\c$\DBRefreshlogs\$date\$source\$rfc\*.txt" -Pattern "Fail")
 {
   write-host "Precheck failed please check the $logfile for details" -f red
   write-output "Precheck failed please check the $logfile  for details" >> $logfile
   $result.line >> $logfile
   write-host "*******************************************************" >> $C200log 
   $result.line >> $C200log
   write-host "*******************************************************" >> $C200log
   write-output "Precheck failed:Return code 1" >> $C200log
   write-host "*******************************************************" >> $C200log 
 }
else{
    write-host "Precheck is success" -f green
    write-output "*******************************************************" >> $C200log
     write-output "ChangeNumber : $rfc" >> $C200log
    write-output "Source server:$source" >> $C200log
    write-output "Target server:$target" >> $C200log
    write-output "Source database:$sdb" >> $C200log
    write-output "Target database:$tdb" >> $C200log
    write-output "*******************************************************" >> $C200log
    write-output "Databases is available in source and target instance" >> $C200log
    write-output "*******************************************************" >> $C200log
    write-output "Space availabile in the target server where the DB files are hosted" >> $C200log
    write-output "*******************************************************" >> $C200log
    write-output "Precheck is success:Return code 0" >> $C200log
    write-output "*******************************************************" >> $C200log
    write-output "Ready for DB Refresh" >> $C200log
    write-output "*******************************************************" >> $C200log
    write-output "Precheck is success">>$logfile
    write-output "Ready for DB Refresh" >>$logfile
        
}

}
}

