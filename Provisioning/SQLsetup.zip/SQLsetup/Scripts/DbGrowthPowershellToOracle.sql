USE [msdb]
GO

/****** Object:  Job [run]    Script Date: 8/25/2019 8:33:01 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 8/25/2019 8:33:01 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'run', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'NA\Admin_dkhilari', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [run]    Script Date: 8/25/2019 8:33:01 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'run', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'###################################################################################################
$ScriptName = "Capacity Report"
$Scriptver = "1.0"
#Description: Transfers the data from Sql to Oracle via port 1521
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			16/4/2018	Darshana Subhash	New Script

####Added the parameters necessary for Database Growth####################################################

###################################################################################################
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient")

           try
            {
       	###################Truncate before making an entry########################
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient")
	#Source server Details 
	$SrcServer= "ITSUSMPW01430"
	$DestTable = "CAPACITY.dbgrowth"
	$DestConnStr = �Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = itsusmpl00644.jnj.com)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = DVDB5076.jnj.com)));User Id=rmanreport;Password=Wsxedc#123 ;�

	$connection1 = New-Object System.Data.OracleClient.OracleConnection($DestConnStr)
	$connection1.Open(); 
	$query = "delete from $DestTable"

	$cmd=new-Object System.Data.OracleClient.OracleCommand($query,$connection1)
	$cmd.ExecuteNonQuery() | Out-Null

	
            }
          catch
          {
              $ex=$_.Exception
           }
         Finally
       { 
          #$bulkCopy.Close()
          $connection1.Close();
          $connection1.Dispose();
         }	
', 
		@database_name=N'sqlmon', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert]    Script Date: 8/25/2019 8:33:01 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'[void][System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient")
#Source server Details 
$SrcServer="ITSUSMPW01430"
$SrcDatabase="sqlmon"
$DestTable ="DBGrowth"
#Data reading from source server

             
	$query=�select  SQLInstanceName,WindowsServerName ,DatabaseName,Allocated_Space_MB,Run_Date,Monthly_Inc,YOY_PCT,Environment from dbo.vwDatabaseGrowth "
	 $dataTable = Invoke-Sqlcmd -Query $query -Database $SrcDatabase -ServerInstance $SrcServer;

           Try
         {
           $DestConnStr = �Data Source=(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = itsusmpl00644.jnj.com)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = DVDB5076.jnj.com)));User Id=Capacity;Password=Jan_2016;�
   
           $connection1 = New-Object System.Data.OracleClient.OracleConnection($DestConnStr)
           $connection1.Open();    
    
    foreach($dt in $dataTable)
    {
        $SQLInstanceName=$dt.SQLInstanceName
        $WindowsServerName=$dt.WindowsServerName
        $DatabaseName=$dt.DatabaseName
        $Allocated_Space_MB=$dt.Allocated_Space_MB
        $Run_Date = $dt.Run_Date
        $Monthly_Inc=$dt.Monthly_Inc
        $YOY_PCT=$dt.YOY_PCT
        $Environment=$dt.Environment
        
      	

        $queryString = "insert into $DestTable(SQLInstanceName,WindowsServerName ,DatabaseName,Allocated_Space_MB,Run_Date,Monthly_Inc,YOY_PCT,Environment) values(''$SQLInstanceName'',''$WindowsServerName'',''$DatabaseName'',''$Allocated_Space_MB'',''$Run_Date'',''$Monthly_Inc'',''$YOY_PCT'',''$Environment'')" 
        
        $cmd=new-Object System.Data.OracleClient.OracleCommand($queryString,$connection1)
        $cmd.ExecuteNonQuery() | Out-Null
    }     
}
Catch
{
    $ex=$_.Exception
    #Write-Host $ex.Message
}
Finally
{ 
    #$bulkCopy.Close()
    $connection1.Close();
    $connection1.Dispose();
}', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'server2', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180710, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'49294a15-9a7c-42cc-9367-c8525af69926'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


