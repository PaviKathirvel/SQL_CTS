USE [msdb]
GO

/****** Object:  Job [DbGrowthCalculation]    Script Date: 8/25/2019 8:30:40 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 8/25/2019 8:30:40 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DbGrowthCalculation', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'NA\Admin_dkhilari', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [server1]    Script Date: 8/25/2019 8:30:40 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'server1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--------###################################################################################################
---$ScriptName = "Capacity Report"#########
-------$Scriptver = "1.0"#######
--------#Description: Description: DatabaseGrowthCalculation#############
-------###################################################################################################
--------#Version		Date		Author		Reason for Change
--###################################################################################################
-------#1.0			16/4/2018	Darshana Subhash	New Script


----------###################################################################################################
truncate table DatabaseGrowth
truncate table DatabaseGrowth1



insert into dbo.DatabaseGrowth select T2.*,T3.ServerType as Environment from (
select all T.SQLInstanceName,T.WindowsServerName,T.DBID,T.DatabaseName,
T.PhysicalName,T.File_Size_GB,convert(varchar(34),T.run_date,113)as Run_Date,T.runMonth,T.runYear,T.File_Size_MB
 from iMonitorHistory.tblDataBaseFileInfohistory T join
( select Max(run_date) as  Max_Run_Date,S.SQLInstanceName,S.DatabaseName,S.runMonth 
from iMonitorHistory.tblDataBaseFileInfohistory S group by S.DatabaseName,S.SQLInstanceName,S.runMonth)

T1
 On T.run_date = T1.Max_Run_Date AND T.DatabaseName = T1.DatabaseName  and T.SQLInstanceName= T1.SQLInstanceName and T.runMonth =T1.runMonth
 group by T.DBID,T.DatabaseName,T.SQLInstanceName,T.WindowsServerName,T.run_date,T.runMonth,T.runYear,T.PhysicalName,T.File_Size_MB,T.File_Size_GB
--order by SQLInstanceName,DBID
)T2 inner join tbl_serverlist T3 on T2.SQLInstanceName=T3.ServerName

--------------######T-SQL Query to find the summation of File_Size_In_MB for a particular dataase in Instance where database=.mdf+.ldf or(.mdf+.ndf+.ldf)############

insert into DatabaseGrowth1 select distinct 
T.SQLInstanceName,T.WindowsServerName,T.DBID,
T.DatabaseName,dbo.uspGetPhysicalName(T.PhysicalName) as Merged_PhysicalName,
T.run_date,T2.Sum_File_Size_MB,
T.runMonth,T.runYear,T.Environment  from DatabaseGrowth T Join
(
Select cast(SUM(File_Size_MB) as DECIMAL(38,19)) AS Sum_File_Size_MB,SQLInstanceName,
DatabaseName,WindowsServerName,DBID,runMonth
 from DatabaseGrowth  
 group by SQLInstanceName,DatabaseName,WindowsServerName,DBID,runMonth
 )
 As T2
 ON T.SQLInstanceName=T2.SQLInstanceName AND  T.WindowsServerName=T2.WindowsServerName AND
 T.DatabaseName=T2.DatabaseName AND T.DBID=T2.DBID AND T.runMonth=T2.runMonth
 order by SQLInstanceName
-----------------########################insert the output returned by above query into another table##############

 if exists
(
select * from tempdb.dbo.sysobjects
where ID = object_id(N''tempdb..#ITS_Capacity'')
)
BEGIN
DROP TABLE #ITS_Capacity
END

Create table #ITS_Capacity
(
 SQLInstanceName nvarchar(128) null,
 WindowsServerName varchar(1000) null,
 DatabaseName nvarchar(128)null,
 Sum_File_Size_MB decimal(38,19) null,
 Run_Date nvarchar(128) null,
 Run_Month int null,
 Run_Year smallint null,
 Environment varchar(20) null,
 RowNum int not null
);

Declare @PYear int
Declare @Month int
Declare @CYear int

Set @PYear = YEAR(GETDATE())-1;
Set @CYear = Year(GETDATE());
--select @CYear
Set @Month = cast(format(GETDATE(),''MM'') as int);

--select @Month





With MyRowSet
AS 
(
Select distinct SQLInstanceName,WindowsServerName,
DatabaseName,Sum_File_Size_MB,
cast(format(Run_Date,''MMM-yyyy'') as nvarchar) as Run_Date,
runMonth,runYear,
Environment,
ROW_NUMBER() 
over(Partition by DatabaseName,SQLInstanceName,WindowsServerName order by Run_Date Desc) as RowNum
 from sqlmon.dbo.DatabaseGrowth1 T1
 Where  Exists
 (Select SQLInstanceName,WindowsServerName,DatabaseName, 
 Run_Date,runMonth,runYear,Environment from DatabaseGrowth1 T2
 where T1.DatabaseName=T2.DatabaseName
 and T1.SQLInstanceName=T2.SQLInstanceName
 and T1.WindowsServerName=T2.WindowsServerName and T1.Environment=T2.Environment
  and T1.runMonth >= @Month and T1.runYear =@PYear group by DatabaseName,SQLInstanceName,WindowsServerName,Environment,run_date,runYear,runMonth,Sum_File_Size_MB

  union all

  Select SQLInstanceName,WindowsServerName,DatabaseName,Sum_File_Size_MB 
 Run_Date,runMonth,runYear,Environment from DatabaseGrowth1 T2
 where T1.DatabaseName=T2.DatabaseName
 and T1.SQLInstanceName=T2.SQLInstanceName
 and T1.WindowsServerName=T2.WindowsServerName and T1.Environment=T2.Environment
  and T1.runMonth <= @Month and T1.runYear =@CYear group by  DatabaseName,SQLInstanceName,WindowsServerName,Environment,run_date,runYear,runMonth,Sum_File_Size_MB

 )
 group by DatabaseName,SQLInstanceName,WindowsServerName,
 Environment,Sum_File_Size_MB,run_date,runMonth,runYear
 )
 insert into #ITS_Capacity select * from MyRowSet 

 if exists
(
select * from tempdb.dbo.sysobjects
where ID = object_id(N''tempdb..#ITS_INT_Capacity'')
)
BEGIN
DROP TABLE #ITS_INT_Capacity
END

Create table #ITS_INT_Capacity
(
 SQLInstanceName nvarchar(128) null,
 WindowsServerName varchar(1000) null,
 DatabaseName nvarchar(128)null,
 Sum_File_Size_MB decimal(38,19) null,
 Run_Date nvarchar(128) null,
 Run_Month varchar(3) null,
 Run_Year smallint null,
 Monthly_Inc nvarchar(38) null,
 Environment varchar(20) null,
 RowNum int null,
);



insert into #ITS_INT_Capacity
 select distinct
T1.SQLInstanceName,
T1.WindowsServerName,
T1.DatabaseName,
T1.Sum_File_Size_MB,
T1.Run_Date,
T1.Run_Month,
T1.Run_Year,
(((T1.Sum_File_Size_MB/T2.Sum_File_Size_MB)-1)*100) as Monthly_Inc,
 T1.Environment,T1.RowNum
from #ITS_Capacity T1
 left outer join #ITS_Capacity T2 on T1.DatabaseName = T2.DatabaseName and 
  T1.SQLInstanceName=T2.SQLInstanceName  AND T1.WindowsServerName=T2.WindowsServerName AND T1.Environment=T2.Environment
     and T1.RowNum < T2.RowNum  and  (T1.Run_Month-T2.Run_Month)=1
	
	

 if exists
(
select * from tempdb.dbo.sysobjects
where ID = object_id(N''tempdb..#ITS_INT_Capacity1'')
)
BEGIN
DROP TABLE #ITS_INT_Capacity1
END

Create table #ITS_INT_Capacity1
(
 SQLInstanceName nvarchar(128) null,
 WindowsServerName varchar(1000) null,
 DatabaseName nvarchar(128)null,
 Sum_File_Size_MB decimal(38,19) null,
 Environment varchar(20) null,
 Run_Date nvarchar(128) null,
 RowNum int not null,
 Run_Month varchar(3) null,
 Run_Year smallint null
);


insert into #ITS_INT_Capacity1
 select SQLInstanceName,WindowsServerName,DatabaseName,Sum_File_Size_MB,Environment,Run_Date,RowNum
 ,Run_Month,Run_Year from #ITS_Capacity where RowNum =
 (
 select max(RowNum) from #ITS_Capacity I where I.DatabaseName=#ITS_Capacity.DatabaseName
 and I.SQLInstanceName=#ITS_Capacity.SQLInstanceName and I.WindowsServerName=#ITS_Capacity.WindowsServerName
 and I.Environment=#ITS_Capacity.Environment 
)



if exists
(
select * from tempdb.dbo.sysobjects
where ID = object_id(N''tempdb..#ITS_INT_Capacity2'')
)
BEGIN
DROP TABLE #ITS_INT_Capacity2
END

Create table #ITS_INT_Capacity2
(
 SQLInstanceName nvarchar(128) null,
 WindowsServerName varchar(1000) null,
 DatabaseName nvarchar(128)null,
 Sum_File_Size_MB decimal(38,19) null,
 Run_Date nvarchar(128) null,
 Run_Month varchar(3) null,
 Run_Year smallint null,
 YOY nvarchar(38) null,
 YOY_PCT nvarchar(38) null,
 Environment varchar(20) null,
 RowNum int not null
);


insert into #ITS_INT_Capacity2
select distinct T1.SQLInstanceName,T1.WindowsServerName,T1.DatabaseName,
T1.Sum_File_Size_MB,T1.Run_Date,T1.Run_Month,T1.Run_Year,
((T1.Sum_File_Size_MB/T2.Sum_File_Size_MB)-1) as YOY,
(((T1.Sum_File_Size_MB/T2.Sum_File_Size_MB)-1)*100) as YOY_PCT,
T1.Environment,T1.RowNum from #ITS_Capacity T1 left outer join  #ITS_INT_Capacity1 T2
on T1.SQLInstanceName=T2.SQLInstanceName and T1.WindowsServerName=T2.WindowsServerName
and T1.DatabaseName=T2.DatabaseName and T1.Environment=T2.Environment
and T1.RowNum < T2.RowNum



Truncate Table   CAPACITYREPORT


insert into  CAPACITYREPORT
select T1.SQLInstanceName, T1.WindowsServerName,T1.DatabaseName,T1.Sum_File_Size_MB as  Allocated_Space_MB ,
T1.Run_Date,T1.Run_Month,T1.Run_Year,T1.Monthly_Inc,T2.YOY,T2.YOY_PCT,T2.Environment,T2.RowNum
  from #ITS_INT_Capacity T1 join #ITS_INT_Capacity2 T2 on 
  T1.SQLInstanceName=T2.SQLInstanceName and T1.WindowsServerName=T2.WindowsServerName and
  T1.DatabaseName=T2.DatabaseName and T1.Sum_File_Size_MB=T2.Sum_File_Size_MB and 
  T1.Run_Date=T2.Run_Date and T1.Run_Month=T2.Run_Month and T1.Run_Year=T2.Run_Year and
  T1.Environment=T2.Environment and T1.RowNum=T2.RowNum

  update CAPACITYREPORT
  set YOY = ''0''  where YOY IS NULL

  update CAPACITYREPORT
  set YOY_PCT = ''0''  where YOY_PCT IS NULL

 update CAPACITYREPORT
  set Monthly_Inc = ''0''  where Monthly_Inc IS NULL

  if exists(select * from sys.views where name=''vwDatabaseGrowth'' and type=''v'')
drop view vwDatabaseGrowth;
go

create view [dbo].[vwDatabaseGrowth]
as 
select SQLInstanceName,WindowsServerName,DatabaseName,Allocated_Space_MB,Run_Date,
	  Monthly_Inc,YOY_PCT,Environment
	from  dbo. CAPACITYREPORT
	

	


', 
		@database_name=N'sqlmon', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Server', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180613, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'3c03e1cb-46a2-457d-8815-df25b084e68d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


