###################################################################################################
$ScriptName = "sddc_sql_Size_Modification_MEMORY.PS1"
$Scriptver = "2.0"
#Description: Script used to adjust SQL Server configuration when size of VM is changed.
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			09/09/2014	Bruno Campos	New Script
#2.0			03/17/2016	Bruno Campos	Changed to cover only changes for Memory
###################################################################################################

####
#*********** Lab DML************* 
#$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML' 
$LabSQLDML= '\\itsusravf1.dfdev.jnj.com\oradist\MSSQLDML\SDDC' 
$LabConfig = "/configurationfile=""" + $LabSQLDML + $cnfgfl


#*********** NA DML*************
$NASQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
$NAConfig = "/configurationfile=""" + $NASQLDML  + $cnfgfl
#####

#*********************************** Start of Post installation function ***********************************#

FUNCTION sddc_sql_Size_Modification($IDMLLOC)  
{

$Time = get-date -Uformat "%Y%m%d%H%M"
$Log = "C:\SQLInstall_Logs\sddc_sql_Size_Modification_MEMORY_$Time.txt"
$M_Plans_sql = $IDMLLOC + "\Scripts"

Write-Host "###################################################################################################"
"###################################################################################################" > $Log
$Hostname = Hostname
$Exec_Time = Get-Date
Write-Host "Script Name: $ScriptName"
"Script Name: $ScriptName" >> $Log
Write-Host "Script Version: $Scriptver"
"Script Version: $Scriptver" >> $Log
Write-Host "Executed On: $Exec_Time"
"Execute On: $Exec_Time" >> $Log
Write-Host "Server Host: $Hostname"
"Server Host: $Hostname" >> $Log

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log

$ErrorActionPreference = "SilentlyContinue"
$error.clear()
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')
$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
$Inst_Name = $svr.name
$Final_Status_Error = 0

$conn = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
$conn.Open()


#--------------------------------- Script Execution for Post Installation Configuration ---------------------------------#
Write-Host "-------"
"-------" >> $Log
Write-Host "Script Execution for Memory Configuration"
"Script Execution for Memory Configuration" >> $Log

$cmd_2 = $IDMLLOC + "\110\Tools\Binn\sqlcmd -S $Inst_Name -i $M_Plans_sql\sddc_sql_Post_Size_Modification_MEMORY.SQL -x && exit 0 || exit 1"

& cmd.exe /c $cmd_2 | out-null
if ($lastexitcode -eq 1)
{
	Write-Host "Script Execution: " -f white -nonewline; Write-Host "Failed" -f red
	"Script Execution: Failed" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Script Execution: " -f white -nonewline; Write-Host "Success" -f green
	"Script Execution: Success" >> $Log
}
Write-Host "-------"
"-------" >> $Log

#--------------------------------- Checking Memory Allocation ---------------------------------#
Write-Host "-------"
"-------" >> $Log
$cmdDD_3 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_3.CommandText = "SELECT CONVERT(INT,(total_physical_memory_kb/1024)*0.75) FROM sys.dm_os_sys_memory"
$cmdDD_3.Connection = $conn
$Max_Mem = $cmdDD_3.ExecuteScalar()
$cmdDD_4 = New-Object System.Data.SqlClient.SqlCommand
$cmdDD_4.CommandText = "SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max server memory (MB)'"
$cmdDD_4.Connection = $conn
$SQL_Mem = $cmdDD_4.ExecuteScalar()
if ($Max_Mem -ne $SQL_Mem)
{
	Write-Host "Expected value for memory allocation to SQL Server : $Max_Mem"
	Write-Host "Current value of memory allocated to SQL Server : $SQL_Mem"
	Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Failed" -f red
	"Expected value for memory allocation to SQL Server : $Max_Mem" >> $Log
	"Current value of memory allocated to SQL Server : $SQL_Mem" >> $Log
	"Memory allocation setting : FAILED" >> $Log
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Expected value for memory allocation to SQL Server : $Max_Mem"
	Write-Host "Current value of memory allocated to SQL Server :  $SQL_Mem"
	Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Success" -f green
	"Expected value for memory allocation to SQL Server : $Max_Mem" >> $Log
	"Current value of memory allocated to SQL Server : $SQL_Mem" >> $Log
	"Memory allocation setting : SUCCESS" >> $Log
}

Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
IF ($Final_Status_Error -eq 1)
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
"FINAL STATUS = FAILED" >> $Log
Write-Host "Please review the verification steps and address the failed step"
"Please review the verification steps and address the failed step" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 1
}
ELSE
{
Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
"FINAL STATUS = SUCCESS" >> $Log
Write-Host "###################################################################################################"
"###################################################################################################" >> $Log
Exit 0
}

}

#*********************************** End of Post installation function ***********************************#


#--------- Start POST install configuration ---------#

$GetIp = Get-WmiObject win32_networkadapterconfiguration | where { $_.ipaddress -like "1*" } | select -ExpandProperty ipaddress | select -First 1
$ipAddressParts = $GetIp.Split('.') 

$IpPartsIdentifier1 = $ipAddressParts[0]
$IpPartsIdentifier2 = $ipAddressParts[1]
$IpPartsIdentifier3 = $ipAddressParts[2] 


IF ($IpPartsIdentifier1 -eq 10) # first octet eq 10
{
 IF ($IpPartsIdentifier2 -eq 0) 
 { 	

	sddc_sql_Size_Modification $LabSQLDML

 }
 ELSEIF ($IpPartsIdentifier2 -ge 1 -and $IpPartsIdentifier2 -le 95) 
 { 

	sddc_sql_Size_Modification $NASQLDML
 }
}

#--------- End POST install configuration ---------#

