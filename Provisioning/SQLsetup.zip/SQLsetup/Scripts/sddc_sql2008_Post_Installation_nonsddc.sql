/**********************************************************************************************
Script Name: SQL_Post_Installation
Description: SQL Script to customize SQL Server installation for SDDC
**********************************************************************************************
Version			Date			Author			Reason For Change
1.0				05/20/2014		Bruno Campos	New Script
**********************************************************************************************/

/*Grant access to server specific DBA groups*/


SET NOCOUNT ON

declare @machinName nvarchar(1000)
declare @grpName nvarchar(1000)
declare @grpName1 nvarchar(1000)
declare @sql nvarchar(4000)
set @machinName = cast(SERVERPROPERTY('machinename') as nvarchar)


set @grpName = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA'
set @grpName1 = 'JNJ\ITS-EP-SQL-' + @machinName + '-DEFAULT-DBA-Temp'


if not exists (select * from sys.syslogins where loginname in (@grpName,@grpName1))
begin
set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
PRINT @sql
exec sp_executesql @sql

set @sql = ''
set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName,'''') + ', @rolename = ' + quotename('sysadmin','''')
PRINT @sql
exec sp_executesql @sql

set @sql = ''
set @sql = 'CREATE LOGIN ' + QUOTENAME(@grpName1) + ' FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
exec sp_executesql @sql

set @sql = 'EXEC master..sp_addsrvrolemember @loginame = ' + quotename(@grpName1,'''') + ', @rolename = ' + quotename('sysadmin','''')
exec sp_executesql @sql
end

/**********************************************/
/*Create Job for DataIntegrity And Optimization Maintenance Plan*/
/**********************************************/
USE [msdb]
GO
/****** Object:  Job [DataIntegrityAndOptimizationMaintenance.Subplan_1]    Script Date: 06/05/2015 13:23:38 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 06/05/2015 13:23:38 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DataIntegrityAndOptimizationMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 06/05/2015 13:23:38 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\DataIntegrityAndOptimizationMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DataIntegrityAndOptimizationMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=120000, 
		@active_end_time=235959, 
		@schedule_uid=N'8e230b2c-f3f0-49bb-b17d-dac479f08b19'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{7F139A48-8ECA-463E-A87E-1D38EC8BABEE}',
@plan_id = '{29D6B55E-9E8B-4212-95F9-7F5DC8483FA0}',
@name = 'DataIntegrityAndOptimizationMaintenance',
@description = 'DataIntegrityAndOptimizationMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/**********************************************/
/*Create Job for Differential Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [DiffDatabaseBackupMaintenance.Subplan_1]    Script Date: 06/08/2015 04:45:55 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 06/08/2015 04:45:55 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DiffDatabaseBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 06/08/2015 04:45:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\DiffDatabaseBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DiffDatabaseBackupMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=95, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'7d608cea-62e9-4d6c-8a19-0d5f7a04c544'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{48366B82-4346-4A41-9A16-230DCB3F32BC}',
@plan_id = '{4736ED03-4314-4291-8C18-6A59C1708F9E}',
@name = 'DiffDatabaseBackupMaintenance',
@description = 'DiffDatabaseBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/**********************************************/
/*Create Job for Full Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [FullDatabaseBackupMaintenance.Subplan_1]    Script Date: 06/08/2015 05:06:22 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 06/08/2015 05:06:22 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FullDatabaseBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 06/08/2015 05:06:23 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\FullDatabaseBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'FullDatabaseBackupMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'54c59be2-5a91-4c61-ac0e-7a25a7f2c87b'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{82B7BBEF-155B-4752-82A6-965CA30A7BFE}',
@plan_id = '{B620D218-8FF6-44DF-B885-025796A41DB3}',
@name = 'FullDatabaseBackupMaintenance',
@description = 'FullDatabaseBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/**********************************************/
/*Create Job for Transaction Log Backup Maintenance Plan*/
USE [msdb]
GO

/****** Object:  Job [TransactionLogBackupMaintenance.Subplan_1]    Script Date: 06/08/2015 05:26:15 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 06/08/2015 05:26:15 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'TransactionLogBackupMaintenance.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 06/08/2015 05:26:15 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\TransactionLogBackupMaintenance" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'TransactionLogBackupMaintenance', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'578d5b23-3839-4ff3-95c3-2d10f8843baf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_maintplan_update_subplan
@subplan_id = '{1615D6D1-A88A-4987-B95E-52AA696A729B}',
@plan_id = '{77F6B63F-774E-4BC3-AE31-19A4CB694DEF}',
@name = 'TransactionLogBackupMaintenance',
@description = 'TransactionLogBackupMaintenance',
@job_id = @jobId,
@allow_create = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



USE master
GO
sp_configure 'show advanced options', 1;
GO
reconfigure
GO
/**********************************************/
/*Enable Backup Compression*/
USE master
GO
sp_configure 'backup compression default',1
GO
reconfigure
GO
/**********************************************/
/*Configure to use 75% of Server Memory*/
DECLARE @S_Mem INT
SELECT @S_Mem = (SELECT total_physical_memory_kb/1024 FROM sys.dm_os_sys_memory) * 0.75
BEGIN
EXEC sp_configure 'max server memory (MB)',@S_Mem
reconfigure
END
GO
/**********************************************/
/*Configure Remote Query Timeout*/
sp_configure 'remote query timeout (s)',0
GO
reconfigure
GO
/**********************************************/
/*Configure Remote admin connection*/
sp_configure 'remote admin connections', 1
GO
reconfigure
GO

/**********************************************/
/*Configure MAXDOP based on # of processors*/
DECLARE @T_CPU INT 
DECLARE @S_CPU INT
SELECT @T_CPU = (SELECT cpu_count FROM sys.dm_os_sys_info)


IF @T_CPU > 4
BEGIN
	SET @S_CPU = @T_CPU / 2
	IF @S_CPU <= 8
		EXEC sp_configure 'max degree of parallelism', @S_CPU
	ELSE
		EXEC sp_configure 'max degree of parallelism', 8
END



/*Configure xp_cmdshell*/
USE master
GO
sp_configure 'xp_cmdshell',1
GO
reconfigure
GO
/**********************************************/
/*Grant access to CMDB auto discovery account*/
/***************Atl**************/
IF NOT Exists (select * from sys.syslogins where loginname = 'JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe')
BEGIN
CREATE LOGIN [JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe] FROM WINDOWS 
END
GO

/**********************************************/


/*Configure Error Log to 45 files*/
EXEC master.sys.xp_instance_regwrite
    N'HKEY_LOCAL_MACHINE',
    N'Software\Microsoft\MSSQLServer\MSSQLServer',
    N'NumErrorLogs',
	N'REG_DWORD',
    45
GO
/**********************************************/





/**********************************************/
/*Configure TempDB Data and LogFiles*/
DECLARE @rc int
DECLARE @TDB_Size_Source INT,@TDB_Size INT,@STDB_Size INT, @CMD NVARCHAR(4000), @CMD_2 NVARCHAR(4000), @CMD_3 NVARCHAR(4000), @i INT, @Loc VARCHAR(1000), @T_CPU INT
CREATE TABLE #output (id int identity(1,1), disksize nvarchar(255) null)
insert #output (disksize) exec @rc = master..xp_cmdshell 'powershell.exe -file "C:\IQOQ\sddc_sql2008_TempDBDiskSpace.ps1" -nologo'
--insert #output (disksize) exec @rc = master..xp_cmdshell 'powershell.exe -file "C:\Jay\sddc_sql2008_TempDBDiskSpace.ps1" -nologo'
-- DECLARE @TDB_Size_Source INT,@TDB_Size INT,@STDB_Size INT, @CMD NVARCHAR(4000), @CMD_2 NVARCHAR(4000), @CMD_3 NVARCHAR(4000), @i INT, @Loc VARCHAR(1000), @T_CPU INT
SELECT @Loc = (SELECT SUBSTRING(physical_name,0,CHARINDEX('\tempdb.mdf',physical_name)+1) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' AND file_id = 1)

SELECT @TDB_Size_Source = (select disksize from #output where disksize is not null)

/*
SELECT @TDB_Size_Source = (SELECT (((total_bytes/1024)/1024)/1024)
					FROM sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)
*/				

SELECT @T_CPU = (SELECT cpu_count FROM sys.dm_os_sys_info)
IF @TDB_Size_Source < 10
BEGIN

SELECT @TDB_Size = (select disksize from #output where disksize is not null)

/*
(SELECT 
						(total_bytes/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)

*/

SET @STDB_Size = @TDB_Size * 0.10 * 1024

IF @T_CPU = 1
BEGIN

	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + ''',
			SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_Size)+'MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
END
IF @TDB_Size_Source >= 10
BEGIN
SELECT @TDB_Size = (select disksize from #output where disksize is not null)

/*
(SELECT 
						((total_bytes/1024)/1024)/1024
					FROM 
						sys.master_files AS f
						CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
					WHERE
						DB_NAME(f.database_id) = 'tempdb'
						AND f.FILE_ID = 1)

*/

IF (@TDB_Size * 0.10) <= 10
	SET @STDB_Size = @TDB_Size * 0.10
ELSE
	SET @STDB_Size = 10

IF @T_CPU = 1
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	print @CMD
	EXEC sp_executesql @CMD
END
IF (@T_CPU > 1) AND (@T_CPU <= 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= @T_CPU
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END
IF (@T_CPU > 8)
BEGIN
	SET @CMD = '
	ALTER DATABASE tempdb
	MODIFY FILE 
	(
		NAME = tempdev,
		SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
		MAXSIZE = UNLIMITED,
		FILEGROWTH = 2GB
	)'
	EXEC sp_executesql @CMD
	SET @i = 2
	WHILE @i <= 8
	BEGIN
		SET @CMD_2 = '
		ALTER DATABASE tempdb
		ADD FILE 
		(
			NAME = tempdev_' + CONVERT(VARCHAR,@i) + ',
			FILENAME = ''' + @Loc + 'tempdb_'+ CONVERT(VARCHAR,@i) + '.ndf'',
			SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
			MAXSIZE = UNLIMITED,
			FILEGROWTH = 2GB
		)'
		EXEC sp_executesql @CMD_2
		SET @i = @i + 1
	END
END

SET @CMD_3 = '
ALTER DATABASE tempdb
MODIFY FILE 
(
	NAME = templog,
	SIZE = '+ CONVERT(varchar,@STDB_Size)+'GB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 1GB
)'
EXEC sp_executesql @CMD_3
DROP TABLE #output
END

/*********End TempDB*************************************/







