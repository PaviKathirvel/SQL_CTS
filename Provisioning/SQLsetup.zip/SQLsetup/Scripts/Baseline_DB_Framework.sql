-- Version 1 : Deployed as of March 2019 
-- Fixed PerformanceCOunter Null value issue
-- Changed the DB conetxt to Baseline for sp_whoisactive
-- Changed Decimal to float datatype for TabPerformance stored procedure 



--------------================ 1. DB CReation ============-----------------

USE [master]
GO


CREATE DATABASE [Baseline] 
GO
ALTER DATABASE [Baseline] MODIFY FILE ( NAME = N'Baseline', SIZE = 2048000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 524288KB )
GO
ALTER DATABASE [Baseline] MODIFY FILE ( NAME = N'Baseline_log', SIZE = 1024000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
GO



IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Baseline].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [Baseline] SET ANSI_NULL_DEFAULT ON 
GO

ALTER DATABASE [Baseline] SET ANSI_NULLS ON 
GO

ALTER DATABASE [Baseline] SET ANSI_PADDING ON 
GO

ALTER DATABASE [Baseline] SET ANSI_WARNINGS ON 
GO

ALTER DATABASE [Baseline] SET ARITHABORT ON 
GO

ALTER DATABASE [Baseline] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [Baseline] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [Baseline] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [Baseline] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [Baseline] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [Baseline] SET CONCAT_NULL_YIELDS_NULL ON 
GO

ALTER DATABASE [Baseline] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [Baseline] SET QUOTED_IDENTIFIER ON 
GO

ALTER DATABASE [Baseline] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [Baseline] SET  DISABLE_BROKER 
GO

ALTER DATABASE [Baseline] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [Baseline] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [Baseline] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [Baseline] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [Baseline] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [Baseline] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [Baseline] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [Baseline] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [Baseline] SET  MULTI_USER 
GO

ALTER DATABASE [Baseline] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [Baseline] SET DB_CHAINING OFF 
GO

ALTER DATABASE [Baseline] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [Baseline] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO


ALTER DATABASE [Baseline] SET  READ_WRITE 
GO


-------------------------======================2. CREATEOBJECTS===================---------------------

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Sessionstatus]') AND type in (N'U'))
              BEGIN
                     DROP TABLE dbo.[Sessionstatus]
                     PRINT 'Table Sessionstatus exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping table'
              END

IF NOT EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[Sessionstatus]') AND TYPE IN (N'U'))
BEGIN
CREATE TABLE [dbo].[Sessionstatus](
       [DateCaptured] [datetime] NULL,
       [dbname] [nvarchar](100) NULL,
       [status] [nvarchar](50) NULL,
       [waittype] [nvarchar](100) NULL,
       [waittime] [bigint] NULL,
       [sessioncnt] [int] NULL,
       [opentran] [int] NULL
) ON [PRIMARY]
PRINT 'Table Sessionstatus created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100))
END
GO


DECLARE @is2008 bit

BEGIN TRY
       IF((SELECT CAST(REPLACE(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS varchar(10)),2),'.','') AS int)) = 10)
              SET @is2008 = 1
       ELSE 
              SET @is2008 = 0

       IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PerformanceCounterList]') AND type in (N'U'))
              BEGIN
                     DROP TABLE [PerformanceCounterList]
                     PRINT 'Table PerformanceCounterList exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping table'
              END

       IF NOT EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[PerformanceCounterList]') AND TYPE IN (N'U'))
              BEGIN
                     CREATE TABLE [PerformanceCounterList](
                           [counter_name] [VARCHAR](500) NOT NULL,
                           [is_captured_ind] [BIT] NOT NULL,
                     CONSTRAINT [PK_PerformanceCounterList] PRIMARY KEY CLUSTERED 
                     (
                           [counter_name] ASC
                     )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 100) ON [PRIMARY]
                     ) ON [PRIMARY]
                     
                     ALTER TABLE [PerformanceCounterList] ADD  CONSTRAINT [DF_PerformanceCounterList_is_captured_ind]  DEFAULT ((1)) FOR [is_captured_ind]
                     
                     PRINT 'Table PerformanceCounterList created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100))
              END

       IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PerformanceCounter]') AND type in (N'U'))
              BEGIN
                     DROP TABLE [PerformanceCounter]
                     PRINT 'Table PerformanceCounter exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping table'
              END

       IF NOT EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[PerformanceCounter]') AND TYPE IN (N'U'))
              BEGIN
                     CREATE TABLE [PerformanceCounter](
                           [CounterName] [VARCHAR](250) NOT NULL,
                           [CounterValue] [VARCHAR](250) NULL,
                           [DateSampled] [DATETIME] NOT NULL,
                     CONSTRAINT [PK_PerformanceCounter] PRIMARY KEY CLUSTERED 
                     (
                           [CounterName] ASC,
                           [DateSampled] ASC
                     )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
                     ) ON [PRIMARY]
                     
                     PRINT 'Table PerformanceCounter created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100))
              END


       SET NOCOUNT ON

       DECLARE @perfStr VARCHAR(100)
       DECLARE @instStr VARCHAR(100)

       SELECT @instStr = @@SERVICENAME
       --SET @instStr = 'NI1'

       IF(@instStr = 'MSSQLSERVER')
              SET @perfStr = '\SQLServer'
       ELSE 
              SET @perfStr = '\MSSQL$' + @instStr

       TRUNCATE TABLE PerformanceCounterList
       PRINT 'Truncated table PerformanceCounterList'

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Memory\Pages/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Memory\Pages Input/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Memory\Available MBytes',1)
              
       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Processor(_Total)\% Processor Time',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Processor(_Total)\% Privileged Time',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Process(sqlservr)\% Privileged Time',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Process(sqlservr)\% Processor Time',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Paging File(_Total)\% Usage',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Paging File(_Total)\% Usage Peak',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\PhysicalDisk(_Total)\Avg. Disk sec/Read',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\PhysicalDisk(_Total)\Avg. Disk sec/Write',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\PhysicalDisk(_Total)\Disk Reads/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\PhysicalDisk(_Total)\Disk Writes/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\System\Processor Queue Length',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\System\Context Switches/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Page life expectancy',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Buffer cache hit ratio',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Checkpoint Pages/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Lazy Writes/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Page Reads/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Page Writes/Sec',1)

       IF (@is2008 = 1)
              INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
              VALUES        (@perfStr + ':Buffer Manager\Free Pages',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Page Lookups/Sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Free List Stalls/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Readahead pages/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Database Pages',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Target Pages',0)
                     
       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Total Pages',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Buffer Manager\Stolen Pages',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\User Connections',1)
                     
       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\Processes blocked',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\Logins/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\Logouts/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Memory Grants Pending',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Total Server Memory (KB)',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Target Server Memory (KB)',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Granted Workspace Memory (KB)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Maximum Workspace Memory (KB)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Memory Manager\Memory Grants Outstanding',1)

	   ------ added newly @2019 July -----------

	   INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Memory Manager\Connection Memory (KB)',1)

	   INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Memory Manager\Stolen Server Memory (KB)',1)

	   INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Memory Manager\SQL Cache Memory (KB)',1)

	   INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Memory Manager\Optimizer Memory (KB)',1)

	   -----------------------------------------

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':SQL Statistics\Batch Requests/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':SQL Statistics\SQL Compilations/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':SQL Statistics\SQL Re-Compilations/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':SQL Statistics\Auto-Param Attempts/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Lock Waits/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Lock Requests/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Lock Timeouts/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Number of Deadlocks/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Lock Wait Time (ms)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Locks(_Total)\Average Wait Time (ms)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Latches\Total Latch Wait Time (ms)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Latches\Latch Waits/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Latches\Average Latch Wait Time (ms)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Forwarded Records/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Full Scans/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Page Splits/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Index Searches/Sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Workfiles Created/Sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Worktables Created/Sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Access Methods\Table Lock Escalations/sec',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Cursor Manager by Type(_Total)\Active cursors',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Transactions\Longest Transaction Running Time',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Transactions\Free Space in tempdb (KB)',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':Transactions\Version Store Size (KB)',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Avg. Disk Queue Length',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Avg. Disk sec/Read',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Avg. Disk sec/Transfer',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Avg. Disk sec/Write',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Current Disk Queue Length',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Paging File(*)\*',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Network Interface(*)\Bytes Total/Sec',1) 

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Disk Bytes/sec',1)


       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\LogicalDisk(*)\Disk Transfers/sec',1)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\Temp Tables Creation Rate',1)


       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES (@perfStr + ':General Statistics\Temp Tables for Destruction',1)

	   
       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        ('\Process(sqlservr)\% User Time',1)


       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Databases(*)\Active Transactions',0)

       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Databases(*)\Log File(s) Used size (KB)',0)


       INSERT INTO PerformanceCounterList(counter_name,is_captured_ind)
       VALUES        (@perfStr + ':Databases(*)\Transactions/sec',0)


	 
       PRINT 'Inserts to table PerformanceCounterList completed'

       IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ClearPerfCtrHistory]') AND type in (N'P', N'PC'))
              BEGIN
                     DROP PROCEDURE [ClearPerfCtrHistory]
   PRINT 'Stored Procedure ClearPerfCtrHistory exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + 'dropping stored procedure'
              END

       IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ClearPerfCtrHistory]') AND type in (N'P', N'PC'))
              BEGIN
                     EXEC dbo.sp_executesql @statement = N'

                     CREATE PROCEDURE [ClearPerfCtrHistory]
                           @old_date     INT = 90
                     AS

                     SET NOCOUNT ON
                     SET XACT_ABORT ON

                     BEGIN TRY

                           IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[PerformanceCounter]'') AND type in (N''U''))
                                  BEGIN
                                         DELETE dbo.PerformanceCounter 
                                         WHERE DateSampled < DATEADD(dd,-@old_date, dateadd(dd, datediff(dd,0, GETDATE()),0))
                                  END

                     END TRY
                     BEGIN CATCH

                           IF (XACT_STATE()) != 0
                                  ROLLBACK TRANSACTION;
                            
                           DECLARE @errMessage varchar(MAX)
                           SET @errMessage = ''Stored procedure '' + OBJECT_NAME(@@PROCID) + '' failed with error '' + CAST(ERROR_NUMBER() AS VARCHAR(20)) + ''. '' + ERROR_MESSAGE() 
                           RAISERROR (@errMessage, 16, 1)
                                  
                     END CATCH
                     '
                     PRINT 'Stored procedure ClearPerfCtrHistory created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) 
              END
END TRY
BEGIN CATCH
       DECLARE @errMessage varchar(MAX) = ERROR_MESSAGE()
       PRINT @errMessage
       
       IF EXISTS(SELECT 1 FROM master.sys.databases WHERE name = 'Baseline')
              AND EXISTS (SELECT 1 FROM Baseline.sys.objects WHERE name = N'install_usp_logevent' AND type in (N'P', N'PC'))
                     BEGIN
                           EXEC [Baseline].[dbo].[install_usp_logevent] @errMessage
                     END
END CATCH

GO



/****** Object:  StoredProcedure [dbo].[spLoadSessionStatus]     ******/

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[spLoadSessionStatus]') AND type in (N'P', N'PC'))
              BEGIN
                     DROP PROCEDURE dbo.[spLoadSessionStatus]
                     PRINT 'Procedure spLoadSessionStatus exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping table'
              END;
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[spLoadSessionStatus]') AND type in (N'P', N'PC'))
			BEGIN
				EXEC dbo.sp_executesql @statement = N'CREATE PROC [dbo].[spLoadSessionStatus] 
				AS
				BEGIN
				delete from dbo.Sessionstatus where DateCaptured < DATEADD(dd,-5,getdate());
				INSERT INTO dbo.Sessionstatus
				SELECT Getdate() as "Date Captured", DB_NAME(database_id) as "Database Name" ,status,wait_type,SUM(wait_time) as [Wait in ms],COUNT(r.session_id) as [Session Count],SUM(open_transaction_count) as [Open Transactions]
				from  sys.dm_exec_requests r  
				where 
				r.blocking_session_id = 0 and r.status NOT IN (''suspended'',''background'') 
				group by status,DB_NAME(database_id),wait_type

				UNION ALL

				SELECT Getdate() as "Date Captured", DB_NAME(database_id) as "Database Name" ,status,wait_type, SUM(wait_time) as [Wait in ms], COUNT(r.session_id) as [Session Count],SUM(open_transaction_count) as [Open Transactions]
				from  sys.dm_exec_requests r  
				where 
				r.blocking_session_id = 0 and r.status = ''suspended''
				group by status,DB_NAME(database_id),wait_type

				UNION ALL

				SELECT Getdate() as "Date Captured", DB_NAME(database_id) as "Database Name",''blocked'',wait_type, SUM(wait_time) as [Wait in ms],COUNT(r.session_id) as [Session Count],SUM(open_transaction_count) as [Open Transactions]
				from  sys.dm_exec_requests r  
				where 
				-- r.session_id > 50 and 
				r.blocking_session_id <> 0
				GROUP BY DB_NAME(database_id),wait_type

				UNION ALL

				SELECT Getdate() as "Date Captured", DB_NAME(database_id) as "Database Name",s.status,s.lastwaittype , SUM(s.waittime) as [Wait in ms],COUNT(s.spid) as [Session Count],SUM(s.open_tran) as [Open Transactions]
				from  sys.sysprocesses s  left join sys.dm_exec_requests r
				on s.spid = r.session_id
				where 
				r.session_id is NULL 
				GROUP BY DB_NAME(database_id),s.status,s.lastwaittype
				END';
			PRINT 'Procedure spLoadSessionStatus created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping table'
		END
GO

 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[spGetPerfCountersFromPowerShell]') AND type in (N'P', N'PC'))
              BEGIN
                     DROP PROCEDURE dbo.[spGetPerfCountersFromPowerShell]
                     PRINT 'Procedure spGetPerfCountersFromPowerShell exists on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' dropping procedure'
              END;
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[spGetPerfCountersFromPowerShell]') AND type in (N'P', N'PC'))
			BEGIN
				EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[spGetPerfCountersFromPowerShell]
AS
BEGIN
DECLARE @syscounters NVARCHAR(4000)
SET @syscounters=STUFF((SELECT DISTINCT '''''','''''' +LTRIM([counter_name])
FROM [Baseline].[dbo].[PerformanceCounterList]
WHERE [is_captured_ind] = 1 FOR XML PATH('''')), 1, 2, '''')+'''''''' 

DECLARE @cmd NVARCHAR(4000)
DECLARE @syscountertable TABLE (id INT IDENTITY(1,1), [output] VARCHAR(500))
DECLARE @syscountervaluestable TABLE (id INT IDENTITY(1,1), [value] VARCHAR(500))

SET @cmd = ''C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe "& get-counter -counter ''+ @syscounters +'' | Select-Object -ExpandProperty Readings"''
INSERT @syscountertable
EXEC master..xp_cmdshell @cmd

declare @sqlnamedinstance sysname
declare @networkname sysname
if (select CHARINDEX(''\'',@@SERVERNAME)) = 0
	begin
	INSERT [Baseline].[dbo].[PerformanceCounter] (CounterName, CounterValue, DateSampled)
	SELECT  REPLACE(REPLACE(REPLACE(ct.[output],''\\''+@@SERVERNAME+''\'',''''),'' :'',''''),''sqlserver:'','''')[CounterName] , CONVERT(varchar(20),ct2.[output]) [CounterValue], GETDATE() [DateSampled]
	FROM @syscountertable ct
	LEFT OUTER JOIN (
	SELECT id - 1 [id], [output]
	FROM @syscountertable
	WHERE PATINDEX(''%[0-9]%'', LEFT([output],1)) > 0  
	) ct2 ON ct.id = ct2.id
	WHERE  ct.[output] LIKE ''\\%''
	ORDER BY [CounterName] ASC
	end

	else
	begin
	select @networkname=RTRIM(left(@@SERVERNAME, CHARINDEX(''\'', @@SERVERNAME) - 1))
	select @sqlnamedinstance=RIGHT(@@SERVERNAME,CHARINDEX(''\'',REVERSE(@@SERVERNAME))-1)
	INSERT [Baseline].[dbo].[PerformanceCounter] (CounterName, CounterValue, DateSampled)
	SELECT  REPLACE(REPLACE(REPLACE(ct.[output],''\\''+@networkname+''\'',''''),'' :'',''''),''mssql$''+@sqlnamedinstance+'':'','''')[CounterName] , CONVERT(varchar(20),ct2.[output]) [CounterValue], GETDATE() [DateSampled]
	FROM @syscountertable ct
	LEFT OUTER JOIN (
	SELECT id - 1 [id], [output]
	FROM @syscountertable
	WHERE PATINDEX(''%[0-9]%'', LEFT([output],1)) > 0  
	) ct2 ON ct.id = ct2.id
	WHERE  ct.[output] LIKE ''\\%''
	ORDER BY [CounterName] ASC
	END
END';
PRINT 'Procedure spGetPerfCountersFromPowerShell created on server ' + CAST(SERVERPROPERTY('ServerName') AS VARCHAR(100)) + ' '
		END
GO


---------------------------=====================3.CreateSystemHealthDBASchema=================--------------------


/****** Object:  StoredProcedure [dbo].[sp_ImportXML]   ******/
use [Baseline]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[sp_ImportXML]
@path_to_health_session nvarchar(4000)
as
If object_id('tbl_XEImport') is not null
	drop table tbl_XEImport
select [object_name] ,CAST(event_data AS XML)  as c1
into tbl_XEImport
from sys.fn_xe_file_target_read_file(@path_to_health_session,NULL,NULL,NULL)

create index ind_xeImport on tbl_XEImport(object_name)

If object_id('tbl_ServerDiagnostics') is not null
	drop table tbl_ServerDiagnostics
	select c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') as SdComponent,c1  
	into tbl_ServerDiagnostics
	from tbl_XEImport
	where object_name = 'sp_server_diagnostics_component_result'
/*
else
select c1.value('(event/data[@name="component"]/value)[1]', 'varchar(100)') as SdComponent,c1  
	into tbl_ServerDiagnostics
	from tbl_XEImport 
	where object_name = 'component_health_result'
*/
--create index ind_ServerDiagnostics on tbl_ServerDiagnostics(SdComponent)

GO
/****** Object:  StoredProcedure [dbo].[SpLoadComponentSummary]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadComponentSummary]
@UTDDateDiff int
as
if object_id('tbl_Summary') is not null
drop table tbl_Summary
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as timestamp,
	 c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') as component_name,
	 c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') as [component_state]
/*
     CASE c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)')
		WHEN '' then  c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)')
		ELSE c1.value('(event/data[@name="component"]/value)[1]', 'varchar(100)')
	 END as component_name,
	 CASE c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') 
	   WHEN '' then c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') 
	   ELSE c1.value('(event/data[@name="state_desc"]/value)[1]', 'varchar(100)') 
	  END as [component_state]
*/
into tbl_Summary
FROM tbl_ServerDiagnostics 

CREATE NONCLUSTERED INDEX [Ind_TblSummary] ON [dbo].[tbl_Summary]
(
	[timestamp] ASC
)WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PRIMARY]


GO
/****** Object:  StoredProcedure [dbo].[spLoadConnectivity_ring_buffer]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[spLoadConnectivity_ring_buffer]
@UTDDateDiff int
as
if object_id('tbl_connectivity_ring_buffer') is not null
drop table tbl_connectivity_ring_buffer

  select 
   c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
  	DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
              c1.value('(./event/data[@name="type"]/text)[1]', 'varchar(100)') AS [Type],
              c1.value('(./event/data[@name="id"]/value)[1]', 'bigint') as record_id,
			  c1.value('(./event/data[@name="source"]/text)[1]', 'varchar(20)') as source,
			  c1.value('(./event/data[@name="session_id"]/value)[1]', 'int') as session_id,
			  c1.value('(./event/data[@name="os_error"]/value)[1]', 'bigint') as os_error,
			  c1.value('(./event/data[@name="sni_error"]/value)[1]', 'bigint') as sni_error,
			  c1.value('(./event/data[@name="sni_consumer_error"]/value)[1]', 'bigint') as sni_consumer_error,
			  c1.value('(./event/data[@name="state"]/value)[1]', 'int') as [state],
			  c1.value('(./event/data[@name="port"]/value)[1]', 'int') as port,
			  c1.value('(./event/data[@name="remote_port"]/value)[1]', 'int') as remote_port,
			  c1.value('(./event/data[@name="tds_input_buffer_error"]/value)[1]', 'bigint') as tds_inputbuffererror,
			  c1.value('(./event/data[@name="total_login_time_ms"]/value)[1]', 'bigint') as total_login_time_ms,
			  c1.value('(./event/data[@name="login_task_enqueued_ms"]/value)[1]', 'bigint') as login_task_enqueued_ms,
			  c1.value('(./event/data[@name="network_writes_ms"]/value)[1]', 'bigint') as network_writes_ms,
			  c1.value('(./event/data[@name="network_reads_ms"]/value)[1]', 'bigint') as network_reads_ms,
			  c1.value('(./event/data[@name="ssl_processing_ms"]/value)[1]', 'bigint') as ssl_processing_ms,
			  c1.value('(./event/data[@name="sspi_processing_ms"]/value)[1]', 'bigint') as sspi_processing_ms,
			  c1.value('(./event/data[@name="login_trigger_and_resource_governor_processing_ms"]/value)[1]', 'bigint') as login_trigger_and_resource_governor_processing_ms,
			  c1.value('(./event/data[@name="connection_id"]/value)[1]', 'varchar(50)') as connection_id,
			  c1.value('(./event/data[@name="connection_peer_id"]/value)[1]', 'varchar(50)') as connection_peer_id,
			  c1.value('(./event/data[@name="local_host"]/value)[1]', 'varchar (50)') as local_host,
			  c1.value('(./event/data[@name="remote_host"]/value)[1]', 'varchar (50)') as remote_host,
			  c1.value('(./event/data[@name="SessionIsKilled"]/value)[1]', 'smallint') as SessionIsKilled
	into tbl_connectivity_ring_buffer
	from tbl_XEImport where  object_name =  'connectivity_ring_buffer_recorded'              

GO
/****** Object:  StoredProcedure [dbo].[SpLoadErrorRecorded]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadErrorRecorded]
@UTDDateDiff int
as
if object_id('tbl_errors') is not null
drop table tbl_errors
select 
			c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
			DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
			c1.value('(./event/data[@name="session_id"])[1]', 'int') as session_id,
			c1.value('(./event/data[@name="database_id"])[1]', 'int') as database_id,
			c1.value('(./event/data[@name="error_number"])[1]', 'int') as [error_number],
			c1.value('(./event/data[@name="severity"])[1]', 'int') as severity,
			c1.value('(./event/data[@name="state"])[1]', 'int') as [state],
			c1.value('(./event/data[@name="category"]/text)[1]', 'nvarchar(100)') as category,
			c1.value('(./event/data[@name="destination"]/text)[1]', 'nvarchar(100)') as destination,
			c1.value('(./event/data[@name="message"])[1]', 'nvarchar(1000)') as message

into tbl_errors		
from tbl_XEImport
where object_name like 'error_reported'
GO

/****** Object:  StoredProcedure [dbo].[SpLoadIO_SUBSYSTEMComponent]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadIO_SUBSYSTEMComponent]
@UTDDateDiff int
as
if object_id('tbl_IO_SUBSYSTEM') is not null
drop table tbl_IO_SUBSYSTEM
select 
     c1.value('(./event/@timestamp)[1]', 'datetime') as UTCtimestamp,
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as timestamp,
     c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') as [component_name],
	 c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') as [component_state],
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/@ioLatchTimeouts)[1]','int') as [ioLatchTimeouts],
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/@intervalLongIos)[1]','int') as [intervalLongIos],
 	 c1.value('(event/data[@name="data"]/value/ioSubsystem/@totalLongIos)[1]','int') as [totalLongIos],	 
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/longestPendingRequests/pendingRequest[1]/@duration)[1]','bigint') as [longestPendingRequests_duration],
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/longestPendingRequests/pendingRequest[1]/@filePath)[1]','nvarchar(500)') as [longestPendingRequests_filePath],
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/longestPendingRequests/pendingRequest[1]/@offset)[1]','bigint') as [longestPendingRequests_offset],
	 c1.value('(event/data[@name="data"]/value/ioSubsystem/longestPendingRequests/pendingRequest[1]/@handle)[1]','nvarchar(20)') as [longestPendingRequests_handle]
into tbl_IO_SUBSYSTEM
FROM tbl_ServerDiagnostics 
where SdComponent = 'IO_SUBSYSTEM'

GO
/****** Object:  StoredProcedure [dbo].[SpLoadQueryProcessing]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadQueryProcessing]
@UTDDateDiff int
as
if object_id('tbl_QUERY_PROCESSING') is not null
drop table [tbl_QUERY_PROCESSING]
select 
			c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
			DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
			 c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') as [component_name],
			c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') as [component_state],
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@maxWorkers)[1]', 'int') as maxworkers,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@workersCreated)[1]', 'int') as workerscreated,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@workersIdle)[1]', 'int') as workersIdle, -- ADDED
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@tasksCompletedWithinInterval)[1]', 'int') as tasksCompletedWithinInterval,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@oldestPendingTaskWaitingTime)[1]', 'bigint') as oldestPendingTaskWaitingTime,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@pendingTasks)[1]', 'int') as pendingTasks,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@hasUnresolvableDeadlockOccurred)[1]', 'int') as hasUnresolvableDeadlockOccurred,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@hasDeadlockedSchedulersOccurred)[1]', 'int') as hasDeadlockedSchedulersOccurred,
			c1.value('(./event//data[@name="data"]/value/queryProcessing/@trackingNonYieldingScheduler)[1]', 'varchar(10)') as trackingNonYieldingScheduler
into [tbl_QUERY_PROCESSING]			
from tblQryProcessingXmlOutput

GO
/****** Object:  StoredProcedure [dbo].[SpLoadQueryProcessingComponent]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadQueryProcessingComponent]
@UTDDateDiff int
as
-- Import the XML
If object_id('tblQryProcessingXmlOutput') is not null
	drop table tblQryProcessingXmlOutput
CREATE TABLE [dbo].[tblQryProcessingXmlOutput](
	[c1] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

insert into tblQryProcessingXmlOutput (c1)
select c1 as snodes 
FROM tbl_ServerDiagnostics 
where SdComponent = 'QUERY_PROCESSING'
	
	
-- Call individual Pieces
exec SpLoadQueryProcessingComponent_TopWaits @UTDDateDiff
exec SpLoadQueryProcessing @UTDDateDiff
exec SpLoadQueryProcessingComponent_Blocking @UTDDateDiff
--exec SpLoadQueryProcessingComponent_HighCPU @UTDDateDiff
--exec SpLoadQueryProcessingComponent_QueryWaits @UTDDateDiff

GO
/****** Object:  StoredProcedure [dbo].[SpLoadQueryProcessingComponent_Blocking]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadQueryProcessingComponent_Blocking]
@UTDDateDiff int
as
if object_id('tbl_BlockingXeOutput') is not null
drop table tbl_BlockingXeOutput
select
	 [utctimestamp],[timestamp],
	 c1.value('(blocked-process-report/blocking-process/process/inputbuf)[1]', 'nvarchar(max)') as [blocking_process],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@spid)[1]', 'int') as [blocking_process_id],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@ecid)[1]', 'int') as [blocking_process_ecid],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@status)[1]', 'varchar(100)') as [blocking_process_status],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@isolationlevel)[1]', 'varchar(200)') as [blocking_process_isolationlevel],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@lastbatchstarted)[1]', 'datetime') as [blocking_process_lastbatchstarted],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@lastbatchcompleted)[1]', 'datetime') as [blocking_process_lastbatchcompleted],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@lastattention)[1]', 'datetime') as [blocking_process_lastattention],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@trancount)[1]', 'int') as [blocking_process_trancount],
	 c1.value('(blocked-process-report/blocking-process/process[1]/@xactid)[1]', 'bigint') as [blocking_process_xactid],
	 c1.value('(/blocked-process-report/blocking-process/process[1]/@clientapp)[1]', 'nvarchar(100)') as [blocking_process_clientapp],
	 c1.value('(/blocked-process-report/blocking-process/process[1]/@hostname)[1]', 'nvarchar(100)') as [blocking_process_hostname],
	 c1.value('(/blocked-process-report/blocking-process/process[1]/@loginname)[1]', 'nvarchar(100)') as [blocking_process_loginname],
	 c1.value('(/blocked-process-report/blocking-process/process[1]/@waitresource)[1]', 'nvarchar(200)') as [blocking_process_wait_resource],

	 c1.value('(/blocked-process-report/blocked-process/process/inputbuf)[1]', 'nvarchar(max)') as [blocked_process],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@spid)[1]', 'int') as [blocked_process_id],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@ecid)[1]', 'int') as [blocked_process_ecid],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@status)[1]', 'varchar(100)') as [blocked_process_status],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@waitresource)[1]', 'nvarchar(200)') as [blocked_process_wait_resource],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@lockMode)[1]', 'char(5)') as [blocked_process_lockMode],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@waittime)[1]', 'nvarchar(200)') as [blocked_process_wait_time],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@lastbatchstarted)[1]', 'datetime') as [blocked_process_lastbatchstarted],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@lastbatchcompleted)[1]', 'datetime') as [blocked_process_lastbatchcompleted],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@lastattention)[1]', 'datetime') as [blocked_process_lastattention],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@clientapp)[1]', 'nvarchar(100)') as [blocked_process_clientapp],
	 c1.value('(/value/blocked-process-report/blocked-process/process[1]/@hostname)[1]', 'nvarchar(100)') as [blocked_process_hostname],
	 c1.value('(/blocked-process-report/blocked-process/process[1]/@loginname)[1]', 'nvarchar(100)') as [blocked_process_loginname]
	 --T.bpnodes.value('(event/data[@name="blocked_process"]/value/blocked-process-report/blocking-process/process/executionstack/frame[1]/@sqlhandle)[1]', 'nvarchar(max)') as [blocking_process_sqlhandle]
into tbl_BlockingXeOutput
FROM 
(
select c1.value('(event/@timestamp)[1]','datetime') as [utctimestamp]
		,DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp]
		,T.blk.query( '.') as c1 from tblQryProcessingXmlOutput
CROSS APPLY c1.nodes('./event/data[@name="data"]/value/queryProcessing/blockingTasks/blocked-process-report') as T(blk) 
) as T1

GO
/****** Object:  StoredProcedure [dbo].[SpLoadQueryProcessingComponent_TopWaits]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadQueryProcessingComponent_TopWaits]
@UTDDateDiff int
as
if object_id('tbl_OS_WAIT_STATS_byDuration') is not null
drop table tbl_OS_WAIT_STATS_byDuration

CREATE TABLE [dbo].[tbl_OS_WAIT_STATS_byDuration](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[wait_type] [varchar](47) NULL,
	[waiting_tasks_count] [bigint] NULL,
	[avg_wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL
) ON [PRIMARY]
ALTER TABLE [dbo].[tbl_OS_WAIT_STATS_byDuration] ADD [wait_category]  AS (case when [wait_type] like 'LCK%' then 'Locks' when [wait_type] like 'PAGEIO%' then 'Page I/O Latch' when [wait_type] like 'PAGELATCH%' then 'Page Latch (non-I/O)' when [wait_type] like 'LATCH%' then 'Latch (non-buffer)' when [wait_type] like 'IO_COMPLETION' then 'I/O Completion' when [wait_type] like 'ASYNC_NETWORK_IO' then 'Network I/O (client fetch)' when [wait_type]='CMEMTHREAD' OR [wait_type]='SOS_RESERVEDMEMBLOCKLIST' OR [wait_type]='RESOURCE_SEMAPHORE' then 'Memory' when [wait_type] like 'RESOURCE_SEMAPHORE_%' then 'Compilation' when [wait_type] like 'MSQL_XP' then 'XProc' when [wait_type] like 'WRITELOG' then 'Writelog' when [wait_type]='FT_IFTS_SCHEDULER_IDLE_WAIT' OR [wait_type]='WAITFOR' OR [wait_type]='EXECSYNC' OR [wait_type]='XE_TIMER_EVENT' OR [wait_type]='XE_DISPATCHER_WAIT' OR [wait_type]='WAITFOR_TASKSHUTDOWN' OR [wait_type]='WAIT_FOR_RESULTS' OR [wait_type]='SNI_HTTP_ACCEPT' OR [wait_type]='SLEEP_TEMPDBSTARTUP' OR [wait_type]='SLEEP_TASK' OR [wait_type]='SLEEP_SYSTEMTASK' OR [wait_type]='SLEEP_MSDBSTARTUP' OR [wait_type]='SLEEP_DCOMSTARTUP' OR [wait_type]='SLEEP_DBSTARTUP' OR [wait_type]='SLEEP_BPOOL_FLUSH' OR [wait_type]='SERVER_IDLE_CHECK' OR [wait_type]='RESOURCE_QUEUE' OR [wait_type]='REQUEST_FOR_DEADLOCK_SEARCH' OR [wait_type]='ONDEMAND_TASK_QUEUE' OR [wait_type]='LOGMGR_QUEUE' OR [wait_type]='LAZYWRITER_SLEEP' OR [wait_type]='KSOURCE_WAKEUP' OR [wait_type]='FSAGENT' OR [wait_type]='CLR_MANUAL_EVENT' OR [wait_type]='CLR_AUTO_EVENT' OR [wait_type]='CHKPT' OR [wait_type]='CHECKPOINT_QUEUE' OR [wait_type]='BROKER_TO_FLUSH' OR [wait_type]='BROKER_TASK_STOP' OR [wait_type]='BROKER_TRANSMITTER' OR [wait_type]='BROKER_RECEIVE_WAITFOR' OR [wait_type]='BROKER_EVENTHANDLER' OR [wait_type]='DBMIRROR_EVENTS_QUEUE' OR [wait_type]='DBMIRROR_DBM_EVENT' OR [wait_type]='DBMIRRORING_CMD' OR [wait_type]='DBMIRROR_WORKER_QUEUE' then 'IGNORABLE' else [wait_type] end)
Create clustered index [tbl_OS_WAIT_STATS_byDuration_Clus] on [tbl_OS_WAIT_STATS_byDuration](timestamp)


INSERT INTO [dbo].[tbl_OS_WAIT_STATS_byDuration]
           ([UTCtimestamp]
		    ,[timestamp]
           ,[wait_type]
           ,[waiting_tasks_count]
           ,[avg_wait_time_ms]
           ,[max_wait_time_ms])
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[1]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[1]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[1]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[1]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[2]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[2]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[2]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[2]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[3]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[3]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[3]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[3]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[4]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[4]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[4]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[4]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[5]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[5]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[5]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[5]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL 
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[6]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[6]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[6]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[6]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[7]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[7]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[7]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[7]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[8]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[8]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[8]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[8]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[9]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[9]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[9]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[9]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[10]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[10]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[10]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/nonPreemptive/byCount/wait[10]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput

UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[1]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[1]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[1]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[1]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[2]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[2]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[2]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[2]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[3]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[3]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[3]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[3]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[4]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[4]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[4]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[4]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[5]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[5]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[5]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[5]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL 
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[6]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[6]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[6]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[6]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[7]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[7]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[7]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[7]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[8]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[8]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[8]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[8]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[9]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[9]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[9]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[9]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput
UNION ALL
select 
     c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
     c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[10]/@waitType)[1]','varchar(47)') as [waitType],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[10]/@waits)[1]','bigint') as [waits],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[10]/@averageWaitTime)[1]','bigint') as [averageWaitTime],
	 c1.value('(event/data[@name="data"]/value/queryProcessing/topWaits/preemptive/byCount/wait[10]/@maxWaitTime)[1]','bigint') as [maxWaitTime]
FROM tblQryProcessingXmlOutput

GO
/****** Object:  StoredProcedure [dbo].[SpLoadResourceComponent]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadResourceComponent]
@UTDDateDiff int
as
if object_id('tbl_Resource') is not null
	drop table tbl_Resource
select 
			c1.value('(./event/@timestamp)[1]', 'datetime') as UTCtimestamp,
			DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
			c1.value('(./event//data[@name="state"]/text)[1]', 'varchar(20)') as State,
			c1.value('(./event//data[@name="data"]/value/resource/@lastNotification)[1]', 'nvarchar(100)') as lastNotification,
			c1.value('(./event//data[@name="data"]/value/resource/@outOfMemoryExceptions)[1]', 'tinyint') as outOfMemoryExceptions,
			c1.value('(./event//data[@name="data"]/value/resource/@isAnyPoolOutOfMemory)[1]', 'tinyint') as isAnyPoolOutOfMemory,
			c1.value('(./event//data[@name="data"]/value/resource/@processOutOfMemoryPeriod)[1]', 'tinyint') as processOutOfMemoryPeriod,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Available Physical Memory"]/@value)[1]', 'bigint') as available_physical_memory,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Available Virtual Memory"]/@value)[1]', 'bigint') as available_virtual_memory,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Available Paging File"]/@value)[1]', 'bigint') as available_paging_file,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Working Set"]/@value)[1]', 'bigint') as working_set,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Percent of Committed Memory in WS"]/@value)[1]', 'bigint') as percent_workingset_committed,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Page Faults"]/@value)[1]', 'bigint') as page_faults,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="System physical memory high"]/@value)[1]', 'bigint') as sys_physical_memory_high,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="System physical memory low"]/@value)[1]', 'bigint') as sys_physical_memory_low,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Process physical memory low"]/@value)[1]', 'bigint') as process_phyiscal_memory_low,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Process/System Counts"]/entry[@description="Process virtual memory low"]/@value)[1]', 'bigint') as process_virtual_memory_low,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="VM Reserved"]/@value)[1]', 'bigint') as vm_reserved_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="VM Committed"]/@value)[1]', 'bigint') as vm_committed_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Locked Pages Allocated"]/@value)[1]', 'bigint') as locked_pages_allocated_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Large Pages Allocated"]/@value)[1]', 'bigint') as large_pages_allocated_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Target Committed"]/@value)[1]', 'bigint') as target_committed_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Current Committed"]/@value)[1]', 'bigint') as current_committed_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Pages Allocated"]/@value)[1]', 'bigint') as Pages_allocated_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Pages Reserved"]/@value)[1]', 'bigint') as pages_reserved_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Pages Free"]/@value)[1]', 'bigint') as pages_free_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Pages In Use"]/@value)[1]', 'bigint') as pages_in_use_kb,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Page Alloc Potential"]/@value)[1]', 'bigint') as page_alloc_potential,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="NUMA Growth Phase"]/@value)[1]', 'int') as numa_growth_phase,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Last OOM Factor"]/@value)[1]', 'int') as last_oom_factor,
			c1.value('(./event//data[@name="data"]/value/resource/memoryReport[@name="Memory Manager"]/entry[@description="Last OS Error"]/@value)[1]', 'int') as last_os_error
into tbl_Resource
FROM  tbl_ServerDiagnostics
where SdComponent = 'RESOURCE'


GO
/****** Object:  StoredProcedure [dbo].[spLoadSchedulerMonitor]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Procedure [dbo].[spLoadSchedulerMonitor]
@UTDDateDiff int
as
if object_id('tbl_scheduler_monitor') is not null
drop table tbl_scheduler_monitor
select 
			c1.value('(./event/@timestamp)[1]', 'datetime') as UTCtimestamp,
			DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
			c1.value('(./event/data[@name="id"])[1]', 'bigint') as [id],
			c1.value('(./event/data[@name="process_utilization"])[1]', 'int') as process_utilization,
			c1.value('(./event/data[@name="system_idle"])[1]', 'int') as system_idle,
			c1.value('(./event/data[@name="user_mode_time"])[1]', 'bigint') as user_mode_time,
			c1.value('(./event/data[@name="kernel_mode_time"])[1]', 'bigint') as kernel_mode_time,
			c1.value('(./event/data[@name="working_set_delta"])[1]', 'numeric(24,0)') as working_set_delta,
			c1.value('(./event/data[@name="memory_utilization"])[1]', 'int') as memory_utilization
into tbl_scheduler_monitor			
from tbl_XEImport
where object_name like 'scheduler_monitor_system_health_ring_buffer_recorded'

GO
/****** Object:  StoredProcedure [dbo].[SpLoadSecurityRingBuffer]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadSecurityRingBuffer]
@UTDDateDiff int
as
if object_id('tbl_security_ring_buffer') is not null
drop table [tbl_security_ring_buffer]
select 
			c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
			DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
			c1.value('(./event/data[@name="id"])[1]', 'bigint') as id,
			c1.value('(./event/data[@name="session_id"])[1]', 'int') as session_id,
			c1.value('(./event/data[@name="error_code"])[1]', 'bigint') as [error_code],
			c1.value('(./event/data[@name="api_name"])[1]', 'nvarchar(100)') as api_name,
			c1.value('(./event/data[@name="calling_api_name"])[1]', 'nvarchar(100)') as calling_api_name

into [tbl_security_ring_buffer]
from tbl_XEImport
where object_name like 'security_error_ring_buffer_recorded'

GO
/****** Object:  StoredProcedure [dbo].[SpLoadSYSTEMComponent]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[SpLoadSYSTEMComponent]
@UTDDateDiff int
as
if object_id('tbl_SYSTEM') is not null
drop table tbl_SYSTEM
select 
	 c1.value('(event/@timestamp)[1]','datetime') as [UTCtimestamp],
	 DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as timestamp,
	 c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') as [component_name],
	 c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') as [component_state],
	 c1.value('(event/data[@name="data"]/value/system[1]/@spinlockBackoffs)[1]', 'int') as [spinlockBackoffs],
	 c1.value('(event/data[@name="data"]/value/system[1]/@sickSpinlockTypeAfterAv)[1]', 'varchar(100)') as [sickSpinlockTypeAfterAv],
	 c1.value('(event/data[@name="data"]/value/system[1]/@latchWarnings)[1]', 'int') as [latchWarnings],
	 c1.value('(event/data[@name="data"]/value/system[1]/@isAccessViolationOccurred)[1]', 'int') as [isAccessViolationOccurred],
	 c1.value('(event/data[@name="data"]/value/system[1]/@writeAccessViolationCount)[1]', 'int') as [writeAccessViolationCount],
	 c1.value('(event/data[@name="data"]/value/system[1]/@totalDumpRequests)[1]', 'int') as [totalDumpRequests],
	 c1.value('(event/data[@name="data"]/value/system[1]/@intervalDumpRequests)[1]', 'int') as [intervalDumpRequests],
	 c1.value('(event/data[@name="data"]/value/system[1]/@nonYieldingTasksReported)[1]', 'int') as [nonYieldingTasksReported],
	 c1.value('(event/data[@name="data"]/value/system[1]/@pageFaults)[1]', 'bigint') as [pageFaults],
	 c1.value('(event/data[@name="data"]/value/system[1]/@systemCpuUtilization)[1]', 'int') as [systemCpuUtilization],
	 c1.value('(event/data[@name="data"]/value/system[1]/@sqlCpuUtilization)[1]', 'int') as [sqlCpuUtilization],
	 c1.value('(event/data[@name="data"]/value/system[1]/@BadPagesDetected)[1]', 'int') as [BadPagesDetected],
	 c1.value('(event/data[@name="data"]/value/system[1]/@BadPagesFixed)[1]', 'int') as [BadPagesFixed],
	 c1.value('(event/data[@name="data"]/value/system[1]/@LastBadPageAddress)[1]', 'nvarchar(30)') as [LastBadPageAddress]
into tbl_SYSTEM	  
FROM tbl_ServerDiagnostics 
where SdComponent = 'SYSTEM'
GO


/****** Object:  StoredProcedure [dbo].[spLoadWaitQueries]    ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[spLoadWaitQueries]
@UTDDateDiff int
as
if object_id('tbl_waitqueries') is not null
drop table tbl_waitqueries
SELECT
c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp],
c1.value('(/event/data[@name="wait_type"]/text)[1]', 'varchar(50)') as WaitType,
c1.value('(/event/data[@name="duration"]/value)[1]', 'bigint') as Duration,
c1.value('(/event/data[@name="signal_duration"]/value)[1]', 'bigint') as signal_duration,
c1.value('(/event/action[@name="session_id"]/value)[1]', 'int') as Session_ID,
c1.value('(/event/action[@name="sql_text"]/value)[1]', 'varchar(max)') as sql_text
into tbl_waitqueries
FROM tbl_XEImport
where object_name like  'wait_info%'
GO




/****** Object:  StoredProcedure [dbo].[spLoadDeadlockReport]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[spLoadDeadlockReport]
@UTDDateDiff int
as
if object_id('tbl_DeadlockReport') is not null
drop table tbl_DeadlockReport
SELECT
c1.value('(./event/@timestamp)[1]', 'datetime') as utctimestamp,
DATEADD(mi,@UTDDateDiff,c1.value('(./event/@timestamp)[1]', 'datetime')) as [timestamp]
, *
into tbl_DeadlockReport
FROM tbl_XEImport
where object_name like  'xml_deadlock_report'
GO




/****** Object:  StoredProcedure [dbo].[spLoadSystemHealthSession]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[spLoadSystemHealthSession]
@path_to_health_session nvarchar(4000) = NULL ,
@UTDDateDiff int = 0
as

if object_id('tbl_ImportStatus') is not null
drop table tbl_ImportStatus
Create table tbl_ImportStatus
( StepName varchar(100),
  Status varchar(20),
  Starttime datetime
)
insert into tbl_ImportStatus Values('Load System Health Session','Processing',getdate())

DECLARE @filename varchar(8000) ;
IF (SUBSTRING(CAST(SERVERPROPERTY ('ProductVersion') AS varchar(50)),1,CHARINDEX('.',CAST(SERVERPROPERTY ('ProductVersion') AS varchar(50)))-1) >= 11)
BEGIN

	If ( @path_to_health_session is null or @path_to_health_session ='')
	begin
		SET @UTDDateDiff = DATEDIFF(mi,GETUTCDATE(),GETDATE())
	-- Fetch information about the XEL file location
	
		SELECT @filename = CAST(target_data as XML).value('(/EventFileTarget/File/@name)[1]', 'varchar(8000)')
		FROM sys.dm_xe_session_targets
		WHERE target_name = 'event_file' and event_session_address = (select address from sys.dm_xe_sessions where name = 'system_health')
		SET @path_to_health_session = SUBSTRING(@filename,1,CHARINDEX('system_health',@filename,1)-1) + 'system_health*.xel'
		select @path_to_health_session,@filename, @UTDDateDiff
	end

	insert into tbl_ImportStatus Values('Importing XEL file','Processing',getdate())
	exec sp_ImportXML @path_to_health_session 
	
	insert into tbl_ImportStatus Values('Load Scheduler Monitor','Processing',getdate())
	exec spLoadSchedulerMonitor @UTDDateDiff

	insert into tbl_ImportStatus Values('Load Resource Server Health Component','Processing',getdate())
	exec SpLoadResourceComponent @UTDDateDiff

	insert into tbl_ImportStatus Values('Load IO_Subsystem Server Health Component','Processing',getdate())
	exec SpLoadIO_SUBSYSTEMComponent @UTDDateDiff

	insert into tbl_ImportStatus Values('Load System Server Health Component','Processing',getdate())
	exec SpLoadSYSTEMComponent @UTDDateDiff

	insert into tbl_ImportStatus Values('Load System Health Summary','Processing',getdate())
	exec SpLoadComponentSummary @UTDDateDiff

	insert into tbl_ImportStatus Values('Load Query_Processing Server Health Component','Processing',getdate())
	exec SpLoadQueryProcessingComponent @UTDDateDiff

	insert into tbl_ImportStatus Values('Load Security Ring Buffer','Processing',getdate())
	exec SpLoadSecurityRingBuffer @UTDDateDiff

	insert into tbl_ImportStatus Values('Load Errors Recorded','Processing',getdate())
	exec SpLoadErrorRecorded @UTDDateDiff
	
	insert into tbl_ImportStatus Values('Wait Queries','Processing',getdate())
	exec spLoadWaitQueries @UTDDateDiff

	insert into tbl_ImportStatus Values('Connectivity Ring Buffer','Processing',getdate())
	exec spLoadConnectivity_ring_buffer @UTDDateDiff

	insert into tbl_ImportStatus Values('Deadlock Report','Processing',getdate())
	exec [spLoadDeadlockReport] @UTDDateDiff

	insert into tbl_ImportStatus Values('Import Finished','Done',getdate())
end
Else 
  select 'Not a supported Server version: ' + @@version

GO

---------------------------========================3b. Create Extended Events History Tables=============-----------------

-- Extended Events history tables ----

--1. tbl_scheduler_monitor_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_scheduler_monitor_history](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[id] [bigint] NULL,
	[process_utilization] [int] NULL,
	[system_idle] [int] NULL,
	[user_mode_time] [bigint] NULL,
	[kernel_mode_time] [bigint] NULL,
	[working_set_delta] [numeric](24, 0) NULL,
	[memory_utilization] [int] NULL
) ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX [Ind_tbl_scheduler_monitor_history] ON [dbo].[tbl_scheduler_monitor_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO



--2. tbl_Resource_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Resource_history](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[State] [varchar](20) NULL,
	[lastNotification] [nvarchar](100) NULL,
	[outOfMemoryExceptions] [tinyint] NULL,
	[isAnyPoolOutOfMemory] [tinyint] NULL,
	[processOutOfMemoryPeriod] [tinyint] NULL,
	[available_physical_memory] [bigint] NULL,
	[available_virtual_memory] [bigint] NULL,
	[available_paging_file] [bigint] NULL,
	[working_set] [bigint] NULL,
	[percent_workingset_committed] [bigint] NULL,
	[page_faults] [bigint] NULL,
	[sys_physical_memory_high] [bigint] NULL,
	[sys_physical_memory_low] [bigint] NULL,
	[process_phyiscal_memory_low] [bigint] NULL,
	[process_virtual_memory_low] [bigint] NULL,
	[vm_reserved_kb] [bigint] NULL,
	[vm_committed_kb] [bigint] NULL,
	[locked_pages_allocated_kb] [bigint] NULL,
	[large_pages_allocated_kb] [bigint] NULL,
	[target_committed_kb] [bigint] NULL,
	[current_committed_kb] [bigint] NULL,
	[Pages_allocated_kb] [bigint] NULL,
	[pages_reserved_kb] [bigint] NULL,
	[pages_free_kb] [bigint] NULL,
	[pages_in_use_kb] [bigint] NULL,
	[page_alloc_potential] [bigint] NULL,
	[numa_growth_phase] [int] NULL,
	[last_oom_factor] [int] NULL,
	[last_os_error] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_Resource_history] ON [dbo].[tbl_Resource_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO



--3. tbl_IO_SUBSYSTEM_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_IO_SUBSYSTEM_history](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[component_name] [varchar](100) NULL,
	[component_state] [varchar](100) NULL,
	[ioLatchTimeouts] [int] NULL,
	[intervalLongIos] [int] NULL,
	[totalLongIos] [int] NULL,
	[longestPendingRequests_duration] [bigint] NULL,
	[longestPendingRequests_filePath] [nvarchar](500) NULL,
	[longestPendingRequests_offset] [bigint] NULL,
	[longestPendingRequests_handle] [nvarchar](20) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_IO_SUBSYSTEM_history] ON [dbo].[tbl_IO_SUBSYSTEM_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

--4. tbl_SYSTEM_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_SYSTEM_history](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[component_name] [varchar](100) NULL,
	[component_state] [varchar](100) NULL,
	[spinlockBackoffs] [int] NULL,
	[sickSpinlockTypeAfterAv] [varchar](100) NULL,
	[latchWarnings] [int] NULL,
	[isAccessViolationOccurred] [int] NULL,
	[writeAccessViolationCount] [int] NULL,
	[totalDumpRequests] [int] NULL,
	[intervalDumpRequests] [int] NULL,
	[nonYieldingTasksReported] [int] NULL,
	[pageFaults] [bigint] NULL,
	[systemCpuUtilization] [int] NULL,
	[sqlCpuUtilization] [int] NULL,
	[BadPagesDetected] [int] NULL,
	[BadPagesFixed] [int] NULL,
	[LastBadPageAddress] [nvarchar](30) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_SYSTEM_history] ON [dbo].[tbl_SYSTEM_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

-- 5. tbl_Summary_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Summary_history](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[component_name] [varchar](100) NULL,
	[component_state] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_Summary_history] ON [dbo].[tbl_Summary_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--6. tbl_QUERY_PROCESSING_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_QUERY_PROCESSING_history](
	[utctimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[component_name] [varchar](100) NULL,
	[component_state] [varchar](100) NULL,
	[maxworkers] [int] NULL,
	[workerscreated] [int] NULL,
	[workersIdle] [int] NULL,
	[tasksCompletedWithinInterval] [int] NULL,
	[oldestPendingTaskWaitingTime] [bigint] NULL,
	[pendingTasks] [int] NULL,
	[hasUnresolvableDeadlockOccurred] [int] NULL,
	[hasDeadlockedSchedulersOccurred] [int] NULL,
	[trackingNonYieldingScheduler] [varchar](10) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO



CREATE NONCLUSTERED INDEX [Ind_tbl_QUERY_PROCESSING_history] ON [dbo].[tbl_QUERY_PROCESSING_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--7. tbl_OS_WAIT_STATS_byDuration_history

USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_OS_WAIT_STATS_byDuration_History](
	[UTCtimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[wait_type] [varchar](47) NULL,
	[waiting_tasks_count] [bigint] NULL,
	[avg_wait_time_ms] [bigint] NULL,
	[max_wait_time_ms] [bigint] NULL,
	[wait_category] [varchar](max) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_OS_WAIT_STATS_byDuration_History] ON [dbo].[tbl_OS_WAIT_STATS_byDuration_History]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--8. tbl_BlockingXeOutput_history

USE [Baseline]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_BlockingXeOutput_history](
	[utctimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[blocking_process] [nvarchar](max) NULL,
	[blocking_process_id] [int] NULL,
	[blocking_process_ecid] [int] NULL,
	[blocking_process_status] [varchar](100) NULL,
	[blocking_process_isolationlevel] [varchar](200) NULL,
	[blocking_process_lastbatchstarted] [datetime] NULL,
	[blocking_process_lastbatchcompleted] [datetime] NULL,
	[blocking_process_lastattention] [datetime] NULL,
	[blocking_process_trancount] [int] NULL,
	[blocking_process_xactid] [bigint] NULL,
	[blocking_process_clientapp] [nvarchar](100) NULL,
	[blocking_process_hostname] [nvarchar](100) NULL,
	[blocking_process_loginname] [nvarchar](100) NULL,
	[blocking_process_wait_resource] [nvarchar](200) NULL,
	[blocked_process] [nvarchar](max) NULL,
	[blocked_process_id] [int] NULL,
	[blocked_process_ecid] [int] NULL,
	[blocked_process_status] [varchar](100) NULL,
	[blocked_process_wait_resource] [nvarchar](200) NULL,
	[blocked_process_lockMode] [char](5) NULL,
	[blocked_process_wait_time] [nvarchar](200) NULL,
	[blocked_process_lastbatchstarted] [datetime] NULL,
	[blocked_process_lastbatchcompleted] [datetime] NULL,
	[blocked_process_lastattention] [datetime] NULL,
	[blocked_process_clientapp] [nvarchar](100) NULL,
	[blocked_process_hostname] [nvarchar](100) NULL,
	[blocked_process_loginname] [nvarchar](100) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_BlockingXeOutput_history] ON [dbo].[tbl_BlockingXeOutput_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO



--9 . tbl_errors_history

USE [Baseline]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_errors_history](
	[utctimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[session_id] [int] NULL,
	[database_id] [int] NULL,
	[error_number] [int] NULL,
	[severity] [int] NULL,
	[state] [int] NULL,
	[category] [nvarchar](100) NULL,
	[destination] [nvarchar](100) NULL,
	[message] [nvarchar](1000) NULL
) ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX [Ind_tbl_errors_history] ON [dbo].[tbl_errors_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--10. tbl_waitqueries_history

USE [Baseline]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_waitqueries_history](
	[utctimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[WaitType] [varchar](50) NULL,
	[Duration] [bigint] NULL,
	[signal_duration] [bigint] NULL,
	[Session_ID] [int] NULL,
	[sql_text] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO

CREATE NONCLUSTERED INDEX [Ind_tbl_waitqueries_history] ON [dbo].[tbl_waitqueries_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


--11. tbl_DeadlockReport_history

USE [Baseline]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_DeadlockReport_history](
	[utctimestamp] [datetime] NULL,
	[timestamp] [datetime] NULL,
	[object_name] [nvarchar](60) NOT NULL,
	[c1] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX [Ind_tbl_DeadlockReport_history] ON [dbo].[tbl_DeadlockReport_history]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO


----- Create stored procedure to insert the records to history tables & also purge the old data----- 


Use Baseline 
GO

CREATE PROCEDURE sp_Insert_EXTND_EVNTS_history
AS 
-- 1. tbl_scheduler_monitor

IF EXISTS(SELECT 1 FROM [dbo].[tbl_scheduler_monitor_history] )

INSERT into [dbo].[tbl_scheduler_monitor_history]  
select * from [dbo].[tbl_scheduler_monitor]  where timestamp > (select max(timestamp) from [dbo].[tbl_scheduler_monitor_history])

ELSE 

INSERT into [dbo].[tbl_scheduler_monitor_history]  
select * from [dbo].[tbl_scheduler_monitor] 


-- 2. tbl_Resource 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_Resource_history] )

INSERT into [dbo].[tbl_Resource_history]  
select * from [dbo].[tbl_Resource]  where timestamp > (select max(timestamp) from [dbo].[tbl_Resource_history])

ELSE 

INSERT into [dbo].[tbl_Resource_history]  
select * from [dbo].[tbl_Resource] 


-- 3. tbl_IO_SUBSYSTEM

IF EXISTS(SELECT 1 FROM [dbo].[tbl_IO_SUBSYSTEM_history] )

INSERT into [dbo].[tbl_IO_SUBSYSTEM_history]  
select * from [dbo].[tbl_IO_SUBSYSTEM]  where timestamp > (select max(timestamp) from [dbo].[tbl_IO_SUBSYSTEM_history])

ELSE 

INSERT into [dbo].[tbl_IO_SUBSYSTEM_history]  
select * from [dbo].[tbl_IO_SUBSYSTEM] 


-- 4. tbl_SYSTEM 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_SYSTEM_history] )

INSERT into [dbo].[tbl_SYSTEM_history]  
select * from [dbo].[tbl_SYSTEM]  where timestamp > (select max(timestamp) from [dbo].[tbl_SYSTEM_history])

ELSE 

INSERT into [dbo].[tbl_SYSTEM_history]  
select * from [dbo].[tbl_SYSTEM] 


-- 5. tbl_Summary 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_Summary_history] )

INSERT into [dbo].[tbl_Summary_history]  
select * from [dbo].[tbl_Summary]  where timestamp > (select max(timestamp) from [dbo].[tbl_Summary_history])

ELSE 

INSERT into [dbo].[tbl_Summary_history]  
select * from [dbo].[tbl_Summary] 


--6. tbl_QUERY_PROCESSING 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_QUERY_PROCESSING_history] )

INSERT into [dbo].[tbl_QUERY_PROCESSING_history]  
select * from [dbo].[tbl_QUERY_PROCESSING]  where timestamp > (select max(timestamp) from [dbo].[tbl_QUERY_PROCESSING_history])

ELSE 

INSERT into [dbo].[tbl_QUERY_PROCESSING_history]  
select * from [dbo].[tbl_QUERY_PROCESSING] 


--7. tbl_OS_WAIT_STATS_byDuration --- Issue


IF EXISTS(SELECT 1 FROM [dbo].[tbl_OS_WAIT_STATS_byDuration_history] )

INSERT into [dbo].[tbl_OS_WAIT_STATS_byDuration_history]  
select * from [dbo].[tbl_OS_WAIT_STATS_byDuration]  where timestamp > (select max(timestamp) from [dbo].[tbl_OS_WAIT_STATS_byDuration_history])

ELSE 

INSERT into [dbo].[tbl_OS_WAIT_STATS_byDuration_history]  
select * from [dbo].[tbl_OS_WAIT_STATS_byDuration] 


--8. tbl_BlockingXeOutput 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_BlockingXeOutput_history] )

INSERT into [dbo].[tbl_BlockingXeOutput_history]  
select * from [dbo].[tbl_BlockingXeOutput]  where timestamp > (select max(timestamp) from [dbo].[tbl_BlockingXeOutput_history])

ELSE 

INSERT into [dbo].[tbl_BlockingXeOutput_history]  
select * from [dbo].[tbl_BlockingXeOutput] 

--9. tbl_errors 

IF EXISTS(SELECT 1 FROM [dbo].[tbl_errors_history] )

INSERT into [dbo].[tbl_errors_history]  
select * from [dbo].[tbl_errors]  where timestamp > (select max(timestamp) from [dbo].[tbl_errors_history])

ELSE 

INSERT into [dbo].[tbl_errors_history]  
select * from [dbo].[tbl_errors] 

--10. tbl_waitqueries 


IF EXISTS(SELECT 1 FROM [dbo].[tbl_waitqueries_history] )

INSERT into [dbo].[tbl_waitqueries_history]  
select * from [dbo].[tbl_waitqueries]  where timestamp > (select max(timestamp) from [dbo].[tbl_waitqueries_history])

ELSE 

INSERT into [dbo].[tbl_waitqueries_history]  
select * from [dbo].[tbl_waitqueries] 


--11. tbl_DeadlockReport 


IF EXISTS(SELECT 1 FROM [dbo].[tbl_DeadlockReport_history] )

INSERT into [dbo].[tbl_DeadlockReport_history]  
select * from [dbo].[tbl_DeadlockReport]  where timestamp > (select max(timestamp) from [dbo].[tbl_DeadlockReport_history])

ELSE 

INSERT into [dbo].[tbl_DeadlockReport_history]  
select * from [dbo].[tbl_DeadlockReport] 

GO


CREATE PROCEDURE sp_Purge_OldData_ExEvents
AS

delete from [Baseline].[dbo].[tbl_scheduler_monitor_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_Resource_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_IO_SUBSYSTEM_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_SYSTEM_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_Summary_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_QUERY_PROCESSING_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_OS_WAIT_STATS_byDuration_History] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_BlockingXeOutput_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_errors_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_waitqueries_history] where timestamp < DATEADD(dd,-90,getdate());
delete from [Baseline].[dbo].[tbl_DeadlockReport_history] where timestamp < DATEADD(dd,-90,getdate());

GO



----------------------=====================4. CREATECollectionJob=================----------------



------ Create Collection Job -------


USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1, 
		@alert_replace_runtime_tokens=1, 
		@use_databasemail=1
GO

/******1. Object:  Job [DBA - Performance Statistics]    ******/

USE [msdb]
GO

/****** Object:  Job [DBA - PerfMon Counter Collection]    Script Date: 3/17/2019 2:24:34 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [PerfMon Collection]    Script Date: 3/17/2019 2:24:34 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'PerfMon Collection' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'PerfMon Collection'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - PerfMon Counter Collection', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Collect performance counters for SQL Server baselining', 
		@category_name=N'PerfMon Collection', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Get PerfMon data]    Script Date: 3/17/2019 2:24:34 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Get PerfMon data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC spGetPerfCountersFromPowerShell', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge OLD Data_Perfmon]    Script Date: 3/17/2019 2:24:34 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge OLD Data_Perfmon', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec ClearPerfCtrHistory', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 2 Minutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140903, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'c469be3f-e33b-4a9e-a02f-4a70db2012bd'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


/****** 2. Object:  Job [DBA - Load Session Status]    ******/

USE [msdb]
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Load Session Status', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job runs every minutes to capture the status of all the sessions running on the instance and loads it in the dbo.Sessionstatus table in Baseline', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load Session Status]    ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load Session Status', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.spLoadSessionStatus', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Load Session status per min', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150817, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'9b226349-52b8-4e4a-8219-ef062a524757'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



/****** 3. Object:  Job [DBA - Load SystemHealthSession]   ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Load SystemHealthSession', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job load the system health session xel trace files to tables in Baseline every morning at 2AM', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load SystemHealthSession', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.spLoadSystemHealthSession', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'INSERT_INTO_HISTORY', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[sp_Insert_EXTND_EVNTS_history]', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge OLD Data', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[sp_Purge_OldData_ExEvents]', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily 2AM', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160726, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'7507f377-9fe9-46b5-ba54-0b3a20965091'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


-----------------===================5. who_is_active_v11_20=================---------------------

--- Who is active --

USE Baseline
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'sp_WhoIsActive')
	EXEC ('CREATE PROC dbo.sp_WhoIsActive AS SELECT ''stub version, to be replaced''')
GO

/*********************************************************************************************
Who Is Active? v11.20 (2017-12-04)
(C) 2007-2017, Adam Machanic

Feedback: mailto:amachanic@gmail.com
Updates: http://whoisactive.com

License: 
	Who is Active? is free to download and use for personal, educational, and internal 
	corporate purposes, provided that this header is preserved. Redistribution or sale 
	of Who is Active?, in whole or in part, is prohibited without the author's express 
	written consent.
*********************************************************************************************/
ALTER PROC dbo.sp_WhoIsActive
(
--~
	--Filters--Both inclusive and exclusive
	--Set either filter to '' to disable
	--Valid filter types are: session, program, database, login, and host
	--Session is a session ID, and either 0 or '' can be used to indicate "all" sessions
	--All other filter types support % or _ as wildcards
	@filter sysname = '',
	@filter_type VARCHAR(10) = 'session',
	@not_filter sysname = '',
	@not_filter_type VARCHAR(10) = 'session',

	--Retrieve data about the calling session?
	@show_own_spid BIT = 0,

	--Retrieve data about system sessions?
	@show_system_spids BIT = 0,

	--Controls how sleeping SPIDs are handled, based on the idea of levels of interest
	--0 does not pull any sleeping SPIDs
	--1 pulls only those sleeping SPIDs that also have an open transaction
	--2 pulls all sleeping SPIDs
	@show_sleeping_spids TINYINT = 1,

	--If 1, gets the full stored procedure or running batch, when available
	--If 0, gets only the actual statement that is currently running in the batch or procedure
	@get_full_inner_text BIT = 0,

	--Get associated query plans for running tasks, if available
	--If @get_plans = 1, gets the plan based on the request's statement offset
	--If @get_plans = 2, gets the entire plan based on the request's plan_handle
	@get_plans TINYINT = 0,

	--Get the associated outer ad hoc query or stored procedure call, if available
	@get_outer_command BIT = 0,

	--Enables pulling transaction log write info and transaction duration
	@get_transaction_info BIT = 0,

	--Get information on active tasks, based on three interest levels
	--Level 0 does not pull any task-related information
	--Level 1 is a lightweight mode that pulls the top non-CXPACKET wait, giving preference to blockers
	--Level 2 pulls all available task-based metrics, including: 
	--number of active tasks, current wait stats, physical I/O, context switches, and blocker information
	@get_task_info TINYINT = 1,

	--Gets associated locks for each request, aggregated in an XML format
	@get_locks BIT = 0,

	--Get average time for past runs of an active query
	--(based on the combination of plan handle, sql handle, and offset)
	@get_avg_time BIT = 0,

	--Get additional non-performance-related information about the session or request
	--text_size, language, date_format, date_first, quoted_identifier, arithabort, ansi_null_dflt_on, 
	--ansi_defaults, ansi_warnings, ansi_padding, ansi_nulls, concat_null_yields_null, 
	--transaction_isolation_level, lock_timeout, deadlock_priority, row_count, command_type
	--
	--If a SQL Agent job is running, an subnode called agent_info will be populated with some or all of
	--the following: job_id, job_name, step_id, step_name, msdb_query_error (in the event of an error)
	--
	--If @get_task_info is set to 2 and a lock wait is detected, a subnode called block_info will be
	--populated with some or all of the following: lock_type, database_name, object_id, file_id, hobt_id, 
	--applock_hash, metadata_resource, metadata_class_id, object_name, schema_name
	@get_additional_info BIT = 0,

	--Walk the blocking chain and count the number of 
	--total SPIDs blocked all the way down by a given session
	--Also enables task_info Level 1, if @get_task_info is set to 0
	@find_block_leaders BIT = 0,

	--Pull deltas on various metrics
	--Interval in seconds to wait before doing the second data pull
	@delta_interval TINYINT = 0,

	--List of desired output columns, in desired order
	--Note that the final output will be the intersection of all enabled features and all 
	--columns in the list. Therefore, only columns associated with enabled features will 
	--actually appear in the output. Likewise, removing columns from this list may effectively
	--disable features, even if they are turned on
	--
	--Each element in this list must be one of the valid output column names. Names must be
	--delimited by square brackets. White space, formatting, and additional characters are
	--allowed, as long as the list contains exact matches of delimited valid column names.
	@output_column_list VARCHAR(8000) = '[dd%][session_id][sql_text][sql_command][login_name][wait_info][tasks][tran_log%][cpu%][temp%][block%][reads%][writes%][context%][physical%][query_plan][locks][%]',

	--Column(s) by which to sort output, optionally with sort directions. 
		--Valid column choices:
		--session_id, physical_io, reads, physical_reads, writes, tempdb_allocations, 
		--tempdb_current, CPU, context_switches, used_memory, physical_io_delta, reads_delta, 
		--physical_reads_delta, writes_delta, tempdb_allocations_delta, tempdb_current_delta, 
		--CPU_delta, context_switches_delta, used_memory_delta, tasks, tran_start_time, 
		--open_tran_count, blocking_session_id, blocked_session_count, percent_complete, 
		--host_name, login_name, database_name, start_time, login_time, program_name
		--
		--Note that column names in the list must be bracket-delimited. Commas and/or white
		--space are not required. 
	@sort_order VARCHAR(500) = '[start_time] ASC',

	--Formats some of the output columns in a more "human readable" form
	--0 disables outfput format
	--1 formats the output for variable-width fonts
	--2 formats the output for fixed-width fonts
	@format_output TINYINT = 1,

	--If set to a non-blank value, the script will attempt to insert into the specified 
	--destination table. Please note that the script will not verify that the table exists, 
	--or that it has the correct schema, before doing the insert.
	--Table can be specified in one, two, or three-part format
	@destination_table VARCHAR(4000) = '',

	--If set to 1, no data collection will happen and no result set will be returned; instead,
	--a CREATE TABLE statement will be returned via the @schema parameter, which will match 
	--the schema of the result set that would be returned by using the same collection of the
	--rest of the parameters. The CREATE TABLE statement will have a placeholder token of 
	--<table_name> in place of an actual table name.
	@return_schema BIT = 0,
	@schema VARCHAR(MAX) = NULL OUTPUT,

	--Help! What do I do?
	@help BIT = 0
--~
)
/*
OUTPUT COLUMNS
--------------
Formatted/Non:	[session_id] [smallint] NOT NULL
	Session ID (a.k.a. SPID)

Formatted:		[dd hh:mm:ss.mss] [varchar](15) NULL
Non-Formatted:	<not returned>
	For an active request, time the query has been running
	For a sleeping session, time since the last batch completed

Formatted:		[dd hh:mm:ss.mss (avg)] [varchar](15) NULL
Non-Formatted:	[avg_elapsed_time] [int] NULL
	(Requires @get_avg_time option)
	How much time has the active portion of the query taken in the past, on average?

Formatted:		[physical_io] [varchar](30) NULL
Non-Formatted:	[physical_io] [bigint] NULL
	Shows the number of physical I/Os, for active requests

Formatted:		[reads] [varchar](30) NULL
Non-Formatted:	[reads] [bigint] NULL
	For an active request, number of reads done for the current query
	For a sleeping session, total number of reads done over the lifetime of the session

Formatted:		[physical_reads] [varchar](30) NULL
Non-Formatted:	[physical_reads] [bigint] NULL
	For an active request, number of physical reads done for the current query
	For a sleeping session, total number of physical reads done over the lifetime of the session

Formatted:		[writes] [varchar](30) NULL
Non-Formatted:	[writes] [bigint] NULL
	For an active request, number of writes done for the current query
	For a sleeping session, total number of writes done over the lifetime of the session

Formatted:		[tempdb_allocations] [varchar](30) NULL
Non-Formatted:	[tempdb_allocations] [bigint] NULL
	For an active request, number of TempDB writes done for the current query
	For a sleeping session, total number of TempDB writes done over the lifetime of the session

Formatted:		[tempdb_current] [varchar](30) NULL
Non-Formatted:	[tempdb_current] [bigint] NULL
	For an active request, number of TempDB pages currently allocated for the query
	For a sleeping session, number of TempDB pages currently allocated for the session

Formatted:		[CPU] [varchar](30) NULL
Non-Formatted:	[CPU] [int] NULL
	For an active request, total CPU time consumed by the current query
	For a sleeping session, total CPU time consumed over the lifetime of the session

Formatted:		[context_switches] [varchar](30) NULL
Non-Formatted:	[context_switches] [bigint] NULL
	Shows the number of context switches, for active requests

Formatted:		[used_memory] [varchar](30) NOT NULL
Non-Formatted:	[used_memory] [bigint] NOT NULL
	For an active request, total memory consumption for the current query
	For a sleeping session, total current memory consumption

Formatted:		[physical_io_delta] [varchar](30) NULL
Non-Formatted:	[physical_io_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of physical I/Os reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[reads_delta] [varchar](30) NULL
Non-Formatted:	[reads_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of reads reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[physical_reads_delta] [varchar](30) NULL
Non-Formatted:	[physical_reads_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of physical reads reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[writes_delta] [varchar](30) NULL
Non-Formatted:	[writes_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of writes reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[tempdb_allocations_delta] [varchar](30) NULL
Non-Formatted:	[tempdb_allocations_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of TempDB writes reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[tempdb_current_delta] [varchar](30) NULL
Non-Formatted:	[tempdb_current_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the number of allocated TempDB pages reported on the first and second 
	collections. If the request started after the first collection, the value will be NULL

Formatted:		[CPU_delta] [varchar](30) NULL
Non-Formatted:	[CPU_delta] [int] NULL
	(Requires @delta_interval option)
	Difference between the CPU time reported on the first and second collections. 
	If the request started after the first collection, the value will be NULL

Formatted:		[context_switches_delta] [varchar](30) NULL
Non-Formatted:	[context_switches_delta] [bigint] NULL
	(Requires @delta_interval option)
	Difference between the context switches count reported on the first and second collections
	If the request started after the first collection, the value will be NULL

Formatted:		[used_memory_delta] [varchar](30) NULL
Non-Formatted:	[used_memory_delta] [bigint] NULL
	Difference between the memory usage reported on the first and second collections
	If the request started after the first collection, the value will be NULL

Formatted:		[tasks] [varchar](30) NULL
Non-Formatted:	[tasks] [smallint] NULL
	Number of worker tasks currently allocated, for active requests

Formatted/Non:	[status] [varchar](30) NOT NULL
	Activity status for the session (running, sleeping, etc)

Formatted/Non:	[wait_info] [nvarchar](4000) NULL
	Aggregates wait information, in the following format:
		(Ax: Bms/Cms/Dms)E
	A is the number of waiting tasks currently waiting on resource type E. B/C/D are wait
	times, in milliseconds. If only one thread is waiting, its wait time will be shown as B.
	If two tasks are waiting, each of their wait times will be shown (B/C). If three or more 
	tasks are waiting, the minimum, average, and maximum wait times will be shown (B/C/D).
	If wait type E is a page latch wait and the page is of a "special" type (e.g. PFS, GAM, SGAM), 
	the page type will be identified.
	If wait type E is CXPACKET, the nodeId from the query plan will be identified

Formatted/Non:	[locks] [xml] NULL
	(Requires @get_locks option)
	Aggregates lock information, in XML format.
	The lock XML includes the lock mode, locked object, and aggregates the number of requests. 
	Attempts are made to identify locked objects by name

Formatted/Non:	[tran_start_time] [datetime] NULL
	(Requires @get_transaction_info option)
	Date and time that the first transaction opened by a session caused a transaction log 
	write to occur.

Formatted/Non:	[tran_log_writes] [nvarchar](4000) NULL
	(Requires @get_transaction_info option)
	Aggregates transaction log write information, in the following format:
	A:wB (C kB)
	A is a database that has been touched by an active transaction
	B is the number of log writes that have been made in the database as a result of the transaction
	C is the number of log kilobytes consumed by the log records

Formatted:		[open_tran_count] [varchar](30) NULL
Non-Formatted:	[open_tran_count] [smallint] NULL
	Shows the number of open transactions the session has open

Formatted:		[sql_command] [xml] NULL
Non-Formatted:	[sql_command] [nvarchar](max) NULL
	(Requires @get_outer_command option)
	Shows the "outer" SQL command, i.e. the text of the batch or RPC sent to the server, 
	if available

Formatted:		[sql_text] [xml] NULL
Non-Formatted:	[sql_text] [nvarchar](max) NULL
	Shows the SQL text for active requests or the last statement executed
	for sleeping sessions, if available in either case.
	If @get_full_inner_text option is set, shows the full text of the batch.
	Otherwise, shows only the active statement within the batch.
	If the query text is locked, a special timeout message will be sent, in the following format:
		<timeout_exceeded />
	If an error occurs, an error message will be sent, in the following format:
		<error message="message" />

Formatted/Non:	[query_plan] [xml] NULL
	(Requires @get_plans option)
	Shows the query plan for the request, if available.
	If the plan is locked, a special timeout message will be sent, in the following format:
		<timeout_exceeded />
	If an error occurs, an error message will be sent, in the following format:
		<error message="message" />

Formatted/Non:	[blocking_session_id] [smallint] NULL
	When applicable, shows the blocking SPID

Formatted:		[blocked_session_count] [varchar](30) NULL
Non-Formatted:	[blocked_session_count] [smallint] NULL
	(Requires @find_block_leaders option)
	The total number of SPIDs blocked by this session,
	all the way down the blocking chain.

Formatted:		[percent_complete] [varchar](30) NULL
Non-Formatted:	[percent_complete] [real] NULL
	When applicable, shows the percent complete (e.g. for backups, restores, and some rollbacks)

Formatted/Non:	[host_name] [sysname] NOT NULL
	Shows the host name for the connection

Formatted/Non:	[login_name] [sysname] NOT NULL
	Shows the login name for the connection

Formatted/Non:	[database_name] [sysname] NULL
	Shows the connected database

Formatted/Non:	[program_name] [sysname] NULL
	Shows the reported program/application name

Formatted/Non:	[additional_info] [xml] NULL
	(Requires @get_additional_info option)
	Returns additional non-performance-related session/request information
	If the script finds a SQL Agent job running, the name of the job and job step will be reported
	If @get_task_info = 2 and the script finds a lock wait, the locked object will be reported

Formatted/Non:	[start_time] [datetime] NOT NULL
	For active requests, shows the time the request started
	For sleeping sessions, shows the time the last batch completed

Formatted/Non:	[login_time] [datetime] NOT NULL
	Shows the time that the session connected

Formatted/Non:	[request_id] [int] NULL
	For active requests, shows the request_id
	Should be 0 unless MARS is being used

Formatted/Non:	[collection_time] [datetime] NOT NULL
	Time that this script's final SELECT ran
*/
AS
BEGIN;
	SET NOCOUNT ON; 
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET QUOTED_IDENTIFIER ON;
	SET ANSI_PADDING ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET ANSI_WARNINGS ON;
	SET NUMERIC_ROUNDABORT OFF;
	SET ARITHABORT ON;

	IF
		@filter IS NULL
		OR @filter_type IS NULL
		OR @not_filter IS NULL
		OR @not_filter_type IS NULL
		OR @show_own_spid IS NULL
		OR @show_system_spids IS NULL
		OR @show_sleeping_spids IS NULL
		OR @get_full_inner_text IS NULL
		OR @get_plans IS NULL
		OR @get_outer_command IS NULL
		OR @get_transaction_info IS NULL
		OR @get_task_info IS NULL
		OR @get_locks IS NULL
		OR @get_avg_time IS NULL
		OR @get_additional_info IS NULL
		OR @find_block_leaders IS NULL
		OR @delta_interval IS NULL
		OR @format_output IS NULL
		OR @output_column_list IS NULL
		OR @sort_order IS NULL
		OR @return_schema IS NULL
		OR @destination_table IS NULL
		OR @help IS NULL
	BEGIN;
		RAISERROR('Input parameters cannot be NULL', 16, 1);
		RETURN;
	END;
	
	IF @filter_type NOT IN ('session', 'program', 'database', 'login', 'host')
	BEGIN;
		RAISERROR('Valid filter types are: session, program, database, login, host', 16, 1);
		RETURN;
	END;
	
	IF @filter_type = 'session' AND @filter LIKE '%[^0123456789]%'
	BEGIN;
		RAISERROR('Session filters must be valid integers', 16, 1);
		RETURN;
	END;
	
	IF @not_filter_type NOT IN ('session', 'program', 'database', 'login', 'host')
	BEGIN;
		RAISERROR('Valid filter types are: session, program, database, login, host', 16, 1);
		RETURN;
	END;
	
	IF @not_filter_type = 'session' AND @not_filter LIKE '%[^0123456789]%'
	BEGIN;
		RAISERROR('Session filters must be valid integers', 16, 1);
		RETURN;
	END;
	
	IF @show_sleeping_spids NOT IN (0, 1, 2)
	BEGIN;
		RAISERROR('Valid values for @show_sleeping_spids are: 0, 1, or 2', 16, 1);
		RETURN;
	END;
	
	IF @get_plans NOT IN (0, 1, 2)
	BEGIN;
		RAISERROR('Valid values for @get_plans are: 0, 1, or 2', 16, 1);
		RETURN;
	END;

	IF @get_task_info NOT IN (0, 1, 2)
	BEGIN;
		RAISERROR('Valid values for @get_task_info are: 0, 1, or 2', 16, 1);
		RETURN;
	END;

	IF @format_output NOT IN (0, 1, 2)
	BEGIN;
		RAISERROR('Valid values for @format_output are: 0, 1, or 2', 16, 1);
		RETURN;
	END;
	
	IF @help = 1
	BEGIN;
		DECLARE 
			@header VARCHAR(MAX),
			@params VARCHAR(MAX),
			@outputs VARCHAR(MAX);

		SELECT 
			@header =
				REPLACE
				(
					REPLACE
					(
						CONVERT
						(
							VARCHAR(MAX),
							SUBSTRING
							(
								t.text, 
								CHARINDEX('/' + REPLICATE('*', 93), t.text) + 94,
								CHARINDEX(REPLICATE('*', 93) + '/', t.text) - (CHARINDEX('/' + REPLICATE('*', 93), t.text) + 94)
							)
						),
						CHAR(13)+CHAR(10),
						CHAR(13)
					),
					'	',
					''
				),
			@params =
				CHAR(13) +
					REPLACE
					(
						REPLACE
						(
							CONVERT
							(
								VARCHAR(MAX),
								SUBSTRING
								(
									t.text, 
									CHARINDEX('--~', t.text) + 5, 
									CHARINDEX('--~', t.text, CHARINDEX('--~', t.text) + 5) - (CHARINDEX('--~', t.text) + 5)
								)
							),
							CHAR(13)+CHAR(10),
							CHAR(13)
						),
						'	',
						''
					),
				@outputs = 
					CHAR(13) +
						REPLACE
						(
							REPLACE
							(
								REPLACE
								(
									CONVERT
									(
										VARCHAR(MAX),
										SUBSTRING
										(
											t.text, 
											CHARINDEX('OUTPUT COLUMNS'+CHAR(13)+CHAR(10)+'--------------', t.text) + 32,
											CHARINDEX('*/', t.text, CHARINDEX('OUTPUT COLUMNS'+CHAR(13)+CHAR(10)+'--------------', t.text) + 32) - (CHARINDEX('OUTPUT COLUMNS'+CHAR(13)+CHAR(10)+'--------------', t.text) + 32)
										)
									),
									CHAR(9),
									CHAR(255)
								),
								CHAR(13)+CHAR(10),
								CHAR(13)
							),
							'	',
							''
						) +
						CHAR(13)
		FROM sys.dm_exec_requests AS r
		CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
		WHERE
			r.session_id = @@SPID;

		WITH
		a0 AS
		(SELECT 1 AS n UNION ALL SELECT 1),
		a1 AS
		(SELECT 1 AS n FROM a0 AS a, a0 AS b),
		a2 AS
		(SELECT 1 AS n FROM a1 AS a, a1 AS b),
		a3 AS
		(SELECT 1 AS n FROM a2 AS a, a2 AS b),
		a4 AS
		(SELECT 1 AS n FROM a3 AS a, a3 AS b),
		numbers AS
		(
			SELECT TOP(LEN(@header) - 1)
				ROW_NUMBER() OVER
				(
					ORDER BY (SELECT NULL)
				) AS number
			FROM a4
			ORDER BY
				number
		)
		SELECT
			RTRIM(LTRIM(
				SUBSTRING
				(
					@header,
					number + 1,
					CHARINDEX(CHAR(13), @header, number + 1) - number - 1
				)
			)) AS [------header---------------------------------------------------------------------------------------------------------------]
		FROM numbers
		WHERE
			SUBSTRING(@header, number, 1) = CHAR(13);

		WITH
		a0 AS
		(SELECT 1 AS n UNION ALL SELECT 1),
		a1 AS
		(SELECT 1 AS n FROM a0 AS a, a0 AS b),
		a2 AS
		(SELECT 1 AS n FROM a1 AS a, a1 AS b),
		a3 AS
		(SELECT 1 AS n FROM a2 AS a, a2 AS b),
		a4 AS
		(SELECT 1 AS n FROM a3 AS a, a3 AS b),
		numbers AS
		(
			SELECT TOP(LEN(@params) - 1)
				ROW_NUMBER() OVER
				(
					ORDER BY (SELECT NULL)
				) AS number
			FROM a4
			ORDER BY
				number
		),
		tokens AS
		(
			SELECT 
				RTRIM(LTRIM(
					SUBSTRING
					(
						@params,
						number + 1,
						CHARINDEX(CHAR(13), @params, number + 1) - number - 1
					)
				)) AS token,
				number,
				CASE
					WHEN SUBSTRING(@params, number + 1, 1) = CHAR(13) THEN number
					ELSE COALESCE(NULLIF(CHARINDEX(',' + CHAR(13) + CHAR(13), @params, number), 0), LEN(@params)) 
				END AS param_group,
				ROW_NUMBER() OVER
				(
					PARTITION BY
						CHARINDEX(',' + CHAR(13) + CHAR(13), @params, number),
						SUBSTRING(@params, number+1, 1)
					ORDER BY 
						number
				) AS group_order
			FROM numbers
			WHERE
				SUBSTRING(@params, number, 1) = CHAR(13)
		),
		parsed_tokens AS
		(
			SELECT
				MIN
				(
					CASE
						WHEN token LIKE '@%' THEN token
						ELSE NULL
					END
				) AS parameter,
				MIN
				(
					CASE
						WHEN token LIKE '--%' THEN RIGHT(token, LEN(token) - 2)
						ELSE NULL
					END
				) AS description,
				param_group,
				group_order
			FROM tokens
			WHERE
				NOT 
				(
					token = '' 
					AND group_order > 1
				)
			GROUP BY
				param_group,
				group_order
		)
		SELECT
			CASE
				WHEN description IS NULL AND parameter IS NULL THEN '-------------------------------------------------------------------------'
				WHEN param_group = MAX(param_group) OVER() THEN parameter
				ELSE COALESCE(LEFT(parameter, LEN(parameter) - 1), '')
			END AS [------parameter----------------------------------------------------------],
			CASE
				WHEN description IS NULL AND parameter IS NULL THEN '----------------------------------------------------------------------------------------------------------------------'
				ELSE COALESCE(description, '')
			END AS [------description-----------------------------------------------------------------------------------------------------]
		FROM parsed_tokens
		ORDER BY
			param_group, 
			group_order;
		
		WITH
		a0 AS
		(SELECT 1 AS n UNION ALL SELECT 1),
		a1 AS
		(SELECT 1 AS n FROM a0 AS a, a0 AS b),
		a2 AS
		(SELECT 1 AS n FROM a1 AS a, a1 AS b),
		a3 AS
		(SELECT 1 AS n FROM a2 AS a, a2 AS b),
		a4 AS
		(SELECT 1 AS n FROM a3 AS a, a3 AS b),
		numbers AS
		(
			SELECT TOP(LEN(@outputs) - 1)
				ROW_NUMBER() OVER
				(
					ORDER BY (SELECT NULL)
				) AS number
			FROM a4
			ORDER BY
				number
		),
		tokens AS
		(
			SELECT 
				RTRIM(LTRIM(
					SUBSTRING
					(
						@outputs,
						number + 1,
						CASE
							WHEN 
								COALESCE(NULLIF(CHARINDEX(CHAR(13) + 'Formatted', @outputs, number + 1), 0), LEN(@outputs)) < 
								COALESCE(NULLIF(CHARINDEX(CHAR(13) + CHAR(255) COLLATE Latin1_General_Bin2, @outputs, number + 1), 0), LEN(@outputs))
								THEN COALESCE(NULLIF(CHARINDEX(CHAR(13) + 'Formatted', @outputs, number + 1), 0), LEN(@outputs)) - number - 1
							ELSE
								COALESCE(NULLIF(CHARINDEX(CHAR(13) + CHAR(255) COLLATE Latin1_General_Bin2, @outputs, number + 1), 0), LEN(@outputs)) - number - 1
						END
					)
				)) AS token,
				number,
				COALESCE(NULLIF(CHARINDEX(CHAR(13) + 'Formatted', @outputs, number + 1), 0), LEN(@outputs)) AS output_group,
				ROW_NUMBER() OVER
				(
					PARTITION BY 
						COALESCE(NULLIF(CHARINDEX(CHAR(13) + 'Formatted', @outputs, number + 1), 0), LEN(@outputs))
					ORDER BY
						number
				) AS output_group_order
			FROM numbers
			WHERE
				SUBSTRING(@outputs, number, 10) = CHAR(13) + 'Formatted'
				OR SUBSTRING(@outputs, number, 2) = CHAR(13) + CHAR(255) COLLATE Latin1_General_Bin2
		),
		output_tokens AS
		(
			SELECT 
				*,
				CASE output_group_order
					WHEN 2 THEN MAX(CASE output_group_order WHEN 1 THEN token ELSE NULL END) OVER (PARTITION BY output_group)
					ELSE ''
				END COLLATE Latin1_General_Bin2 AS column_info
			FROM tokens
		)
		SELECT
			CASE output_group_order
				WHEN 1 THEN '-----------------------------------'
				WHEN 2 THEN 
					CASE
						WHEN CHARINDEX('Formatted/Non:', column_info) = 1 THEN
							SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info)+1, CHARINDEX(']', column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info)+2) - CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info))
						ELSE
							SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info)+2, CHARINDEX(']', column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info)+2) - CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info)-1)
					END
				ELSE ''
			END AS formatted_column_name,
			CASE output_group_order
				WHEN 1 THEN '-----------------------------------'
				WHEN 2 THEN 
					CASE
						WHEN CHARINDEX('Formatted/Non:', column_info) = 1 THEN
							SUBSTRING(column_info, CHARINDEX(']', column_info)+2, LEN(column_info))
						ELSE
							SUBSTRING(column_info, CHARINDEX(']', column_info)+2, CHARINDEX('Non-Formatted:', column_info, CHARINDEX(']', column_info)+2) - CHARINDEX(']', column_info)-3)
					END
				ELSE ''
			END AS formatted_column_type,
			CASE output_group_order
				WHEN 1 THEN '---------------------------------------'
				WHEN 2 THEN 
					CASE
						WHEN CHARINDEX('Formatted/Non:', column_info) = 1 THEN ''
						ELSE
							CASE
								WHEN SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1, 1) = '<' THEN
									SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1, CHARINDEX('>', column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1) - CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info)))
								ELSE
									SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1, CHARINDEX(']', column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1) - CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info)))
							END
					END
				ELSE ''
			END AS unformatted_column_name,
			CASE output_group_order
				WHEN 1 THEN '---------------------------------------'
				WHEN 2 THEN 
					CASE
						WHEN CHARINDEX('Formatted/Non:', column_info) = 1 THEN ''
						ELSE
							CASE
								WHEN SUBSTRING(column_info, CHARINDEX(CHAR(255) COLLATE Latin1_General_Bin2, column_info, CHARINDEX('Non-Formatted:', column_info))+1, 1) = '<' THEN ''
								ELSE
									SUBSTRING(column_info, CHARINDEX(']', column_info, CHARINDEX('Non-Formatted:', column_info))+2, CHARINDEX('Non-Formatted:', column_info, CHARINDEX(']', column_info)+2) - CHARINDEX(']', column_info)-3)
							END
					END
				ELSE ''
			END AS unformatted_column_type,
			CASE output_group_order
				WHEN 1 THEN '----------------------------------------------------------------------------------------------------------------------'
				ELSE REPLACE(token, CHAR(255) COLLATE Latin1_General_Bin2, '')
			END AS [------description-----------------------------------------------------------------------------------------------------]
		FROM output_tokens
		WHERE
			NOT 
			(
				output_group_order = 1 
				AND output_group = LEN(@outputs)
			)
		ORDER BY
			output_group,
			CASE output_group_order
				WHEN 1 THEN 99
				ELSE output_group_order
			END;

		RETURN;
	END;

	WITH
	a0 AS
	(SELECT 1 AS n UNION ALL SELECT 1),
	a1 AS
	(SELECT 1 AS n FROM a0 AS a, a0 AS b),
	a2 AS
	(SELECT 1 AS n FROM a1 AS a, a1 AS b),
	a3 AS
	(SELECT 1 AS n FROM a2 AS a, a2 AS b),
	a4 AS
	(SELECT 1 AS n FROM a3 AS a, a3 AS b),
	numbers AS
	(
		SELECT TOP(LEN(@output_column_list))
			ROW_NUMBER() OVER
			(
				ORDER BY (SELECT NULL)
			) AS number
		FROM a4
		ORDER BY
			number
	),
	tokens AS
	(
		SELECT 
			'|[' +
				SUBSTRING
				(
					@output_column_list,
					number + 1,
					CHARINDEX(']', @output_column_list, number) - number - 1
				) + '|]' AS token,
			number
		FROM numbers
		WHERE
			SUBSTRING(@output_column_list, number, 1) = '['
	),
	ordered_columns AS
	(
		SELECT
			x.column_name,
			ROW_NUMBER() OVER
			(
				PARTITION BY
					x.column_name
				ORDER BY
					tokens.number,
					x.default_order
			) AS r,
			ROW_NUMBER() OVER
			(
				ORDER BY
					tokens.number,
					x.default_order
			) AS s
		FROM tokens
		JOIN
		(
			SELECT '[session_id]' AS column_name, 1 AS default_order
			UNION ALL
			SELECT '[dd hh:mm:ss.mss]', 2
			WHERE
				@format_output IN (1, 2)
			UNION ALL
			SELECT '[dd hh:mm:ss.mss (avg)]', 3
			WHERE
				@format_output IN (1, 2)
				AND @get_avg_time = 1
			UNION ALL
			SELECT '[avg_elapsed_time]', 4
			WHERE
				@format_output = 0
				AND @get_avg_time = 1
			UNION ALL
			SELECT '[physical_io]', 5
			WHERE
				@get_task_info = 2
			UNION ALL
			SELECT '[reads]', 6
			UNION ALL
			SELECT '[physical_reads]', 7
			UNION ALL
			SELECT '[writes]', 8
			UNION ALL
			SELECT '[tempdb_allocations]', 9
			UNION ALL
			SELECT '[tempdb_current]', 10
			UNION ALL
			SELECT '[CPU]', 11
			UNION ALL
			SELECT '[context_switches]', 12
			WHERE
				@get_task_info = 2
			UNION ALL
			SELECT '[used_memory]', 13
			UNION ALL
			SELECT '[physical_io_delta]', 14
			WHERE
				@delta_interval > 0	
				AND @get_task_info = 2
			UNION ALL
			SELECT '[reads_delta]', 15
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[physical_reads_delta]', 16
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[writes_delta]', 17
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[tempdb_allocations_delta]', 18
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[tempdb_current_delta]', 19
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[CPU_delta]', 20
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[context_switches_delta]', 21
			WHERE
				@delta_interval > 0
				AND @get_task_info = 2
			UNION ALL
			SELECT '[used_memory_delta]', 22
			WHERE
				@delta_interval > 0
			UNION ALL
			SELECT '[tasks]', 23
			WHERE
				@get_task_info = 2
			UNION ALL
			SELECT '[status]', 24
			UNION ALL
			SELECT '[wait_info]', 25
			WHERE
				@get_task_info > 0
				OR @find_block_leaders = 1
			UNION ALL
			SELECT '[locks]', 26
			WHERE
				@get_locks = 1
			UNION ALL
			SELECT '[tran_start_time]', 27
			WHERE
				@get_transaction_info = 1
			UNION ALL
			SELECT '[tran_log_writes]', 28
			WHERE
				@get_transaction_info = 1
			UNION ALL
			SELECT '[open_tran_count]', 29
			UNION ALL
			SELECT '[sql_command]', 30
			WHERE
				@get_outer_command = 1
			UNION ALL
			SELECT '[sql_text]', 31
			UNION ALL
			SELECT '[query_plan]', 32
			WHERE
				@get_plans >= 1
			UNION ALL
			SELECT '[blocking_session_id]', 33
			WHERE
				@get_task_info > 0
				OR @find_block_leaders = 1
			UNION ALL
			SELECT '[blocked_session_count]', 34
			WHERE
				@find_block_leaders = 1
			UNION ALL
			SELECT '[percent_complete]', 35
			UNION ALL
			SELECT '[host_name]', 36
			UNION ALL
			SELECT '[login_name]', 37
			UNION ALL
			SELECT '[database_name]', 38
			UNION ALL
			SELECT '[program_name]', 39
			UNION ALL
			SELECT '[additional_info]', 40
			WHERE
				@get_additional_info = 1
			UNION ALL
			SELECT '[start_time]', 41
			UNION ALL
			SELECT '[login_time]', 42
			UNION ALL
			SELECT '[request_id]', 43
			UNION ALL
			SELECT '[collection_time]', 44
		) AS x ON 
			x.column_name LIKE token ESCAPE '|'
	)
	SELECT
		@output_column_list =
			STUFF
			(
				(
					SELECT
						',' + column_name as [text()]
					FROM ordered_columns
					WHERE
						r = 1
					ORDER BY
						s
					FOR XML
						PATH('')
				),
				1,
				1,
				''
			);
	
	IF COALESCE(RTRIM(@output_column_list), '') = ''
	BEGIN;
		RAISERROR('No valid column matches found in @output_column_list or no columns remain due to selected options.', 16, 1);
		RETURN;
	END;
	
	IF @destination_table <> ''
	BEGIN;
		SET @destination_table = 
			--database
			COALESCE(QUOTENAME(PARSENAME(@destination_table, 3)) + '.', '') +
			--schema
			COALESCE(QUOTENAME(PARSENAME(@destination_table, 2)) + '.', '') +
			--table
			COALESCE(QUOTENAME(PARSENAME(@destination_table, 1)), '');
			
		IF COALESCE(RTRIM(@destination_table), '') = ''
		BEGIN;
			RAISERROR('Destination table not properly formatted.', 16, 1);
			RETURN;
		END;
	END;

	WITH
	a0 AS
	(SELECT 1 AS n UNION ALL SELECT 1),
	a1 AS
	(SELECT 1 AS n FROM a0 AS a, a0 AS b),
	a2 AS
	(SELECT 1 AS n FROM a1 AS a, a1 AS b),
	a3 AS
	(SELECT 1 AS n FROM a2 AS a, a2 AS b),
	a4 AS
	(SELECT 1 AS n FROM a3 AS a, a3 AS b),
	numbers AS
	(
		SELECT TOP(LEN(@sort_order))
			ROW_NUMBER() OVER
			(
				ORDER BY (SELECT NULL)
			) AS number
		FROM a4
		ORDER BY
			number
	),
	tokens AS
	(
		SELECT 
			'|[' +
				SUBSTRING
				(
					@sort_order,
					number + 1,
					CHARINDEX(']', @sort_order, number) - number - 1
				) + '|]' AS token,
			SUBSTRING
			(
				@sort_order,
				CHARINDEX(']', @sort_order, number) + 1,
				COALESCE(NULLIF(CHARINDEX('[', @sort_order, CHARINDEX(']', @sort_order, number)), 0), LEN(@sort_order)) - CHARINDEX(']', @sort_order, number)
			) AS next_chunk,
			number
		FROM numbers
		WHERE
			SUBSTRING(@sort_order, number, 1) = '['
	),
	ordered_columns AS
	(
		SELECT
			x.column_name +
				CASE
					WHEN tokens.next_chunk LIKE '%asc%' THEN ' ASC'
					WHEN tokens.next_chunk LIKE '%desc%' THEN ' DESC'
					ELSE ''
				END AS column_name,
			ROW_NUMBER() OVER
			(
				PARTITION BY
					x.column_name
				ORDER BY
					tokens.number
			) AS r,
			tokens.number
		FROM tokens
		JOIN
		(
			SELECT '[session_id]' AS column_name
			UNION ALL
			SELECT '[physical_io]'
			UNION ALL
			SELECT '[reads]'
			UNION ALL
			SELECT '[physical_reads]'
			UNION ALL
			SELECT '[writes]'
			UNION ALL
			SELECT '[tempdb_allocations]'
			UNION ALL
			SELECT '[tempdb_current]'
			UNION ALL
			SELECT '[CPU]'
			UNION ALL
			SELECT '[context_switches]'
			UNION ALL
			SELECT '[used_memory]'
			UNION ALL
			SELECT '[physical_io_delta]'
			UNION ALL
			SELECT '[reads_delta]'
			UNION ALL
			SELECT '[physical_reads_delta]'
			UNION ALL
			SELECT '[writes_delta]'
			UNION ALL
			SELECT '[tempdb_allocations_delta]'
			UNION ALL
			SELECT '[tempdb_current_delta]'
			UNION ALL
			SELECT '[CPU_delta]'
			UNION ALL
			SELECT '[context_switches_delta]'
			UNION ALL
			SELECT '[used_memory_delta]'
			UNION ALL
			SELECT '[tasks]'
			UNION ALL
			SELECT '[tran_start_time]'
			UNION ALL
			SELECT '[open_tran_count]'
			UNION ALL
			SELECT '[blocking_session_id]'
			UNION ALL
			SELECT '[blocked_session_count]'
			UNION ALL
			SELECT '[percent_complete]'
			UNION ALL
			SELECT '[host_name]'
			UNION ALL
			SELECT '[login_name]'
			UNION ALL
			SELECT '[database_name]'
			UNION ALL
			SELECT '[start_time]'
			UNION ALL
			SELECT '[login_time]'
			UNION ALL
			SELECT '[program_name]'
		) AS x ON 
			x.column_name LIKE token ESCAPE '|'
	)
	SELECT
		@sort_order = COALESCE(z.sort_order, '')
	FROM
	(
		SELECT
			STUFF
			(
				(
					SELECT
						',' + column_name as [text()]
					FROM ordered_columns
					WHERE
						r = 1
					ORDER BY
						number
					FOR XML
						PATH('')
				),
				1,
				1,
				''
			) AS sort_order
	) AS z;

	CREATE TABLE #sessions
	(
		recursion SMALLINT NOT NULL,
		session_id SMALLINT NOT NULL,
		request_id INT NOT NULL,
		session_number INT NOT NULL,
		elapsed_time INT NOT NULL,
		avg_elapsed_time INT NULL,
		physical_io BIGINT NULL,
		reads BIGINT NULL,
		physical_reads BIGINT NULL,
		writes BIGINT NULL,
		tempdb_allocations BIGINT NULL,
		tempdb_current BIGINT NULL,
		CPU INT NULL,
		thread_CPU_snapshot BIGINT NULL,
		context_switches BIGINT NULL,
		used_memory BIGINT NOT NULL, 
		tasks SMALLINT NULL,
		status VARCHAR(30) NOT NULL,
		wait_info NVARCHAR(4000) NULL,
		locks XML NULL,
		transaction_id BIGINT NULL,
		tran_start_time DATETIME NULL,
		tran_log_writes NVARCHAR(4000) NULL,
		open_tran_count SMALLINT NULL,
		sql_command XML NULL,
		sql_handle VARBINARY(64) NULL,
		statement_start_offset INT NULL,
		statement_end_offset INT NULL,
		sql_text XML NULL,
		plan_handle VARBINARY(64) NULL,
		query_plan XML NULL,
		blocking_session_id SMALLINT NULL,
		blocked_session_count SMALLINT NULL,
		percent_complete REAL NULL,
		host_name sysname NULL,
		login_name sysname NOT NULL,
		database_name sysname NULL,
		program_name sysname NULL,
		additional_info XML NULL,
		start_time DATETIME NOT NULL,
		login_time DATETIME NULL,
		last_request_start_time DATETIME NULL,
		PRIMARY KEY CLUSTERED (session_id, request_id, recursion) WITH (IGNORE_DUP_KEY = ON),
		UNIQUE NONCLUSTERED (transaction_id, session_id, request_id, recursion) WITH (IGNORE_DUP_KEY = ON)
	);

	IF @return_schema = 0
	BEGIN;
		--Disable unnecessary autostats on the table
		CREATE STATISTICS s_session_id ON #sessions (session_id)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_request_id ON #sessions (request_id)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_transaction_id ON #sessions (transaction_id)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_session_number ON #sessions (session_number)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_status ON #sessions (status)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_start_time ON #sessions (start_time)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_last_request_start_time ON #sessions (last_request_start_time)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;
		CREATE STATISTICS s_recursion ON #sessions (recursion)
		WITH SAMPLE 0 ROWS, NORECOMPUTE;

		DECLARE @recursion SMALLINT;
		SET @recursion = 
			CASE @delta_interval
				WHEN 0 THEN 1
				ELSE -1
			END;

		DECLARE @first_collection_ms_ticks BIGINT;
		DECLARE @last_collection_start DATETIME;

		--Used for the delta pull
		REDO:;
		
		IF 
			@get_locks = 1 
			AND @recursion = 1
			AND @output_column_list LIKE '%|[locks|]%' ESCAPE '|'
		BEGIN;
			SELECT
				y.resource_type,
				y.database_name,
				y.object_id,
				y.file_id,
				y.page_type,
				y.hobt_id,
				y.allocation_unit_id,
				y.index_id,
				y.schema_id,
				y.principal_id,
				y.request_mode,
				y.request_status,
				y.session_id,
				y.resource_description,
				y.request_count,
				s.request_id,
				s.start_time,
				CONVERT(sysname, NULL) AS object_name,
				CONVERT(sysname, NULL) AS index_name,
				CONVERT(sysname, NULL) AS schema_name,
				CONVERT(sysname, NULL) AS principal_name,
				CONVERT(NVARCHAR(2048), NULL) AS query_error
			INTO #locks
			FROM
			(
				SELECT
					sp.spid AS session_id,
					CASE sp.status
						WHEN 'sleeping' THEN CONVERT(INT, 0)
						ELSE sp.request_id
					END AS request_id,
					CASE sp.status
						WHEN 'sleeping' THEN sp.last_batch
						ELSE COALESCE(req.start_time, sp.last_batch)
					END AS start_time,
					sp.dbid
				FROM sys.sysprocesses AS sp
				OUTER APPLY
				(
					SELECT TOP(1)
						CASE
							WHEN 
							(
								sp.hostprocess > ''
								OR r.total_elapsed_time < 0
							) THEN
								r.start_time
							ELSE
								DATEADD
								(
									ms, 
									1000 * (DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())) / 500) - DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())), 
									DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())
								)
						END AS start_time
					FROM sys.dm_exec_requests AS r
					WHERE
						r.session_id = sp.spid
						AND r.request_id = sp.request_id
				) AS req
				WHERE
					--Process inclusive filter
					1 =
						CASE
							WHEN @filter <> '' THEN
								CASE @filter_type
									WHEN 'session' THEN
										CASE
											WHEN
												CONVERT(SMALLINT, @filter) = 0
												OR sp.spid = CONVERT(SMALLINT, @filter)
													THEN 1
											ELSE 0
										END
									WHEN 'program' THEN
										CASE
											WHEN sp.program_name LIKE @filter THEN 1
											ELSE 0
										END
									WHEN 'login' THEN
										CASE
											WHEN sp.loginame LIKE @filter THEN 1
											ELSE 0
										END
									WHEN 'host' THEN
										CASE
											WHEN sp.hostname LIKE @filter THEN 1
											ELSE 0
										END
									WHEN 'database' THEN
										CASE
											WHEN DB_NAME(sp.dbid) LIKE @filter THEN 1
											ELSE 0
										END
									ELSE 0
								END
							ELSE 1
						END
					--Process exclusive filter
					AND 0 =
						CASE
							WHEN @not_filter <> '' THEN
								CASE @not_filter_type
									WHEN 'session' THEN
										CASE
											WHEN sp.spid = CONVERT(SMALLINT, @not_filter) THEN 1
											ELSE 0
										END
									WHEN 'program' THEN
										CASE
											WHEN sp.program_name LIKE @not_filter THEN 1
											ELSE 0
										END
									WHEN 'login' THEN
										CASE
											WHEN sp.loginame LIKE @not_filter THEN 1
											ELSE 0
										END
									WHEN 'host' THEN
										CASE
											WHEN sp.hostname LIKE @not_filter THEN 1
											ELSE 0
										END
									WHEN 'database' THEN
										CASE
											WHEN DB_NAME(sp.dbid) LIKE @not_filter THEN 1
											ELSE 0
										END
									ELSE 0
								END
							ELSE 0
						END
					AND 
					(
						@show_own_spid = 1
						OR sp.spid <> @@SPID
					)
					AND 
					(
						@show_system_spids = 1
						OR sp.hostprocess > ''
					)
					AND sp.ecid = 0
			) AS s
			INNER HASH JOIN
			(
				SELECT
					x.resource_type,
					x.database_name,
					x.object_id,
					x.file_id,
					CASE
						WHEN x.page_no = 1 OR x.page_no % 8088 = 0 THEN 'PFS'
						WHEN x.page_no = 2 OR x.page_no % 511232 = 0 THEN 'GAM'
						WHEN x.page_no = 3 OR (x.page_no - 1) % 511232 = 0 THEN 'SGAM'
						WHEN x.page_no = 6 OR (x.page_no - 6) % 511232 = 0 THEN 'DCM'
						WHEN x.page_no = 7 OR (x.page_no - 7) % 511232 = 0 THEN 'BCM'
						WHEN x.page_no IS NOT NULL THEN '*'
						ELSE NULL
					END AS page_type,
					x.hobt_id,
					x.allocation_unit_id,
					x.index_id,
					x.schema_id,
					x.principal_id,
					x.request_mode,
					x.request_status,
					x.session_id,
					x.request_id,
					CASE
						WHEN COALESCE(x.object_id, x.file_id, x.hobt_id, x.allocation_unit_id, x.index_id, x.schema_id, x.principal_id) IS NULL THEN NULLIF(resource_description, '')
						ELSE NULL
					END AS resource_description,
					COUNT(*) AS request_count
				FROM
				(
					SELECT
						tl.resource_type +
							CASE
								WHEN tl.resource_subtype = '' THEN ''
								ELSE '.' + tl.resource_subtype
							END AS resource_type,
						COALESCE(DB_NAME(tl.resource_database_id), N'(null)') AS database_name,
						CONVERT
						(
							INT,
							CASE
								WHEN tl.resource_type = 'OBJECT' THEN tl.resource_associated_entity_id
								WHEN tl.resource_description LIKE '%object_id = %' THEN
									(
										SUBSTRING
										(
											tl.resource_description, 
											(CHARINDEX('object_id = ', tl.resource_description) + 12), 
											COALESCE
											(
												NULLIF
												(
													CHARINDEX(',', tl.resource_description, CHARINDEX('object_id = ', tl.resource_description) + 12),
													0
												), 
												DATALENGTH(tl.resource_description)+1
											) - (CHARINDEX('object_id = ', tl.resource_description) + 12)
										)
									)
								ELSE NULL
							END
						) AS object_id,
						CONVERT
						(
							INT,
							CASE 
								WHEN tl.resource_type = 'FILE' THEN CONVERT(INT, tl.resource_description)
								WHEN tl.resource_type IN ('PAGE', 'EXTENT', 'RID') THEN LEFT(tl.resource_description, CHARINDEX(':', tl.resource_description)-1)
								ELSE NULL
							END
						) AS file_id,
						CONVERT
						(
							INT,
							CASE
								WHEN tl.resource_type IN ('PAGE', 'EXTENT', 'RID') THEN 
									SUBSTRING
									(
										tl.resource_description, 
										CHARINDEX(':', tl.resource_description) + 1, 
										COALESCE
										(
											NULLIF
											(
												CHARINDEX(':', tl.resource_description, CHARINDEX(':', tl.resource_description) + 1), 
												0
											), 
											DATALENGTH(tl.resource_description)+1
										) - (CHARINDEX(':', tl.resource_description) + 1)
									)
								ELSE NULL
							END
						) AS page_no,
						CASE
							WHEN tl.resource_type IN ('PAGE', 'KEY', 'RID', 'HOBT') THEN tl.resource_associated_entity_id
							ELSE NULL
						END AS hobt_id,
						CASE
							WHEN tl.resource_type = 'ALLOCATION_UNIT' THEN tl.resource_associated_entity_id
							ELSE NULL
						END AS allocation_unit_id,
						CONVERT
						(
							INT,
							CASE
								WHEN
									/*TODO: Deal with server principals*/ 
									tl.resource_subtype <> 'SERVER_PRINCIPAL' 
									AND tl.resource_description LIKE '%index_id or stats_id = %' THEN
									(
										SUBSTRING
										(
											tl.resource_description, 
											(CHARINDEX('index_id or stats_id = ', tl.resource_description) + 23), 
											COALESCE
											(
												NULLIF
												(
													CHARINDEX(',', tl.resource_description, CHARINDEX('index_id or stats_id = ', tl.resource_description) + 23), 
													0
												), 
												DATALENGTH(tl.resource_description)+1
											) - (CHARINDEX('index_id or stats_id = ', tl.resource_description) + 23)
										)
									)
								ELSE NULL
							END 
						) AS index_id,
						CONVERT
						(
							INT,
							CASE
								WHEN tl.resource_description LIKE '%schema_id = %' THEN
									(
										SUBSTRING
										(
											tl.resource_description, 
											(CHARINDEX('schema_id = ', tl.resource_description) + 12), 
											COALESCE
											(
												NULLIF
												(
													CHARINDEX(',', tl.resource_description, CHARINDEX('schema_id = ', tl.resource_description) + 12), 
													0
												), 
												DATALENGTH(tl.resource_description)+1
											) - (CHARINDEX('schema_id = ', tl.resource_description) + 12)
										)
									)
								ELSE NULL
							END 
						) AS schema_id,
						CONVERT
						(
							INT,
							CASE
								WHEN tl.resource_description LIKE '%principal_id = %' THEN
									(
										SUBSTRING
										(
											tl.resource_description, 
											(CHARINDEX('principal_id = ', tl.resource_description) + 15), 
											COALESCE
											(
												NULLIF
												(
													CHARINDEX(',', tl.resource_description, CHARINDEX('principal_id = ', tl.resource_description) + 15), 
													0
												), 
												DATALENGTH(tl.resource_description)+1
											) - (CHARINDEX('principal_id = ', tl.resource_description) + 15)
										)
									)
								ELSE NULL
							END
						) AS principal_id,
						tl.request_mode,
						tl.request_status,
						tl.request_session_id AS session_id,
						tl.request_request_id AS request_id,

						/*TODO: Applocks, other resource_descriptions*/
						RTRIM(tl.resource_description) AS resource_description,
						tl.resource_associated_entity_id
						/*********************************************/
					FROM 
					(
						SELECT 
							request_session_id,
							CONVERT(VARCHAR(120), resource_type) COLLATE Latin1_General_Bin2 AS resource_type,
							CONVERT(VARCHAR(120), resource_subtype) COLLATE Latin1_General_Bin2 AS resource_subtype,
							resource_database_id,
							CONVERT(VARCHAR(512), resource_description) COLLATE Latin1_General_Bin2 AS resource_description,
							resource_associated_entity_id,
							CONVERT(VARCHAR(120), request_mode) COLLATE Latin1_General_Bin2 AS request_mode,
							CONVERT(VARCHAR(120), request_status) COLLATE Latin1_General_Bin2 AS request_status,
							request_request_id
						FROM sys.dm_tran_locks
					) AS tl
				) AS x
				GROUP BY
					x.resource_type,
					x.database_name,
					x.object_id,
					x.file_id,
					CASE
						WHEN x.page_no = 1 OR x.page_no % 8088 = 0 THEN 'PFS'
						WHEN x.page_no = 2 OR x.page_no % 511232 = 0 THEN 'GAM'
						WHEN x.page_no = 3 OR (x.page_no - 1) % 511232 = 0 THEN 'SGAM'
						WHEN x.page_no = 6 OR (x.page_no - 6) % 511232 = 0 THEN 'DCM'
						WHEN x.page_no = 7 OR (x.page_no - 7) % 511232 = 0 THEN 'BCM'
						WHEN x.page_no IS NOT NULL THEN '*'
						ELSE NULL
					END,
					x.hobt_id,
					x.allocation_unit_id,
					x.index_id,
					x.schema_id,
					x.principal_id,
					x.request_mode,
					x.request_status,
					x.session_id,
					x.request_id,
					CASE
						WHEN COALESCE(x.object_id, x.file_id, x.hobt_id, x.allocation_unit_id, x.index_id, x.schema_id, x.principal_id) IS NULL THEN NULLIF(resource_description, '')
						ELSE NULL
					END
			) AS y ON
				y.session_id = s.session_id
				AND y.request_id = s.request_id
			OPTION (HASH GROUP);

			--Disable unnecessary autostats on the table
			CREATE STATISTICS s_database_name ON #locks (database_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_object_id ON #locks (object_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_hobt_id ON #locks (hobt_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_allocation_unit_id ON #locks (allocation_unit_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_index_id ON #locks (index_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_schema_id ON #locks (schema_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_principal_id ON #locks (principal_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_request_id ON #locks (request_id)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_start_time ON #locks (start_time)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_resource_type ON #locks (resource_type)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_object_name ON #locks (object_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_schema_name ON #locks (schema_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_page_type ON #locks (page_type)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_request_mode ON #locks (request_mode)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_request_status ON #locks (request_status)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_resource_description ON #locks (resource_description)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_index_name ON #locks (index_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_principal_name ON #locks (principal_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
		END;
		
		DECLARE 
			@sql VARCHAR(MAX), 
			@sql_n NVARCHAR(MAX);

		SET @sql = 
			CONVERT(VARCHAR(MAX), '') +
			'DECLARE @blocker BIT;
			SET @blocker = 0;
			DECLARE @i INT;
			SET @i = 2147483647;

			DECLARE @sessions TABLE
			(
				session_id SMALLINT NOT NULL,
				request_id INT NOT NULL,
				login_time DATETIME,
				last_request_end_time DATETIME,
				status VARCHAR(30),
				statement_start_offset INT,
				statement_end_offset INT,
				sql_handle BINARY(20),
				host_name NVARCHAR(128),
				login_name NVARCHAR(128),
				program_name NVARCHAR(128),
				database_id SMALLINT,
				memory_usage INT,
				open_tran_count SMALLINT, 
				' +
				CASE
					WHEN 
					(
						@get_task_info <> 0 
						OR @find_block_leaders = 1 
					) THEN
						'wait_type NVARCHAR(32),
						wait_resource NVARCHAR(256),
						wait_time BIGINT, 
						'
					ELSE 
						''
				END +
				'blocked SMALLINT,
				is_user_process BIT,
				cmd VARCHAR(32),
				PRIMARY KEY CLUSTERED (session_id, request_id) WITH (IGNORE_DUP_KEY = ON)
			);

			DECLARE @blockers TABLE
			(
				session_id INT NOT NULL PRIMARY KEY WITH (IGNORE_DUP_KEY = ON)
			);

			BLOCKERS:;

			INSERT @sessions
			(
				session_id,
				request_id,
				login_time,
				last_request_end_time,
				status,
				statement_start_offset,
				statement_end_offset,
				sql_handle,
				host_name,
				login_name,
				program_name,
				database_id,
				memory_usage,
				open_tran_count, 
				' +
				CASE
					WHEN 
					(
						@get_task_info <> 0
						OR @find_block_leaders = 1 
					) THEN
						'wait_type,
						wait_resource,
						wait_time, 
						'
					ELSE
						''
				END +
				'blocked,
				is_user_process,
				cmd 
			)
			SELECT TOP(@i)
				spy.session_id,
				spy.request_id,
				spy.login_time,
				spy.last_request_end_time,
				spy.status,
				spy.statement_start_offset,
				spy.statement_end_offset,
				spy.sql_handle,
				spy.host_name,
				spy.login_name,
				spy.program_name,
				spy.database_id,
				spy.memory_usage,
				spy.open_tran_count,
				' +
				CASE
					WHEN 
					(
						@get_task_info <> 0  
						OR @find_block_leaders = 1 
					) THEN
						'spy.wait_type,
						CASE
							WHEN
								spy.wait_type LIKE N''PAGE%LATCH_%''
								OR spy.wait_type = N''CXPACKET''
								OR spy.wait_type LIKE N''LATCH[_]%''
								OR spy.wait_type = N''OLEDB'' THEN
									spy.wait_resource
							ELSE
								NULL
						END AS wait_resource,
						spy.wait_time, 
						'
					ELSE
						''
				END +
				'spy.blocked,
				spy.is_user_process,
				spy.cmd
			FROM
			(
				SELECT TOP(@i)
					spx.*, 
					' +
					CASE
						WHEN 
						(
							@get_task_info <> 0 
							OR @find_block_leaders = 1 
						) THEN
							'ROW_NUMBER() OVER
							(
								PARTITION BY
									spx.session_id,
									spx.request_id
								ORDER BY
									CASE
										WHEN spx.wait_type LIKE N''LCK[_]%'' THEN 
											1
										ELSE
											99
									END,
									spx.wait_time DESC,
									spx.blocked DESC
							) AS r 
							'
						ELSE 
							'1 AS r 
							'
					END +
				'FROM
				(
					SELECT TOP(@i)
						sp0.session_id,
						sp0.request_id,
						sp0.login_time,
						sp0.last_request_end_time,
						LOWER(sp0.status) AS status,
						CASE
							WHEN sp0.cmd = ''CREATE INDEX'' THEN
								0
							ELSE
								sp0.stmt_start
						END AS statement_start_offset,
						CASE
							WHEN sp0.cmd = N''CREATE INDEX'' THEN
								-1
							ELSE
								COALESCE(NULLIF(sp0.stmt_end, 0), -1)
						END AS statement_end_offset,
						sp0.sql_handle,
						sp0.host_name,
						sp0.login_name,
						sp0.program_name,
						sp0.database_id,
						sp0.memory_usage,
						sp0.open_tran_count, 
						' +
						CASE
							WHEN 
							(
								@get_task_info <> 0 
								OR @find_block_leaders = 1 
							) THEN
								'CASE
									WHEN sp0.wait_time > 0 AND sp0.wait_type <> N''CXPACKET'' THEN
										sp0.wait_type
									ELSE
										NULL
								END AS wait_type,
								CASE
									WHEN sp0.wait_time > 0 AND sp0.wait_type <> N''CXPACKET'' THEN 
										sp0.wait_resource
									ELSE
										NULL
								END AS wait_resource,
								CASE
									WHEN sp0.wait_type <> N''CXPACKET'' THEN
										sp0.wait_time
									ELSE
										0
								END AS wait_time, 
								'
							ELSE
								''
						END +
						'sp0.blocked,
						sp0.is_user_process,
						sp0.cmd
					FROM
					(
						SELECT TOP(@i)
							sp1.session_id,
							sp1.request_id,
							sp1.login_time,
							sp1.last_request_end_time,
							sp1.status,
							sp1.cmd,
							sp1.stmt_start,
							sp1.stmt_end,
							MAX(NULLIF(sp1.sql_handle, 0x00)) OVER (PARTITION BY sp1.session_id, sp1.request_id) AS sql_handle,
							sp1.host_name,
							MAX(sp1.login_name) OVER (PARTITION BY sp1.session_id, sp1.request_id) AS login_name,
							sp1.program_name,
							sp1.database_id,
							MAX(sp1.memory_usage)  OVER (PARTITION BY sp1.session_id, sp1.request_id) AS memory_usage,
							MAX(sp1.open_tran_count)  OVER (PARTITION BY sp1.session_id, sp1.request_id) AS open_tran_count,
							sp1.wait_type,
							sp1.wait_resource,
							sp1.wait_time,
							sp1.blocked,
							sp1.hostprocess,
							sp1.is_user_process
						FROM
						(
							SELECT TOP(@i)
								sp2.spid AS session_id,
								CASE sp2.status
									WHEN ''sleeping'' THEN
										CONVERT(INT, 0)
									ELSE
										sp2.request_id
								END AS request_id,
								MAX(sp2.login_time) AS login_time,
								MAX(sp2.last_batch) AS last_request_end_time,
								MAX(CONVERT(VARCHAR(30), RTRIM(sp2.status)) COLLATE Latin1_General_Bin2) AS status,
								MAX(CONVERT(VARCHAR(32), RTRIM(sp2.cmd)) COLLATE Latin1_General_Bin2) AS cmd,
								MAX(sp2.stmt_start) AS stmt_start,
								MAX(sp2.stmt_end) AS stmt_end,
								MAX(sp2.sql_handle) AS sql_handle,
								MAX(CONVERT(sysname, RTRIM(sp2.hostname)) COLLATE SQL_Latin1_General_CP1_CI_AS) AS host_name,
								MAX(CONVERT(sysname, RTRIM(sp2.loginame)) COLLATE SQL_Latin1_General_CP1_CI_AS) AS login_name,
								MAX
								(
									CASE
										WHEN blk.queue_id IS NOT NULL THEN
											N''Service Broker
												database_id: '' + CONVERT(NVARCHAR, blk.database_id) +
												N'' queue_id: '' + CONVERT(NVARCHAR, blk.queue_id)
										ELSE
											CONVERT
											(
												sysname,
												RTRIM(sp2.program_name)
											)
									END COLLATE SQL_Latin1_General_CP1_CI_AS
								) AS program_name,
								MAX(sp2.dbid) AS database_id,
								MAX(sp2.memusage) AS memory_usage,
								MAX(sp2.open_tran) AS open_tran_count,
								RTRIM(sp2.lastwaittype) AS wait_type,
								RTRIM(sp2.waitresource) AS wait_resource,
								MAX(sp2.waittime) AS wait_time,
								COALESCE(NULLIF(sp2.blocked, sp2.spid), 0) AS blocked,
								MAX
								(
									CASE
										WHEN blk.session_id = sp2.spid THEN
											''blocker''
										ELSE
											RTRIM(sp2.hostprocess)
									END
								) AS hostprocess,
								CONVERT
								(
									BIT,
									MAX
									(
										CASE
											WHEN sp2.hostprocess > '''' THEN
												1
											ELSE
												0
										END
									)
								) AS is_user_process
							FROM
							(
								SELECT TOP(@i)
									session_id,
									CONVERT(INT, NULL) AS queue_id,
									CONVERT(INT, NULL) AS database_id
								FROM @blockers

								UNION ALL

								SELECT TOP(@i)
									CONVERT(SMALLINT, 0),
									CONVERT(INT, NULL) AS queue_id,
									CONVERT(INT, NULL) AS database_id
								WHERE
									@blocker = 0

								UNION ALL

								SELECT TOP(@i)
									CONVERT(SMALLINT, spid),
									queue_id,
									database_id
								FROM sys.dm_broker_activated_tasks
								WHERE
									@blocker = 0
							) AS blk
							INNER JOIN sys.sysprocesses AS sp2 ON
								sp2.spid = blk.session_id
								OR
								(
									blk.session_id = 0
									AND @blocker = 0
								)
							' +
							CASE 
								WHEN 
								(
									@get_task_info = 0 
									AND @find_block_leaders = 0
								) THEN
									'WHERE
										sp2.ecid = 0 
									' 
								ELSE
									''
							END +
							'GROUP BY
								sp2.spid,
								CASE sp2.status
									WHEN ''sleeping'' THEN
										CONVERT(INT, 0)
									ELSE
										sp2.request_id
								END,
								RTRIM(sp2.lastwaittype),
								RTRIM(sp2.waitresource),
								COALESCE(NULLIF(sp2.blocked, sp2.spid), 0)
						) AS sp1
					) AS sp0
					WHERE
						@blocker = 1
						OR
						(1=1 
						' +
							--inclusive filter
							CASE
								WHEN @filter <> '' THEN
									CASE @filter_type
										WHEN 'session' THEN
											CASE
												WHEN CONVERT(SMALLINT, @filter) <> 0 THEN
													'AND sp0.session_id = CONVERT(SMALLINT, @filter) 
													'
												ELSE
													''
											END
										WHEN 'program' THEN
											'AND sp0.program_name LIKE @filter 
											'
										WHEN 'login' THEN
											'AND sp0.login_name LIKE @filter 
											'
										WHEN 'host' THEN
											'AND sp0.host_name LIKE @filter 
											'
										WHEN 'database' THEN
											'AND DB_NAME(sp0.database_id) LIKE @filter 
											'
										ELSE
											''
									END
								ELSE
									''
							END +
							--exclusive filter
							CASE
								WHEN @not_filter <> '' THEN
									CASE @not_filter_type
										WHEN 'session' THEN
											CASE
												WHEN CONVERT(SMALLINT, @not_filter) <> 0 THEN
													'AND sp0.session_id <> CONVERT(SMALLINT, @not_filter) 
													'
												ELSE
													''
											END
										WHEN 'program' THEN
											'AND sp0.program_name NOT LIKE @not_filter 
											'
										WHEN 'login' THEN
											'AND sp0.login_name NOT LIKE @not_filter 
											'
										WHEN 'host' THEN
											'AND sp0.host_name NOT LIKE @not_filter 
											'
										WHEN 'database' THEN
											'AND DB_NAME(sp0.database_id) NOT LIKE @not_filter 
											'
										ELSE
											''
									END
								ELSE
									''
							END +
							CASE @show_own_spid
								WHEN 1 THEN
									''
								ELSE
									'AND sp0.session_id <> @@spid 
									'
							END +
							CASE 
								WHEN @show_system_spids = 0 THEN
									'AND sp0.hostprocess > '''' 
									' 
								ELSE
									''
							END +
							CASE @show_sleeping_spids
								WHEN 0 THEN
									'AND sp0.status <> ''sleeping'' 
									'
								WHEN 1 THEN
									'AND
									(
										sp0.status <> ''sleeping''
										OR sp0.open_tran_count > 0
									)
									'
								ELSE
									''
							END +
						')
				) AS spx
			) AS spy
			WHERE
				spy.r = 1; 
			' + 
			CASE @recursion
				WHEN 1 THEN 
					'IF @@ROWCOUNT > 0
					BEGIN;
						INSERT @blockers
						(
							session_id
						)
						SELECT TOP(@i)
							blocked
						FROM @sessions
						WHERE
							NULLIF(blocked, 0) IS NOT NULL

						EXCEPT

						SELECT TOP(@i)
							session_id
						FROM @sessions; 
						' +

						CASE
							WHEN
							(
								@get_task_info > 0
								OR @find_block_leaders = 1
							) THEN
								'IF @@ROWCOUNT > 0
								BEGIN;
									SET @blocker = 1;
									GOTO BLOCKERS;
								END; 
								'
							ELSE 
								''
						END +
					'END; 
					'
				ELSE 
					''
			END +
			'SELECT TOP(@i)
				@recursion AS recursion,
				x.session_id,
				x.request_id,
				DENSE_RANK() OVER
				(
					ORDER BY
						x.session_id
				) AS session_number,
				' +
				CASE
					WHEN @output_column_list LIKE '%|[dd hh:mm:ss.mss|]%' ESCAPE '|' THEN 
						'x.elapsed_time '
					ELSE 
						'0 '
				END + 
					'AS elapsed_time, 
					' +
				CASE
					WHEN
						(
							@output_column_list LIKE '%|[dd hh:mm:ss.mss (avg)|]%' ESCAPE '|' OR 
							@output_column_list LIKE '%|[avg_elapsed_time|]%' ESCAPE '|'
						)
						AND @recursion = 1
							THEN 
								'x.avg_elapsed_time / 1000 '
					ELSE 
						'NULL '
				END + 
					'AS avg_elapsed_time, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[physical_io|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[physical_io_delta|]%' ESCAPE '|'
							THEN 
								'x.physical_io '
					ELSE 
						'NULL '
				END + 
					'AS physical_io, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[reads|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[reads_delta|]%' ESCAPE '|'
							THEN 
								'x.reads '
					ELSE 
						'0 '
				END + 
					'AS reads, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[physical_reads|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[physical_reads_delta|]%' ESCAPE '|'
							THEN 
								'x.physical_reads '
					ELSE 
						'0 '
				END + 
					'AS physical_reads, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[writes|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[writes_delta|]%' ESCAPE '|'
							THEN 
								'x.writes '
					ELSE 
						'0 '
				END + 
					'AS writes, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[tempdb_allocations|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[tempdb_allocations_delta|]%' ESCAPE '|'
							THEN 
								'x.tempdb_allocations '
					ELSE 
						'0 '
				END + 
					'AS tempdb_allocations, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[tempdb_current|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[tempdb_current_delta|]%' ESCAPE '|'
							THEN 
								'x.tempdb_current '
					ELSE 
						'0 '
				END + 
					'AS tempdb_current, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[CPU|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[CPU_delta|]%' ESCAPE '|'
							THEN
								'x.CPU '
					ELSE
						'0 '
				END + 
					'AS CPU, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[CPU_delta|]%' ESCAPE '|'
						AND @get_task_info = 2
							THEN 
								'x.thread_CPU_snapshot '
					ELSE 
						'0 '
				END + 
					'AS thread_CPU_snapshot, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[context_switches|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[context_switches_delta|]%' ESCAPE '|'
							THEN 
								'x.context_switches '
					ELSE 
						'NULL '
				END + 
					'AS context_switches, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[used_memory|]%' ESCAPE '|'
						OR @output_column_list LIKE '%|[used_memory_delta|]%' ESCAPE '|'
							THEN 
								'x.used_memory '
					ELSE 
						'0 '
				END + 
					'AS used_memory, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[tasks|]%' ESCAPE '|'
						AND @recursion = 1
							THEN 
								'x.tasks '
					ELSE 
						'NULL '
				END + 
					'AS tasks, 
					' +
				CASE
					WHEN 
						(
							@output_column_list LIKE '%|[status|]%' ESCAPE '|' 
							OR @output_column_list LIKE '%|[sql_command|]%' ESCAPE '|'
						)
						AND @recursion = 1
							THEN 
								'x.status '
					ELSE 
						''''' '
				END + 
					'AS status, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[wait_info|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								CASE @get_task_info
									WHEN 2 THEN
										'COALESCE(x.task_wait_info, x.sys_wait_info) '
									ELSE
										'x.sys_wait_info '
								END
					ELSE 
						'NULL '
				END + 
					'AS wait_info, 
					' +
				CASE
					WHEN 
						(
							@output_column_list LIKE '%|[tran_start_time|]%' ESCAPE '|' 
							OR @output_column_list LIKE '%|[tran_log_writes|]%' ESCAPE '|' 
						)
						AND @recursion = 1
							THEN 
								'x.transaction_id '
					ELSE 
						'NULL '
				END + 
					'AS transaction_id, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[open_tran_count|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.open_tran_count '
					ELSE 
						'NULL '
				END + 
					'AS open_tran_count, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[sql_text|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.sql_handle '
					ELSE 
						'NULL '
				END + 
					'AS sql_handle, 
					' +
				CASE
					WHEN 
						(
							@output_column_list LIKE '%|[sql_text|]%' ESCAPE '|' 
							OR @output_column_list LIKE '%|[query_plan|]%' ESCAPE '|' 
						)
						AND @recursion = 1
							THEN 
								'x.statement_start_offset '
					ELSE 
						'NULL '
				END + 
					'AS statement_start_offset, 
					' +
				CASE
					WHEN 
						(
							@output_column_list LIKE '%|[sql_text|]%' ESCAPE '|' 
							OR @output_column_list LIKE '%|[query_plan|]%' ESCAPE '|' 
						)
						AND @recursion = 1
							THEN 
								'x.statement_end_offset '
					ELSE 
						'NULL '
				END + 
					'AS statement_end_offset, 
					' +
				'NULL AS sql_text, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[query_plan|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.plan_handle '
					ELSE 
						'NULL '
				END + 
					'AS plan_handle, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[blocking_session_id|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'NULLIF(x.blocking_session_id, 0) '
					ELSE 
						'NULL '
				END + 
					'AS blocking_session_id, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[percent_complete|]%' ESCAPE '|'
						AND @recursion = 1
							THEN 
								'x.percent_complete '
					ELSE 
						'NULL '
				END + 
					'AS percent_complete, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[host_name|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.host_name '
					ELSE 
						''''' '
				END + 
					'AS host_name, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[login_name|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.login_name '
					ELSE 
						''''' '
				END + 
					'AS login_name, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[database_name|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'DB_NAME(x.database_id) '
					ELSE 
						'NULL '
				END + 
					'AS database_name, 
					' +
				CASE
					WHEN 
						@output_column_list LIKE '%|[program_name|]%' ESCAPE '|' 
						AND @recursion = 1
							THEN 
								'x.program_name '
					ELSE 
						''''' '
				END + 
					'AS program_name, 
					' +
				CASE
					WHEN
						@output_column_list LIKE '%|[additional_info|]%' ESCAPE '|'
						AND @recursion = 1
							THEN
								'(
									SELECT TOP(@i)
										x.text_size,
										x.language,
										x.date_format,
										x.date_first,
										CASE x.quoted_identifier
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS quoted_identifier,
										CASE x.arithabort
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS arithabort,
										CASE x.ansi_null_dflt_on
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS ansi_null_dflt_on,
										CASE x.ansi_defaults
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS ansi_defaults,
										CASE x.ansi_warnings
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS ansi_warnings,
										CASE x.ansi_padding
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS ansi_padding,
										CASE ansi_nulls
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS ansi_nulls,
										CASE x.concat_null_yields_null
											WHEN 0 THEN ''OFF''
											WHEN 1 THEN ''ON''
										END AS concat_null_yields_null,
										CASE x.transaction_isolation_level
											WHEN 0 THEN ''Unspecified''
											WHEN 1 THEN ''ReadUncomitted''
											WHEN 2 THEN ''ReadCommitted''
											WHEN 3 THEN ''Repeatable''
											WHEN 4 THEN ''Serializable''
											WHEN 5 THEN ''Snapshot''
										END AS transaction_isolation_level,
										x.lock_timeout,
										x.deadlock_priority,
										x.row_count,
										x.command_type, 
										master.dbo.fn_varbintohexstr(x.sql_handle) AS sql_handle,
										master.dbo.fn_varbintohexstr(x.plan_handle) AS plan_handle,
										' +
										CASE
											WHEN @output_column_list LIKE '%|[program_name|]%' ESCAPE '|' THEN
												'(
													SELECT TOP(1)
														CONVERT(uniqueidentifier, CONVERT(XML, '''').value(''xs:hexBinary( substring(sql:column("agent_info.job_id_string"), 0) )'', ''binary(16)'')) AS job_id,
														agent_info.step_id,
														(
															SELECT TOP(1)
																NULL
															FOR XML
																PATH(''job_name''),
																TYPE
														),
														(
															SELECT TOP(1)
																NULL
															FOR XML
																PATH(''step_name''),
																TYPE
														)
													FROM
													(
														SELECT TOP(1)
															SUBSTRING(x.program_name, CHARINDEX(''0x'', x.program_name) + 2, 32) AS job_id_string,
															SUBSTRING(x.program_name, CHARINDEX('': Step '', x.program_name) + 7, CHARINDEX('')'', x.program_name, CHARINDEX('': Step '', x.program_name)) - (CHARINDEX('': Step '', x.program_name) + 7)) AS step_id
														WHERE
															x.program_name LIKE N''SQLAgent - TSQL JobStep (Job 0x%''
													) AS agent_info
													FOR XML
														PATH(''agent_job_info''),
														TYPE
												),
												'
											ELSE ''
										END +
										CASE
											WHEN @get_task_info = 2 THEN
												'CONVERT(XML, x.block_info) AS block_info, 
												'
											ELSE
												''
										END + '
										x.host_process_id,
										x.group_id
									FOR XML
										PATH(''additional_info''),
										TYPE
								) '
					ELSE
						'NULL '
				END + 
					'AS additional_info, 
				x.start_time, 
					' +
				CASE
					WHEN
						@output_column_list LIKE '%|[login_time|]%' ESCAPE '|'
						AND @recursion = 1
							THEN
								'x.login_time '
					ELSE 
						'NULL '
				END + 
					'AS login_time, 
				x.last_request_start_time
			FROM
			(
				SELECT TOP(@i)
					y.*,
					CASE
						WHEN DATEDIFF(hour, y.start_time, GETDATE()) > 576 THEN
							DATEDIFF(second, GETDATE(), y.start_time)
						ELSE DATEDIFF(ms, y.start_time, GETDATE())
					END AS elapsed_time,
					COALESCE(tempdb_info.tempdb_allocations, 0) AS tempdb_allocations,
					COALESCE
					(
						CASE
							WHEN tempdb_info.tempdb_current < 0 THEN 0
							ELSE tempdb_info.tempdb_current
						END,
						0
					) AS tempdb_current, 
					' +
					CASE
						WHEN 
							(
								@get_task_info <> 0
								OR @find_block_leaders = 1
							) THEN
								'N''('' + CONVERT(NVARCHAR, y.wait_duration_ms) + N''ms)'' +
									y.wait_type +
										CASE
											WHEN y.wait_type LIKE N''PAGE%LATCH_%'' THEN
												N'':'' +
												COALESCE(DB_NAME(CONVERT(INT, LEFT(y.resource_description, CHARINDEX(N'':'', y.resource_description) - 1))), N''(null)'') +
												N'':'' +
												SUBSTRING(y.resource_description, CHARINDEX(N'':'', y.resource_description) + 1, LEN(y.resource_description) - CHARINDEX(N'':'', REVERSE(y.resource_description)) - CHARINDEX(N'':'', y.resource_description)) +
												N''('' +
													CASE
														WHEN
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) = 1 OR
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) % 8088 = 0
																THEN 
																	N''PFS''
														WHEN
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) = 2 OR
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) % 511232 = 0
																THEN 
																	N''GAM''
														WHEN
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) = 3 OR
															(CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) - 1) % 511232 = 0
																THEN
																	N''SGAM''
														WHEN
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) = 6 OR
															(CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) - 6) % 511232 = 0 
																THEN 
																	N''DCM''
														WHEN
															CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) = 7 OR
															(CONVERT(INT, RIGHT(y.resource_description, CHARINDEX(N'':'', REVERSE(y.resource_description)) - 1)) - 7) % 511232 = 0 
																THEN 
																	N''BCM''
														ELSE 
															N''*''
													END +
												N'')''
											WHEN y.wait_type = N''CXPACKET'' THEN
												N'':'' + SUBSTRING(y.resource_description, CHARINDEX(N''nodeId'', y.resource_description) + 7, 4)
											WHEN y.wait_type LIKE N''LATCH[_]%'' THEN
												N'' ['' + LEFT(y.resource_description, COALESCE(NULLIF(CHARINDEX(N'' '', y.resource_description), 0), LEN(y.resource_description) + 1) - 1) + N'']''
											WHEN
												y.wait_type = N''OLEDB''
												AND y.resource_description LIKE N''%(SPID=%)'' THEN
													N''['' + LEFT(y.resource_description, CHARINDEX(N''(SPID='', y.resource_description) - 2) +
														N'':'' + SUBSTRING(y.resource_description, CHARINDEX(N''(SPID='', y.resource_description) + 6, CHARINDEX(N'')'', y.resource_description, (CHARINDEX(N''(SPID='', y.resource_description) + 6)) - (CHARINDEX(N''(SPID='', y.resource_description) + 6)) + '']''
											ELSE
												N''''
										END COLLATE Latin1_General_Bin2 AS sys_wait_info, 
										'
							ELSE
								''
						END +
						CASE
							WHEN @get_task_info = 2 THEN
								'tasks.physical_io,
								tasks.context_switches,
								tasks.tasks,
								tasks.block_info,
								tasks.wait_info AS task_wait_info,
								tasks.thread_CPU_snapshot,
								'
							ELSE
								'' 
					END +
					CASE 
						WHEN NOT (@get_avg_time = 1 AND @recursion = 1) THEN
							'CONVERT(INT, NULL) '
						ELSE 
							'qs.total_elapsed_time / qs.execution_count '
					END + 
						'AS avg_elapsed_time 
				FROM
				(
					SELECT TOP(@i)
						sp.session_id,
						sp.request_id,
						COALESCE(r.logical_reads, s.logical_reads) AS reads,
						COALESCE(r.reads, s.reads) AS physical_reads,
						COALESCE(r.writes, s.writes) AS writes,
						COALESCE(r.CPU_time, s.CPU_time) AS CPU,
						sp.memory_usage + COALESCE(r.granted_query_memory, 0) AS used_memory,
						LOWER(sp.status) AS status,
						COALESCE(r.sql_handle, sp.sql_handle) AS sql_handle,
						COALESCE(r.statement_start_offset, sp.statement_start_offset) AS statement_start_offset,
						COALESCE(r.statement_end_offset, sp.statement_end_offset) AS statement_end_offset,
						' +
						CASE
							WHEN 
							(
								@get_task_info <> 0
								OR @find_block_leaders = 1 
							) THEN
								'sp.wait_type COLLATE Latin1_General_Bin2 AS wait_type,
								sp.wait_resource COLLATE Latin1_General_Bin2 AS resource_description,
								sp.wait_time AS wait_duration_ms, 
								'
							ELSE
								''
						END +
						'NULLIF(sp.blocked, 0) AS blocking_session_id,
						r.plan_handle,
						NULLIF(r.percent_complete, 0) AS percent_complete,
						sp.host_name,
						sp.login_name,
						sp.program_name,
						s.host_process_id,
						COALESCE(r.text_size, s.text_size) AS text_size,
						COALESCE(r.language, s.language) AS language,
						COALESCE(r.date_format, s.date_format) AS date_format,
						COALESCE(r.date_first, s.date_first) AS date_first,
						COALESCE(r.quoted_identifier, s.quoted_identifier) AS quoted_identifier,
						COALESCE(r.arithabort, s.arithabort) AS arithabort,
						COALESCE(r.ansi_null_dflt_on, s.ansi_null_dflt_on) AS ansi_null_dflt_on,
						COALESCE(r.ansi_defaults, s.ansi_defaults) AS ansi_defaults,
						COALESCE(r.ansi_warnings, s.ansi_warnings) AS ansi_warnings,
						COALESCE(r.ansi_padding, s.ansi_padding) AS ansi_padding,
						COALESCE(r.ansi_nulls, s.ansi_nulls) AS ansi_nulls,
						COALESCE(r.concat_null_yields_null, s.concat_null_yields_null) AS concat_null_yields_null,
						COALESCE(r.transaction_isolation_level, s.transaction_isolation_level) AS transaction_isolation_level,
						COALESCE(r.lock_timeout, s.lock_timeout) AS lock_timeout,
						COALESCE(r.deadlock_priority, s.deadlock_priority) AS deadlock_priority,
						COALESCE(r.row_count, s.row_count) AS row_count,
						COALESCE(r.command, sp.cmd) AS command_type,
						COALESCE
						(
							CASE
								WHEN
								(
									s.is_user_process = 0
									AND r.total_elapsed_time >= 0
								) THEN
									DATEADD
									(
										ms,
										1000 * (DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())) / 500) - DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())),
										DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())
									)
							END,
							NULLIF(COALESCE(r.start_time, sp.last_request_end_time), CONVERT(DATETIME, ''19000101'', 112)),
							(
								SELECT TOP(1)
									DATEADD(second, -(ms_ticks / 1000), GETDATE())
								FROM sys.dm_os_sys_info
							)
						) AS start_time,
						sp.login_time,
						CASE
							WHEN s.is_user_process = 1 THEN
								s.last_request_start_time
							ELSE
								COALESCE
								(
									DATEADD
									(
										ms,
										1000 * (DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())) / 500) - DATEPART(ms, DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())),
										DATEADD(second, -(r.total_elapsed_time / 1000), GETDATE())
									),
									s.last_request_start_time
								)
						END AS last_request_start_time,
						r.transaction_id,
						sp.database_id,
						sp.open_tran_count,
						' +
							CASE
								WHEN EXISTS
								(
									SELECT
										*
									FROM sys.all_columns AS ac
									WHERE
										ac.object_id = OBJECT_ID('sys.dm_exec_sessions')
										AND ac.name = 'group_id'
								)
									THEN 's.group_id'
								ELSE 'CONVERT(INT, NULL) AS group_id'
							END + '
					FROM @sessions AS sp
					LEFT OUTER LOOP JOIN sys.dm_exec_sessions AS s ON
						s.session_id = sp.session_id
						AND s.login_time = sp.login_time
					LEFT OUTER LOOP JOIN sys.dm_exec_requests AS r ON
						sp.status <> ''sleeping''
						AND r.session_id = sp.session_id
						AND r.request_id = sp.request_id
						AND
						(
							(
								s.is_user_process = 0
								AND sp.is_user_process = 0
							)
							OR
							(
								r.start_time = s.last_request_start_time
								AND s.last_request_end_time <= sp.last_request_end_time
							)
						)
				) AS y
				' + 
				CASE 
					WHEN @get_task_info = 2 THEN
						CONVERT(VARCHAR(MAX), '') +
						'LEFT OUTER HASH JOIN
						(
							SELECT TOP(@i)
								task_nodes.task_node.value(''(session_id/text())[1]'', ''SMALLINT'') AS session_id,
								task_nodes.task_node.value(''(request_id/text())[1]'', ''INT'') AS request_id,
								task_nodes.task_node.value(''(physical_io/text())[1]'', ''BIGINT'') AS physical_io,
								task_nodes.task_node.value(''(context_switches/text())[1]'', ''BIGINT'') AS context_switches,
								task_nodes.task_node.value(''(tasks/text())[1]'', ''INT'') AS tasks,
								task_nodes.task_node.value(''(block_info/text())[1]'', ''NVARCHAR(4000)'') AS block_info,
								task_nodes.task_node.value(''(waits/text())[1]'', ''NVARCHAR(4000)'') AS wait_info,
								task_nodes.task_node.value(''(thread_CPU_snapshot/text())[1]'', ''BIGINT'') AS thread_CPU_snapshot
							FROM
							(
								SELECT TOP(@i)
									CONVERT
									(
										XML,
										REPLACE
										(
											CONVERT(NVARCHAR(MAX), tasks_raw.task_xml_raw) COLLATE Latin1_General_Bin2,
											N''</waits></tasks><tasks><waits>'',
											N'', ''
										)
									) AS task_xml
								FROM
								(
									SELECT TOP(@i)
										CASE waits.r
											WHEN 1 THEN
												waits.session_id
											ELSE
												NULL
										END AS [session_id],
										CASE waits.r
											WHEN 1 THEN
												waits.request_id
											ELSE
												NULL
										END AS [request_id],											
										CASE waits.r
											WHEN 1 THEN
												waits.physical_io
											ELSE
												NULL
										END AS [physical_io],
										CASE waits.r
											WHEN 1 THEN
												waits.context_switches
											ELSE
												NULL
										END AS [context_switches],
										CASE waits.r
											WHEN 1 THEN
												waits.thread_CPU_snapshot
											ELSE
												NULL
										END AS [thread_CPU_snapshot],
										CASE waits.r
											WHEN 1 THEN
												waits.tasks
											ELSE
												NULL
										END AS [tasks],
										CASE waits.r
											WHEN 1 THEN
												waits.block_info
											ELSE
												NULL
										END AS [block_info],
										REPLACE
										(
											REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
											REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
											REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
												CONVERT
												(
													NVARCHAR(MAX),
													N''('' +
														CONVERT(NVARCHAR, num_waits) + N''x: '' +
														CASE num_waits
															WHEN 1 THEN
																CONVERT(NVARCHAR, min_wait_time) + N''ms''
															WHEN 2 THEN
																CASE
																	WHEN min_wait_time <> max_wait_time THEN
																		CONVERT(NVARCHAR, min_wait_time) + N''/'' + CONVERT(NVARCHAR, max_wait_time) + N''ms''
																	ELSE
																		CONVERT(NVARCHAR, max_wait_time) + N''ms''
																END
															ELSE
																CASE
																	WHEN min_wait_time <> max_wait_time THEN
																		CONVERT(NVARCHAR, min_wait_time) + N''/'' + CONVERT(NVARCHAR, avg_wait_time) + N''/'' + CONVERT(NVARCHAR, max_wait_time) + N''ms''
																	ELSE 
																		CONVERT(NVARCHAR, max_wait_time) + N''ms''
																END
														END +
													N'')'' + wait_type COLLATE Latin1_General_Bin2
												),
												NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''),
												NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''),
												NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''),
											NCHAR(0),
											N''''
										) AS [waits]
									FROM
									(
										SELECT TOP(@i)
											w1.*,
											ROW_NUMBER() OVER
											(
												PARTITION BY
													w1.session_id,
													w1.request_id
												ORDER BY
													w1.block_info DESC,
													w1.num_waits DESC,
													w1.wait_type
											) AS r
										FROM
										(
											SELECT TOP(@i)
												task_info.session_id,
												task_info.request_id,
												task_info.physical_io,
												task_info.context_switches,
												task_info.thread_CPU_snapshot,
												task_info.num_tasks AS tasks,
												CASE
													WHEN task_info.runnable_time IS NOT NULL THEN
														''RUNNABLE''
													ELSE
														wt2.wait_type
												END AS wait_type,
												NULLIF(COUNT(COALESCE(task_info.runnable_time, wt2.waiting_task_address)), 0) AS num_waits,
												MIN(COALESCE(task_info.runnable_time, wt2.wait_duration_ms)) AS min_wait_time,
												AVG(COALESCE(task_info.runnable_time, wt2.wait_duration_ms)) AS avg_wait_time,
												MAX(COALESCE(task_info.runnable_time, wt2.wait_duration_ms)) AS max_wait_time,
												MAX(wt2.block_info) AS block_info
											FROM
											(
												SELECT TOP(@i)
													t.session_id,
													t.request_id,
													SUM(CONVERT(BIGINT, t.pending_io_count)) OVER (PARTITION BY t.session_id, t.request_id) AS physical_io,
													SUM(CONVERT(BIGINT, t.context_switches_count)) OVER (PARTITION BY t.session_id, t.request_id) AS context_switches, 
													' +
													CASE
														WHEN @output_column_list LIKE '%|[CPU_delta|]%' ESCAPE '|'
															THEN
																'SUM(tr.usermode_time + tr.kernel_time) OVER (PARTITION BY t.session_id, t.request_id) '
														ELSE
															'CONVERT(BIGINT, NULL) '
													END + 
														' AS thread_CPU_snapshot, 
													COUNT(*) OVER (PARTITION BY t.session_id, t.request_id) AS num_tasks,
													t.task_address,
													t.task_state,
													CASE
														WHEN
															t.task_state = ''RUNNABLE''
															AND w.runnable_time > 0 THEN
																w.runnable_time
														ELSE
															NULL
													END AS runnable_time
												FROM sys.dm_os_tasks AS t
												CROSS APPLY
												(
													SELECT TOP(1)
														sp2.session_id
													FROM @sessions AS sp2
													WHERE
														sp2.session_id = t.session_id
														AND sp2.request_id = t.request_id
														AND sp2.status <> ''sleeping''
												) AS sp20
												LEFT OUTER HASH JOIN
												(
													SELECT TOP(@i)
														(
															SELECT TOP(@i)
																ms_ticks
															FROM sys.dm_os_sys_info
														) -
															w0.wait_resumed_ms_ticks AS runnable_time,
														w0.worker_address,
														w0.thread_address,
														w0.task_bound_ms_ticks
													FROM sys.dm_os_workers AS w0
													WHERE
														w0.state = ''RUNNABLE''
														OR @first_collection_ms_ticks >= w0.task_bound_ms_ticks
												) AS w ON
													w.worker_address = t.worker_address 
												' +
												CASE
													WHEN @output_column_list LIKE '%|[CPU_delta|]%' ESCAPE '|'
														THEN
															'LEFT OUTER HASH JOIN sys.dm_os_threads AS tr ON
																tr.thread_address = w.thread_address
																AND @first_collection_ms_ticks >= w.task_bound_ms_ticks
															'
													ELSE
														''
												END +
											') AS task_info
											LEFT OUTER HASH JOIN
											(
												SELECT TOP(@i)
													wt1.wait_type,
													wt1.waiting_task_address,
													MAX(wt1.wait_duration_ms) AS wait_duration_ms,
													MAX(wt1.block_info) AS block_info
												FROM
												(
													SELECT DISTINCT TOP(@i)
														wt.wait_type +
															CASE
																WHEN wt.wait_type LIKE N''PAGE%LATCH_%'' THEN
																	'':'' +
																	COALESCE(DB_NAME(CONVERT(INT, LEFT(wt.resource_description, CHARINDEX(N'':'', wt.resource_description) - 1))), N''(null)'') +
																	N'':'' +
																	SUBSTRING(wt.resource_description, CHARINDEX(N'':'', wt.resource_description) + 1, LEN(wt.resource_description) - CHARINDEX(N'':'', REVERSE(wt.resource_description)) - CHARINDEX(N'':'', wt.resource_description)) +
																	N''('' +
																		CASE
																			WHEN
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) = 1 OR
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) % 8088 = 0
																					THEN 
																						N''PFS''
																			WHEN
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) = 2 OR
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) % 511232 = 0 
																					THEN 
																						N''GAM''
																			WHEN
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) = 3 OR
																				(CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) - 1) % 511232 = 0 
																					THEN 
																						N''SGAM''
																			WHEN
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) = 6 OR
																				(CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) - 6) % 511232 = 0 
																					THEN 
																						N''DCM''
																			WHEN
																				CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) = 7 OR
																				(CONVERT(INT, RIGHT(wt.resource_description, CHARINDEX(N'':'', REVERSE(wt.resource_description)) - 1)) - 7) % 511232 = 0
																					THEN 
																						N''BCM''
																			ELSE
																				N''*''
																		END +
																	N'')''
																WHEN wt.wait_type = N''CXPACKET'' THEN
																	N'':'' + SUBSTRING(wt.resource_description, CHARINDEX(N''nodeId'', wt.resource_description) + 7, 4)
																WHEN wt.wait_type LIKE N''LATCH[_]%'' THEN
																	N'' ['' + LEFT(wt.resource_description, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description), 0), LEN(wt.resource_description) + 1) - 1) + N'']''
																ELSE 
																	N''''
															END COLLATE Latin1_General_Bin2 AS wait_type,
														CASE
															WHEN
															(
																wt.blocking_session_id IS NOT NULL
																AND wt.wait_type LIKE N''LCK[_]%''
															) THEN
																(
																	SELECT TOP(@i)
																		x.lock_type,
																		REPLACE
																		(
																			REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
																			REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
																			REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
																				DB_NAME
																				(
																					CONVERT
																					(
																						INT,
																						SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''dbid='', wt.resource_description), 0) + 5, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''dbid='', wt.resource_description) + 5), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''dbid='', wt.resource_description) - 5)
																					)
																				),
																				NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''),
																				NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''),
																				NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''),
																			NCHAR(0),
																			N''''
																		) AS database_name,
																		CASE x.lock_type
																			WHEN N''objectlock'' THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''objid='', wt.resource_description), 0) + 6, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''objid='', wt.resource_description) + 6), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''objid='', wt.resource_description) - 6)
																			ELSE
																				NULL
																		END AS object_id,
																		CASE x.lock_type
																			WHEN N''filelock'' THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''fileid='', wt.resource_description), 0) + 7, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''fileid='', wt.resource_description) + 7), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''fileid='', wt.resource_description) - 7)
																			ELSE
																				NULL
																		END AS file_id,
																		CASE
																			WHEN x.lock_type in (N''pagelock'', N''extentlock'', N''ridlock'') THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''associatedObjectId='', wt.resource_description), 0) + 19, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''associatedObjectId='', wt.resource_description) + 19), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''associatedObjectId='', wt.resource_description) - 19)
																			WHEN x.lock_type in (N''keylock'', N''hobtlock'', N''allocunitlock'') THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''hobtid='', wt.resource_description), 0) + 7, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''hobtid='', wt.resource_description) + 7), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''hobtid='', wt.resource_description) - 7)
																			ELSE
																				NULL
																		END AS hobt_id,
																		CASE x.lock_type
																			WHEN N''applicationlock'' THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''hash='', wt.resource_description), 0) + 5, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''hash='', wt.resource_description) + 5), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''hash='', wt.resource_description) - 5)
																			ELSE
																				NULL
																		END AS applock_hash,
																		CASE x.lock_type
																			WHEN N''metadatalock'' THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''subresource='', wt.resource_description), 0) + 12, COALESCE(NULLIF(CHARINDEX(N'' '', wt.resource_description, CHARINDEX(N''subresource='', wt.resource_description) + 12), 0), LEN(wt.resource_description) + 1) - CHARINDEX(N''subresource='', wt.resource_description) - 12)
																			ELSE
																				NULL
																		END AS metadata_resource,
																		CASE x.lock_type
																			WHEN N''metadatalock'' THEN
																				SUBSTRING(wt.resource_description, NULLIF(CHARINDEX(N''classid='', wt.resource_description), 0) + 8, COALESCE(NULLIF(CHARINDEX(N'' dbid='', wt.resource_description) - CHARINDEX(N''classid='', wt.resource_description), 0), LEN(wt.resource_description) + 1) - 8)
																			ELSE
																				NULL
																		END AS metadata_class_id
																	FROM
																	(
																		SELECT TOP(1)
																			LEFT(wt.resource_description, CHARINDEX(N'' '', wt.resource_description) - 1) COLLATE Latin1_General_Bin2 AS lock_type
																	) AS x
																	FOR XML
																		PATH('''')
																)
															ELSE NULL
														END AS block_info,
														wt.wait_duration_ms,
														wt.waiting_task_address
													FROM
													(
														SELECT TOP(@i)
															wt0.wait_type COLLATE Latin1_General_Bin2 AS wait_type,
															wt0.resource_description COLLATE Latin1_General_Bin2 AS resource_description,
															wt0.wait_duration_ms,
															wt0.waiting_task_address,
															CASE
																WHEN wt0.blocking_session_id = p.blocked THEN
																	wt0.blocking_session_id
																ELSE
																	NULL
															END AS blocking_session_id
														FROM sys.dm_os_waiting_tasks AS wt0
														CROSS APPLY
														(
															SELECT TOP(1)
																s0.blocked
															FROM @sessions AS s0
															WHERE
																s0.session_id = wt0.session_id
																AND COALESCE(s0.wait_type, N'''') <> N''OLEDB''
																AND wt0.wait_type <> N''OLEDB''
														) AS p
													) AS wt
												) AS wt1
												GROUP BY
													wt1.wait_type,
													wt1.waiting_task_address
											) AS wt2 ON
												wt2.waiting_task_address = task_info.task_address
												AND wt2.wait_duration_ms > 0
												AND task_info.runnable_time IS NULL
											GROUP BY
												task_info.session_id,
												task_info.request_id,
												task_info.physical_io,
												task_info.context_switches,
												task_info.thread_CPU_snapshot,
												task_info.num_tasks,
												CASE
													WHEN task_info.runnable_time IS NOT NULL THEN
														''RUNNABLE''
													ELSE
														wt2.wait_type
												END
										) AS w1
									) AS waits
									ORDER BY
										waits.session_id,
										waits.request_id,
										waits.r
									FOR XML
										PATH(N''tasks''),
										TYPE
								) AS tasks_raw (task_xml_raw)
							) AS tasks_final
							CROSS APPLY tasks_final.task_xml.nodes(N''/tasks'') AS task_nodes (task_node)
							WHERE
								task_nodes.task_node.exist(N''session_id'') = 1
						) AS tasks ON
							tasks.session_id = y.session_id
							AND tasks.request_id = y.request_id 
						'
					ELSE
						''
				END +
				'LEFT OUTER HASH JOIN
				(
					SELECT TOP(@i)
						t_info.session_id,
						COALESCE(t_info.request_id, -1) AS request_id,
						SUM(t_info.tempdb_allocations) AS tempdb_allocations,
						SUM(t_info.tempdb_current) AS tempdb_current
					FROM
					(
						SELECT TOP(@i)
							tsu.session_id,
							tsu.request_id,
							tsu.user_objects_alloc_page_count +
								tsu.internal_objects_alloc_page_count AS tempdb_allocations,
							tsu.user_objects_alloc_page_count +
								tsu.internal_objects_alloc_page_count -
								tsu.user_objects_dealloc_page_count -
								tsu.internal_objects_dealloc_page_count AS tempdb_current
						FROM sys.dm_db_task_space_usage AS tsu
						CROSS APPLY
						(
							SELECT TOP(1)
								s0.session_id
							FROM @sessions AS s0
							WHERE
								s0.session_id = tsu.session_id
						) AS p

						UNION ALL

						SELECT TOP(@i)
							ssu.session_id,
							NULL AS request_id,
							ssu.user_objects_alloc_page_count +
								ssu.internal_objects_alloc_page_count AS tempdb_allocations,
							ssu.user_objects_alloc_page_count +
								ssu.internal_objects_alloc_page_count -
								ssu.user_objects_dealloc_page_count -
								ssu.internal_objects_dealloc_page_count AS tempdb_current
						FROM sys.dm_db_session_space_usage AS ssu
						CROSS APPLY
						(
							SELECT TOP(1)
								s0.session_id
							FROM @sessions AS s0
							WHERE
								s0.session_id = ssu.session_id
						) AS p
					) AS t_info
					GROUP BY
						t_info.session_id,
						COALESCE(t_info.request_id, -1)
				) AS tempdb_info ON
					tempdb_info.session_id = y.session_id
					AND tempdb_info.request_id =
						CASE
							WHEN y.status = N''sleeping'' THEN
								-1
							ELSE
								y.request_id
						END
				' +
				CASE 
					WHEN 
						NOT 
						(
							@get_avg_time = 1 
							AND @recursion = 1
						) THEN 
							''
					ELSE
						'LEFT OUTER HASH JOIN
						(
							SELECT TOP(@i)
								*
							FROM sys.dm_exec_query_stats
						) AS qs ON
							qs.sql_handle = y.sql_handle
							AND qs.plan_handle = y.plan_handle
							AND qs.statement_start_offset = y.statement_start_offset
							AND qs.statement_end_offset = y.statement_end_offset
						'
				END + 
			') AS x
			OPTION (KEEPFIXED PLAN, OPTIMIZE FOR (@i = 1)); ';

		SET @sql_n = CONVERT(NVARCHAR(MAX), @sql);

		SET @last_collection_start = GETDATE();

		IF @recursion = -1
		BEGIN;
			SELECT
				@first_collection_ms_ticks = ms_ticks
			FROM sys.dm_os_sys_info;
		END;

		INSERT #sessions
		(
			recursion,
			session_id,
			request_id,
			session_number,
			elapsed_time,
			avg_elapsed_time,
			physical_io,
			reads,
			physical_reads,
			writes,
			tempdb_allocations,
			tempdb_current,
			CPU,
			thread_CPU_snapshot,
			context_switches,
			used_memory,
			tasks,
			status,
			wait_info,
			transaction_id,
			open_tran_count,
			sql_handle,
			statement_start_offset,
			statement_end_offset,		
			sql_text,
			plan_handle,
			blocking_session_id,
			percent_complete,
			host_name,
			login_name,
			database_name,
			program_name,
			additional_info,
			start_time,
			login_time,
			last_request_start_time
		)
		EXEC sp_executesql 
			@sql_n,
			N'@recursion SMALLINT, @filter sysname, @not_filter sysname, @first_collection_ms_ticks BIGINT',
			@recursion, @filter, @not_filter, @first_collection_ms_ticks;

		--Collect transaction information?
		IF
			@recursion = 1
			AND
			(
				@output_column_list LIKE '%|[tran_start_time|]%' ESCAPE '|'
				OR @output_column_list LIKE '%|[tran_log_writes|]%' ESCAPE '|' 
			)
		BEGIN;	
			DECLARE @i INT;
			SET @i = 2147483647;

			UPDATE s
			SET
				tran_start_time =
					CONVERT
					(
						DATETIME,
						LEFT
						(
							x.trans_info,
							NULLIF(CHARINDEX(NCHAR(254) COLLATE Latin1_General_Bin2, x.trans_info) - 1, -1)
						),
						121
					),
				tran_log_writes =
					RIGHT
					(
						x.trans_info,
						LEN(x.trans_info) - CHARINDEX(NCHAR(254) COLLATE Latin1_General_Bin2, x.trans_info)
					)
			FROM
			(
				SELECT TOP(@i)
					trans_nodes.trans_node.value('(session_id/text())[1]', 'SMALLINT') AS session_id,
					COALESCE(trans_nodes.trans_node.value('(request_id/text())[1]', 'INT'), 0) AS request_id,
					trans_nodes.trans_node.value('(trans_info/text())[1]', 'NVARCHAR(4000)') AS trans_info				
				FROM
				(
					SELECT TOP(@i)
						CONVERT
						(
							XML,
							REPLACE
							(
								CONVERT(NVARCHAR(MAX), trans_raw.trans_xml_raw) COLLATE Latin1_General_Bin2, 
								N'</trans_info></trans><trans><trans_info>', N''
							)
						)
					FROM
					(
						SELECT TOP(@i)
							CASE u_trans.r
								WHEN 1 THEN u_trans.session_id
								ELSE NULL
							END AS [session_id],
							CASE u_trans.r
								WHEN 1 THEN u_trans.request_id
								ELSE NULL
							END AS [request_id],
							CONVERT
							(
								NVARCHAR(MAX),
								CASE
									WHEN u_trans.database_id IS NOT NULL THEN
										CASE u_trans.r
											WHEN 1 THEN COALESCE(CONVERT(NVARCHAR, u_trans.transaction_start_time, 121) + NCHAR(254), N'')
											ELSE N''
										END + 
											REPLACE
											(
												REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
												REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
												REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
													CONVERT(VARCHAR(128), COALESCE(DB_NAME(u_trans.database_id), N'(null)')),
													NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
													NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
													NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
												NCHAR(0),
												N'?'
											) +
											N': ' +
										CONVERT(NVARCHAR, u_trans.log_record_count) + N' (' + CONVERT(NVARCHAR, u_trans.log_kb_used) + N' kB)' +
										N','
									ELSE
										N'N/A,'
								END COLLATE Latin1_General_Bin2
							) AS [trans_info]
						FROM
						(
							SELECT TOP(@i)
								trans.*,
								ROW_NUMBER() OVER
								(
									PARTITION BY
										trans.session_id,
										trans.request_id
									ORDER BY
										trans.transaction_start_time DESC
								) AS r
							FROM
							(
								SELECT TOP(@i)
									session_tran_map.session_id,
									session_tran_map.request_id,
									s_tran.database_id,
									COALESCE(SUM(s_tran.database_transaction_log_record_count), 0) AS log_record_count,
									COALESCE(SUM(s_tran.database_transaction_log_bytes_used), 0) / 1024 AS log_kb_used,
									MIN(s_tran.database_transaction_begin_time) AS transaction_start_time
								FROM
								(
									SELECT TOP(@i)
										*
									FROM sys.dm_tran_active_transactions
									WHERE
										transaction_begin_time <= @last_collection_start
								) AS a_tran
								INNER HASH JOIN
								(
									SELECT TOP(@i)
										*
									FROM sys.dm_tran_database_transactions
									WHERE
										database_id < 32767
								) AS s_tran ON
									s_tran.transaction_id = a_tran.transaction_id
								LEFT OUTER HASH JOIN
								(
									SELECT TOP(@i)
										*
									FROM sys.dm_tran_session_transactions
								) AS tst ON
									s_tran.transaction_id = tst.transaction_id
								CROSS APPLY
								(
									SELECT TOP(1)
										s3.session_id,
										s3.request_id
									FROM
									(
										SELECT TOP(1)
											s1.session_id,
											s1.request_id
										FROM #sessions AS s1
										WHERE
											s1.transaction_id = s_tran.transaction_id
											AND s1.recursion = 1
											
										UNION ALL
									
										SELECT TOP(1)
											s2.session_id,
											s2.request_id
										FROM #sessions AS s2
										WHERE
											s2.session_id = tst.session_id
											AND s2.recursion = 1
									) AS s3
									ORDER BY
										s3.request_id
								) AS session_tran_map
								GROUP BY
									session_tran_map.session_id,
									session_tran_map.request_id,
									s_tran.database_id
							) AS trans
						) AS u_trans
						FOR XML
							PATH('trans'),
							TYPE
					) AS trans_raw (trans_xml_raw)
				) AS trans_final (trans_xml)
				CROSS APPLY trans_final.trans_xml.nodes('/trans') AS trans_nodes (trans_node)
			) AS x
			INNER HASH JOIN #sessions AS s ON
				s.session_id = x.session_id
				AND s.request_id = x.request_id
			OPTION (OPTIMIZE FOR (@i = 1));
		END;

		--Variables for text and plan collection
		DECLARE	
			@session_id SMALLINT,
			@request_id INT,
			@sql_handle VARBINARY(64),
			@plan_handle VARBINARY(64),
			@statement_start_offset INT,
			@statement_end_offset INT,
			@start_time DATETIME,
			@database_name sysname;

		IF 
			@recursion = 1
			AND @output_column_list LIKE '%|[sql_text|]%' ESCAPE '|'
		BEGIN;
			DECLARE sql_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR 
				SELECT 
					session_id,
					request_id,
					sql_handle,
					statement_start_offset,
					statement_end_offset
				FROM #sessions
				WHERE
					recursion = 1
					AND sql_handle IS NOT NULL
			OPTION (KEEPFIXED PLAN);

			OPEN sql_cursor;

			FETCH NEXT FROM sql_cursor
			INTO 
				@session_id,
				@request_id,
				@sql_handle,
				@statement_start_offset,
				@statement_end_offset;

			--Wait up to 5 ms for the SQL text, then give up
			SET LOCK_TIMEOUT 5;

			WHILE @@FETCH_STATUS = 0
			BEGIN;
				BEGIN TRY;
					UPDATE s
					SET
						s.sql_text =
						(
							SELECT
								REPLACE
								(
									REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
										N'--' + NCHAR(13) + NCHAR(10) +
										CASE 
											WHEN @get_full_inner_text = 1 THEN est.text
											WHEN LEN(est.text) < (@statement_end_offset / 2) + 1 THEN est.text
											WHEN SUBSTRING(est.text, (@statement_start_offset/2), 2) LIKE N'[a-zA-Z0-9][a-zA-Z0-9]' THEN est.text
											ELSE
												CASE
													WHEN @statement_start_offset > 0 THEN
														SUBSTRING
														(
															est.text,
															((@statement_start_offset/2) + 1),
															(
																CASE
																	WHEN @statement_end_offset = -1 THEN 2147483647
																	ELSE ((@statement_end_offset - @statement_start_offset)/2) + 1
																END
															)
														)
													ELSE RTRIM(LTRIM(est.text))
												END
										END +
										NCHAR(13) + NCHAR(10) + N'--' COLLATE Latin1_General_Bin2,
										NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
										NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
										NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
									NCHAR(0),
									N''
								) AS [processing-instruction(query)]
							FOR XML
								PATH(''),
								TYPE
						),
						s.statement_start_offset = 
							CASE 
								WHEN LEN(est.text) < (@statement_end_offset / 2) + 1 THEN 0
								WHEN SUBSTRING(CONVERT(VARCHAR(MAX), est.text), (@statement_start_offset/2), 2) LIKE '[a-zA-Z0-9][a-zA-Z0-9]' THEN 0
								ELSE @statement_start_offset
							END,
						s.statement_end_offset = 
							CASE 
								WHEN LEN(est.text) < (@statement_end_offset / 2) + 1 THEN -1
								WHEN SUBSTRING(CONVERT(VARCHAR(MAX), est.text), (@statement_start_offset/2), 2) LIKE '[a-zA-Z0-9][a-zA-Z0-9]' THEN -1
								ELSE @statement_end_offset
							END
					FROM 
						#sessions AS s,
						(
							SELECT TOP(1)
								text
							FROM
							(
								SELECT 
									text, 
									0 AS row_num
								FROM sys.dm_exec_sql_text(@sql_handle)
								
								UNION ALL
								
								SELECT 
									NULL,
									1 AS row_num
							) AS est0
							ORDER BY
								row_num
						) AS est
					WHERE 
						s.session_id = @session_id
						AND s.request_id = @request_id
						AND s.recursion = 1
					OPTION (KEEPFIXED PLAN);
				END TRY
				BEGIN CATCH;
					UPDATE s
					SET
						s.sql_text = 
							CASE ERROR_NUMBER() 
								WHEN 1222 THEN '<timeout_exceeded />'
								ELSE '<error message="' + ERROR_MESSAGE() + '" />'
							END
					FROM #sessions AS s
					WHERE 
						s.session_id = @session_id
						AND s.request_id = @request_id
						AND s.recursion = 1
					OPTION (KEEPFIXED PLAN);
				END CATCH;

				FETCH NEXT FROM sql_cursor
				INTO
					@session_id,
					@request_id,
					@sql_handle,
					@statement_start_offset,
					@statement_end_offset;
			END;

			--Return this to the default
			SET LOCK_TIMEOUT -1;

			CLOSE sql_cursor;
			DEALLOCATE sql_cursor;
		END;

		IF 
			@get_outer_command = 1 
			AND @recursion = 1
			AND @output_column_list LIKE '%|[sql_command|]%' ESCAPE '|'
		BEGIN;
			DECLARE @buffer_results TABLE
			(
				EventType VARCHAR(30),
				Parameters INT,
				EventInfo NVARCHAR(4000),
				start_time DATETIME,
				session_number INT IDENTITY(1,1) NOT NULL PRIMARY KEY
			);

			DECLARE buffer_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR 
				SELECT 
					session_id,
					MAX(start_time) AS start_time
				FROM #sessions
				WHERE
					recursion = 1
				GROUP BY
					session_id
				ORDER BY
					session_id
				OPTION (KEEPFIXED PLAN);

			OPEN buffer_cursor;

			FETCH NEXT FROM buffer_cursor
			INTO 
				@session_id,
				@start_time;

			WHILE @@FETCH_STATUS = 0
			BEGIN;
				BEGIN TRY;
					--In SQL Server 2008, DBCC INPUTBUFFER will throw 
					--an exception if the session no longer exists
					INSERT @buffer_results
					(
						EventType,
						Parameters,
						EventInfo
					)
					EXEC sp_executesql
						N'DBCC INPUTBUFFER(@session_id) WITH NO_INFOMSGS;',
						N'@session_id SMALLINT',
						@session_id;

					UPDATE br
					SET
						br.start_time = @start_time
					FROM @buffer_results AS br
					WHERE
						br.session_number = 
						(
							SELECT MAX(br2.session_number)
							FROM @buffer_results br2
						);
				END TRY
				BEGIN CATCH
				END CATCH;

				FETCH NEXT FROM buffer_cursor
				INTO 
					@session_id,
					@start_time;
			END;

			UPDATE s
			SET
				sql_command = 
				(
					SELECT 
						REPLACE
						(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								CONVERT
								(
									NVARCHAR(MAX),
									N'--' + NCHAR(13) + NCHAR(10) + br.EventInfo + NCHAR(13) + NCHAR(10) + N'--' COLLATE Latin1_General_Bin2
								),
								NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
								NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
								NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
							NCHAR(0),
							N''
						) AS [processing-instruction(query)]
					FROM @buffer_results AS br
					WHERE 
						br.session_number = s.session_number
						AND br.start_time = s.start_time
						AND 
						(
							(
								s.start_time = s.last_request_start_time
								AND EXISTS
								(
									SELECT *
									FROM sys.dm_exec_requests r2
									WHERE
										r2.session_id = s.session_id
										AND r2.request_id = s.request_id
										AND r2.start_time = s.start_time
								)
							)
							OR 
							(
								s.request_id = 0
								AND EXISTS
								(
									SELECT *
									FROM sys.dm_exec_sessions s2
									WHERE
										s2.session_id = s.session_id
										AND s2.last_request_start_time = s.last_request_start_time
								)
							)
						)
					FOR XML
						PATH(''),
						TYPE
				)
			FROM #sessions AS s
			WHERE
				recursion = 1
			OPTION (KEEPFIXED PLAN);

			CLOSE buffer_cursor;
			DEALLOCATE buffer_cursor;
		END;

		IF 
			@get_plans >= 1 
			AND @recursion = 1
			AND @output_column_list LIKE '%|[query_plan|]%' ESCAPE '|'
		BEGIN;
			DECLARE @live_plan BIT;
			SET @live_plan = ISNULL(CONVERT(BIT, SIGN(OBJECT_ID('sys.dm_exec_query_statistics_xml'))), 0)

			DECLARE plan_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR 
				SELECT
					session_id,
					request_id,
					plan_handle,
					statement_start_offset,
					statement_end_offset
				FROM #sessions
				WHERE
					recursion = 1
					AND plan_handle IS NOT NULL
			OPTION (KEEPFIXED PLAN);

			OPEN plan_cursor;

			FETCH NEXT FROM plan_cursor
			INTO 
				@session_id,
				@request_id,
				@plan_handle,
				@statement_start_offset,
				@statement_end_offset;

			--Wait up to 5 ms for a query plan, then give up
			SET LOCK_TIMEOUT 5;

			WHILE @@FETCH_STATUS = 0
			BEGIN;
				DECLARE @query_plan XML;

				IF @live_plan = 1
				BEGIN;
					SELECT
						@query_plan = x.query_plan
					FROM sys.dm_exec_query_statistics_xml(@session_id) AS x;

					IF 
						@query_plan IS NOT NULL
						AND EXISTS
						(
							SELECT
								*
							FROM sys.dm_exec_requests AS r
							WHERE
								r.session_id = @session_id
								AND r.request_id = @request_id
								AND r.plan_handle = @plan_handle
								AND r.statement_start_offset = @statement_start_offset
								AND r.statement_end_offset = @statement_end_offset
						)
					BEGIN;
						UPDATE s
						SET
							s.query_plan = @query_plan
						FROM #sessions AS s
						WHERE 
							s.session_id = @session_id
							AND s.request_id = @request_id
							AND s.recursion = 1
						OPTION (KEEPFIXED PLAN);
					END;
				END;

				IF @query_plan IS NULL
				BEGIN;
					BEGIN TRY;
						UPDATE s
						SET
							s.query_plan =
							(
								SELECT
									CONVERT(xml, query_plan)
								FROM sys.dm_exec_text_query_plan
								(
									@plan_handle, 
									CASE @get_plans
										WHEN 1 THEN
											@statement_start_offset
										ELSE
											0
									END, 
									CASE @get_plans
										WHEN 1 THEN
											@statement_end_offset
										ELSE
											-1
									END
								)
							)
						FROM #sessions AS s
						WHERE 
							s.session_id = @session_id
							AND s.request_id = @request_id
							AND s.recursion = 1
						OPTION (KEEPFIXED PLAN);
					END TRY
					BEGIN CATCH;
						IF ERROR_NUMBER() = 6335
						BEGIN;
							UPDATE s
							SET
								s.query_plan =
								(
									SELECT
										N'--' + NCHAR(13) + NCHAR(10) + 
										N'-- Could not render showplan due to XML data type limitations. ' + NCHAR(13) + NCHAR(10) + 
										N'-- To see the graphical plan save the XML below as a .SQLPLAN file and re-open in SSMS.' + NCHAR(13) + NCHAR(10) +
										N'--' + NCHAR(13) + NCHAR(10) +
											REPLACE(qp.query_plan, N'<RelOp', NCHAR(13)+NCHAR(10)+N'<RelOp') + 
											NCHAR(13) + NCHAR(10) + N'--' COLLATE Latin1_General_Bin2 AS [processing-instruction(query_plan)]
									FROM sys.dm_exec_text_query_plan
									(
										@plan_handle, 
										CASE @get_plans
											WHEN 1 THEN
												@statement_start_offset
											ELSE
												0
										END, 
										CASE @get_plans
											WHEN 1 THEN
												@statement_end_offset
											ELSE
												-1
										END
									) AS qp
									FOR XML
										PATH(''),
										TYPE
								)
							FROM #sessions AS s
							WHERE 
								s.session_id = @session_id
								AND s.request_id = @request_id
								AND s.recursion = 1
							OPTION (KEEPFIXED PLAN);
						END;
						ELSE
						BEGIN;
							UPDATE s
							SET
								s.query_plan = 
									CASE ERROR_NUMBER() 
										WHEN 1222 THEN '<timeout_exceeded />'
										ELSE '<error message="' + ERROR_MESSAGE() + '" />'
									END
							FROM #sessions AS s
							WHERE 
								s.session_id = @session_id
								AND s.request_id = @request_id
								AND s.recursion = 1
							OPTION (KEEPFIXED PLAN);
						END;
					END CATCH;
				END;

				FETCH NEXT FROM plan_cursor
				INTO
					@session_id,
					@request_id,
					@plan_handle,
					@statement_start_offset,
					@statement_end_offset;
			END;

			--Return this to the default
			SET LOCK_TIMEOUT -1;

			CLOSE plan_cursor;
			DEALLOCATE plan_cursor;
		END;

		IF 
			@get_locks = 1 
			AND @recursion = 1
			AND @output_column_list LIKE '%|[locks|]%' ESCAPE '|'
		BEGIN;
			DECLARE locks_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR 
				SELECT DISTINCT
					database_name
				FROM #locks
				WHERE
					EXISTS
					(
						SELECT *
						FROM #sessions AS s
						WHERE
							s.session_id = #locks.session_id
							AND recursion = 1
					)
					AND database_name <> '(null)'
				OPTION (KEEPFIXED PLAN);

			OPEN locks_cursor;

			FETCH NEXT FROM locks_cursor
			INTO 
				@database_name;

			WHILE @@FETCH_STATUS = 0
			BEGIN;
				BEGIN TRY;
					SET @sql_n = CONVERT(NVARCHAR(MAX), '') +
						'UPDATE l ' +
						'SET ' +
							'object_name = ' +
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										'o.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								'), ' +
							'index_name = ' +
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										'i.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								'), ' +
							'schema_name = ' +
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										's.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								'), ' +
							'principal_name = ' + 
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										'dp.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								') ' +
						'FROM #locks AS l ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.allocation_units AS au ON ' +
							'au.allocation_unit_id = l.allocation_unit_id ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.partitions AS p ON ' +
							'p.hobt_id = ' +
								'COALESCE ' +
								'( ' +
									'l.hobt_id, ' +
									'CASE ' +
										'WHEN au.type IN (1, 3) THEN au.container_id ' +
										'ELSE NULL ' +
									'END ' +
								') ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.partitions AS p1 ON ' +
							'l.hobt_id IS NULL ' +
							'AND au.type = 2 ' +
							'AND p1.partition_id = au.container_id ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.objects AS o ON ' +
							'o.object_id = COALESCE(l.object_id, p.object_id, p1.object_id) ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.indexes AS i ON ' +
							'i.object_id = COALESCE(l.object_id, p.object_id, p1.object_id) ' +
							'AND i.index_id = COALESCE(l.index_id, p.index_id, p1.index_id) ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.schemas AS s ON ' +
							's.schema_id = COALESCE(l.schema_id, o.schema_id) ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.database_principals AS dp ON ' +
							'dp.principal_id = l.principal_id ' +
						'WHERE ' +
							'l.database_name = @database_name ' +
						'OPTION (KEEPFIXED PLAN); ';
					
					EXEC sp_executesql
						@sql_n,
						N'@database_name sysname',
						@database_name;
				END TRY
				BEGIN CATCH;
					UPDATE #locks
					SET
						query_error = 
							REPLACE
							(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									CONVERT
									(
										NVARCHAR(MAX), 
										ERROR_MESSAGE() COLLATE Latin1_General_Bin2
									),
									NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
									NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
									NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
								NCHAR(0),
								N''
							)
					WHERE 
						database_name = @database_name
					OPTION (KEEPFIXED PLAN);
				END CATCH;

				FETCH NEXT FROM locks_cursor
				INTO
					@database_name;
			END;

			CLOSE locks_cursor;
			DEALLOCATE locks_cursor;

			CREATE CLUSTERED INDEX IX_SRD ON #locks (session_id, request_id, database_name);

			UPDATE s
			SET 
				s.locks =
				(
					SELECT 
						REPLACE
						(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
							REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								CONVERT
								(
									NVARCHAR(MAX), 
									l1.database_name COLLATE Latin1_General_Bin2
								),
								NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
								NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
								NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
							NCHAR(0),
							N''
						) AS [Database/@name],
						MIN(l1.query_error) AS [Database/@query_error],
						(
							SELECT 
								l2.request_mode AS [Lock/@request_mode],
								l2.request_status AS [Lock/@request_status],
								COUNT(*) AS [Lock/@request_count]
							FROM #locks AS l2
							WHERE 
								l1.session_id = l2.session_id
								AND l1.request_id = l2.request_id
								AND l2.database_name = l1.database_name
								AND l2.resource_type = 'DATABASE'
							GROUP BY
								l2.request_mode,
								l2.request_status
							FOR XML
								PATH(''),
								TYPE
						) AS [Database/Locks],
						(
							SELECT
								COALESCE(l3.object_name, '(null)') AS [Object/@name],
								l3.schema_name AS [Object/@schema_name],
								(
									SELECT
										l4.resource_type AS [Lock/@resource_type],
										l4.page_type AS [Lock/@page_type],
										l4.index_name AS [Lock/@index_name],
										CASE 
											WHEN l4.object_name IS NULL THEN l4.schema_name
											ELSE NULL
										END AS [Lock/@schema_name],
										l4.principal_name AS [Lock/@principal_name],
										l4.resource_description AS [Lock/@resource_description],
										l4.request_mode AS [Lock/@request_mode],
										l4.request_status AS [Lock/@request_status],
										SUM(l4.request_count) AS [Lock/@request_count]
									FROM #locks AS l4
									WHERE 
										l4.session_id = l3.session_id
										AND l4.request_id = l3.request_id
										AND l3.database_name = l4.database_name
										AND COALESCE(l3.object_name, '(null)') = COALESCE(l4.object_name, '(null)')
										AND COALESCE(l3.schema_name, '') = COALESCE(l4.schema_name, '')
										AND l4.resource_type <> 'DATABASE'
									GROUP BY
										l4.resource_type,
										l4.page_type,
										l4.index_name,
										CASE 
											WHEN l4.object_name IS NULL THEN l4.schema_name
											ELSE NULL
										END,
										l4.principal_name,
										l4.resource_description,
										l4.request_mode,
										l4.request_status
									FOR XML
										PATH(''),
										TYPE
								) AS [Object/Locks]
							FROM #locks AS l3
							WHERE 
								l3.session_id = l1.session_id
								AND l3.request_id = l1.request_id
								AND l3.database_name = l1.database_name
								AND l3.resource_type <> 'DATABASE'
							GROUP BY 
								l3.session_id,
								l3.request_id,
								l3.database_name,
								COALESCE(l3.object_name, '(null)'),
								l3.schema_name
							FOR XML
								PATH(''),
								TYPE
						) AS [Database/Objects]
					FROM #locks AS l1
					WHERE
						l1.session_id = s.session_id
						AND l1.request_id = s.request_id
						AND l1.start_time IN (s.start_time, s.last_request_start_time)
						AND s.recursion = 1
					GROUP BY 
						l1.session_id,
						l1.request_id,
						l1.database_name
					FOR XML
						PATH(''),
						TYPE
				)
			FROM #sessions s
			OPTION (KEEPFIXED PLAN);
		END;

		IF 
			@find_block_leaders = 1
			AND @recursion = 1
			AND @output_column_list LIKE '%|[blocked_session_count|]%' ESCAPE '|'
		BEGIN;
			WITH
			blockers AS
			(
				SELECT
					session_id,
					session_id AS top_level_session_id,
					CONVERT(VARCHAR(8000), '.' + CONVERT(VARCHAR(8000), session_id) + '.') AS the_path
				FROM #sessions
				WHERE
					recursion = 1

				UNION ALL

				SELECT
					s.session_id,
					b.top_level_session_id,
					CONVERT(VARCHAR(8000), b.the_path + CONVERT(VARCHAR(8000), s.session_id) + '.') AS the_path
				FROM blockers AS b
				JOIN #sessions AS s ON
					s.blocking_session_id = b.session_id
					AND s.recursion = 1
					AND b.the_path NOT LIKE '%.' + CONVERT(VARCHAR(8000), s.session_id) + '.%' COLLATE Latin1_General_Bin2
			)
			UPDATE s
			SET
				s.blocked_session_count = x.blocked_session_count
			FROM #sessions AS s
			JOIN
			(
				SELECT
					b.top_level_session_id AS session_id,
					COUNT(*) - 1 AS blocked_session_count
				FROM blockers AS b
				GROUP BY
					b.top_level_session_id
			) x ON
				s.session_id = x.session_id
			WHERE
				s.recursion = 1;
		END;

		IF
			@get_task_info = 2
			AND @output_column_list LIKE '%|[additional_info|]%' ESCAPE '|'
			AND @recursion = 1
		BEGIN;
			CREATE TABLE #blocked_requests
			(
				session_id SMALLINT NOT NULL,
				request_id INT NOT NULL,
				database_name sysname NOT NULL,
				object_id INT,
				hobt_id BIGINT,
				schema_id INT,
				schema_name sysname NULL,
				object_name sysname NULL,
				query_error NVARCHAR(2048),
				PRIMARY KEY (database_name, session_id, request_id)
			);

			CREATE STATISTICS s_database_name ON #blocked_requests (database_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_schema_name ON #blocked_requests (schema_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_object_name ON #blocked_requests (object_name)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
			CREATE STATISTICS s_query_error ON #blocked_requests (query_error)
			WITH SAMPLE 0 ROWS, NORECOMPUTE;
		
			INSERT #blocked_requests
			(
				session_id,
				request_id,
				database_name,
				object_id,
				hobt_id,
				schema_id
			)
			SELECT
				session_id,
				request_id,
				database_name,
				object_id,
				hobt_id,
				CONVERT(INT, SUBSTRING(schema_node, CHARINDEX(' = ', schema_node) + 3, LEN(schema_node))) AS schema_id
			FROM
			(
				SELECT
					session_id,
					request_id,
					agent_nodes.agent_node.value('(database_name/text())[1]', 'sysname') AS database_name,
					agent_nodes.agent_node.value('(object_id/text())[1]', 'int') AS object_id,
					agent_nodes.agent_node.value('(hobt_id/text())[1]', 'bigint') AS hobt_id,
					agent_nodes.agent_node.value('(metadata_resource/text()[.="SCHEMA"]/../../metadata_class_id/text())[1]', 'varchar(100)') AS schema_node
				FROM #sessions AS s
				CROSS APPLY s.additional_info.nodes('//block_info') AS agent_nodes (agent_node)
				WHERE
					s.recursion = 1
			) AS t
			WHERE
				t.database_name IS NOT NULL
				AND
				(
					t.object_id IS NOT NULL
					OR t.hobt_id IS NOT NULL
					OR t.schema_node IS NOT NULL
				);
			
			DECLARE blocks_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR
				SELECT DISTINCT
					database_name
				FROM #blocked_requests;
				
			OPEN blocks_cursor;
			
			FETCH NEXT FROM blocks_cursor
			INTO 
				@database_name;
			
			WHILE @@FETCH_STATUS = 0
			BEGIN;
				BEGIN TRY;
					SET @sql_n = 
						CONVERT(NVARCHAR(MAX), '') +
						'UPDATE b ' +
						'SET ' +
							'b.schema_name = ' +
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										's.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								'), ' +
							'b.object_name = ' +
								'REPLACE ' +
								'( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
									'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( ' +
										'o.name COLLATE Latin1_General_Bin2, ' +
										'NCHAR(31),N''?''),NCHAR(30),N''?''),NCHAR(29),N''?''),NCHAR(28),N''?''),NCHAR(27),N''?''),NCHAR(26),N''?''),NCHAR(25),N''?''),NCHAR(24),N''?''),NCHAR(23),N''?''),NCHAR(22),N''?''), ' +
										'NCHAR(21),N''?''),NCHAR(20),N''?''),NCHAR(19),N''?''),NCHAR(18),N''?''),NCHAR(17),N''?''),NCHAR(16),N''?''),NCHAR(15),N''?''),NCHAR(14),N''?''),NCHAR(12),N''?''), ' +
										'NCHAR(11),N''?''),NCHAR(8),N''?''),NCHAR(7),N''?''),NCHAR(6),N''?''),NCHAR(5),N''?''),NCHAR(4),N''?''),NCHAR(3),N''?''),NCHAR(2),N''?''),NCHAR(1),N''?''), ' +
									'NCHAR(0), ' +
									N''''' ' +
								') ' +
						'FROM #blocked_requests AS b ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.partitions AS p ON ' +
							'p.hobt_id = b.hobt_id ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.objects AS o ON ' +
							'o.object_id = COALESCE(p.object_id, b.object_id) ' +
						'LEFT OUTER JOIN ' + QUOTENAME(@database_name) + '.sys.schemas AS s ON ' +
							's.schema_id = COALESCE(o.schema_id, b.schema_id) ' +
						'WHERE ' +
							'b.database_name = @database_name; ';
					
					EXEC sp_executesql
						@sql_n,
						N'@database_name sysname',
						@database_name;
				END TRY
				BEGIN CATCH;
					UPDATE #blocked_requests
					SET
						query_error = 
							REPLACE
							(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									CONVERT
									(
										NVARCHAR(MAX), 
										ERROR_MESSAGE() COLLATE Latin1_General_Bin2
									),
									NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
									NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
									NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
								NCHAR(0),
								N''
							)
					WHERE
						database_name = @database_name;
				END CATCH;

				FETCH NEXT FROM blocks_cursor
				INTO
					@database_name;
			END;
			
			CLOSE blocks_cursor;
			DEALLOCATE blocks_cursor;
			
			UPDATE s
			SET
				additional_info.modify
				('
					insert <schema_name>{sql:column("b.schema_name")}</schema_name>
					as last
					into (/additional_info/block_info)[1]
				')
			FROM #sessions AS s
			INNER JOIN #blocked_requests AS b ON
				b.session_id = s.session_id
				AND b.request_id = s.request_id
				AND s.recursion = 1
			WHERE
				b.schema_name IS NOT NULL;

			UPDATE s
			SET
				additional_info.modify
				('
					insert <object_name>{sql:column("b.object_name")}</object_name>
					as last
					into (/additional_info/block_info)[1]
				')
			FROM #sessions AS s
			INNER JOIN #blocked_requests AS b ON
				b.session_id = s.session_id
				AND b.request_id = s.request_id
				AND s.recursion = 1
			WHERE
				b.object_name IS NOT NULL;

			UPDATE s
			SET
				additional_info.modify
				('
					insert <query_error>{sql:column("b.query_error")}</query_error>
					as last
					into (/additional_info/block_info)[1]
				')
			FROM #sessions AS s
			INNER JOIN #blocked_requests AS b ON
				b.session_id = s.session_id
				AND b.request_id = s.request_id
				AND s.recursion = 1
			WHERE
				b.query_error IS NOT NULL;
		END;

		IF
			@output_column_list LIKE '%|[program_name|]%' ESCAPE '|'
			AND @output_column_list LIKE '%|[additional_info|]%' ESCAPE '|'
			AND @recursion = 1
		BEGIN;
			DECLARE @job_id UNIQUEIDENTIFIER;
			DECLARE @step_id INT;

			DECLARE agent_cursor
			CURSOR LOCAL FAST_FORWARD
			FOR 
				SELECT
					s.session_id,
					agent_nodes.agent_node.value('(job_id/text())[1]', 'uniqueidentifier') AS job_id,
					agent_nodes.agent_node.value('(step_id/text())[1]', 'int') AS step_id
				FROM #sessions AS s
				CROSS APPLY s.additional_info.nodes('//agent_job_info') AS agent_nodes (agent_node)
				WHERE
					s.recursion = 1
			OPTION (KEEPFIXED PLAN);
			
			OPEN agent_cursor;

			FETCH NEXT FROM agent_cursor
			INTO 
				@session_id,
				@job_id,
				@step_id;

			WHILE @@FETCH_STATUS = 0
			BEGIN;
				BEGIN TRY;
					DECLARE @job_name sysname;
					SET @job_name = NULL;
					DECLARE @step_name sysname;
					SET @step_name = NULL;
					
					SELECT
						@job_name = 
							REPLACE
							(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									j.name,
									NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
									NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
									NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
								NCHAR(0),
								N'?'
							),
						@step_name = 
							REPLACE
							(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
								REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
									s.step_name,
									NCHAR(31),N'?'),NCHAR(30),N'?'),NCHAR(29),N'?'),NCHAR(28),N'?'),NCHAR(27),N'?'),NCHAR(26),N'?'),NCHAR(25),N'?'),NCHAR(24),N'?'),NCHAR(23),N'?'),NCHAR(22),N'?'),
									NCHAR(21),N'?'),NCHAR(20),N'?'),NCHAR(19),N'?'),NCHAR(18),N'?'),NCHAR(17),N'?'),NCHAR(16),N'?'),NCHAR(15),N'?'),NCHAR(14),N'?'),NCHAR(12),N'?'),
									NCHAR(11),N'?'),NCHAR(8),N'?'),NCHAR(7),N'?'),NCHAR(6),N'?'),NCHAR(5),N'?'),NCHAR(4),N'?'),NCHAR(3),N'?'),NCHAR(2),N'?'),NCHAR(1),N'?'),
								NCHAR(0),
								N'?'
							)
					FROM msdb.dbo.sysjobs AS j
					INNER JOIN msdb..sysjobsteps AS s ON
						j.job_id = s.job_id
					WHERE
						j.job_id = @job_id
						AND s.step_id = @step_id;

					IF @job_name IS NOT NULL
					BEGIN;
						UPDATE s
						SET
							additional_info.modify
							('
								insert text{sql:variable("@job_name")}
								into (/additional_info/agent_job_info/job_name)[1]
							')
						FROM #sessions AS s
						WHERE 
							s.session_id = @session_id
						OPTION (KEEPFIXED PLAN);
						
						UPDATE s
						SET
							additional_info.modify
							('
								insert text{sql:variable("@step_name")}
								into (/additional_info/agent_job_info/step_name)[1]
							')
						FROM #sessions AS s
						WHERE 
							s.session_id = @session_id
						OPTION (KEEPFIXED PLAN);
					END;
				END TRY
				BEGIN CATCH;
					DECLARE @msdb_error_message NVARCHAR(256);
					SET @msdb_error_message = ERROR_MESSAGE();
				
					UPDATE s
					SET
						additional_info.modify
						('
							insert <msdb_query_error>{sql:variable("@msdb_error_message")}</msdb_query_error>
							as last
							into (/additional_info/agent_job_info)[1]
						')
					FROM #sessions AS s
					WHERE 
						s.session_id = @session_id
						AND s.recursion = 1
					OPTION (KEEPFIXED PLAN);
				END CATCH;

				FETCH NEXT FROM agent_cursor
				INTO 
					@session_id,
					@job_id,
					@step_id;
			END;

			CLOSE agent_cursor;
			DEALLOCATE agent_cursor;
		END; 
		
		IF 
			@delta_interval > 0 
			AND @recursion <> 1
		BEGIN;
			SET @recursion = 1;

			DECLARE @delay_time CHAR(12);
			SET @delay_time = CONVERT(VARCHAR, DATEADD(second, @delta_interval, 0), 114);
			WAITFOR DELAY @delay_time;

			GOTO REDO;
		END;
	END;

	SET @sql = 
		--Outer column list
		CONVERT
		(
			VARCHAR(MAX),
			CASE
				WHEN 
					@destination_table <> '' 
					AND @return_schema = 0 
						THEN 'INSERT ' + @destination_table + ' '
				ELSE ''
			END +
			'SELECT ' +
				@output_column_list + ' ' +
			CASE @return_schema
				WHEN 1 THEN 'INTO #session_schema '
				ELSE ''
			END
		--End outer column list
		) + 
		--Inner column list
		CONVERT
		(
			VARCHAR(MAX),
			'FROM ' +
			'( ' +
				'SELECT ' +
					'session_id, ' +
					--[dd hh:mm:ss.mss]
					CASE
						WHEN @format_output IN (1, 2) THEN
							'CASE ' +
								'WHEN elapsed_time < 0 THEN ' +
									'RIGHT ' +
									'( ' +
										'REPLICATE(''0'', max_elapsed_length) + CONVERT(VARCHAR, (-1 * elapsed_time) / 86400), ' +
										'max_elapsed_length ' +
									') + ' +
										'RIGHT ' +
										'( ' +
											'CONVERT(VARCHAR, DATEADD(second, (-1 * elapsed_time), 0), 120), ' +
											'9 ' +
										') + ' +
										'''.000'' ' +
								'ELSE ' +
									'RIGHT ' +
									'( ' +
										'REPLICATE(''0'', max_elapsed_length) + CONVERT(VARCHAR, elapsed_time / 86400000), ' +
										'max_elapsed_length ' +
									') + ' +
										'RIGHT ' +
										'( ' +
											'CONVERT(VARCHAR, DATEADD(second, elapsed_time / 1000, 0), 120), ' +
											'9 ' +
										') + ' +
										'''.'' + ' + 
										'RIGHT(''000'' + CONVERT(VARCHAR, elapsed_time % 1000), 3) ' +
							'END AS [dd hh:mm:ss.mss], '
						ELSE
							''
					END +
					--[dd hh:mm:ss.mss (avg)] / avg_elapsed_time
					CASE 
						WHEN  @format_output IN (1, 2) THEN 
							'RIGHT ' +
							'( ' +
								'''00'' + CONVERT(VARCHAR, avg_elapsed_time / 86400000), ' +
								'2 ' +
							') + ' +
								'RIGHT ' +
								'( ' +
									'CONVERT(VARCHAR, DATEADD(second, avg_elapsed_time / 1000, 0), 120), ' +
									'9 ' +
								') + ' +
								'''.'' + ' +
								'RIGHT(''000'' + CONVERT(VARCHAR, avg_elapsed_time % 1000), 3) AS [dd hh:mm:ss.mss (avg)], '
						ELSE
							'avg_elapsed_time, '
					END +
					--physical_io
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, physical_io))) OVER() - LEN(CONVERT(VARCHAR, physical_io))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_io), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_io), 1), 19)) AS '
						ELSE ''
					END + 'physical_io, ' +
					--reads
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, reads))) OVER() - LEN(CONVERT(VARCHAR, reads))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, reads), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, reads), 1), 19)) AS '
						ELSE ''
					END + 'reads, ' +
					--physical_reads
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, physical_reads))) OVER() - LEN(CONVERT(VARCHAR, physical_reads))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_reads), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_reads), 1), 19)) AS '
						ELSE ''
					END + 'physical_reads, ' +
					--writes
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, writes))) OVER() - LEN(CONVERT(VARCHAR, writes))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, writes), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, writes), 1), 19)) AS '
						ELSE ''
					END + 'writes, ' +
					--tempdb_allocations
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, tempdb_allocations))) OVER() - LEN(CONVERT(VARCHAR, tempdb_allocations))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_allocations), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_allocations), 1), 19)) AS '
						ELSE ''
					END + 'tempdb_allocations, ' +
					--tempdb_current
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, tempdb_current))) OVER() - LEN(CONVERT(VARCHAR, tempdb_current))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_current), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_current), 1), 19)) AS '
						ELSE ''
					END + 'tempdb_current, ' +
					--CPU
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, CPU))) OVER() - LEN(CONVERT(VARCHAR, CPU))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, CPU), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, CPU), 1), 19)) AS '
						ELSE ''
					END + 'CPU, ' +
					--context_switches
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, context_switches))) OVER() - LEN(CONVERT(VARCHAR, context_switches))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, context_switches), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, context_switches), 1), 19)) AS '
						ELSE ''
					END + 'context_switches, ' +
					--used_memory
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, used_memory))) OVER() - LEN(CONVERT(VARCHAR, used_memory))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, used_memory), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, used_memory), 1), 19)) AS '
						ELSE ''
					END + 'used_memory, ' +
					CASE
						WHEN @output_column_list LIKE '%|_delta|]%' ESCAPE '|' THEN
							--physical_io_delta			
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND physical_io_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, physical_io_delta))) OVER() - LEN(CONVERT(VARCHAR, physical_io_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_io_delta), 1), 19)) ' 
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_io_delta), 1), 19)) '
											ELSE 'physical_io_delta '
										END +
								'ELSE NULL ' +
							'END AS physical_io_delta, ' +
							--reads_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND reads_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, reads_delta))) OVER() - LEN(CONVERT(VARCHAR, reads_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, reads_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, reads_delta), 1), 19)) '
											ELSE 'reads_delta '
										END +
								'ELSE NULL ' +
							'END AS reads_delta, ' +
							--physical_reads_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND physical_reads_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, physical_reads_delta))) OVER() - LEN(CONVERT(VARCHAR, physical_reads_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_reads_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, physical_reads_delta), 1), 19)) '
											ELSE 'physical_reads_delta '
										END + 
								'ELSE NULL ' +
							'END AS physical_reads_delta, ' +
							--writes_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND writes_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, writes_delta))) OVER() - LEN(CONVERT(VARCHAR, writes_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, writes_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, writes_delta), 1), 19)) '
											ELSE 'writes_delta '
										END + 
								'ELSE NULL ' +
							'END AS writes_delta, ' +
							--tempdb_allocations_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND tempdb_allocations_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, tempdb_allocations_delta))) OVER() - LEN(CONVERT(VARCHAR, tempdb_allocations_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_allocations_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_allocations_delta), 1), 19)) '
											ELSE 'tempdb_allocations_delta '
										END + 
								'ELSE NULL ' +
							'END AS tempdb_allocations_delta, ' +
							--tempdb_current_delta
							--this is the only one that can (legitimately) go negative 
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, tempdb_current_delta))) OVER() - LEN(CONVERT(VARCHAR, tempdb_current_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_current_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tempdb_current_delta), 1), 19)) '
											ELSE 'tempdb_current_delta '
										END + 
								'ELSE NULL ' +
							'END AS tempdb_current_delta, ' +
							--CPU_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
										'THEN ' +
											'CASE ' +
												'WHEN ' +
													'thread_CPU_delta > CPU_delta ' +
													'AND thread_CPU_delta > 0 ' +
														'THEN ' +
															CASE @format_output
																WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, thread_CPU_delta + CPU_delta))) OVER() - LEN(CONVERT(VARCHAR, thread_CPU_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, thread_CPU_delta), 1), 19)) '
																WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, thread_CPU_delta), 1), 19)) '
																ELSE 'thread_CPU_delta '
															END + 
												'WHEN CPU_delta >= 0 THEN ' +
													CASE @format_output
														WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, thread_CPU_delta + CPU_delta))) OVER() - LEN(CONVERT(VARCHAR, CPU_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, CPU_delta), 1), 19)) '
														WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, CPU_delta), 1), 19)) '
														ELSE 'CPU_delta '
													END + 
												'ELSE NULL ' +
											'END ' +
								'ELSE ' +
									'NULL ' +
							'END AS CPU_delta, ' +
							--context_switches_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND context_switches_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, context_switches_delta))) OVER() - LEN(CONVERT(VARCHAR, context_switches_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, context_switches_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, context_switches_delta), 1), 19)) '
											ELSE 'context_switches_delta '
										END + 
								'ELSE NULL ' +
							'END AS context_switches_delta, ' +
							--used_memory_delta
							'CASE ' +
								'WHEN ' +
									'first_request_start_time = last_request_start_time ' + 
									'AND num_events = 2 ' +
									'AND used_memory_delta >= 0 ' +
										'THEN ' +
										CASE @format_output
											WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, used_memory_delta))) OVER() - LEN(CONVERT(VARCHAR, used_memory_delta))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, used_memory_delta), 1), 19)) '
											WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, used_memory_delta), 1), 19)) '
											ELSE 'used_memory_delta '
										END + 
								'ELSE NULL ' +
							'END AS used_memory_delta, '
						ELSE ''
					END +
					--tasks
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, tasks))) OVER() - LEN(CONVERT(VARCHAR, tasks))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tasks), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, tasks), 1), 19)) '
						ELSE ''
					END + 'tasks, ' +
					'status, ' +
					'wait_info, ' +
					'locks, ' +
					'tran_start_time, ' +
					'LEFT(tran_log_writes, LEN(tran_log_writes) - 1) AS tran_log_writes, ' +
					--open_tran_count
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, open_tran_count))) OVER() - LEN(CONVERT(VARCHAR, open_tran_count))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, open_tran_count), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, open_tran_count), 1), 19)) AS '
						ELSE ''
					END + 'open_tran_count, ' +
					--sql_command
					CASE @format_output 
						WHEN 0 THEN 'REPLACE(REPLACE(CONVERT(NVARCHAR(MAX), sql_command), ''<?query --''+CHAR(13)+CHAR(10), ''''), CHAR(13)+CHAR(10)+''--?>'', '''') AS '
						ELSE ''
					END + 'sql_command, ' +
					--sql_text
					CASE @format_output 
						WHEN 0 THEN 'REPLACE(REPLACE(CONVERT(NVARCHAR(MAX), sql_text), ''<?query --''+CHAR(13)+CHAR(10), ''''), CHAR(13)+CHAR(10)+''--?>'', '''') AS '
						ELSE ''
					END + 'sql_text, ' +
					'query_plan, ' +
					'blocking_session_id, ' +
					--blocked_session_count
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, blocked_session_count))) OVER() - LEN(CONVERT(VARCHAR, blocked_session_count))) + LEFT(CONVERT(CHAR(22), CONVERT(MONEY, blocked_session_count), 1), 19)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, LEFT(CONVERT(CHAR(22), CONVERT(MONEY, blocked_session_count), 1), 19)) AS '
						ELSE ''
					END + 'blocked_session_count, ' +
					--percent_complete
					CASE @format_output
						WHEN 1 THEN 'CONVERT(VARCHAR, SPACE(MAX(LEN(CONVERT(VARCHAR, CONVERT(MONEY, percent_complete), 2))) OVER() - LEN(CONVERT(VARCHAR, CONVERT(MONEY, percent_complete), 2))) + CONVERT(CHAR(22), CONVERT(MONEY, percent_complete), 2)) AS '
						WHEN 2 THEN 'CONVERT(VARCHAR, CONVERT(CHAR(22), CONVERT(MONEY, blocked_session_count), 1)) AS '
						ELSE ''
					END + 'percent_complete, ' +
					'host_name, ' +
					'login_name, ' +
					'database_name, ' +
					'program_name, ' +
					'additional_info, ' +
					'start_time, ' +
					'login_time, ' +
					'CASE ' +
						'WHEN status = N''sleeping'' THEN NULL ' +
						'ELSE request_id ' +
					'END AS request_id, ' +
					'GETDATE() AS collection_time '
		--End inner column list
		) +
		--Derived table and INSERT specification
		CONVERT
		(
			VARCHAR(MAX),
				'FROM ' +
				'( ' +
					'SELECT TOP(2147483647) ' +
						'*, ' +
						'CASE ' +
							'MAX ' +
							'( ' +
								'LEN ' +
								'( ' +
									'CONVERT ' +
									'( ' +
										'VARCHAR, ' +
										'CASE ' +
											'WHEN elapsed_time < 0 THEN ' +
												'(-1 * elapsed_time) / 86400 ' +
											'ELSE ' +
												'elapsed_time / 86400000 ' +
										'END ' +
									') ' +
								') ' +
							') OVER () ' +
								'WHEN 1 THEN 2 ' +
								'ELSE ' +
									'MAX ' +
									'( ' +
										'LEN ' +
										'( ' +
											'CONVERT ' +
											'( ' +
												'VARCHAR, ' +
												'CASE ' +
													'WHEN elapsed_time < 0 THEN ' +
														'(-1 * elapsed_time) / 86400 ' +
													'ELSE ' +
														'elapsed_time / 86400000 ' +
												'END ' +
											') ' +
										') ' +
									') OVER () ' +
						'END AS max_elapsed_length, ' +
						CASE
							WHEN @output_column_list LIKE '%|_delta|]%' ESCAPE '|' THEN
								'MAX(physical_io * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(physical_io * recursion) OVER (PARTITION BY session_id, request_id) AS physical_io_delta, ' +
								'MAX(reads * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(reads * recursion) OVER (PARTITION BY session_id, request_id) AS reads_delta, ' +
								'MAX(physical_reads * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(physical_reads * recursion) OVER (PARTITION BY session_id, request_id) AS physical_reads_delta, ' +
								'MAX(writes * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(writes * recursion) OVER (PARTITION BY session_id, request_id) AS writes_delta, ' +
								'MAX(tempdb_allocations * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(tempdb_allocations * recursion) OVER (PARTITION BY session_id, request_id) AS tempdb_allocations_delta, ' +
								'MAX(tempdb_current * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(tempdb_current * recursion) OVER (PARTITION BY session_id, request_id) AS tempdb_current_delta, ' +
								'MAX(CPU * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(CPU * recursion) OVER (PARTITION BY session_id, request_id) AS CPU_delta, ' +
								'MAX(thread_CPU_snapshot * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(thread_CPU_snapshot * recursion) OVER (PARTITION BY session_id, request_id) AS thread_CPU_delta, ' +
								'MAX(context_switches * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(context_switches * recursion) OVER (PARTITION BY session_id, request_id) AS context_switches_delta, ' +
								'MAX(used_memory * recursion) OVER (PARTITION BY session_id, request_id) + ' +
									'MIN(used_memory * recursion) OVER (PARTITION BY session_id, request_id) AS used_memory_delta, ' +
								'MIN(last_request_start_time) OVER (PARTITION BY session_id, request_id) AS first_request_start_time, '
							ELSE ''
						END +
						'COUNT(*) OVER (PARTITION BY session_id, request_id) AS num_events ' +
					'FROM #sessions AS s1 ' +
					CASE 
						WHEN @sort_order = '' THEN ''
						ELSE
							'ORDER BY ' +
								@sort_order
					END +
				') AS s ' +
				'WHERE ' +
					's.recursion = 1 ' +
			') x ' +
			'OPTION (KEEPFIXED PLAN); ' +
			'' +
			CASE @return_schema
				WHEN 1 THEN
					'SET @schema = ' +
						'''CREATE TABLE <table_name> ( '' + ' +
							'STUFF ' +
							'( ' +
								'( ' +
									'SELECT ' +
										''','' + ' +
										'QUOTENAME(COLUMN_NAME) + '' '' + ' +
										'DATA_TYPE + ' + 
										'CASE ' +
											'WHEN DATA_TYPE LIKE ''%char'' THEN ''('' + COALESCE(NULLIF(CONVERT(VARCHAR, CHARACTER_MAXIMUM_LENGTH), ''-1''), ''max'') + '') '' ' +
											'ELSE '' '' ' +
										'END + ' +
										'CASE IS_NULLABLE ' +
											'WHEN ''NO'' THEN ''NOT '' ' +
											'ELSE '''' ' +
										'END + ''NULL'' AS [text()] ' +
									'FROM tempdb.INFORMATION_SCHEMA.COLUMNS ' +
									'WHERE ' +
										'TABLE_NAME = (SELECT name FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(''tempdb..#session_schema'')) ' +
										'ORDER BY ' +
											'ORDINAL_POSITION ' +
									'FOR XML ' +
										'PATH('''') ' +
								'), + ' +
								'1, ' +
								'1, ' +
								''''' ' +
							') + ' +
						''')''; ' 
				ELSE ''
			END
		--End derived table and INSERT specification
		);

	SET @sql_n = CONVERT(NVARCHAR(MAX), @sql);

	EXEC sp_executesql
		@sql_n,
		N'@schema VARCHAR(MAX) OUTPUT',
		@schema OUTPUT;
END;
GO

------------------------------==================6. WIA_MemoryClerks_File_IO : Tables & Job================----------------------

----- 1. WIA Tables ----


USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WIA_Output](
	[dd hh:mm:ss.mss] [varchar](8000) NULL,
	[collection_time] [datetime] NOT NULL,
	[start_time] [datetime] NOT NULL,
	[session_id] [smallint] NOT NULL,
	[status] [varchar](30) NOT NULL,
	[percent_complete] [varchar](30) NULL,
	[host_name] [nvarchar](128) NULL,
	[database_name] [nvarchar](128) NULL,
	[program_name] [nvarchar](128) NULL,
	[sql_text] [xml] NULL,
	[sql_command] [xml] NULL,
	[query_plan] [xml] NULL,
	[login_name] [nvarchar](128) NOT NULL,
	[open_tran_count] [varchar](30) NULL,
	[wait_info] [nvarchar](4000) NULL,
	[blocking_session_id] [smallint] NULL,
	[blocked_session_count] [varchar](30) NULL,
	[CPU] [varchar](30) NULL,
	[used_memory] [varchar](30) NULL,
	[tempdb_current] [varchar](30) NULL,
	[tempdb_allocations] [varchar](30) NULL,
	[reads] [varchar](30) NULL,
	[writes] [varchar](30) NULL,
	[physical_reads] [varchar](30) NULL,
	[login_time] [datetime] NULL	
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[WIA_Output_tmp](
	[dd hh:mm:ss.mss] [varchar](8000) NULL,
	[collection_time] [datetime] NOT NULL,
	[start_time] [datetime] NOT NULL,
	[session_id] [smallint] NOT NULL,
	[status] [varchar](30) NOT NULL,
	[percent_complete] [varchar](30) NULL,
	[host_name] [nvarchar](128) NULL,
	[database_name] [nvarchar](128) NULL,
	[program_name] [nvarchar](128) NULL,
	[sql_text] [xml] NULL,
	[sql_command] [xml] NULL,
	[query_plan] [xml] NULL,
	[login_name] [nvarchar](128) NOT NULL,
	[open_tran_count] [varchar](30) NULL,
	[wait_info] [nvarchar](4000) NULL,
	[blocking_session_id] [smallint] NULL,
	[blocked_session_count] [varchar](30) NULL,
	[CPU] [varchar](30) NULL,
	[used_memory] [varchar](30) NULL,
	[tempdb_current] [varchar](30) NULL,
	[tempdb_allocations] [varchar](30) NULL,
	[reads] [varchar](30) NULL,
	[writes] [varchar](30) NULL,
	[physical_reads] [varchar](30) NULL,
	[login_time] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO




-------2. Table : Memory_Clerks

USE [Baseline]
GO

/****** Object:  Table [dbo].[Memory_Clerks]    Script Date: 7/18/2019 2:19:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[Memory_Clerks](
	[Memory Clerk Type] [varchar](60) NOT NULL,
	[Name] [varchar](60) NULL,
	[Memory Usage(MB)] [bigint] NULL,
	[collection_time] [datetime] NOT NULL
) ON [PRIMARY]
GO


--------3. Table : Files_IO_Latency


USE [Baseline]
GO

/****** Object:  Table [dbo].[Files_IO_Latency]    Script Date: 7/18/2019 2:20:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[Files_IO_Latency](
	[Collection_time] [datetime] NOT NULL,
	[database_id] [smallint] NOT NULL,
	[file_id] [smallint] NOT NULL,
	[num_of_reads] [bigint] NOT NULL,
	[io_stall_read_ms] [bigint] NOT NULL,
	[num_of_writes] [bigint] NOT NULL,
	[io_stall_write_ms] [bigint] NOT NULL,
	[io_stall] [bigint] NOT NULL,
	[num_of_bytes_read] [bigint] NOT NULL,
	[num_of_bytes_written] [bigint] NOT NULL,
	[file_handle] [varbinary](8) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO




------------4. Stored procedures



USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_Memory_FilesIO]    Script Date: 7/18/2019 2:23:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_Memory_FilesIO] AS

set nocount on;
set transaction isolation level read uncommitted;

declare	@product_version nvarchar(128)
declare @product_version_major decimal(10,2)
declare @product_version_minor decimal(10,2)

		--------------------------------------------------------------------------------------------------------------
		-- check the version and get top 10 Memory clerks
		--------------------------------------------------------------------------------------------------------------
		set @product_version = convert(nvarchar(128),serverproperty('productversion'));

		select 
			 @product_version_major = substring(@product_version, 1,charindex('.', @product_version) + 1 )
			,@product_version_minor = parsename(convert(varchar(32), @product_version), 2);


--------------------------------------------------------------------------------------------------------------
	---1. Capture Memory clerks
--------------------------------------------------------------------------------------------------------------

				if @product_version_major < 11
			begin
				insert into [dbo].[memory_clerks]
				exec sp_executesql N'
				SELECT TOP(10) mc.[type] AS [Memory Clerk Type], 
				Name, CAST((SUM(mc.single_pages_kb + mc.multi_pages_kb)/1024.0) AS DECIMAL (15,2)) AS [Memory Usage (MB)],
				getdate() as Collection_Time  
				FROM sys.dm_os_memory_clerks AS mc WITH (NOLOCK)
				GROUP BY mc.[type] , name
				ORDER BY SUM(mc.single_pages_kb + mc.multi_pages_kb) DESC OPTION (RECOMPILE)'

			end
		else
			begin
				insert into [dbo].[memory_clerks]
				exec sp_executesql N'
				SELECT TOP(10) mc.[type] AS [Memory Clerk Type], 
				Name, CAST((SUM(mc.pages_kb)/1024.0) AS DECIMAL (15,2)) AS [Memory Usage (MB)],
				getdate() as Collection_Time 
				FROM sys.dm_os_memory_clerks AS mc WITH (NOLOCK)
				GROUP BY mc.[type]  , name
				ORDER BY SUM(mc.pages_kb) DESC OPTION (RECOMPILE)'
			end

--------------------------------------------------------------------------------------------------------------
	---2. Capture DB Files I/O
--------------------------------------------------------------------------------------------------------------
			

			INSERT INTO [Baseline].[dbo].[Files_IO_Latency]
SELECT getdate(),[database_id], [file_id], [num_of_reads], [io_stall_read_ms],
[num_of_writes], [io_stall_write_ms], [io_stall],
[num_of_bytes_read], [num_of_bytes_written], [file_handle]
FROM sys.dm_io_virtual_file_stats (NULL, NULL);

GO


-----------------------------------


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[Clear_MemoryFilesIO_History]    Script Date: 7/18/2019 2:24:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




                     CREATE PROCEDURE [dbo].[Clear_MemoryFilesIO_History]
                           @old_date     INT = 30
                     AS

                     SET NOCOUNT ON
                     SET XACT_ABORT ON

                     BEGIN TRY

                                         DELETE [dbo].[Memory_Clerks]
                                         WHERE collection_time < DATEADD(dd,-@old_date, dateadd(dd, datediff(dd,0, GETDATE()),0));
                                  

										 DELETE [dbo].[Files_IO_Latency]
                                         WHERE collection_time < DATEADD(dd,-@old_date, dateadd(dd, datediff(dd,0, GETDATE()),0));
                                  

                     END TRY
                     BEGIN CATCH

                           IF (XACT_STATE()) != 0
                                  ROLLBACK TRANSACTION;
                            
                           DECLARE @errMessage varchar(MAX)
                           SET @errMessage = 'Stored procedure ' + OBJECT_NAME(@@PROCID) + ' failed with error ' + CAST(ERROR_NUMBER() AS VARCHAR(20)) + '. ' + ERROR_MESSAGE() 
                           RAISERROR (@errMessage, 16, 1)
                                  
                     END CATCH
                     

GO




------------ 5. Job for WIA_MemoryClerks_FilesIO

USE [msdb]
GO

/****** Object:  Job [DBA - Capture Who is Active]    Script Date: 7/18/2019 2:21:32 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    Script Date: 7/18/2019 2:21:32 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Capture Who is Active', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This Captures the current Active sessions with below data           
	[sql_text] 
	[login_name]
	[wait_info] 
	[CPU] 
	[blocking_session_id]
	[reads] 
	[writes] 
	[open_tran_count] and so on.... into the table dbo.WIA_Output', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Capture_WIA]    Script Date: 7/18/2019 2:21:32 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Capture_WIA', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @sp_whoisactive_destination_table varchar(255)

				truncate table [dbo].[WIA_Output_tmp]
				set @sp_whoisactive_destination_table = quotename(db_name()) + ''.[dbo].[WIA_Output_tmp]''
				exec dbo.sp_whoisactive
					@get_outer_command = 1
					,@output_column_list = ''[dd hh:mm:ss.mss][collection_time][start_time][session_id]
					[status][percent_complete][host_name][database_name][program_name]
					[sql_text][sql_command][query_plan][login_name][open_tran_count]
					[wait_info][blocking_session_id][blocked_session_count]
					[CPU][used_memory][tempdb_current][tempdb_allocations]
					[reads][writes][physical_reads][login_time]''
					,@find_block_leaders = 1
					 ,@get_plans = 1
					,@destination_table = @sp_whoisactive_destination_table
				insert into [dbo].[WIA_Output]
				select   
				[dd hh:mm:ss.mss],[collection_time],[start_time],[session_id],
				[status],[percent_complete],[host_name],[database_name],[program_name],
				[sql_text],[sql_command],[query_plan],[login_name],[open_tran_count],
				[wait_info],[blocking_session_id],[blocked_session_count],
				[CPU],[used_memory],[tempdb_current],[tempdb_allocations],
				[reads],[writes],[physical_reads],[login_time]
				from [dbo].[WIA_Output_tmp]
				where [start_time] < dateadd(s,(-600.0),getdate())
				or [blocking_session_id] is not null or [blocked_session_count] > 0
				GO
', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge OLD Data]    Script Date: 7/18/2019 2:21:32 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge OLD Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [Baseline].[dbo].[WIA_Output] where collection_time < DATEADD(dd,-30,getdate());
delete from [dbo].[WIA_Output] where login_name in (''NT SERVICE\SQLSERVERAGENT'', ''NT AUTHORITY\SYSTEM'');
delete from [dbo].[WIA_Output] where database_name in ( ''master'', ''msdb'', ''Baseline'' );
', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MemoryClerks_FilesIO_Latency]    Script Date: 7/18/2019 2:21:32 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MemoryClerks_FilesIO_Latency', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[sp_Memory_FilesIO];
exec [dbo].[Clear_MemoryFilesIO_History];', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Capture_WIA', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180305, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'd1973182-c265-4b47-a986-3a34feb98c74'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


-------------------------===================7. Index & stats Info_Sp=================----------------------

-----1. Create a table to hold the Index Usage ------


USE [Baseline];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE TABLE [dbo].[IndexUsage](
	[CaptureDate] DATETIME NOT NULL,
	[DatabaseName] NVARCHAR(128) NULL,
	[SchemaName] NVARCHAR(128) NULL,
	[ObjectName] NVARCHAR(128) NULL,
	[database_id] SMALLINT NOT NULL,
	[object_id] INT NOT NULL,
	[index_id] INT NOT NULL,
	[user_seeks] BIGINT NOT NULL,
	[user_scans] BIGINT NOT NULL,
	[user_lookups] BIGINT NOT NULL,
	[user_updates] BIGINT NOT NULL,
	[last_user_seek] DATETIME NULL,
	[last_user_scan] DATETIME NULL,
	[last_user_lookup] DATETIME NULL,
	[last_user_update] DATETIME NULL,
	[system_seeks] BIGINT NOT NULL,
	[system_scans] BIGINT NOT NULL,
	[system_lookups] BIGINT NOT NULL,
	[system_updates] BIGINT NOT NULL,
	[last_system_seek] DATETIME NULL,
	[last_system_scan] DATETIME NULL,
	[last_system_lookup] DATETIME NULL,
	[last_system_update] DATETIME NULL
	) ON [PRIMARY]
GO



---2. CReate a table to hold Indexfragmentation-----------


USE [Baseline];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO


CREATE TABLE [Indexfragmentation](
    	[CaptureDate] DATETIME NOT NULL,
	[DatabaseName] 	[nvarchar] (200) NULL,
	[ObjectName]	[nvarchar] (200) NULL,
	[Index Name] 	[nvarchar] (200) NULL,
	[Index_id] 		INT,
	[Index_type_desc] [nvarchar] (200) NULL,
	[avg_fragmentation_in_percent]		float NULL,
	[fragment_count] INT NULL, 
	[page_count] INT NULL,
	[fill_factor] INT NULL,
	[has_filter] INT NULL,
	[filter_definition]	[nvarchar] (200) NULL 
) ON [PRIMARY]

-----3. Create a table to hold Bad indexes 

USE [Baseline]
GO

/****** Object:  Table [dbo].[BadIndexes]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BadIndexes](
	[CaptureDate] [datetime] NOT NULL,
	[DatabaseName] [nvarchar](200) NULL,
	[Table Name] [nvarchar](200) NULL,
	[Index Name] [nvarchar](200) NULL,
	[Index_id] [int] NULL,
	[is_disabled] [int] NULL,
	[is_hypothetical] [int] NULL,
	[has_filter] [int] NULL,
	[fill_factor] [int] NULL,
	[Total Writes] [int] NULL,
	[Total Reads] [int] NULL,
	[Difference] [nvarchar](200) NULL
) ON [PRIMARY]

GO





----- 4. CReate a table for Stats data-------------

USE [Baseline]
GO

/****** Object:  Table [dbo].[Statistics_Info]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Statistics_Info](
	[CaptureDate] [datetime] NOT NULL,
	[DatabaseName] [nvarchar](200) NULL,
	[Schema] [nvarchar](200) NULL,
	[Table] [nvarchar](200) NULL,
	[Column Name] [nvarchar](200) NULL,
	[Statistic name] [nvarchar](200) NULL,
	[Last Updated] [datetime] NULL,
	[rows] [int] NULL,
	[rows_sampled] [int] NULL,
	[Modifications] [int] NULL
) ON [PRIMARY]

GO


----------- CReate Stored Procedures as below -------------


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_IndexUsage]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[sp_IndexUsage] 
AS

delete from [Baseline].[dbo].[IndexUsage] where CaptureDate < DATEADD(dd,-90,getdate());

INSERT INTO [dbo].[IndexUsage] (
	[CaptureDate],
	[DatabaseName],
	[SchemaName],
	[ObjectName],
	[database_id],
	[object_id],
	[index_id],
	[user_seeks],
	[user_scans],
	[user_lookups],
	[user_updates],
	[last_user_seek],
	[last_user_scan],
	[last_user_lookup],
	[last_user_update],
	[system_seeks],
	[system_scans],
	[system_lookups],
	[system_updates],
	[last_system_seek],
	[last_system_scan],
	[last_system_lookup],
	[last_system_update]
	)
SELECT 
	getdate(),
	DB_NAME(i.database_id),
	OBJECT_SCHEMA_NAME (i.object_id, i.database_id),
	OBJECT_NAME(i.object_id, i.database_id),
	[i].[database_id],
	[i].[object_id],
	[i].[index_id],
	[i].[user_seeks],
	[i].[user_scans],
	[i].[user_lookups],
	[i].[user_updates],
	[i].[last_user_seek],
	[i].[last_user_scan],
	[i].[last_user_lookup],
	[i].[last_user_update],
	[i].[system_seeks],
	[i].[system_scans],
	[i].[system_lookups],
	[i].[system_updates],
	[i].[last_system_seek],
	[i].[last_system_scan],
	[i].[last_system_lookup],
	[i].[last_system_update]
FROM sys.dm_db_index_usage_stats i
WHERE i.object_id > 100 
and DB_NAME(i.database_id) not in ( 'master','msdb','model','tempdb','ReportServer','ReportServerTempDB','distribution','Baseline')

GO


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_Indexfragmentation]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[sp_Indexfragmentation]
AS

delete from [Baseline].[dbo].[Indexfragmentation] where CaptureDate < DATEADD(dd,-90,getdate());

DECLARE @dbname varchar(1000)
DECLARE @sqlQuery nvarchar(4000)

DECLARE dbcursor CURSOR for
SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb', 'Baseline','ReportServer','ReportServerTempDB','distribution')

OPEN dbcursor
FETCH NEXT FROM dbcursor INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sqlQuery = '
	USE [' + @dbname + '];

	IF EXISTS
	(
		SELECT compatibility_level 
		FROM sys.databases 
		WHERE 
			name  = N'''+ @dbname +'''
			AND compatibility_level >= 90
	)
	BEGIN
		INSERT INTO [Baseline].[dbo].[Indexfragmentation] 
		(
	[CaptureDate],
	[DatabaseName],
	[ObjectName],
	[Index Name],
	[Index_id],
	[Index_type_desc],
	[avg_fragmentation_in_percent],
	[fragment_count], 
	[page_count],
	[fill_factor],
	[has_filter],
	[filter_definition]
		) 
		SELECT 
 getdate(),
 DB_NAME(ps.database_id) AS [Database Name], 
 OBJECT_NAME(ps.OBJECT_ID) AS [Object Name], 
 i.name AS [Index Name],
 ps.index_id, 
 ps.index_type_desc, 
 ps.avg_fragmentation_in_percent, 
 ps.fragment_count,
 ps.page_count, 
 i.fill_factor, 
 i.has_filter, 
 i.filter_definition
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL, NULL, NULL , NULL) AS ps
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON ps.[object_id] = i.[object_id] 
AND ps.index_id = i.index_id
WHERE ps.database_id = DB_ID()
AND ps.page_count > 1000
ORDER BY ps.avg_fragmentation_in_percent DESC OPTION (RECOMPILE)
END; '
	
	EXEC sp_executesql @sqlQuery
	
FETCH NEXT FROM dbcursor
INTO @dbname
END

CLOSE dbcursor
Deallocate dbcursor


GO


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_BadIndexes]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[sp_BadIndexes]
AS

delete from [Baseline].[dbo].[BadIndexes]  where CaptureDate < DATEADD(dd,-90,getdate());

DECLARE @dbname varchar(1000)
DECLARE @sqlQuery nvarchar(4000)
DECLARE @UserTable  varchar(1000)

Set @UserTable = 'IsUserTable'

DECLARE dbcursor CURSOR for
SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb', 'Baseline','ReportServer','ReportServerTempDB','distribution')

OPEN dbcursor
FETCH NEXT FROM dbcursor INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sqlQuery = '
	USE [' + @dbname + '];

	IF EXISTS
	(
		SELECT compatibility_level 
		FROM sys.databases 
		WHERE 
			name  = N'''+ @dbname +'''
			AND compatibility_level >= 90
	)
	BEGIN

			INSERT INTO [Baseline].[dbo].[BadIndexes] 
		(
	[CaptureDate],
	[DatabaseName],
	[Table Name],
	[Index Name],
	[Index_id],
	[is_disabled],
	[is_hypothetical],
	[has_filter],
	[fill_factor],
	[Total Writes],
	[Total Reads],
	[Difference] 
		) 
		
SELECT 
 getdate(),
 DB_NAME() AS DataBaseName,
OBJECT_NAME(s.[object_id]) AS [Table Name], 
i.name AS [Index Name], 
i.index_id, 
i.is_disabled, 
i.is_hypothetical, 
i.has_filter, 
i.fill_factor,
user_updates AS [Total Writes], 
user_seeks + user_scans + user_lookups AS [Total Reads],
user_updates - (user_seeks + user_scans + user_lookups) AS [Difference]
FROM sys.dm_db_index_usage_stats AS s WITH (NOLOCK)
INNER JOIN sys.indexes AS i WITH (NOLOCK)
ON s.[object_id] = i.[object_id]
AND i.index_id = s.index_id
WHERE OBJECTPROPERTY(s.[object_id],N'''+ @UserTable +''') = 1
AND s.database_id = DB_ID()
AND user_updates > (user_seeks + user_scans + user_lookups)
AND i.index_id > 1
ORDER BY [Difference] DESC, [Total Writes] DESC, [Total Reads] ASC OPTION (RECOMPILE); 
END; '


	EXEC sp_executesql @sqlQuery
	
FETCH NEXT FROM dbcursor
INTO @dbname
END

CLOSE dbcursor
Deallocate dbcursor
GO


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_Statistics_Info]     ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [dbo].[sp_Statistics_Info]
AS

delete from [Baseline].[dbo].[Statistics_Info] where CaptureDate < DATEADD(dd,-90,getdate());

DECLARE @dbname varchar(1000)
DECLARE @sqlQuery nvarchar(4000)
DECLARE @Schema  varchar(1000)

Set @Schema = 'SYS'

DECLARE dbcursor CURSOR for
SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb', 'Baseline','ReportServer','ReportServerTempDB','distribution')

OPEN dbcursor
FETCH NEXT FROM dbcursor INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sqlQuery = '
	USE [' + @dbname + '];

	IF EXISTS
	(
		SELECT compatibility_level 
		FROM sys.databases 
		WHERE 
			name  = N'''+ @dbname +'''
			AND compatibility_level >= 90
	)
	BEGIN

			INSERT INTO [Baseline].[dbo].[Statistics_Info] 
		(
	 [CaptureDate],
	[DatabaseName],
	[Schema],
	[Table],
	[Column Name],
	[Statistic name],
	[Last Updated],
	[rows],
	[rows_sampled] , 
	[Modifications] 
		) 
		-- When were Statistics last updated on all indexes?  (Statistics Update)
SELECT
 getdate(),
 DB_NAME() AS DataBaseName,
    sch.name as [schema],
    o.name AS "Table",
    c.name AS "Column Name",
    [s].[name] AS "Statistic name",
    [sp].[last_updated] AS "Last Updated",
    [sp].[rows],
    [sp].[rows_sampled],
    [sp].[modification_counter] AS "Modifications"
FROM 
    [sys].[stats] AS [s] inner join sys.stats_columns sc WITH (NOLOCK)
        on s.stats_id=sc.stats_id and s.object_id=sc.object_id
    inner join sys.columns c WITH (NOLOCK)
        on c.object_id=sc.object_id and c.column_id=sc.column_id
    inner join sys.objects o WITH (NOLOCK)
        on s.object_id=o.object_id
    inner join sys.schemas sch WITH (NOLOCK)
        on o.schema_id=sch.schema_id
    OUTER APPLY sys.dm_db_stats_properties ([s].[object_id],[s].[stats_id])  AS [sp] 
WHERE  sch.name ! =  N'''+ @Schema +''' and [sp].[modification_counter] > 0 
END; '


	EXEC sp_executesql @sqlQuery
	
FETCH NEXT FROM dbcursor
INTO @dbname
END

CLOSE dbcursor
Deallocate dbcursor
GO


--------- Job which collects Index usage, Fragmentation, Bad indexes, Outdated Stats ------------------


USE [msdb]
GO

/****** Object:  Job [DBA - Collect Index_Stats Info]    ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Collect Index_Stats Info', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Collect Index Usage Stats across all databases & the Index Fragmentation aswell', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Index Usage]     ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Index Usage', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [Baseline].[dbo].[sp_IndexUsage];



', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Index Fragmentation]     ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Index Fragmentation', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [Baseline].[dbo].[sp_Indexfragmentation];', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Bad Indexes]    ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Bad Indexes', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [Baseline].[dbo].[sp_BadIndexes];', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Stats Info]     ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Stats Info', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [Baseline].[dbo].[sp_Statistics_Info];', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Index Usage', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=72, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180306, 
		@active_end_date=99991231, 
		@active_start_time=40000, 
		@active_end_time=235959, 
		@schedule_uid=N'051f3d94-dc68-43d4-8a93-7414c2267524'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



-------------------------================8. Server Config Changes==================-----------------

--- Server configuration changes ----

------------1. Create the table


USE [Baseline];
GO
 
IF OBJECT_ID(N'dbo.Server_ConfigData', N'U') IS NULL

  CREATE TABLE [dbo].[Server_ConfigData] 
  (
    [ConfigurationID] [int] NOT NULL ,
    [Name] [nvarchar](35) NOT NULL ,
    [Value] [sql_variant] NULL ,
    [ValueInUse] [sql_variant] NULL ,
    [CaptureDate] [datetime] NOT NULL DEFAULT SYSDATETIME()
  ) ON [PRIMARY];

 
CREATE CLUSTERED INDEX [CI_Server_ConfigData] 
  ON [dbo].[Server_ConfigData] ([CaptureDate],[ConfigurationID]);

GO

------ CReate sp-----------------

USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[Capture_Server_Config_Change]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create procedure [dbo].[Capture_Server_Config_Change]
as 

INSERT INTO [Baseline].[dbo].[Server_ConfigData]
(
  [ConfigurationID] ,
  [Name] ,
  [Value] ,
  [ValueInUse]
)

SELECT 
  [configuration_id] ,
  [name] ,
  [value] ,
  [value_in_use]
FROM [sys].[configurations];

GO


----- CReate a job --------------


USE [msdb]
GO

/****** Object:  Job [DBA - Server Config Changes]    ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - Server Config Changes', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Captures any changes to Server configurations', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Capture Server config changes]     ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Capture Server config changes', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [Baseline].[dbo].[Capture_Server_Config_Change];', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge old data]     ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge old data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [Baseline].[dbo].[Server_ConfigData] where CaptureDate < DATEADD(dd,-180,getdate());', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Config changes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180628, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'17350600-6058-403f-9556-651d650f3966'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



--------------------==================9. Disk_DB_Logspace =============-------------------

------------------------ Table creation 1. DBFilesSpace

USE [Baseline]
GO

/****** Object:  Table [dbo].[DBFilesSpace]    Script Date: 7/18/2019 1:54:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DBFilesSpace](
	[DBname] [varchar](50) NULL,
	[File_id] [int] NULL,
	[Filename] [varchar](100) NULL,
	[Physicalname] [varchar](200) NULL,
	[Drive] [char](1) NULL,
	[Totalsize_MB] [decimal](18, 0) NULL,
	[Spaceused_MB] [decimal](18, 0) NULL,
	[Freespace_MB] [decimal](18, 0) NULL,
	[%Freespace] [int] NULL,
	[%Spaceused] [int] NULL,
	[RunDate] [datetime2](0) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO


------------- Table 2. DiskSpace 

USE [Baseline]
GO

/****** Object:  Table [dbo].[DiskSpace]    Script Date: 7/18/2019 1:53:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DiskSpace](
	[Drive] [nvarchar](50) NULL,
	[Drive_Label] [nvarchar](50) NULL,
	[Drive_Size_MB] [nvarchar](50) NULL,
	[Drive_Free_Space_MB] [nvarchar](50) NULL,
	[Rundate] [datetime2](0) NULL
) ON [PRIMARY]

GO



-------------- Table 3. LogUsage_VLFs

USE [Baseline]
GO

/****** Object:  Table [dbo].[LogUsage_VLFs]    Script Date: 7/18/2019 1:57:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LogUsage_VLFs](
	[database_name] [sysname] NOT NULL,
	[total_log_size_in_bytes] [bigint] NULL,
	[used_log_space_in_bytes] [bigint] NULL,
	[VLFs] [bigint] NULL,
	[Rundate] [datetime] NOT NULL,
 CONSTRAINT [PK_LogUsage_VLFs] PRIMARY KEY CLUSTERED 
(
	[Rundate] ASC,
	[database_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



------------------- Stored Procedures ------------------------


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[sp_logUsage_VLFs]    Script Date: 7/18/2019 1:59:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_logUsage_VLFs]
AS
set nocount on;

declare	@product_version nvarchar(128)
declare @product_version_major decimal(10,2)
declare @product_version_minor decimal(10,2)
declare @sql varchar(max)

set @product_version = convert(nvarchar(128),serverproperty('productversion'));
select @product_version_major = substring(@product_version, 1,charindex('.', @product_version) + 1 )
	  ,@product_version_minor = parsename(convert(varchar(32), @product_version), 2);

--------------------------------------------------------------------------------------------------------------
-- 1. Log usage
--------------------------------------------------------------------------------------------------------------
declare @logspace_SQL2008 table (
	[database_name] sysname,
	[log_space_mb] decimal(18,2),
	[log_space_used_perc] real,
	[status] bit
)

declare @logspace table (
	[database_name] sysname,
	[total_log_size_in_bytes] bigint,
	[used_log_space_in_bytes] bigint
)

if @product_version_major < 11
	begin
		insert into @logspace_SQL2008
			exec ('DBCC SQLPERF(LOGSPACE);')

		/* make into a 2012 format */
		insert into @logspace
		select 
			[database_name],
			[total_log_size_in_bytes] = [log_space_mb] * 1024.0 * 1024.0,
			[used_log_space_in_bytes] = ([log_space_mb] * [log_space_used_perc] / 100.0) * 1024.0 * 1024.0
		from @logspace_SQL2008
	end
else
	begin
		insert into @logspace
			exec sp_MSforeachdb '
				use [?]
				select 
					''?'',
					[total_log_size_in_bytes],
					[used_log_space_in_bytes]
				from sys.dm_db_log_space_usage' 
	end 
		

	----------------------------------------------------------------------------------
	--- 2. Get VLFs 
	-----------------------------------------------------------------------------------

--declare @query varchar(100)  
declare @dbname sysname  
declare @vlf int  
  

declare @databases table (dbname sysname)  
insert into @databases  
select name from sys.databases where state = 0  
  
declare @vlfcounts table  
    (dbname sysname,  
    vlfcount int)  
   
-- check the version and execute the query accrodingly 
 if @product_version_major < 11
	begin


    declare @dbccloginfo table  
    (  
        fileid smallint,  
        file_size bigint,  
        start_offset bigint,  
        fseqno int,  
        [status] tinyint,  
        parity tinyint,  
        create_lsn numeric(25,0)  
    )  
  
    while exists(select top 1 dbname from @databases)  
		begin  
			  set @dbname = (select top 1 dbname from @databases)  
			set @sql = 'dbcc loginfo (' + '''' + @dbname + ''') '  
  
			insert into @dbccloginfo  
			exec (@sql)  
  
			set @vlf = @@rowcount  
  
			insert @vlfcounts  
			values(@dbname, @vlf)  
  
			delete from @databases where dbname = @dbname  
		  end --while loop

end 

		else 
begin 
    declare @dbccloginfo2012 table  
    (  
        RecoveryUnitId int, 
        fileid smallint,  
        file_size bigint,  
        start_offset bigint,  
        fseqno int,  
        [status] tinyint,  
        parity tinyint,  
        create_lsn numeric(25,0)  
    )  
  
    while exists(select top 1 dbname from @databases)  
    begin  
  
        set @dbname = (select top 1 dbname from @databases)  
        set @sql = 'dbcc loginfo (' + '''' + @dbname + ''') '  
  
        insert into @dbccloginfo2012  
        exec (@sql)  
  
        set @vlf = @@rowcount  
  
        insert @vlfcounts  
        values(@dbname, @vlf)  
  
        delete from @databases where dbname = @dbname  
      end --while 

end 
  

--------------------------------------------------------
--- 3. Combine results
--------------------------------------------------------

insert into [Baseline].[dbo].[LogUsage_VLFs]
select 
	  ls.[database_name]
	, ls.[total_log_size_in_bytes] 
	, ls.[used_log_space_in_bytes] 
	, vlfs.[vlfcount]
	, [collection_time] = getdate()
	
from  @logspace ls
	inner join @vlfcounts vlfs
	on ls.[database_name] = vlfs.[dbname]

GO



-------------------------------------------------------------------------


USE [Baseline]
GO

/****** Object:  StoredProcedure [dbo].[Clear_Disk_FileSpace_History]    Script Date: 7/18/2019 2:00:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



                     CREATE PROCEDURE [dbo].[Clear_Disk_FileSpace_History]
                           AS

                     SET NOCOUNT ON
                     SET XACT_ABORT ON

                     BEGIN TRY

                                         DELETE [Baseline].[dbo].[DiskSpace]
                                         WHERE Rundate < DATEADD(dd,-90, dateadd(dd, datediff(dd,0, GETDATE()),0));
                                  
										DELETE [Baseline].[dbo].[DBFilesSpace]
                                        WHERE Rundate < DATEADD(dd,-90, dateadd(dd, datediff(dd,0, GETDATE()),0));

										DELETE  [Baseline].[dbo].[LogUsage_VLFs]
                                        WHERE RunDate < DATEADD(dd,-30, dateadd(dd, datediff(dd,0, GETDATE()),0));
                                  

                     END TRY
                     BEGIN CATCH

                           IF (XACT_STATE()) != 0
                                  ROLLBACK TRANSACTION;
                            
                           DECLARE @errMessage varchar(MAX)
                           SET @errMessage = 'Stored procedure ' + OBJECT_NAME(@@PROCID) + ' failed with error ' + CAST(ERROR_NUMBER() AS VARCHAR(20)) + '. ' + ERROR_MESSAGE() 
                           RAISERROR (@errMessage, 16, 1)
                                  
                     END CATCH
                     


GO




--- Job creation to insert the records every 1 hour


USE [msdb]
GO

/****** Object:  Job [DBA - DB Space Utilization]    Script Date: 7/18/2019 1:56:44 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    Script Date: 7/18/2019 1:56:44 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA - DB Space Utilization', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Collects DB files Space utilization and runs every 1 hour

', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBSpace]    Script Date: 7/18/2019 1:56:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBSpace', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT INTO DBFilesSpace 
EXEC Sp_msforeachdb 
''USE [?] 
SELECT db_name(), 
[file_id], name, 
physical_name, 
LEFT(physical_name, 1),
size/128.0,
cast(fileproperty(name, ''''spaceused'''') AS INT)/128.0, size/128.0 - cast(fileproperty(name, ''''spaceused'''') AS INT)/128.0, 
(size/128.0 - cast( fileproperty(name, ''''spaceused'''') AS INT)/128.0)*100/(size/128.0), 
100 - (size/128.0 - cast(fileproperty(name, ''''spaceused'''') AS INT)/128.0)*100/(size/128.0),
getdate()
FROM sys.database_files''', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DiskSpace]    Script Date: 7/18/2019 1:56:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DiskSpace', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT INTO DiskSpace
SELECT DISTINCT
  vs.volume_mount_point AS [Drive],
  vs.logical_volume_name AS [Drive_Label],
  vs.total_bytes/1024/1024 AS [Drive_Size_MB],
  vs.available_bytes/1024/1024 AS [Drive_Free_Space_MB],
    getdate() as Rundate 
FROM sys.master_files AS f
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
ORDER BY vs.volume_mount_point;
', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LogSpace_VLFs]    Script Date: 7/18/2019 1:56:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LogSpace_VLFs', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[sp_logUsage_VLFs]', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge_OLDSpaceLog]    Script Date: 7/18/2019 1:56:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge_OLDSpaceLog', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[Clear_Disk_FileSpace_History]', 
		@database_name=N'Baseline', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DB Space', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20181016, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=75959, 
		@schedule_uid=N'b674f1c2-673d-48f0-b64c-6836ee030da6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO




------------------======================10. Waits_Ignored===================----------------------



-- Create Table


USE [Baseline]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[Waits_Ignored]') AND type in (N'U'))

CREATE TABLE [dbo].[Waits_Ignored](
	[WaitType] [sysname] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[WaitType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


--- Insert the wait types which should be ignored



USE [Baseline]
GO

INSERT INTO [dbo].[Waits_Ignored]
           ([WaitType])
     VALUES
          
		  ('BROKER_EVENTHANDLER'),
('BROKER_RECEIVE_WAITFOR'),
('BROKER_TASK_STOP'),
('BROKER_TO_FLUSH'),
('BROKER_TRANSMITTER'),
('CHECKPOINT_QUEUE'),
('CHKPT'),
('CLR_AUTO_EVENT'),
('CLR_MANUAL_EVENT'),
('CLR_SEMAPHORE'),
('DBMIRROR_DBM_EVENT'),
('DBMIRROR_EVENTS_QUEUE'),
('DBMIRROR_WORKER_QUEUE'),
('DBMIRRORING_CMD'),
('DIRTY_PAGE_POLL'),
('DISPATCHER_QUEUE_SEMAPHORE'),
('EXECSYNC'),
('FSAGENT'),
('FT_IFTS_SCHEDULER_IDLE_WAIT'),
('FT_IFTSHC_MUTEX'),
('HADR_CLUSAPI_CALL'),
('HADR_FILESTREAM_IOMGR_IOCOMPLETION'),
('HADR_LOGCAPTURE_WAIT'),
('HADR_NOTIFICATION_DEQUEUE'),
('HADR_TIMER_TASK'),
('HADR_WORK_QUEUE'),
('KSOURCE_WAKEUP'),
('LAZYWRITER_SLEEP'),
('LOGMGR_QUEUE'),
('ONDEMAND_TASK_QUEUE'),
('PWAIT_ALL_COMPONENTS_INITIALIZED'),
('QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP'),
('QDS_PERSIST_TASK_MAIN_LOOP_SLEEP'),
('REQUEST_FOR_DEADLOCK_SEARCH'),
('RESOURCE_QUEUE'),
('SERVER_IDLE_CHECK'),
('SLEEP_BPOOL_FLUSH'),
('SLEEP_DBSTARTUP'),
('SLEEP_DCOMSTARTUP'),
('SLEEP_MASTERDBREADY'),
('SLEEP_MASTERMDREADY'),
('SLEEP_MASTERUPGRADED'),
('SLEEP_MSDBSTARTUP'),
('SLEEP_SYSTEMTASK'),
('SLEEP_TASK'),
('SLEEP_TEMPDBSTARTUP'),
('SNI_HTTP_ACCEPT'),
('SP_SERVER_DIAGNOSTICS_SLEEP'),
('SQLTRACE_BUFFER_FLUSH'),
('SQLTRACE_INCREMENTAL_FLUSH_SLEEP'),
('SQLTRACE_WAIT_ENTRIES'),
('WAIT_FOR_RESULTS'),
('WAIT_XTP_CKPT_CLOSE'),
('WAIT_XTP_HOST_WAIT'),
('WAIT_XTP_OFFLINE_CKPT_NEW_LOG'),
('WAITFOR'),
('WAITFOR_TASKSHUTDOWN'),
('XE_DISPATCHER_JOIN'),
('XE_DISPATCHER_WAIT'),
('XE_TIMER_EVENT'),
('CXCONSUMER'),
('MEMORY_ALLOCATION_EXT'),
('PARALLEL_REDO_DRAIN_WORKER'),
('PARALLEL_REDO_LOG_CACHE'),
('PARALLEL_REDO_TRAN_LIST'),
('PARALLEL_REDO_WORKER_SYNC'),
('PARALLEL_REDO_WORKER_WAIT_WORK'),
('PREEMPTIVE_XE_GETTARGETSTATE'),
('PWAIT_DIRECTLOGCONSUMER_GETNEXT'),
('QDS_ASYNC_QUEUE'),
('QDS_SHUTDOWN_QUEUE'),
('REDO_THREAD_PENDING_WORK'),
('SOS_WORK_DISPATCHER'),
('WAIT_XTP_RECOVERY')



GO


---------------------------------------------------

--11. Tab Performance Table

--- Create table---------

USE [Baseline]
GO

/****** Object:  Table [dbo].[TabPerformance]    Script Date: 8/30/2018 3:23:58 PM ******/

IF OBJECT_ID('dbo.TabPerformance', 'U') IS NOT NULL 
  DROP TABLE dbo.TabPerformance; 

/****** Object:  Table [dbo].[TabPerformance]    Script Date: 8/30/2018 3:23:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TabPerformance](
	[Type] [varchar](100) NULL,
	[Object] [varchar](100) NULL,
	[CounterName] [nvarchar](100) NULL,
	[Threshold] [nvarchar](100) NULL,
	[Today_AVG] [nvarchar](100) NULL,
	[Yesterday_AVG] [nvarchar](100) NULL,
	[Last_Week_AVG] [nvarchar](300) NULL,
	[Today_MAX] [nvarchar](100) NULL,
	[Yesterday_MAX] [nvarchar](100) NULL,
	[Last_Week_MAX] [nvarchar](300) NULL,
	[Status] [nvarchar](100)NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO




----------INSERT---------- -- Pre populate the static content of the table



--truncate table [TabPerformance]

INSERT INTO [dbo].[TabPerformance]

           ([Type],
		   [Object]
           ,[CounterName]
           ,[Threshold]
           ,[Today_AVG]
           ,[Yesterday_AVG]
           ,[Last_Week_AVG]
           ,[Today_MAX]
           ,[Yesterday_MAX]
           ,[Last_Week_MAX]
           ,[Status]
           )
     VALUES

	 -- CPU
           ('OS','CPU','Processor Utilization','<= 80%','','', '','','', '',''),
		   ('OS','CPU','Priviledged Utilization','< 40% of % Processor Time','','', '','','', '','' ),
		   ('OS','CPU','SQL Process Utilization','<= 80%','','', '','','', '','' ),
		   ('OS','CPU','SQL Privileged Utilization','< 40% of % SQL Process Time','','', '','','', '','' ),
		   ('OS','CPU','Processor Queue length','12','','', '' ,'','', '',''),
		   

     -- Disk 
		   ('Disk','Disk I/O','Avg Disk Read Latency','< 10ms','','', '','','', '','' ),
		   ('Disk','Disk I/O','Avg Disk Write Latency','< 10ms','','', '' ,'','', '',''),
		   ('Disk','Disk I/O','Avg Disk Transfer Latency','< 10ms','','', '' ,'','', '',''),
		   ('Disk','Disk I/O','Disk Bytes/sec','Depends on load','','', '' ,'','', '',''),
		   ('Disk','Disk I/O','Disk Transfers/sec','Depends on load','','', '' ,'','', '',''),
		   ('Disk','Disk I/O','Avg Disk Queue Length','< 2','','', '' ,'','', '',''),
		   ('Disk','Disk I/O','Current Disk Queue Length','< 10','','', '' ,'','', '',''),
		
     -- Memory
		   ('OS','Memory','Available Memory In MB','> 10%','','', '' ,'','', '',''),
		   ('OS','Memory','Pages Input/sec','< 1000','','', '' ,'','', '',''),
		   ('OS','Memory','Pages/sec','< 1000','','', '' ,'','', '',''),
		   ('OS','System','Paging File','< 10%','','', '' ,'','', '',''),


	-- Network 


		  ('Network','Network Interface','Bytes Total/sec','< 40% of the interface consumed','','', '' ,'','', '',''),
		  ('Network','Network Interface','Output Queue Length','0','','', '' ,'','', '',''),

     -- SQL Server 



		   ('SQL Server','SQL Statistics','Batch Request per second ','Proportionate to workload','','', '' ,'','', '',''),
		   ('SQL Server','SQL Statistics','SQL Compilations per second','< 10% of Batch Requests/Sec','','', '' ,'','', '',''),
		   ('SQL Server','SQL Statistics','SQL Recompilations per second','< 10% of SQL Compilations/sec','','', '' ,'','', '',''),
		   

		   ('SQL Server','General Statistics','User Connections','Proportionate to Batch Requests /sec','','', '' ,'','', '',''),
		   ('SQL Server','General Statistics','Logins/Sec','< 2','','', '' ,'','', '',''),
		   ('SQL Server','General Statistics','Logouts/Sec','< 2','','', '' ,'','', '',''), 
		   ('SQL Server','General Statistics','Temp tables creation rate','Depends on load','','', '' ,'','', '',''),
		   ('SQL Server','General Statistics','Temp tables creation destruction','Depends on load','','', '' ,'','', '',''),

		   
		   ('SQL Server','Locks','Lock Waits/sec','< 1','','', '' ,'','', '',''),
		   ('SQL Server','Locks','Number of Deadlocks/sec','< 1','','', '','','', '','' ),

		   	   	   
		   ('SQL Server','Access Methods','Forwarded Records/sec','< 10 /100 Batch Requests/Sec','','', '' ,'','', '',''),
		   ('SQL Server','Access Methods','Full Scans/sec','(Index Searches/sec)/(Full Scans/sec) > 1000','','', '' ,'','', '',''),
		   ('SQL Server','Access Methods','Index Searches/sec','(Index Searches/sec)/(Full Scans/sec) > 1000','','', '' ,'','', '',''),
		   ('SQL Server','Access Methods','Page Splits/Sec','< 20 /100 Batch Requests/Sec','','', '','','', '' ,''),

		             
		   ('SQL Server','Buffer manager','Buffer cache hit ratio','> 98%','','', '' ,'','', '',''),
		   ('SQL Server','Buffer manager','Checkpoint Pages/Sec','< 30','','', '' ,'','', '',''),
		--   ('SQL Server','Buffer manager','Free Pages','> 640','','', '' ,'','', '',''),
		   ('SQL Server','Buffer manager','Lazy Writes/Sec','< 20','','', '' ,'','', '',''),
		   ('SQL Server','Buffer manager','Page life expectancy','> 600','','', '','','', '','' ),
		   ('SQL Server','Buffer manager','Page Reads/Sec','< 90','','', '' ,'','', '',''),
		   ('SQL Server','Buffer manager','Page Writes/Sec','< 90','','', '' ,'','', '',''),

		   ('SQL Server','Memory manager','Memory Grants Outstanding','0','','', '' ,'','', '',''),
		   ('SQL Server','Memory manager','Memory Grants Pending','0','','', '' ,'','', '',''),
		   ('SQL Server','Memory manager','Target Server Memory_MB','Close to Max memory allocated to SQL','','', '' ,'','', '',''),
		   ('SQL Server','Memory manager','Total Server Memory_MB','What SQL currently has','','', '' ,'','', '',''),

		   
		   ('SQL Server','Transactions','Free Space in Tempdb_GB','>20%','','', '','','', '','' ) 
		   
		   GO


-------------------------------------------------------------------------------------------------------
--- Create a STored Procedure which does the Calculation of AVG and MAX for each metric-----------



USE [Baseline]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create procedure [dbo].[sp_TabularData] 
AS



IF OBJECT_ID('tempdb.dbo.#output', 'U') IS NOT NULL
  DROP TABLE #output; 



DECLARE @CPUCOUNT int
SELECT @CPUCOUNT=cpu_count from sys.dm_os_sys_info

---- 1. Create the temporary table ----

CREATE TABLE #output(
[DateSampled] [datetime] NULL, 

[Processor Utilization] [nvarchar](100) NULL,
[Priviledged Utilization] [nvarchar](100) NULL,
[SQL Process Utilization] [nvarchar](100) NULL,
[SQL Privileged Utilization] [nvarchar](100) NULL,
[Processor queue length] [nvarchar](100) NULL,

[Batch Request per second] [nvarchar](100) NULL,
[SQL Compilations per second] [nvarchar](100) NULL,
[SQL Recompilations per second] [nvarchar](100) NULL,

[User Connections] [nvarchar](100) NULL,
[Logins per Sec] [nvarchar](100) NULL,
[Logouts per Sec] [nvarchar](100) NULL,
[Temp tables creation] [nvarchar](100) NULL,
[Temp tables deletion] [nvarchar](100) NULL,

[Avg Disk Read Latency] [nvarchar](100) NULL,
[Avg Disk Write Latency] [nvarchar](100) NULL,
[Disk Transfer Latency] [nvarchar](100) NULL,
[Disk Bytes per Sec in MB] [float] NULL,
[Disk Transfers per Sec] [nvarchar](100) NULL,
[Avg Disk Queue Length] [nvarchar](100) NULL,
[Current Disk Queue Length] [nvarchar](100) NULL,

[Available Memory In MB] [nvarchar](100) NULL,
[Memory Pages Input per Sec] [nvarchar](100) NULL,
[Memory Pages per Sec] [nvarchar](100) NULL,
[Paging File Usage] [nvarchar](100) NULL,

[Lock waits per Sec] [nvarchar](100) NULL,
[Deadlocks per Sec] [nvarchar](100) NULL,

[Forwarded records Sec] [nvarchar](100) NULL,
[Full scans per Sec] [nvarchar](100) NULL,
[Index searches per Sec] [float] NULL,
[Page Splits per Sec] [nvarchar](100) NULL,

[Buffer Cache Hit Ratio] [nvarchar](100) NULL,
[Page Life Expectancy] [nvarchar](100) NULL,
[Checkpoint Pages per sec] [nvarchar](100) NULL,
[Page reads per sec] [nvarchar](100) NULL,
[Page Writes per sec] [nvarchar](100) NULL,
[Lazy Writes per sec] [nvarchar](100) NULL,

[Target Server Memory_MB] [nvarchar](100) NULL,
[Total Server Memory_MB] [nvarchar](100) NULL,
[Memory Grants Outstanding] [nvarchar](100) NULL,
[Memory Grants Pending] [nvarchar](100) NULL,

[Free Space in Tempdb_GB] [nvarchar](100) NULL,

[Network Bytes Total Per Sec] [numeric](18,0) NULL,
[Network Output Queue Length] [nvarchar](100) NULL

)



INSERT INTO #output (
[DateSampled], 

[Processor Utilization],
[Priviledged Utilization],
[SQL Process Utilization],
[SQL Privileged Utilization],
[Processor queue length],

[Batch Request per second],
[SQL Compilations per second],
[SQL Recompilations per second],

[User Connections],
[Logins per Sec],
[Logouts per Sec],
[Temp tables creation],
[Temp tables deletion],

[Avg Disk Read Latency],
[Avg Disk Write Latency],
[Disk Transfer Latency],
[Disk Bytes per Sec in MB],
[Disk Transfers per Sec],
[Avg Disk Queue Length],
[Current Disk Queue Length],

[Available Memory In MB],
[Memory Pages Input per Sec],
[Memory Pages per Sec],
[Paging File Usage],

[Lock waits per Sec],
[Deadlocks per Sec],

[Forwarded records Sec],
[Full scans per Sec],
[Index searches per Sec],
[Page Splits per Sec],

[Buffer Cache Hit Ratio],
[Page Life Expectancy],
[Checkpoint Pages per sec],
[Page reads per sec],
[Page Writes per sec],
[Lazy Writes per sec],

[Target Server Memory_MB],
[Total Server Memory_MB],
[Memory Grants Outstanding],
[Memory Grants Pending],

[Free Space in Tempdb_GB],
[Network Bytes Total Per Sec],
[Network Output Queue Length]

)



--DECLARE @CPUCOUNT int
--SELECT @CPUCOUNT=cpu_count from sys.dm_os_sys_info

----2. Output of Perfmon counters ----


SELECT 
Datesampled, 

-- CPU 
ROUND([processor(_total)\% processor time],0) as 'Processor Utilization',
ROUND(([processor(_total)\% privileged time]*[processor(_total)\% processor time])/100,0) as 'Priviledged Utilization',
ROUND(([process(sqlservr)\% processor time])/@CPUCOUNT,0) as 'SQL Process Utilization',
ROUND(([process(sqlservr)\% privileged time])/@CPUCOUNT,0) as 'SQL Privileged Utilization',
ROUND([system\processor queue length],0) as 'Processor queue length',

-- SQL Server : Statistics 

ROUND([sql statistics\batch requests/sec],0) as 'Batch Request per second',
ROUND([sql statistics\sql compilations/sec],1) as 'SQL Compilations per second',
ROUND([sql statistics\sql re-compilations/sec],1) as 'SQL Recompilations per second',

-- SQL Server : General Statistics 

ROUND([General Statistics\User Connections],0) as 'User Connections',
ROUND([general statistics\logins/sec],0) as 'Logins per Sec',
ROUND([general statistics\logouts/sec],0) as 'Logouts per Sec',
ROUND([general statistics\temp tables creation rate],0) as 'Temp tables creation',
ROUND([general statistics\temp tables for destruction],0) as 'Temp tables deletion',


-- DISK I/O

ROUND([logicaldisk(_total)\avg. disk sec/read]*1000.0,1) AS 'Avg Disk Read Latency', 
ROUND([logicaldisk(_total)\avg. disk sec/write]*1000.0,1) AS 'Avg Disk Write Latency',
ROUND([logicaldisk(_total)\avg. disk sec/transfer]*1000.0,1) AS 'Disk Transfer Latency',
ROUND([logicaldisk(_total)\disk bytes/sec]/1024.0,1) AS 'Disk Bytes per Sec in MB',
ROUND([logicaldisk(_total)\disk transfers/sec],1) AS 'Disk Transfers per Sec',
ROUND([logicaldisk(_total)\avg. disk queue length],1) AS 'Avg Disk Queue Length',
ROUND([logicaldisk(_total)\current disk queue length],1) AS 'Current Disk Queue Length',

-- OS:  Memory 

ROUND([memory\available mbytes],0) AS 'Available Memory In MB',
ROUND([memory\pages input/sec],0) AS 'Memory Pages Input per Sec',
ROUND([memory\pages/sec],0) AS 'Memory Pages per Sec',
ROUND([paging file(_total)\% usage peak],0) AS 'Paging File Usage',

--SQL Server : Locks

ROUND([locks(_total)\lock waits/sec],1) AS 'Lock waits per Sec',
ROUND([locks(_total)\number of deadlocks/sec],0) AS 'Deadlocks per Sec',

-- SQL server : Access methods

ROUND([access methods\forwarded records/sec],0) AS 'Forwarded records Sec',
ROUND([access methods\full scans/sec],1) AS 'Full scans per Sec',
ROUND([access methods\index searches/sec],1) AS 'Index searches per Sec',
ROUND([access methods\page splits/sec],1) AS 'Page Splits per Sec',

-- SQL Server : Buffer Manager

ROUND([buffer manager\buffer cache hit ratio],1) AS 'Buffer Cache Hit Ratio',
[buffer manager\page life expectancy] AS 'Page Life Expectancy',
ROUND([buffer manager\checkpoint pages/sec],1) AS 'Checkpoint Pages per sec',
ROUND([buffer manager\page reads/sec],1) AS 'Page reads per sec', 
ROUND([buffer manager\page writes/sec],1) AS 'Page Writes per sec', 
[buffer manager\lazy writes/sec] AS 'Lazy Writes per sec',

-- Need to add Free Pages (only for 2008)


-- SQL Server : Memory Manager 

ROUND([memory manager\Target Server Memory (KB)]/1024.0,0) AS 'Target Server Memory_MB',
ROUND([memory manager\Total Server Memory (KB)]/1024.0,0) AS 'Total Server Memory_MB',
ISNULL(ROUND([memory manager\memory grants outstanding],0),0) AS 'Memory Grants Outstanding',
ISNULL(ROUND([memory manager\memory grants pending],0),0) AS 'Memory Grants Pending',


-- Need to add grants

-- SQL Server : Transactions 

ROUND([transactions\free space in tempdb (kb)]/1024.0/1024.0,0) AS 'Free Space in Tempdb_GB',

-- Network : Bytes Total 

--Standard Ones

--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter)\bytes total/sec],0),0) AS 'Network_0 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _2)\bytes total/sec],0),0) AS 'Network_2 Bytes Total per Sec',

----Non Standard Ones

--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter#1)\bytes total/sec],0),0) AS 'Network_1 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _5)\bytes total/sec],0),0) AS 'Network_5 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _6)\bytes total/sec],0),0) AS 'Network_6 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _3)\bytes total/sec],0),0) AS 'Network_3 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _4)\bytes total/sec],0),0) AS 'Network_4 Bytes Total per Sec',
--ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _2)\bytes total/se],0),0) AS 'Network_2s Bytes Total per Sec',


-- Adding network adapters into single column 


---************** Showing Only added column***********************

ROUND((

    ISNULL (ROUND([network interface(vmxnet3 ethernet adapter)\bytes total/sec],0),0)
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _2)\bytes total/sec],0),0)
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter#1)\bytes total/sec],0),0)
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _5)\bytes total/sec],0),0) 
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _6)\bytes total/sec],0),0) 
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _3)\bytes total/sec],0),0) 
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _4)\bytes total/sec],0),0) 
 +  ISNULL (ROUND([network interface(vmxnet3 ethernet adapter _2)\bytes total/sec],0),0)

),0) 
as 'Network Bytes Total Per Sec',


--AVG(CAST([Network Bytes Total Per Sec] as DECIMAL(9,2)))

-- Network : Network Output Queue Length 


--network interface(vmxnet3 ethernet adapter _2)\output queue length
--network interface(vmxnet3 ethernet adapter)\output queue length


--Standard Ones

--ISNULL([network interface(vmxnet3 ethernet adapter)\output queue length],0) AS 'Network_0 output queue length',
--ISNULL([network interface(vmxnet3 ethernet adapter _2)\output queue length],0) AS 'Network_2 output queue length',

--Non Standard Ones

--ISNULL([network interface(vmxnet3 ethernet adapter#1)\output queue length],0) AS 'Network_1 output queue length',
--ISNULL([network interface(vmxnet3 ethernet adapter _5)\output queue length],0) AS 'Network_5 output queue length',
--ISNULL([network interface(vmxnet3 ethernet adapter _6)\output queue length],0) AS 'Network_6 output queue length',
--ISNULL([network interface(vmxnet3 ethernet adapter _3)\output queue length],0) AS 'Network_3 output queue length',
--ISNULL([network interface(vmxnet3 ethernet adapter _4)\output queue length],0) AS 'Network_4 output queue length',
----ISNULL(ROUND([network interface(vmxnet3 ethernet adapter _2)\bytes total/se],0),0) AS 'Network_2s Bytes Total per Sec',


-- Adding network adapters into single column 

ROUND((

    ISNULL ([network interface(vmxnet3 ethernet adapter)\output queue length],0)
 +  ISNULL ([network interface(vmxnet3 ethernet adapter _2)\output queue length],0)
 +  ISNULL ([network interface(vmxnet3 ethernet adapter#1)\output queue length],0) 
 +  ISNULL ([network interface(vmxnet3 ethernet adapter _5)\output queue length],0) 
 +  ISNULL ([network interface(vmxnet3 ethernet adapter _6)\output queue length],0) 
 +  ISNULL ([network interface(vmxnet3 ethernet adapter _3)\output queue length],0) 
 +  ISNULL ([network interface(vmxnet3 ethernet adapter _4)\output queue length],0) 
 --+  ISNULL ([network interface(vmxnet3 ethernet adapter _2)\bytes total/se],0)

),0) 
as 'Network Output Queue Length'


-- Need to Output Queue


FROM
(
select 
DateSampled, 
CounterName,
ROUND(CounterValue,7) as 'CounterValue'
from PerformanceCounter
where CounterName IN 

('processor(_total)\% processor time',
'processor(_total)\% privileged time',
'process(sqlservr)\% processor time',
'process(sqlservr)\% privileged time',
'system\processor queue length',

'sql statistics\batch requests/sec',
'sql statistics\sql compilations/sec',
'sql statistics\sql re-compilations/sec',

'general Statistics\User Connections',
'general statistics\logins/sec',
'general statistics\logouts/sec',
'general statistics\temp tables creation rate',
'general statistics\temp tables for destruction',


'logicaldisk(_total)\avg. disk sec/read', 
'logicaldisk(_total)\avg. disk sec/write', 
'logicaldisk(_total)\avg. disk sec/transfer',
'logicaldisk(_total)\disk bytes/sec',
'logicaldisk(_total)\disk transfers/sec',
'logicaldisk(_total)\avg. disk queue length',
'logicaldisk(_total)\current disk queue length',


'memory\available mbytes',
'memory\pages input/sec',
'memory\pages/sec',
'paging file(_total)\% usage peak',

'locks(_total)\lock waits/sec',
'locks(_total)\number of deadlocks/sec',


'access methods\forwarded records/sec',
'access methods\full scans/sec',
'access methods\index searches/sec',
'access methods\page splits/sec',

'buffer manager\buffer cache hit ratio',
'buffer manager\page life expectancy',
'buffer manager\checkpoint pages/sec',
'buffer manager\page reads/sec',
'buffer manager\page writes/sec',
'buffer manager\lazy writes/sec',


'memory manager\Target Server Memory (KB)',
'memory manager\Total Server Memory (KB)',
'memory manager\memory grants outstanding',
'memory manager\memory grants pending',


'transactions\free space in tempdb (kb)',


'network interface(vmxnet3 ethernet adapter)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _2)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter#1)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _5)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _6)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _3)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _4)\bytes total/sec',
'network interface(vmxnet3 ethernet adapter _2)\bytes total/se',

'network interface(vmxnet3 ethernet adapter)\output queue length',
'network interface(vmxnet3 ethernet adapter _2)\output queue length',
'network interface(vmxnet3 ethernet adapter#1)\output queue length',
'network interface(vmxnet3 ethernet adapter _5)\output queue length',
'network interface(vmxnet3 ethernet adapter _6)\output queue length',
'network interface(vmxnet3 ethernet adapter _3)\output queue length',
'network interface(vmxnet3 ethernet adapter _4)\output queue length'
--,'network interface(vmxnet3 ethernet adapter _2)\bytes total/se'


)
 --and DateSampled > = DATEADD(MOnth, -2, GETDATE()) -- Last 2 months Data
--and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))
--and DateSampled > = DATEADD(MONTH, -1, GETDATE()) --- Last one month Data

and DateSampled > = DATEADD(DAY, -10, GETDATE()) --- Last 10 days Data
) AS P
PIVOT 
(
AVG(CounterValue)
FOR 
CounterName IN ([processor(_total)\% processor time],
[processor(_total)\% privileged time],
[process(sqlservr)\% processor time],
[process(sqlservr)\% privileged time],
[system\processor queue length],

[sql statistics\batch requests/sec],
[sql statistics\sql compilations/sec],
[sql statistics\sql re-compilations/sec],

[General Statistics\User Connections],
[general statistics\logins/sec],
[general statistics\logouts/sec],
[general statistics\temp tables creation rate],
[general statistics\temp tables for destruction],


[logicaldisk(_total)\avg. disk sec/read], 
[logicaldisk(_total)\avg. disk sec/write], 
[logicaldisk(_total)\avg. disk sec/transfer],
[logicaldisk(_total)\disk bytes/sec],
[logicaldisk(_total)\disk transfers/sec],
[logicaldisk(_total)\avg. disk queue length],
[logicaldisk(_total)\current disk queue length],

[memory\available mbytes],
[memory\pages input/sec],
[memory\pages/sec],
[paging file(_total)\% usage peak],

[locks(_total)\lock waits/sec],
[locks(_total)\number of deadlocks/sec],

[access methods\forwarded records/sec],
[access methods\full scans/sec],
[access methods\index searches/sec],
[access methods\page splits/sec],


[buffer manager\buffer cache hit ratio],
[buffer manager\page life expectancy],
[buffer manager\checkpoint pages/sec],
[buffer manager\page reads/sec],
[buffer manager\page writes/sec],
[buffer manager\lazy writes/sec],
--[buffer Manager\Free pages],


[memory manager\Target Server Memory (KB)],
[memory manager\Total Server Memory (KB)],
[memory manager\memory grants outstanding],
[memory manager\memory grants pending],

[transactions\free space in tempdb (kb)],


[network interface(vmxnet3 ethernet adapter)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _2)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter#1)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _5)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _6)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _3)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _4)\bytes total/sec],
[network interface(vmxnet3 ethernet adapter _2)\bytes total/se],


[network interface(vmxnet3 ethernet adapter)\output queue length],
[network interface(vmxnet3 ethernet adapter _2)\output queue length],
[network interface(vmxnet3 ethernet adapter#1)\output queue length],
[network interface(vmxnet3 ethernet adapter _5)\output queue length],
[network interface(vmxnet3 ethernet adapter _6)\output queue length],
[network interface(vmxnet3 ethernet adapter _3)\output queue length],
[network interface(vmxnet3 ethernet adapter _4)\output queue length]
--,[network interface(vmxnet3 ethernet adapter _2)\bytes total/se] 
)
) AS pivottable

Order by [DateSampled]

--select * from #output

--select * from TabPerformance

--drop table #output



---------------------------------------------------------------- AVG ----------------------------------------------------------------------
-- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Processor Utilization' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Priviledged Utilization' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Process Utilization' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Privileged Utilization' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Processor Queue length' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Batch Request per second ' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Compilations per second' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Recompilations per second' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'User Connections' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Logins/Sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Logouts/Sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Temp tables creation rate' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Temp tables creation destruction' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where CAST([Avg Disk Read Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Avg Disk Read Latency' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where CAST([Avg Disk Write Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Avg Disk Write Latency' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Disk Transfer Latency] from #output where CAST([Disk Transfer Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Avg Disk Transfer Latency' -- Today_AVG
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where CAST([Disk Bytes per Sec in MB] as float) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Disk Bytes/sec' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where CAST([Disk Transfers per Sec] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Disk Transfers/sec' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where CAST([Avg Disk Queue Length] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Avg Disk Queue Length' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = 
(select AVG(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where CAST([Current Disk Queue Length] as DECIMAL(9,2)) > 0 and DateSampled  >= convert(date, GETDATE())) where CounterName = 'Current Disk Queue Length' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Available Memory In MB' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Pages Input/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Pages/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Paging File' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Lock Waits/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Number of Deadlocks/sec' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Forwarded Records/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Full Scans/sec' -- Today_AVG

-- Float
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Index Searches/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Splits/Sec' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Buffer cache hit ratio' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page life expectancy' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Checkpoint Pages/Sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Reads/Sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Writes/Sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Lazy Writes/Sec' -- Today_AVG



Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Target Server Memory_MB' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Total Server Memory_MB' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Memory Grants Outstanding' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Memory Grants Pending' -- Today_AVG


Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Free Space in Tempdb_GB' -- Today_AVG

Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Bytes Total/sec' -- Today_AVG
Update [Baseline].[dbo].[TabPerformance] set  Today_AVG = (select AVG(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Output Queue Length' -- Today_AVG


-- Yesterday_AVG

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Processor Utilization' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Priviledged Utilization' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Process Utilization' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Privileged Utilization' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Processor Queue length' -- Yesterday_AVG

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Batch Request per second ' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Compilations per second' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Recompilations per second' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'User Connections' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Logins/Sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Logouts/Sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Temp tables creation rate' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Temp tables creation destruction' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where CAST([Avg Disk Read Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Read Latency' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where CAST([Avg Disk Write Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Write Latency' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Disk Transfer Latency] from #output where CAST([Disk Transfer Latency] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Transfer Latency' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
-- Float
(select AVG(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where CAST([Disk Bytes per Sec in MB] as float) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Disk Bytes/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where CAST([Disk Transfers per Sec] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Disk Transfers/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where CAST([Avg Disk Queue Length] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Queue Length' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = 
(select AVG(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where CAST([Current Disk Queue Length] as DECIMAL(9,2)) > 0 and DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Current Disk Queue Length' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Available Memory In MB' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Pages Input/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Pages/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Paging File' -- Yesterday_AVG

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Lock Waits/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Number of Deadlocks/sec' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Forwarded Records/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Full Scans/sec' -- Yesterday_AVG
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Index Searches/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Splits/Sec' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Buffer cache hit ratio' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page life expectancy' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Checkpoint Pages/Sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Reads/Sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Writes/Sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Lazy Writes/Sec' -- Yesterday_AVG



Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Target Server Memory_MB' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Total Server Memory_MB' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Memory Grants Outstanding' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Memory Grants Pending' -- Yesterday_AVG


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Free Space in Tempdb_GB' -- Yesterday_AVG

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Bytes Total/sec' -- Yesterday_AVG
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_AVG = (select AVG(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Output Queue Length' -- Yesterday_AVG



--Last Week (7th day from Today_AVG)


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Processor Utilization'

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Priviledged Utilization'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Process Utilization' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'SQL Privileged Utilization' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where  CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Processor Queue length'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Batch Request per second '  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Compilations per second'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Recompilations per second'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'User Connections'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Logins/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Logouts/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Temp tables creation rate' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Temp tables creation destruction'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where CAST([Avg Disk Read Latency] as DECIMAL(9,2)) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Read Latency' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where CAST([Avg Disk Write Latency] as DECIMAL(9,2)) > 0 and  CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Write Latency'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Disk Transfer Latency] from #output where CAST([Disk Transfer Latency] as DECIMAL(9,2)) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Transfer Latency'

-- Float -- changed it to float as there was issue reading long string of numeric data
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where CAST([Disk Bytes per Sec in MB] as float) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Disk Bytes/sec'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where CAST([Disk Transfers per Sec] as DECIMAL(9,2)) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Disk Transfers/sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where CAST([Avg Disk Queue Length] as DECIMAL(9,2)) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Queue Length' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = 
(select AVG(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where CAST([Current Disk Queue Length] as DECIMAL(9,2)) > 0 and CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Current Disk Queue Length' 


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Available Memory In MB'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Pages Input/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Pages/sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Paging File'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Lock Waits/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Number of Deadlocks/sec'


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Forwarded Records/sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where  CounterName = 'Full Scans/sec' 
-- Float
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Index Searches/sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where  CounterName = 'Page Splits/Sec'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Buffer cache hit ratio'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page life expectancy'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))   where CounterName = 'Checkpoint Pages/Sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page Reads/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page Writes/Sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Lazy Writes/Sec'



Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Target Server Memory_MB'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Total Server Memory_MB'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Memory Grants Outstanding'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Memory Grants Pending'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Free Space in Tempdb_GB'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Bytes Total/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_AVG] = (select AVG(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Output Queue Length'




--------------------------------------------------------------------------- MAX -------------------------------------------------------------



-- Today


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Processor Utilization' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Priviledged Utilization' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Process Utilization' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Privileged Utilization' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Processor Queue length' -- Today_MAX

Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Batch Request per second ' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Compilations per second' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'SQL Recompilations per second' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'User Connections' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Logins/Sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Logouts/Sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Temp tables creation rate' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Temp tables creation destruction' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'AVG Disk Read Latency' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'AVG Disk Write Latency' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Avg Transfer Latency]   from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'AVG Disk Transfer Latency' -- Today_MAX
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Disk Bytes/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Disk Transfers/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Avg Disk Queue Length' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Current Disk Queue Length' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Available Memory In MB' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Pages Input/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Pages/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Paging File' -- Today_MAX

Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Lock Waits/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Number of Deadlocks/sec' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Forwarded Records/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Full Scans/sec' -- Today_MAX
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Index Searches/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Splits/Sec' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Buffer cache hit ratio' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page life expectancy' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Checkpoint Pages/Sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Reads/Sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Page Writes/Sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Lazy Writes/Sec' -- Today_MAX



Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Target Server Memory_MB' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Total Server Memory_MB' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Memory Grants Outstanding' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Memory Grants Pending' -- Today_MAX


Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Free Space in Tempdb_GB' -- Today_MAX

Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Bytes Total/sec' -- Today_MAX
Update [Baseline].[dbo].[TabPerformance] set  Today_MAX = (select MAX(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where DateSampled  >= convert(date, GETDATE())) where CounterName = 'Output Queue Length' -- Today_MAX


-- Yesterday

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Processor Utilization' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Priviledged Utilization' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Process Utilization' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Privileged Utilization' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Processor Queue length' -- Yesterday_MAX

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Batch Request per second ' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Compilations per second' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'SQL Recompilations per second' -- Yesterday_MAX


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'User Connections' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Logins/Sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Logouts/Sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Temp tables creation rate' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Temp tables creation destruction' -- Yesterday_MAX




Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Read Latency' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Write Latency' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Avg Disk Transfer Latency] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Transfer Latency' -- Yesterday_MAX
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Disk Bytes/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Disk Transfers/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Avg Disk Queue Length' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Current Disk Queue Length' -- Yesterday_MAX




Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Available Memory In MB' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Pages Input/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Pages/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Paging File' -- Yesterday_MAX

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Lock Waits/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Number of Deadlocks/sec' -- Yesterday_MAX


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Forwarded Records/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Full Scans/sec' -- Yesterday_MAX
-- Float
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Index Searches/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Splits/Sec' -- Yesterday_MAX


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Buffer cache hit ratio' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page life expectancy' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Checkpoint Pages/Sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Reads/Sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Page Writes/Sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Lazy Writes/Sec' -- Yesterday_MAX



Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Target Server Memory_MB' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Total Server Memory_MB' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Memory Grants Outstanding' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Memory Grants Pending' -- Yesterday_MAX


Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Free Space in Tempdb_GB' -- Yesterday_MAX

Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Bytes Total/sec' -- Yesterday_MAX
Update [Baseline].[dbo].[TabPerformance] set  Yesterday_MAX = (select MAX(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where DateSampled  >= DATEADD(day, -1, convert(date, GETDATE())) and DateSampled < convert(date, GETDATE())) where CounterName = 'Output Queue Length' -- Yesterday_MAX



--Last Week (7th day from Today)



Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Processor Utilization] as DECIMAL(9,2))) as [Processor Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Processor Utilization'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Priviledged Utilization] as DECIMAL(9,2))) as [Priviledged Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Priviledged Utilization'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([SQL Process Utilization] as DECIMAL(9,2))) as [SQL Process Utilization] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Process Utilization' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([SQL Privileged Utilization] as DECIMAL(9,2))) as [SQL Privileged Utilization] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'SQL Privileged Utilization' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Processor queue length] as DECIMAL(9,2))) as [Processor queue length] from #output where  CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Processor Queue length'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Batch Request per second] as DECIMAL(9,2))) as [Batch Request per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Batch Request per second '  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([SQL Compilations per second] as DECIMAL(9,2))) as [SQL Compilations per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Compilations per second'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([SQL Recompilations per second] as DECIMAL(9,2))) as [SQL Recompilations per second] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'SQL Recompilations per second'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([User Connections] as DECIMAL(9,2))) as [User Connections] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'User Connections'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Logins per Sec] as DECIMAL(9,2))) as [Logins per Sec] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Logins/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Logouts per Sec] as DECIMAL(9,2))) as [Logouts per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Logouts/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Temp tables creation] as DECIMAL(9,2))) as [Temp tables creation] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Temp tables creation rate' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Temp tables deletion] as DECIMAL(9,2))) as [Temp tables deletion] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Temp tables creation destruction'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Avg Disk Read Latency] as DECIMAL(9,2))) as [Avg Disk Read Latency] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Read Latency' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Avg Disk Write Latency] as DECIMAL(9,2))) as [Avg Disk Write Latency] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Write Latency'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Disk Transfer Latency] as DECIMAL(9,2))) as [Disk Transfer Latency] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Transfer Latency'
-- Float
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Disk Bytes per Sec in MB] as float)) as [Disk Bytes per Sec in MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Disk Bytes/sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Disk Transfers per Sec] as DECIMAL(9,2))) as [Disk Transfers per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Disk Transfers/sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Avg Disk Queue Length] as DECIMAL(9,2))) as [Avg Disk Queue Length] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Avg Disk Queue Length' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Current Disk Queue Length] as DECIMAL(9,2))) as [Current Disk Queue Length] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Current Disk Queue Length' 


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Available Memory In MB] as DECIMAL(9,2))) as [Available Memory In MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Available Memory In MB'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Memory Pages Input per Sec] as DECIMAL(9,2))) as [Memory Pages Input per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Pages Input/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Memory Pages per Sec] as DECIMAL(9,2))) as [Memory Pages per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Pages/sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Paging File Usage] as DECIMAL(9,2))) as [Paging File Usage] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Paging File'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Lock waits per Sec] as DECIMAL(9,2))) as [Lock waits per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Lock Waits/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Deadlocks per Sec] as DECIMAL(9,2))) as [Deadlocks per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Number of Deadlocks/sec'


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Forwarded records Sec] as DECIMAL(9,2))) as [Forwarded records Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Forwarded Records/sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Full scans per Sec] as DECIMAL(9,2))) as [Full scans per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where  CounterName = 'Full Scans/sec' 
-- Float
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Index searches per Sec] as float)) as [Index searches per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Index Searches/sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Page Splits per Sec] as DECIMAL(9,2))) as [Page Splits per Sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where  CounterName = 'Page Splits/Sec'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Buffer Cache Hit Ratio] as DECIMAL(9,2))) as [Buffer Cache Hit Ratio] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Buffer cache hit ratio'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Page Life Expectancy] as DECIMAL(9,2))) as [Page Life Expectancy] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page life expectancy'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Checkpoint Pages per sec] as DECIMAL(9,2))) as [Checkpoint Pages per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))   where CounterName = 'Checkpoint Pages/Sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Page reads per sec] as DECIMAL(9,2))) as [Page reads per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page Reads/Sec'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Page Writes per sec] as DECIMAL(9,2))) as [Page Writes per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Page Writes/Sec'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Lazy Writes per sec] as DECIMAL(9,2))) as [Lazy Writes per sec] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Lazy Writes/Sec'



Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Target Server Memory_MB] as DECIMAL(9,2))) as [Target Server Memory_MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Target Server Memory_MB'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Total Server Memory_MB] as DECIMAL(9,2))) as [Total Server Memory_MB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Total Server Memory_MB'  
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Memory Grants Outstanding] as DECIMAL(9,2))) as [Memory Grants Outstanding] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate()))))  where CounterName = 'Memory Grants Outstanding'
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Memory Grants Pending] as DECIMAL(9,2))) as [Memory Grants Pending] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Memory Grants Pending'  


Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Free Space in Tempdb_GB] as DECIMAL(9,2))) as [Free Space in Tempdb_GB] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Free Space in Tempdb_GB'  

Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Network Bytes Total Per Sec] as DECIMAL(18,2))) as [Network Bytes Total Per Sec] from #output  where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Bytes Total/sec' 
Update [Baseline].[dbo].[TabPerformance] set  [Last_Week_MAX] = (select MAX(CAST([Network Output Queue Length] as DECIMAL(9,2))) as [Network Output Queue Length] from #output where CONVERT(date,DateSampled,101) = Convert(datetime, DateAdd(day, -7, Convert(date, GetDate())))) where CounterName = 'Output Queue Length'

Drop table #output


-------------- Updating Status Column -----------------


-------------------------- CPU -------------------

-- GREEN 
-- If Today's AND Yesterday's Utilization is less\equal to 50% 
-- Processor Q length is less\equal to 6

update TabPerformance set [Status] = 'Green' where CounterName = 'Processor Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 50 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 50)
update TabPerformance set [Status] = 'Green' where CounterName = 'Priviledged Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 20 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 20 )
update TabPerformance set [Status] = 'Green' where CounterName = 'SQL Process Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 50 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 50 )
update TabPerformance set [Status] = 'Green' where CounterName = 'SQL Privileged Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 20 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 20 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Processor Queue length' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 6 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 6 )

-- YELLOW
-- If either Today's or Yesterday's Utilization is in between 51% to 80%
-- Processor Q length is between 7 to 12

update TabPerformance set [Status] = 'Yellow' where CounterName = 'Processor Utilization' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Priviledged Utilization' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 21 AND 40) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 21 AND 40))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'SQL Process Utilization' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'SQL Privileged Utilization' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 21 AND 40))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Processor Queue length' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 7 AND 12) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 7 AND 12))



-- RED
-- If either Today's or Yesterday's Utilization is greater than 80% 
-- Processor Q length is greater than 12


update TabPerformance set [Status] = 'Red' where CounterName = 'Processor Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 80 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 80 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Priviledged Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 40 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 40 )
update TabPerformance set [Status] = 'Red' where CounterName = 'SQL Process Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 80 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 80 )
update TabPerformance set [Status] = 'Red' where CounterName = 'SQL Privileged Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 40 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 40 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Processor Queue length' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 12 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 12 )




-------------------------- Disk I/O -------------------

-- Depends

update TabPerformance set [Status] = 'Depends' where CounterName = 'Disk Bytes/sec' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Disk Transfers/sec' 


-- GREEN 
-- If Today's AND Yesterday's Utilization is less\equal to 10ms 
--Disk Avg Q length is less than  1
--Disk Current Q length is less than  5

update TabPerformance set [Status] = 'Green' where CounterName = 'Avg Disk Read Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 10 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 10)
update TabPerformance set [Status] = 'Green' where CounterName = 'Avg Disk Write Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 10 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 10 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Avg Disk Transfer Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 10 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 10 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Avg Disk Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) < 1 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) < 1 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Current Disk Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) < 5 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) < 5 )

 
-- YELLOW
-- If either Today's or Yesterday's Utilization is in between 11ms to 20ms
-- Disk Q length is in between 1 to 2
--Disk Current Q length is in between 5 to 10

update TabPerformance set [Status] = 'Yellow' where CounterName = 'Avg Disk Read Latency' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Avg Disk Write Latency' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Avg Disk Transfer Latency' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 20))
update TabPerformance set [Status] = 'Depends' where CounterName = 'Avg Disk Queue Length'  AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Current Disk Queue Length' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 5 AND 10) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 5 AND 10))



-- RED
-- If either Today's or Yesterday's Disk Utilization is greater than 20ms 
-- Disk Q length is greater than 2
--Disk Current Q length is greater than 10


update TabPerformance set [Status] = 'Red' where CounterName = 'Avg Disk Read Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 20 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 20 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Avg Disk Write Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 20 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 20 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Avg Disk Transfer Latency' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 20 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 20 )
update TabPerformance set [Status] = 'Depends' where CounterName = 'Avg Disk Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 2 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 2 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Current Disk Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 10 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 10 )



-------------------------- Memory -------------------

--Depends

update TabPerformance set [Status] = 'Depends' where CounterName = 'Available Memory In MB' 


-- GREEN 
-- If Today's AND Yesterday's Value is less\equal to 500 


update TabPerformance set [Status] = 'Green' where CounterName = 'Pages Input/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 500 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 500 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Pages/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 500 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 500 )

-- YELLOW
-- If either Today's or Yesterday's Value is in between 501 to 1000


update TabPerformance set [Status] = 'Yellow' where CounterName = 'Pages Input/sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 501 AND 1000) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 501 AND 1000))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Pages/sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 501 AND 1000) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 501 AND 1000))


-- RED
-- If either Today's or Yesterday's Value is greater than 1000 


update TabPerformance set [Status] = 'Red' where CounterName = 'Pages Input/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1000 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1000 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Pages/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1000 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1000 )



-------------------------- System & Network -------------------

--Depends

-- Page file size = RAM * 1.5 or RAM * 2

update TabPerformance set [Status] = 'Depends' where CounterName = 'Paging File' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Bytes Total/sec' 

--Output Q length
--0 = Healthy
--1-2 = Monitor or Caution
--Greater than 2 = Critical, performance will be adversely affected

-- GREEN 
-- If Today's AND Yesterday's Value is equal to 0
update TabPerformance set [Status] = 'Green' where CounterName = 'Output Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) = 0 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) = 0 )

-- YELLOW
-- If either Today's or Yesterday's Value is in between 1 to 2
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Output Queue Length' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2))

-- RED
-- If either Today's or Yesterday's Value is greater than 2 
update TabPerformance set [Status] = 'Red' where CounterName = 'Output Queue Length' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 2 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 2 )



-------------------------- SQL Statistics/Genral Statistics -------------------

--Depends


update TabPerformance set [Status] = 'Depends' where CounterName = 'Batch Request per second' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'SQL Compilations per second' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'SQL Recompilations per second' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'User Connections' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Temp tables creation rate' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Temp tables creation destruction' 


-- GREEN 
-- If Today's AND Yesterday's Value is equal or less than 1
update TabPerformance set [Status] = 'Green' where CounterName = 'Logins/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 1 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 1 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Logouts/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 1 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 1 )

-- YELLOW
-- If either Today's or Yesterday's Value is in between 1 to 2
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Logins/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Logouts/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 1 AND 2))

-- RED
-- If either Today's or Yesterday's Value is greater than 2 
update TabPerformance set [Status] = 'Red' where CounterName = 'Logins/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 2 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 2 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Logouts/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 2 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 2 )



-------------------------- Locks -------------------



-- GREEN 
-- If Today's AND Yesterday's Value is equal to 0
update TabPerformance set [Status] = 'Green' where CounterName = 'Lock Waits/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) = 0 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) = 0 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Number of Deadlocks/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) = 0 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) = 0 )

-- YELLOW
-- If either Today's or Yesterday's Value is in between 0.1 to 1
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Lock Waits/sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Number of Deadlocks/sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1))

-- RED
-- If either Today's or Yesterday's Value is greater than 1 
update TabPerformance set [Status] = 'Red' where CounterName = 'Lock Waits/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Number of Deadlocks/sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1 )



-------------------------- Access Methods -------------------

--Depends

update TabPerformance set [Status] = 'Depends' where CounterName = 'Forwarded Records/sec' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Full Scans/sec' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Index Searches/sec' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Page Splits/Sec' 



-------------------------- Buffer manager -------------------

-- GREEN 
-- BCHR greater than 99
-- Checkpoint Pages is less than or equal to 10
-- Lazy writes is less than or equal to 5 
-- Page life expectancy is greater than 1500
-- Page Reads & Writes is less than or equal 60

update TabPerformance set [Status] = 'Green' where CounterName = 'Buffer cache hit ratio' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 99 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) > 99)
update TabPerformance set [Status] = 'Green' where CounterName = 'Checkpoint Pages/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 10 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 10 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Lazy Writes/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 5 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 5 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Page life expectancy' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1500 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1500 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Page Reads/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 60 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 60 )
update TabPerformance set [Status] = 'Green' where CounterName = 'Page Writes/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 60 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 60 )

-- YELLOW
-- BCHR is between 98 and 99
-- Checkpoint Pages is between 11 to 30
-- Lazy writes is between 6 to 20
-- Page life expectancy is between 600 to 1500
-- Page Reads & Writes is between 61 to 90



update TabPerformance set [Status] = 'Yellow' where CounterName = 'Buffer cache hit ratio' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 98 AND 99) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 98 AND 99))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Checkpoint Pages/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 30) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 11 AND 30))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Lazy Writes/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 6 AND 20) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 6 AND 20))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Page life expectancy' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 600 AND 1500) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 600 AND 1500))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Page Reads/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 61 AND 90) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 61 AND 90))
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Page Writes/Sec' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 61 AND 90) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 61 AND 90))



-- RED
-- BCHR is lesser than 98
-- Checkpoint Pages is greater than 30
-- Lazy writes is greater than 20
-- Page life expectancy is lesser than 600
-- Page Reads & Writes is greater 90


update TabPerformance set [Status] = 'Red' where CounterName = 'Buffer cache hit ratio' AND (CAST([Today_AVG] as DECIMAL(9,2)) < 98 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) < 98 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Checkpoint Pages/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 30 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 30 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Lazy Writes/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 20 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 20 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Page life expectancy' AND (CAST([Today_AVG] as DECIMAL(9,2)) < 600 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) < 600 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Page Reads/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 90 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 90 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Page Writes/Sec' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 90 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 90 )





-------------------------- Memory Manager/Transactions -------------------

--Depends

update TabPerformance set [Status] = 'Depends' where CounterName = 'Target Server Memory_MB' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Total Server Memory_MB' 
update TabPerformance set [Status] = 'Depends' where CounterName = 'Free Space in Tempdb_GB' 


-- GREEN 

-- Memory Grants Outstanding is equal to 1
-- Memory Grants Pending is equal to 0

update TabPerformance set [Status] = 'Green' where CounterName = 'Memory Grants Outstanding' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 1 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 1)
update TabPerformance set [Status] = 'Green' where CounterName = 'Memory Grants Pending' AND (CAST([Today_AVG] as DECIMAL(9,2)) = 0 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) = 0 )

-- YELLOW
-- Memory Grants Outstanding is less than 1
--update TabPerformance set [Status] = 'Yellow' where CounterName = 'Memory Grants Outstanding' AND ((CAST([Today_AVG] as DECIMAL(9,2)) <  1) OR (CAST([Yesterday_AVG] as DECIMAL(9,2))< 1))
--update TabPerformance set [Status] = 'Yellow' where CounterName = 'Memory Grants Pending' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 0.1 AND 1))


-- RED
-- Memory Grants Outstanding is greater than 1
-- Memory Grants Pending is greater than 0


update TabPerformance set [Status] = 'Red' where CounterName = 'Memory Grants Outstanding' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 1 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 1 )
update TabPerformance set [Status] = 'Red' where CounterName = 'Memory Grants Pending' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 0 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 0 )

GO




/*

select * from TabPerformance where CounterName = 'Processor Utilization'


update TabPerformance set Today_AVG = '75' where CounterName = 'Processor Utilization'
update TabPerformance set Yesterday_AVG = '85' where CounterName = 'Processor Utilization'
-- UPDATE  TabPerformance SET Status = Null;


update TabPerformance set [Status] = 'Green' where CounterName = 'Processor Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) <= 50 AND CAST([Yesterday_AVG] as DECIMAL(9,2)) <= 50)
update TabPerformance set [Status] = 'Yellow' where CounterName = 'Processor Utilization' AND ((CAST([Today_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80) OR (CAST([Yesterday_AVG] as DECIMAL(9,2)) BETWEEN 51 AND 80))
update TabPerformance set [Status] = 'Red' where CounterName = 'Processor Utilization' AND (CAST([Today_AVG] as DECIMAL(9,2)) > 80 OR CAST([Yesterday_AVG] as DECIMAL(9,2)) > 80 )


------All cases been tested-----

Today_AVG	Yesterday_AVG  
20			20		..... green
20			50		..... green
20			51		..... Yellow
51			20                            ..... yellow
72			65		..... yellow
20			81		..... red
85			90		..... red
75			85 		..... red	     
*/

GO

-----------------------------------------------------------------

---- Create a BASELINEVERSION table


--select * from [dbo].[BaselineVersion]


IF NOT EXISTS (select * from sysobjects where name='BaselineVersion' and xtype='U')
    
BEGIN 

CREATE TABLE [dbo].[BaselineVersion](
	[Version] [nchar](10) NULL,
	[Version_Updates] [nvarchar](max) NULL,
	[Release_date] [date] NULL,
	[Deployed_date] [date] NULL
)
END

INSERT INTO BaselineVersion 
(
	[Version], 
	[Version_Updates],
	[Release_date],
	[Deployed_date]
	)

	VALUES ('2.0','Files_IO, Memory Clerks','2019-07-10',getdate())






