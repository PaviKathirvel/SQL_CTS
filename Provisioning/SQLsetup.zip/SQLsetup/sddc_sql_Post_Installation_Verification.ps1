###################################################################################################
$global:ScriptName = "sddc_sql_Post_Installation_Verification.PS1"
$global:Scriptver = "1.0"
#Description: Description: SQL Post Installation Steps for SDDC
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			11/08/2024	Pavithra	          New Script

###################################################################################################

try
{
	$Time = get-date -Uformat "%Y%m%d%H%M"
	$Log = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_Verification_$Time.txt"
	$BatchOutput4 = "C:\IQOQ\Status.txt"

	$sqlversion = $args[0]
	$spversion = $args[1]
	$InstName = $args[2] 
	$InstName = "MSSQLSERVER"
    $majorversion = $args[3]

	#------------------------ Check if valid instance name is being passed --------------------------------------
	$intalled_instances = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
	if($intalled_instances -notcontains $InstName)
	{
		Write-Host "`nInstance $InstName not found.`n" -f red		
		Exit 0
	}

	#------------------- Check if instance name really belongs to the SQLVersion passed as parameter ---------------------------
	$default_instance = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName
	$version = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${default_instance}\Setup").Version
	$edition = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${default_instance}\Setup").Edition
	$build = $version.substring(0,2)
	if($build -ne $majorversion)
	{
		Write-Host "`n Insatnce $InstName doesn't belong to $sqlversion. check again and pass the correct parameters.`n" -f red
		Exit 0
	}

	$Hostname = Hostname
	$Exec_Time = Get-Date

	Write-Host "###################################################################################################"
	Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname"
	Write-Host "###################################################################################################"

	"###################################################################################################" > $Log
	"Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname" >> $Log
	"Execution string: $ScriptName $sqlversion $InstName" >> $Log
	"###################################################################################################" >> $Log

	$ErrorActionPreference = "SilentlyContinue"
	$error.clear()
	[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
	[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
	[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
	[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')

	if($InstName -eq "MSSQLSERVER")
	{
		$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
		$Inst_Name = $svr.name
		$Final_Status_Error = 0
	}
	else
	{
		$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
		$Inst_Name = $svr.name + "\" + $InstName
		$Final_Status_Error = 0
	}

	Write-Host "--------------------------------- IQOQ verification results ---------------------------------"
	"--------------------------------- IQOQ verification results ---------------------------------" >> $Log
	$connection = New-Object System.Data.SqlClient.SqlConnection("Data Source=$Inst_Name; Initial Catalog=master; Integrated Security=SSPI")
	$connection.Open()

	#--------------------------------- Checking SQL Server build version --------------------------------#
	Write-Host "-------"
	"-------" >> $Log

	#$currentversion = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${default_instance}\MSSQLServer\CurrentVersion").CurrentVersion
	#if($currentversion -match $spversion)
	#{
	#	Write-Host "Expected value for $sqlversion version installed : $spversion"
	#	Write-Host "Current value of $sqlversion version installed : $currentversion"
	#	Write-Host "$sqlversion version $currentversion installation: " -f white -nonewline; Write-Host "Success" -f green
	#	"Expected value for $sqlversion version installed : $spversion" >> $Log
	#	"Current value of $sqlversion version installed : $currentversion" >> $Log
	#	"$sqlversion version $currentversion installation: SUCCESS" >> $Log
	#}
	#else
	#{
	#	Write-Host "Expected value for $sqlversion version installed : $spversion"
	#	Write-Host "Current value of $sqlversion version installed : $currentversion"
	#	Write-Host "$sqlversion version $currentversion installation: " -f white -nonewline; Write-Host "Success" -f red
	#	"Expected value for $sqlversion version installed : $spversion" >> $Log
	#	"Current value of $sqlversion version installed : $currentversion" >> $Log
	#	"$sqlversion version $currentversion installation: FAILED" >> $Log
  	#	$Final_Status_Error = 1
	#}
	#--------------------------------- Checking SQL Server patch version --------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$patch = (Get-SQLAgent -ServerInstance $Hostname).ServerVersion
	$patchversion = $($patch.major).toString() + "." + $($patch.minor).toString() + "." + $($patch.buildnumber).toString()
	#$patch = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${default_instance}\MSSQLServer\Setup").PatchLevel
	$spversion_01 = $spversion.replace(".exe","")
	if($patchversion -match $spversion_01) 
	{
		Write-Host "Expected value for $sqlversion version installed : $spversion_01"
		Write-Host "Current value of $sqlversion version installed : $patchversion"
		Write-Host "$sqlversion version $patchversion installation: " -f white -nonewline; Write-Host "Success" -f green
		"Expected value for $sqlversion version installed : $spversion_01" >> $Log
		"Current value of $sqlversion version installed : $patchversion" >> $Log
		"$sqlversion version $patchversion installation: SUCCESS" >> $Log
	}
	else
	{
		Write-Host "Expected value for $sqlversion version installed : $spversion_01"
		Write-Host "Current value of $sqlversion version installed : $patchversion"
		Write-Host "$sqlversion version $patch versioninstallation: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected value for $sqlversion version installed : $spversion_01" >> $Log
		"Current value of $sqlversion version installed : $patchversion" >> $Log
		"$sqlversion version $patchversion installation: FAILED" >> $Log
		  $Final_Status_Error = 1
	}

	#--------------------------------- Checking SQL Services ----------------------------------# 
	Write-Host ""
	"" >> $Log
	$services_statuscheck = @("MSSQLSERVER", "SQLSERVERAGENT", "SQLBROWSER")
	foreach($service in $services_statuscheck)
	{
		Write-Host "Expected status of $service service :  Running"
		"Expected status of $service service :  Running" >> $Log
		if(Get-Service | Where-Object {$_.name -like $service -and $_.Status -eq 'Running'} -ErrorAction SilentlyContinue)
		{
			Write-Host "Current Status for $service service : " -f White -NoNewline; Write-Host "Running" -f Green
			"Current Sattus for $service : Running" >> $Log
		}
		else 
		{
			Write-Host "Current Status for $service service : " -f White -NoNewline; Write-Host "Not in Running or in Stopped" -f Green
			"Current Sattus for $service : not in running or in stopped" >> $Log
			$Final_Status_Error = 1
		}
	}
	Write-Host ""
	"" >> $Log

	#--------------------------------- Checking BI Components ---------------------------------#

	Write-Host "-------"
	"-------" >> $Log

	$bi_components = [ordered]@{}
	$bi_Components["Integration"] = "MSDTSSERVER"
	$bi_Components["Analysis"] = "OLAP"
	$bi_components["Reporting"] = "Report*Serv*"

	foreach($key in $bi_Components.Keys)
	{
		Write-Host "Expected status for installation of $key services : Success"
		"Expected status for installation of $key services : Success" >> $Log
		if(Get-Service | Where-Object {$_.name -like "*$($bi_components[$key])*"}-ErrorAction SilentlyContinue)
		{
			Write-Host "Current status for installation of $key services : Success"
			Write-Host "Installation of $key services : " -f White -NoNewline; Write-Host "Sucesss" -f Green
			"Current status for installation of $key services : Success" >> $Log
			"Installation of $key services :  Success" >> $Log
		}
		else 
		{
			Write-Host "Current status for installation of $key services : Failed"
			Write-Host "Installation of $key services : " -f White -NoNewline; Write-Host "Failed" -f Red
			"Current status for installation of $key services : Failed" >> $Log
			"Installation of $key services : Failed" >> $Log
			$Final_Status_Error = 1
		}
		Write-Host ""
		"" >> $Log
	}
	Write-Host "-------"
	"-------" >> $Log

	#------------------------------------System DB Drive Verification --------------------------------------------------#

	Write-Host "System DB and the Drive Letter on the Server"
	"System DB and the Drive Letter on the Server" >> $Log
	Write-Host "--------------------------------"
	"------------------------------" >> $Log
 
	$SysDB_Query = "select distinct db_name(dbid) as systemDBName,substring(filename,1,3) as drivename from master..sysaltfiles where dbid <= 4 "
 	$SysDBInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $SysDB_Query -As DataSet
 	$SysDBInfo_Result.Tables[0].Rows | ForEach-Object { Write-Output "{ $($_['systemDBName']), $($_['drivename']) }" }
 	$SysDBInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $SysDB_Query -As DataTable
 	$SysDBInfo_Result.ItemArray  | Add-Content -Path $Log 
 
	Write-Host ""
 	"" >> $Log

	#-----------------------------------------Password Policy Check  --------------------------------------------------#

	Write-Host "Password Policy Check for Logins"
	"Password Policy Check for Logins" >> $Log
 	Write-Host "------------------------"
 	"-----------------------" >> $Log
 	$PwdPolicy_Query = "USE [master]
 	GO
 	SELECT name,
 	case is_policy_checked 
 	when '0' then 'Password Policy Not Checked'
 	when '1' then 'Password Policy Checked'
 	end  as 'is_policy_checked'
 	FROM sys.sql_logins where name not like '%#%'"
 	$PwdPolicyInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $PwdPolicy_Query -As DataSet
 	$PwdPolicyInfo_Result.Tables[0].Rows | ForEach-Object{ Write-Output "{ $($_['name']), $($_['is_policy_checked']) }" }
 	$PwdPolicyInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $PwdPolicy_Query -As DataTable
 	$PwdPolicyInfo_Result.ItemArray  | Add-Content -Path $Log 
	
 	Write-Host ""
 	"" >> $Log
	
	#-------------------------------------Login Auditing Configuration------------------------------------------------#
	
	Write-Host "Login Auditing Configuration "
   	"Login Auditing Configuration " >> $Log
	Write-Host "------------------------"
	"-----------------------" >> $Log
	$AuditLevel_Query = "declare @SQLServerAuditLevel int
	exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
                                    ,N'Software\Microsoft\MSSQLServer\MSSQLServer'
                                    ,N'AuditLevel', 
                            @SQLServerAuditLevel OUTPUT
	select (CASE 
        WHEN @SQLServerAuditLevel = 0 THEN 'None.'
        WHEN @SQLServerAuditLevel = 1 THEN 'Successful Logins Only'
        WHEN @SQLServerAuditLevel = 2 THEN 'Failed Logins Only'
        WHEN @SQLServerAuditLevel = 3 THEN 'Both Failed and Successful Logins Only'
        ELSE 'N/A' END) AS [AuditLevel]
	Go"
	$AuditLevelInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $AuditLevel_Query -As DataSet
	$AuditLevelInfo_Result.Tables[0].Rows | ForEach-Object{ Write-Output "{ $($_['AuditLevel'])}" }
	$AuditLevelInfo_Result = Invoke-Sqlcmd  -Database 'Master' -Query $AuditLevel_Query -As DataTable
	$AuditLevelInfo_Result.ItemArray  | Add-Content -Path $Log 
	Write-Host "-------"
	"-------" >> $Log
	Write-Host ""
	"" >> $Log
	
	#-------------------------------
	$sqlcmd_object = New-Object System.Data.SqlClient.SqlCommand
	$sqlcmd_object.Connection = $connection
	$commandtext =@("SELECT CONVERT(INT,value) AS VALUE FROM sys.configurations WHERE name = 'remote access'",
	"SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'backup compression default'",
	"SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'remote query timeout (s)'",
	"SELECT CONVERT(INT,(total_physical_memory_kb/1024)*0.75) FROM sys.dm_os_sys_memory",
	"SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max server memory (MB)'",
	"SELECT cpu_count FROM sys.dm_os_sys_info",
	"SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'max degree of parallelism'",
	"SELECT (((total_bytes/1024)/1024)/1024) AS Value FROM sys.master_files AS f CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.FILE_ID) WHERE DB_NAME(f.database_id) = 'tempdb' AND f.FILE_ID = 1",
	"SELECT COUNT(*) FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and type_desc = 'ROWS'",
	"SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'tempdev'",
	"SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'templog'",
	"SELECT CONVERT(INT,value_in_use) AS VALUE FROM sys.configurations WHERE name = 'xp_cmdshell'",
	"SELECT 1 FROM sys.syslogins WHERE name = 'JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe'",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name in ( 'DatabaseIntegrityCheck - All Databases' ,'IndexOptimize - All Databases')AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name like 'ITSSQL_%' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_FULL' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_DIFF' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_DirectTape_LOG' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'ITSSQL_MetaData' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'FullDatabaseBackupMaintenance.Subplan_1' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'DiffDatabaseBackupMaintenance.Subplan_1' AND enabled = 1",
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name = 'TransactionLogBackupMaintenance.Subplan_1' AND enabled = 1",
	"SELECT COUNT(*) FROM master.sys.databases WHERE name = 'Baseline' AND state_desc = 'ONLINE'"
	"SELECT COUNT(*) FROM msdb..sysjobs WHERE name in ('DBA - Capture Who is Active','DBA - Collect Index_Stats Info','DBA - DB Space Utilization','DBA - Load Session Status','DBA - Load SystemHealthSession', 'DBA - PerfMon Counter Collection', 'DBA - Server Config Changes' ) AND enabled = 1"
	) 

	#------------------Check for Remote Access -----------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[0]
	$Remote_Access = $sqlcmd_object.ExecuteScalar()
	if($Remote_Access -ne 1)
	{
		Write-Host "Expected Value for Remote Access : 1"
		Write-Host "Current Value for Remote Access : $Remote_Access"
		Write-Host "Remote Access : " -f White -NoNewline; Write-Host "Failed" -f Red
		"Expected value for Remote Access : 1`nCurrent value of Remote Access : $Remote_Access`nRemote Access setting : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else 
	{
		Write-Host "Expected value for Remote Access : 1"
		Write-Host "Current value of Remote Access : $Remote_Access"
		Write-Host "Remote Access: " -f White -NoNewline; Write-Host "Success" -f Green
		"Expected value for Remote Access : 1`nCurrent value of Remote Access : 1`nRemote Access setting : SUCCESS" >> $Log
	}
	Write-Host "-------"
	"-------" >> $Log

	#------------------Check for Backup Compression ------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[1]
	$Backup_Comp = $sqlcmd_object.ExecuteScalar()
	if($Backup_Comp -ne 1)
	{
		Write-Host "Expected Value for Backup Compression : 1"
		Write-Host "Current Value for Backup Compression : $Backup_Comp"
		Write-Host "Backup compression : " -f White -NoNewline; Write-Host "Failed" -f Red
		"Expected value for Backup Compression : 1`nCurrent value of Backup compression : $Backup_Comp`nBackup Compression setting : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else 
	{
		Write-Host "Expected value for ackup Compression : 1"
		Write-Host "Current value of ackup Compression : $Backup_Comp"
		Write-Host "Backup Compression: " -f White -NoNewline; Write-Host "Success" -f Green
		"Expected value for ackup Compression : 1`nCurrent value of ackup Compression : 1`nackup Compression setting : SUCCESS" >> $Log
	}
	Write-Host "-------"
	"-------" >> $Log 

	#--------------------------------- Checking Remote Query Time Out---------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[2]
	$Remote_QueryTimeout = $sqlcmd_object.ExecuteScalar()
	if ($Remote_QueryTimeout -ne 0)
	{
		Write-Host "Expected value for Remote Query Timeout : 0"
		Write-Host "Current value for Remote Query Timeout : $Remote_QueryTimeout"
		Write-Host "Remote Query Timeout: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected value for Remote Query Timeout : 0`nCurrent value for Remote Query Timeout : $Remote_QueryTimeout`nRemote Query Timeout setting : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected value for Remote Query Timeout : 0"
		Write-Host "Current value for Remote Query Timeout : 0"
		Write-Host "Remote Query Timeout: " -f white -nonewline; Write-Host "Success" -f green
		"Expected value for Remote Query Timeout : 0`nCurrent value for Remote Query Timeout : 0`nRemote Query Timeout setting : SUCCESS" >> $Log
	}

	#--------------------------------- Checking Memory Allocation ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[3]
	$Max_Mem = $sqlcmd_object.ExecuteScalar()
	$sqlcmd_object.CommandText = $commandtext[4]
	$SQL_Mem = $sqlcmd_object.ExecuteScalar()
	if($Max_Mem -ne $SQL_Mem)
	{
		Write-Host "Expected value for memory allocation to SQL Server : 75% of total memory"
		Write-Host "Current value of memory allocated to SQL Server : $SQL_Mem"
		Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected value for memory allocation to SQL Server : 75% of total memory`nCurrent value of memory allocated to SQL Server : $SQL_Mem`nMemory allocation setting : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected value for memory allocation to SQL Server : 75% of total memory"
		Write-Host "Current value of memory allocated to SQL Server :  75% of total memory"
		Write-Host "Memory Allocated to SQL Server is 75% of server's Total Memory: " -f white -nonewline; Write-Host "Success" -f green
		"Expected value for memory allocation to SQL Server : 75% of total memory`nCurrent value of memory allocated to SQL Server : 75% of total memory`nMemory allocation setting : SUCCESS" >> $Log
	}
	#--------------------------------- Checking MAX DOP Configuration ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[5]
	$cpu_count = $sqlcmd_object.ExecuteScalar()
	$sqlcmd_object.CommandText = $commandtext[6]
	$deg_parallelism = $sqlcmd_object.ExecuteScalar()
	if ($cpu_count -le 4)
	{
		if($deg_parallelism -eq 0)
		{
			Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: 2"
			Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
			Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
			"For $cpu_count CPU(s), expected value in use for Max DOP allocation: 0`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : SUCCESS" >> $Log
		}
		else
		{
			Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: 0"
			Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
			Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
			"For $cpu_count CPU(s), expected value in use for Max DOP allocation: 0`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : FAILED" >> $Log
			$Final_Status_Error = 1
		}
	}
	elseif($cpu_count -gt 4)
	{
		$C_CPU = $cpu_count / 2
		if($cpu_count -gt 8)
		{
			if($deg_parallelism -eq 8)
			{
				Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: 8"
				Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
				Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
				"For $cpu_count CPU(s), expected value in use for Max DOP allocation: 8`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : SUCCESS" >> $Log
			}
			else
			{
				Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: 8"
				Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
				Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
				"For $cpu_count CPU(s), expected value in use for Max DOP allocation: 8`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : FAILED" >> $Log
				$Final_Status_Error = 1
			}
		}
		if($deg_parallelism -eq $C_CPU)
		{
			Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: $C_CPU"
			Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
			Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Success" -f green
			"For $cpu_count CPU(s), expected value in use for Max DOP allocation: $C_CPU`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : SUCCESS" >> $Log
		}
		else
		{
			Write-Host "For $cpu_count CPU(s), expected value in use for Max DOP allocation: $C_CPU"
			Write-Host "For $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism"
			Write-Host "Max DOP Allocation: " -f white -nonewline; Write-Host "Failed" -f red
			"For $cpu_count CPU(s), expected value in use for Max DOP allocation: $C_CPU`nFor $cpu_count CPU(s), current value in use for Max DOP allocation: $deg_parallelism`nMax DOP Allocation status : Failed" >> $Log
			$Final_Status_Error = 1
		}
	}
	#--------------------------------- Checking TEMPDB Configuration ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log

	$sqlcmd_object.CommandText = $commandtext[7]
	$TempDrive_T_Size = $sqlcmd_object.ExecuteScalar()
	$sqlcmd_object.CommandText = "SELECT CONVERT(INT,$TempDrive_T_Size * 0.10)"
	$TempDB_Size = $sqlcmd_object.ExecuteScalar()
	if($TempDB_Size -gt 10)
	{
		$TempDB_Size = 10
	}
	$sqlcmd_object.CommandText = $commandtext[8]
	$Temp_Count = $sqlcmd_object.ExecuteScalar()
	if($cpu_count -lt 9)
	{
		if ($Temp_Count -eq $cpu_count)
		{
			Write-Host "For $cpu_count CPU(s), expected number of TempDB files : $cpu_count"
			Write-Host "For $cpu_count CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Success" -f green
			"For $cpu_count CPU(s), expected number of TempDB files : $cpu_count`nFor $cpu_count CPU(s), current number of TempDB files : $Temp_Count`nTempDB # files based on # of CPUs: SUCCESS" >> $Log
			"" >> $Log
			$T = 0
		}
		else
		{
			Write-Host "For $cpu_count CPU(s), expected number of TempDB files : $cpu_count"
			Write-Host "For $cpu_count CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"For $cpu_count CPU(s), expected number of TempDB files : $cpu_count`nFor $cpu_count CPU(s), current number of TempDB files : $Temp_Count`nTempDB # files based on # of CPUs: FAILED" >> $Log
			"" >> $Log
			$T = 1
			$Final_Status_Error = 1
		}
	}
	else
	{
		if ($Temp_Count -eq 8)
		{
			Write-Host "For $cpu_count CPU(s), expected number of TempDB files : 8"
			Write-Host "For $cpu_count CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"For $cpu_count CPU(s), expected number of TempDB files : 8`nFor $cpu_count CPU(s), current number of TempDB files : $Temp_Count`nTempDB # files based on # of CPUs: SUCCESS" >> $Log
			"" >> $Log
			$T = 0
		}
		else
		{
			Write-Host "For $cpu_count CPU(s), expected number of TempDB files : 8"
			Write-Host "For $cpu_count CPU(s), current number of TempDB files : $Temp_Count"
			Write-Host "TempDB # files based on # of CPUs: " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"For $cpu_count CPU(s), expected number of TempDB files : 8`nFor $cpu_count CPU(s), current number of TempDB files : $Temp_Count`nTempDB # files based on # of CPUs: FAILED" >> $Log
			"" >> $Log
			$T = 1
			$Final_Status_Error = 1
		}
	}
	$sqlcmd_object.CommandText = $commandtext[9]
	$Temp_Files = $sqlcmd_object.ExecuteScalar()
	if($Temp_Files -eq $TempDB_Size)
	{
		Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
		Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
		Write-Host "TempDB File Size (Initial File): " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected TempDB size for the given drive size : $TempDB_Size GB`nCurrent TempDB size for the given drive size : $Temp_Files GB`nTempDB File Size (Initial File): SUCCESS" >> $Log
		"" >> $Log
		$TF = 0
	}
	else
	{
		Write-Host "Expected TempDB size for the given drive size : $TempDB_Size GB"
		Write-Host "Current TempDB size for the given drive size : $Temp_Files GB"
		Write-Host "TempDB File Size (Initial File): " -f white -nonewline; Write-Host "Failed" -f red
		Write-Host ""
		"Expected TempDB size for the given drive size : $TempDB_Size GB`nCurrent TempDB size for the given drive size : $Temp_Files GB`nTempDB File Size (Initial File): FAILED" >> $Log
		"" >> $Log
		$TF = 1
		$Final_Status_Error = 1
	}
	if($Temp_Count -gt 1)
	{
		$i = 2
		$y = 0
		while ($i -le $Temp_Count)
		{
			$sqlcmd_object.CommandText = "SELECT ((size*8)/1024)/1024 AS Value FROM sys.master_files WHERE DB_NAME(database_id) = 'tempdb' and name = 'tempdev_$i'"
			$Temp_Files2 = $sqlcmd_object.ExecuteScalar()
			if ($Temp_Files2 -ne $TempDB_Size)
			{
				$y = $y + 1
			}
			$i = $i + 1
		}
		if(($T -eq 0) -and ($TF -eq 0 ) -and ($y -eq 0))
		{
			Write-Host "Expected size of each additional TempDB files : $TempDB_Size GB"
			Write-Host "Current size of each additional TempDB files : $TempDB_Size GB"
			Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"Expected size of each additional TempDB files : $TempDB_Size GB`nCurrent size of each additional TempDB files : $TempDB_Size GB`nTempDB File Size (Additional Files): SUCCESS" >> $Log
			"" >> $Log 
			$Temp_DB_Final = 0
		}
		else
		{
			Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"TempDB File Size (Additional Files): FAILED" >> $Log
			"" >> $Log
			$Temp_DB_Final = 1
			$Final_Status_Error = 1
		}
	}
	else
	{
		if(($T -eq 0) -and ($TF -eq 0 ))
		{
			Write-Host "Expected number of additional TempDB files required : 0"
			Write-Host "Current number of additional TempDB files : 0"
			Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"Expected number of additional TempDB files required : 0`nCurrent number of additional TempDB files : 0`nTempDB File Size (Additional Files): SUCCESS" >> $Log
			"" >> $Log
			$Temp_DB_Final = 0
		}
		else
		{
			Write-Host "TempDB File Size (Additional Files): " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"TempDB File Size (Additional Files): FAILED" >> $Log
			"" >> $Log
			$Temp_DB_Final = 1
			$Final_Status_Error = 1
		}
	}
	$sqlcmd_object.CommandText = $commandtext[10]
	$Temp_Log = $sqlcmd_object.ExecuteScalar()
	if($Temp_Log -eq $TempDB_Size)
	{
		Write-Host "Expected size of Temp log file : $TempDB_Size"
		Write-Host "Current size of Temp log file : $Temp_Log"
		Write-Host "TempDB Log File Size: " -f white -nonewline; Write-Host "Success" -f green
		"Expected size of Temp log file : $TempDB_Size`nCurrent size of Temp log file : $Temp_Log`nTempDB Log File Size: SUCCESS" >> $Log
		Write-Host "-------"
		"-------" >> $Log
	}
	else
	{
		Write-Host "Expected size of Temp log file : $TempDB_Size"
		Write-Host "Current size of Temp log file : $Temp_Log"
		Write-Host "TempDB Log File Size: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected size of Temp log file : $TempDB_Size`nCurrent size of Temp log file : $Temp_Log`nTempDB Log File Size: FAILED" >> $Log
		Write-Host "-------"
		"-------" >> $Log
		$Final_Status_Error = 1
	}
	#---------------------------------Checking # of Error Logs ---------------------------------#
	$server = New-Object 'Microsoft.SqlServer.Management.SMO.Server' ($Inst_Name)  
	$NLogFiles = $server.NumberOfLogFiles
	if($NLogFiles -ne 45)
	{
		Write-Host "Expected number of error logs : 45"
		Write-Host "Current number of error logs : $NLogFiles"
		Write-Host "Setup number of error logs to 45: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected number of error logs : 45`nCurrent number of error logs : $NLogFiles`nSetup number of error logs to 45: FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected number of error logs : 45"
		Write-Host "Current number of error logs : 45"
		Write-Host "Setup number of error logs to 45: " -f white -nonewline; Write-Host "Success" -f green
		"Expected number of error logs : 45`nCurrent number of error logs : 45`nSetup number of error logs to 45: SUCCESS" >> $Log
	}

	#--------------------------------- checking xp_cmdshell ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[11]
	$xp_cmd = $sqlcmd_object.ExecuteScalar()
	if($xp_cmd -ne 1)
	{
		Write-Host "Expected value of xp_cmdshell : 1"
		Write-Host "Current value of xp_cmdshell : $xp_cmd"
		Write-Host "Enable xp_cmdshell: " -f white -nonewline; Write-Host "Failed" -f red
		"Expected value of xp_cmdshell : 1`nCurrent value of xp_cmdshell : $xp_cmd`nEnable xp_cmdshell: FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected value of xp_cmdshell : 1"
		Write-Host "Current value of xp_cmdshell : 1"
		Write-Host "Enable xp_cmdshell: " -f white -nonewline; Write-Host "Success" -f green
		"Expected value of xp_cmdshell : 1`nCurrent value of xp_cmdshell : 1`nEnable xp_cmdshell: SUCCESS" >> $Log
	}
	#--------------------------------- Checking CMDB account ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[12]
	$cmdb = $sqlcmd_object.ExecuteScalar()
	if($cmdb -ne 1)
	{
		Write-Host ""
		Write-Host "Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe"
		Write-Host "Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: " -f white -nonewline; Write-Host "Failed" -f red
		Write-Host ""
		"Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe`nProvision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: FAILED`n" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host ""
		Write-Host "Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe"
		Write-Host "Provision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected AD group to be provisioned : JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe`nProvision account JNJ\ITS-EP-APP-AutoDiscovery-DatabaseProbe: SUCCESS`n" >> $Log
	}
	#--------------------------------- Checking Native Auditing status ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log

	$native_audit = (Get-Content 'C:\IQOQ\IQOQ_2.txt')[0]

	if($native_audit -eq "Native Auditing:1")
	{
		Write-Host "Expected setting for Native Auditing : Enabled"
		Write-Host "Current setting for Native Auditing : Disabled"
		Write-Host "Native Auditing enabled : " -f white -nonewline; Write-Host "Failed" -f red
		"Expected setting for Native Auditing : Enabled`nCurrent setting for Native Auditing : Disabled`nNative Auditing setting enabled : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	if($native_audit -eq "Native Auditing:0")
	{
		Write-Host "Expected setting for Native Auditing : Enabled"
		Write-Host "Current setting for Native Auditing : Enabled"
		Write-Host "Native Auditing enabled: " -f white -nonewline; Write-Host "Success" -f green
		"Expected setting for Native Auditing : Enabled`nCurrent setting for Native Auditing : Enabled`nNative Auditing setting enabled : SUCCESS" >> $Log
	}
	if($native_audit -eq "Native Auditing:D")
	{
		Write-Host "Expected setting for Native Auditing : Disabled"
		Write-Host "Current setting for Native Auditing : Disabled"
		Write-Host "Native Auditing Disabled: " -f white -nonewline; Write-Host "Success" -f green
		"Expected setting for Native Auditing : Disabled`nCurrent setting for Native Auditing : Disabled`nNative Auditing setting disabled: SUCCESS" >> $Log
	}
	#--------------------------------- Checking Cold Backup status ---------------------------------#
	Write-Host "-------"
	"-------" >> $Log

	$ColdBackup = (Get-Content 'C:\IQOQ\IQOQ_2.txt')[1]

	if($ColdBackup -eq "Cold Backup:1")
	{
		Write-Host "Expected status of cold backup of system databases : Success"
		Write-Host "Current status of cold backup of system databases : Failed"
		Write-Host "Cold backups of system databases performed : " -f white -nonewline; Write-Host "Failed" -f red
		"Expected status of cold backup of system databases : Success`nCurrent status of cold backup of system databases : Failed`nCold backup of system databases : FAILED" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected status of cold backup of system databases : Success"
		Write-Host "Current status of cold backup of system databases : Success"
		Write-Host "Cold backups of system databases performed: " -f white -nonewline; Write-Host "Success" -f green
		"Expected status of cold backup of system databases : Success`nCurrent status of cold backup of system databases : Success`nNative Auditing setting enabled : SUCCESS" >> $Log
	}

	#--------------------------------- Checking Data Integrity and Optimization Plan Deployment ----------------------------------#
	Write-Host "-------"
	"-------" >> $Log
	$sqlcmd_object.CommandText = $commandtext[13]
	$DataInt = $sqlcmd_object.ExecuteScalar()
	if($DataInt -eq 2)
	{
		Write-Host "Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success"
		Write-Host "Current status of Data Integrity and Optimization Maintenance Jobs creation: Success"
		Write-Host "Creation of job for Data Integrity and Optimization Maintenance Jobs: " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success`nCurrent status of Data Integrity and Optimization Maintenance Jobs creation: Success`nCreation of job for Data Integrity and Optimization Maintenance Jobs: SUCCESS" >> $Log
		"" >> $Log	
	}
	else
	{
		Write-Host "Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success"
		Write-Host "Current status of Data Integrity and Optimization Maintenance Jobs creation: Failed"
		Write-Host "Creation of job for Data Integrity and Optimization Maintenance Jobs: " -f white -nonewline; Write-Host "Failed" -f red
		Write-Host ""
		"Expected status of Data Integrity and Optimization Maintenance Jobs creation: Success`nCurrent status of Data Integrity and Optimization Maintenance Jobs creation: Failed`nCreation of job for Data Integrity and Optimization Maintenance Jobs: FAILED" >> $Log
		"" >> $Log
		$Final_Status_Error = 1
	}
	#--------------------------------- Checking Backup jobs Deployment ---------------------------------#
	$sqlcmd_object.CommandText = $commandtext[14]
	$BackupInt = $sqlcmd_object.ExecuteScalar()
	if($BackupInt -ne 0)
	{
		Write-Host "-------"
		"-------" >> $Log
		if($BackupInt -ge 3)
		{
			$sqlcmd_object.CommandText = $commandtext[15]
			$DataInt = $sqlcmd_object.ExecuteScalar()
			if ($DataInt -ne 1)
			{
				Write-Host "Expected status of ITSSQL_DirectTape_FULL job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_FULL job creation: Failed"
				Write-Host "Creation of ITSSQL_DirectTape_FULL job: " -f white -nonewline; Write-Host "Failed" -f red
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_FULL job creation: Success`nCurrent status of ITSSQL_DirectTape_FULL job creation: Failed`nCreation of ITSSQL_DirectTape_FULL job: FAILED" >> $Log
				"" >> $Log
				$Final_Status_Error = 1
			}
			else
			{
				Write-Host "Expected status of ITSSQL_DirectTape_FULL job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_FULL job creation: Success"
				Write-Host "Creation of ITSSQL_DirectTape_FULL job: " -f white -nonewline; Write-Host "Success" -f green
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_FULL job creation: Success`nCurrent status of ITSSQL_DirectTape_FULL job creation: Success`nCreation of ITSSQL_DirectTape_FULL job: SUCCESS" >> $Log
				"" >> $Log
			}

			$sqlcmd_object.CommandText = $commandtext[16]
			$DataInt = $sqlcmd_object.ExecuteScalar()
			if ($DataInt -ne 1)
			{
				Write-Host "Expected status of ITSSQL_DirectTape_DIFF job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_DIFF job creation: Failed"
				Write-Host "Creation of ITSSQL_DirectTape_DIFF job : " -f white -nonewline; Write-Host "Failed" -f red
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_DIFF job creation: Success`nCurrent status of ITSSQL_DirectTape_DIFF job creation: Failed`nCreation of ITSSQL_DirectTape_DIFF job: FAILED" >> $Log
				"" >> $Log
				$Final_Status_Error = 1
			}
			else
			{
				Write-Host "Expected status of ITSSQL_DirectTape_DIFF job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_DIFF job creation: Success"
				Write-Host "Creation of ITSSQL_DirectTape_DIFF job: " -f white -nonewline; Write-Host "Success" -f green
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_DIFF job creation: Success`nCurrent status of ITSSQL_DirectTape_DIFF job creation: Success`nCreation of ITSSQL_DirectTape_DIFF job: SUCCESS" >> $Log
				"" >> $Log
			}

			$sqlcmd_object.CommandText = $commandtext[17]
			$DataInt = $sqlcmd_object.ExecuteScalar()
			if ($DataInt -ne 1)
			{
				Write-Host "Expected status of ITSSQL_DirectTape_Log job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_Log job creation: Failed"
				Write-Host "Creation of ITSSQL_DirectTape_Log job: " -f white -nonewline; Write-Host "Failed" -f red
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_Log job creation: Success`nCurrent status of ITSSQL_DirectTape_Log job creation: Failed`nCreation of ITSSQL_DirectTape_Log job: FAILED" >> $Log
				"" >> $Log
				$Final_Status_Error = 1
			}
			else
			{
				Write-Host "Expected status of ITSSQL_DirectTape_Log job creation: Success"
				Write-Host "Current status of ITSSQL_DirectTape_Log job creation: Success"
				Write-Host "Creation of ITSSQL_DirectTape_Log job: " -f white -nonewline; Write-Host "Success" -f green
				Write-Host ""
				"Expected status of ITSSQL_DirectTape_Log job creation: Success`nCurrent status of ITSSQL_DirectTape_Log job creation: Success`nCreation of ITSSQL_DirectTape_Log job: SUCCESS" >> $Log
				"" >> $Log
			}
		}
		else 
		{
			$sqlcmd_object.CommandText = $commandtext[18]
			$DataInt = $sqlcmd_object.ExecuteScalar()
			if($DataInt -ne 1)
			{
				Write-Host "Expected status of ITSSQL_MetaData job creation: Success"
				Write-Host "Current status of ITSSQL_MetaData job creation: Failed"
				Write-Host "Creation of ITSSQL_MetaData job: " -f white -nonewline; Write-Host "Failed" -f red
				Write-Host ""
				"Expected status of ITSSQL_MetaData job creation: Success`nCurrent status of ITSSQL_MetaData job creation: Failed`nCreation of ITSSQL_MetaData job: FAILED" >> $Log
				"" >> $Log
				$Final_Status_Error = 1
			}
			else
			{
				Write-Host "Expected status of ITSSQL_MetaData job creation: Success"
				Write-Host "Current status of ITSSQL_MetaData job creation: Success"
				Write-Host "Creation of ITSSQL_MetaData job: " -f white -nonewline; Write-Host "Success" -f green
				"Expected status of ITSSQL_MetaData job creation: Success`nCurrent status of ITSSQL_MetaData job creation: Success`nCreation of ITSSQL_MetaData job: SUCCESS" >> $Log
				"" >> $Log
			}
		}
	}
	else 
	{
		#--------------------------------- Checking Full Backup Plan Deployment ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		$sqlcmd_object.CommandText = $commandtext[19]
		$FullBKP = $sqlcmd_object.ExecuteScalar()
		if($FullBKP -ne 1)
		{
			Write-Host "Expected status of Full Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Full Backup Maintenance Plan creation: Failed"
			Write-Host "Creation of job for Full Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"Expected status of Full Backup Maintenance Plan creation: Success`nCurrent status of Full Backup Maintenance Plan creation: Failed`nCreation of job for Full Backup Maintenance Plan: FAILED" >> $Log
			"" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Expected status of Full Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Full Backup Maintenance Plan creation: Success"
			Write-Host "Creation of job for Full Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"Expected status of Full Backup Maintenance Plan creation: Success`nCurrent status of Full Backup Maintenance Plan creation: Success`nCreation of job for Full Backup Maintenance Plan: SUCCESS" >> $Log
			"" >> $Log
		}

		#--------------------------------- Checking Differential Backup Plan Deployment ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		$sqlcmd_object.CommandText = $commandtext[20]
		$DiffBKP = $sqlcmd_object.ExecuteScalar()
		if ($DiffBKP -ne 1)
		{
			Write-Host "Expected status of Differential Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Differential Backup Maintenance Plan creation: Failed"
			Write-Host "Creation of job for Differential Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"Expected status of Differential Backup Maintenance Plan creation: Success`nCurrent status of Differential Backup Maintenance Plan creation: Failed`nCreation of job for Differential Backup Maintenance Plan: FAILED" >> $Log
			"" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Expected status of Differential Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Differential Backup Maintenance Plan creation: Success"
			Write-Host "Creation of job for Differential Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"Expected status of Differential Backup Maintenance Plan creation: Success`nCurrent status of Differential Backup Maintenance Plan creation: Success`nCreation of job for Differential Backup Maintenance Plan: SUCCESS" >> $Log
			"" >> $Log
		}

		#--------------------------------- Checking Transaction Log Backup Plan Deployment ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		$sqlcmd_object.CommandText = $commandtext[21]
		$TLOGBKP = $sqlcmd_object.ExecuteScalar()
		if ($TLOGBKP -ne 1)
		{
			Write-Host "Expected status of Transaction Log Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Transaction Log Backup Maintenance Plan creation: Failed"
			Write-Host "Creation of job for Transaction Log Backup Maintenance Plan: " -f white -nonewline; Write-Host "Failed" -f red
			Write-Host ""
			"Expected status of Transaction Log Backup Maintenance Plan creation: Success`nCurrent status of Transaction Log Backup Maintenance Plan creation: Failed`nCreation of job for Transaction Log Backup Maintenance Plan: FAILED" >> $Log
			"" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Expected status of Transaction Log Backup Maintenance Plan creation: Success"
			Write-Host "Current status of Transaction Log Backup Maintenance Plan creation: Success"
			Write-Host "Creation of job for Transaction Log Backup Maintenance Plan: " -f white -nonewline; Write-Host "Success" -f green
			Write-Host ""
			"Expected status of Transaction Log Backup Maintenance Plan creation: Success`nCurrent status of Transaction Log Backup Maintenance Plan creation: Success`nCreation of job for Transaction Log Backup Maintenance Plan: SUCCESS" >> $Log
			"" >> $Log
		}
	}
	#############################################Baseline Framework Validation Log #########################################
	Write-Host "-------"
	"-------" >> $Log

	Write-Host "Baseline Framework Validation"
	"Baseline Framework Validation" >> $Log

	Write-Host "-------"
	"-------" >> $Log

	$sqlcmd_object.CommandText = $commandtext[22]
	$DataInt = $sqlcmd_object.ExecuteScalar()
	if ($DataInt -ne 1)
	{
		Write-Host "Expected status of Baseline Framework Database and Job creation: Success"
		Write-Host "Current status of Baseline Framework  Database and Jobcreation: Failed"
		Write-Host "Creation of Baseline Framework  Database and Job: " -f white -nonewline; Write-Host "Failed" -f red
		Write-Host ""
		"Expected status of Baseline Framework Database and Jobcreation: Success`nCurrent status of Baseline Framework Database and Jobcreation: Failed`nCreation of Baseline Framework Database and Job: FAILED" >> $Log
		"" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected status of Baseline Framework Database creation: Success"
		Write-Host "Current status of Baseline Framework Database: Success"
		Write-Host "Creation of Baseline Framework Database: " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected status of Baseline Framework Database creation: Success`nCurrent status of Baseline Framework Database creation: Success`nCreation of Baseline Framework Database: SUCCESS" >> $Log
		"" >> $Log
	$DataInt = "null"
	$sqlcmd_object.CommandText = $commandtext[23]
	$DataInt = $sqlcmd_object.ExecuteScalar()
	if($DataInt -ne 7)
	{
		Write-Host "Expected status of Baseline Framework Job creation: Success"
		Write-Host "Current status of Baseline Framework  job creation: Failed"
		Write-Host "Creation of Baseline Framework  job: " -f white -nonewline; Write-Host "Failed" -f red
		Write-Host ""
		"Expected status of Baseline Framework Job creation: Success`nCurrent status of Baseline Framework Job creation: Failed`nCreation of Baseline Framework Job: FAILED" >> $Log
		"" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Expected status of Baseline Framework Job creation: Success"
		Write-Host "Current status of Baseline Framework Job: Success"
		Write-Host "Creation of Baseline Framework Job: " -f white -nonewline; Write-Host "Success" -f green
		Write-Host ""
		"Expected status of Baseline Framework Job creation: Success`nCurrent status of Baseline Framework Job creation: Success`nCreation of Baseline Framework Job: SUCCESS" >> $Log
		"" >> $Log
	}
	}
	###############################################END OF BASELINE FRAMEWORK VALIDATION ###################################


	Write-Host "########################## SQL INSTALLATION OPERATIONAL VERIFICATION ##########################"
	"########################## SQL INSTALLATION OPERATIONAL VERIFICATION ##########################" >> $Log
	if($Final_Status_Error -eq 1)
	{
		Write-Host ""
		Write-Host "SQL IQOQ verification FAILED. Return code is 1"
		Write-Host "Please review the verification steps and address the failed step"
		Write-Host ""
		"" >> $Log
		"SQL IQOQ verification FAILED. Return code is 1" >> $Log
		"Please review the verification steps and address the failed step" >> $Log
		"" >> $Log
		"FAILED" > $BatchOutput4
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log
		Exit 1
	}
	else
	{
		Write-Host ""
		Write-Host "SQL IQOQ verification PASSED. Return code is 0"
		Write-Host ""
		"" >> $Log
		"SQL IQOQ verification PASSED. Return code is 0" >> $Log
		"" >> $Log
		"SUCCESS" > $BatchOutput4
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log
		Exit 0
	}
}
catch
{
	Write-Host "Error Occurred : $_"
}

