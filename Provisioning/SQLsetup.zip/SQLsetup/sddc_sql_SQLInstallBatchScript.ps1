$global:ScriptName = "sddc_SQL_InstallBatchScript.ps1"
$global:Scriptver = "1.0"
###################################################################################################
<#Description 
    The script deals with the download of SQL binaries from the build server and provision the server with SQL instance.
    It takes 7 inputs
        1. SDDC or NON_SDDC
        2. Tier
        3. Environment
        4. SQLVersion
        5. Patch Level Version
        6. Edition
        7. Collation
    The script validated the given parameters
    Downloads the files from the build server to the local directory of the server which needs to be provisioned. 
    And executes the further scripts for OS_Prequisites verification, Install SQL instance, Job Deployment and verification of installation
#>
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			11/08/2024	Pavithra K	New Script
###################################################################################################
function CheckParameters
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$Process,
        [Parameter(Mandatory)]
        [string]$Tier,
        [Parameter(Mandatory)]
        [string]$Env,
        [Parameter(Mandatory)]
        [string]$Edition,
        [Parameter(Mandatory)]
        [string]$strCollation,
        [Parameter(Mandatory)]
        [string]$SQLVersion,
        [Parameter(Mandatory)]
        [string]$SPVersion,
        [Parameter(Mandatory)]
        [hashtable]$SQLVer_SPVer,
        [Parameter(Mandatory)]
        [String[]]$arrCollation

    )
    try
    {
        if(($Process -ine "SDDC") -and ($Process -ine "NON_SDDC"))
        {
            Write-Host "`nProcess not Valid. Please pass SDDC or NON_SDDC(AWS/AZR) as 1st parameter`n" -f red
            EXIT 0
        }

        if(($Tier -ine "Small") -and ($Tier -ine "Medium") -and ($Tier -ine "Large"))
        {
            Write-Host "`nSize not Valid. Please pass SMALL or MEDIUM or LARGE as 2nd parameter`n" -f red
            EXIT 0
        }

        if(($Env -ine "DEV") -and ($Env -ine "QA") -and ($Env -ine "PROD"))
        {
            Write-Host "`nEnvironment not Valid. Please pass DEV or QA or PROD as 3rd parameter`n" -f red
            EXIT 0
        }

        if(!($SQLVer_SPVer.ContainsKey($SQLVersion))) 
        {
            Write-Host "`nInvalid SQLServer version. Please pass any of the avaliable SQL versions as 4th parameter : $($SQLVer_SPVer.Keys)`n" -f red
            Exit 0
        }
        else
        {
            $values = $SQLVer_SPVer[$SQLVersion]
            if($values -notcontains $SPVersion)
            {
                Write-Host "Service pack version not valid for $key. Please pass any of the available Server Pack Versions as 5th parameter : $values`n" -f red
                EXIT 0
            }
        }

        if(($Edition -ine "E") -and ($Edition -ine "S"))
        {
            Write-Host "`nInvalid SQLServer Edition. Please pass any of the avaliable SQL versions as 6th parameter :  E(express) or S(standard)`n" -f red
            Exit 0
        }

        if($arrCollation -notcontains $strCollation)
        {
            Write-Host "`nPlease pass a valid collation name as 7th parameter`n" -f red
            EXIT 0
        }
        
        Write-Host "The parameters are valid..good to proceed next.." -f Green
        
    }
    catch
    {
        Write-Output "Error Occurred : $_.Message" 
        Exit 1
    }
    
}
function DownloadFiles
{
    Param(
        [string] $sqlversion,
        [string] $spversion,
        [string] $rtm_to_install,
        [string] $build_server_url,
        [string] $destinationpath
    )
    #try
    #{
    #    #download RTM file
    #    $rtmurl = "$build_server_url/$sqlversion/binaries/$rtm_to_install"
    #    $rtm_response = Invoke-WebRequest -Uri $rtmurl -OutFile "$destinationpath\rtm.iso"
    #    $spurl = "$build_server_url/sp_hf/$sqlversion/$spversion"
    #    $sp_response = Invoke-WebRequest -Uri $spurl -OutFile "$destinationpath\setup.exe"
    #}
    #catch
    #{
    #    Write-Host "Error in downloading the executable files...$_"
    #}
	#
        #downloading the rtm file
	    $url = "$build_server_url/$sqlversion/binaries/$rtm_to_install"
        $url
		$outputPath = "$destinationpath\rtm.iso"
		$request = [System.Net.HttpWebRequest]::Create($url)
        Start-Sleep -s 3
		$response = $request.GetResponse()
		$stream = $response.GetResponseStream()
		$fileStream = [System.IO.File]::Create($outputPath)
		$buffer = New-Object byte[] 1024
		$bytesRead = 0
		while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
			$fileStream.Write($buffer, 0, $bytesRead)
		}
		$fileStream.Close()
		$response.Close()
		Write-Host "$($rtm_to_install) downloaded successfully to the $outputPath" -f Green
		
        #downloading the setup.exe patch file
		$url = "$build_server_url/$sqlversion/patches/$spversion" 	
		$outputPath = "$destinationpath\setup.exe"
		$request = [System.Net.HttpWebRequest]::Create($url)
        Start-Sleep -s 3
		$response = $request.GetResponse()
		$stream = $response.GetResponseStream()
		$fileStream = [System.IO.File]::Create($outputPath)
		$buffer = New-Object byte[] 1024
		$bytesRead = 0
		while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
			$fileStream.Write($buffer, 0, $bytesRead)
		}
		$fileStream.Close()
		$response.Close()
		Write-Host "$spversion downloaded successfully to $outputPath" -f Green

        #downloading the rs
        try
        {
		    $url = "$build_server_url/$sqlversion/rs/SQLServerReportingServices.exe" 	
		    $outputPath = "$destinationpath\sqlserverreportingservices.exe"
		    $request = [System.Net.HttpWebRequest]::Create($url)
            Start-Sleep -s 3
		    $response = $request.GetResponse()
		    $stream = $response.GetResponseStream()
		    $fileStream = [System.IO.File]::Create($outputPath)
		    $buffer = New-Object byte[] 1024
		    $bytesRead = 0
		    while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
		    	$fileStream.Write($buffer, 0, $bytesRead)
		    }
		    $fileStream.Close()
		    $response.Close()
		    Write-Host "RS downloaded successfully to $outputPath" -f Green
        }
        catch
        {
            try
            {
                $url = "$build_server_url/$sqlversion/rs/sqlserverreportingservices.exe" 	
		        $outputPath = "$destinationpath/sqlserverreportingservices.exe"
		        $request = [System.Net.HttpWebRequest]::Create($url)
                Start-Sleep -s 3
		        $response = $request.GetResponse()
		        $stream = $response.GetResponseStream()
		        $fileStream = [System.IO.File]::Create($outputPath)
		        $buffer = New-Object byte[] 1024
		        $bytesRead = 0
		        while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
		        	$fileStream.Write($buffer, 0, $bytesRead)
		        }
		        $fileStream.Close()
		        $response.Close()
		        Write-Host "RS downloaded successfully to $outputPath" -f Green
            }
            catch
            {
                $sql_latestversion = $SQLmatches[-1]
                $url = "$build_server_url/$sql_latestversion/rs/SQLServerReportingServices.exe" 	
		        $outputPath = "$destinationpath/sqlserverreportingservices.exe"
		        $request = [System.Net.HttpWebRequest]::Create($url)
                Start-Sleep -s 3
		        $response = $request.GetResponse()
		        $stream = $response.GetResponseStream()
		        $fileStream = [System.IO.File]::Create($outputPath)
		        $buffer = New-Object byte[] 1024
		        $bytesRead = 0
		        while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
		        	$fileStream.Write($buffer, 0, $bytesRead)
		        }
		        $fileStream.Close()
		        $response.Close()
		        Write-Host "RS downloaded successfully to $outputPath" -f Green
            }

        }


        #downloading the ssms
		$url = "$build_server_url/$sqlversion/ssms/SSMS-Setup-ENU.exe" 	
		$outputPath = "$destinationpath/ssms-setup-enu.exe"
		$request = [System.Net.HttpWebRequest]::Create($url)
        Start-Sleep -s 3
		$response = $request.GetResponse()
		$stream = $response.GetResponseStream()
		$fileStream = [System.IO.File]::Create($outputPath)
		$buffer = New-Object byte[] 1024
		$bytesRead = 0
		while (($bytesRead = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
			$fileStream.Write($buffer, 0, $bytesRead)
		}
		$fileStream.Close()
		$response.Close()
		Write-Host "SSMS downloaded successfully to $outputPath" -f Green

        }
function MountISOandCopy
{
    param(
        [String]$path
    )
    try
    {
        $isofile = (Get-ChildItem $path | Where-Object {$_.PSIsContainer -eq $false}).Name | Where-Object {$_.contains(".iso") -or $_.contains(".ISO")}
        if($isofile.Count -eq 1)
        {
            $isofilepath = "$path\$isofile"
            Mount-DiskImage -imagepath $isofilepath -PassThru
            $driveletter = (Get-Volume | where-object {$_.DriveType -eq "CD-ROM"} | where-object {$_.FileSystemLabel -ilike "*SQL*"}).DriveLetter
            $downloadpath = "$path\Binaries"
            if(!(Test-Path -path $downloadpath))
            {
                New-Item -path $downloadpath -ItemType Directory
            }
            Copy-Item "${driveletter}:\*" "$downloadpath" -Recurse -Force
            Dismount-DiskImage -imagepath $isofilepath
        }
        else
        {
            Write-Host "The folder has more than one iso files. So exiting...." -f Red
            Exit 0
        }
    }
    catch
    {
        Write-Host "Error Occurred while downloading the binaries from the mounted iso.. $_" -f Red
    }
}
function CheckHostedEnv
{
    param($awsInstanceMetadataUrl, $azureInstanceMetadataUrl)
    try 
    {
        $awsInstanceMetadata = Invoke-WebRequest -Uri $awsInstanceMetadataUrl -UseBasicParsing -TimeoutSec 2
        if($awsInstanceMetadata)
        {
            Write-Host "The server is hosted on AWS."
            return "AWS"
        }
    }
    catch
    {
        try
        {
            $azureInstanceMetadata = Invoke-WebRequest -Uri $azureInstanceMetadataUrl -Headers @{ "Metadata" = "true" } -UseBasicParsing -TimeoutSec 2
            if($azureInstanceMetadata) 
            {
                Write-Host "The server is hosted on Azure."
                return "AZR"
            }
        }
        catch
        {
            Write-Host "Error in finding the hosted environment :  $_"
            Exit 0
        }
    }
}
function Executeallscripts
{
    Param(
       [string] $dmllocation,
       [string] $prc,
       [string] $tr,
       [string] $envr,
       [string] $sqlver,
       [string] $edtn,
       [string] $instnc,
       [string] $spver,
       [string] $collation,
       [string] $majorversion,
       [string] $setupfilepath
    )
    try 
    {
        $Time = Get-Date -UFormat "%y%m%d%H%M"
        $pathforLogs = "C:\SQLInstall_Logs"
        if(!(Test-Path $pathforLogs))
        {
            New-Item -path $pathforLogs -ItemType Directory
        }

        $BatchLog = "$pathforLogs\sddc_sql_SQLInstallBatchScript_$Time.txt"
        $Exec_Time = Get-Date

        Write-Host "###################################################################################################"
        Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $ENV:computername"
        Write-Host "###################################################################################################"

        "###################################################################################################" >> $BatchLog
        "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $ENV:computername" >> $BatchLog
        "Execution string: $ScriptName $prc $tr $envr $sqlver $spver $edtn $instnc $collation" >> $BatchLog
        "###################################################################################################" >> $BatchLog
        "" >> $BatchLog

        $ResultFilePath = "C:\IQOQ\Status.txt"
        $local_script_location = "D:\SQLsetup"
        #----------------------------Execute OS Verfication Script --------------------------#
        $OSVerificationScript = "$local_script_location\sddc_sql_Pre-Req_OS_Verification.ps1"
        powershell.exe -ExecutionPolicy Bypass $OSVerificationScript $prc $tr $envr 
        $PreReqOSVerficationResult = Get-Content $ResultFilePath
        Write-Host "$PreReqOSVerficationResult"
        if($PreReqOSVerficationResult -ne "FAILED")
        {
            "Script sddc_sql_Pre-Req_OS_Verification.ps1 : Executed successfully" >> $BatchLog

            #----------------------Execute SQL Installation Script --------------------------#
            $SQLInstallationScript = "$local_script_location\sddc_sql_InstallSQLServer.ps1"
            powershell.exe -ExecutionPolicy Bypass $SQLInstallationScript $prc $sqlver $edtn $spver $collation $instnc $majorversion $setupfilepath
            $SQLInstallationResult = Get-Content $ResultFilePath
            Write-Host $SQLInstallationResult
            if($SQLInstallationResult -ne "FAILED")
            {
                "Script SDDC_sql_InstallSQLServer.ps1 : Executed successfully" >> $BatchLog
                #----------------------Execute SQL Post Installation Script --------------------------#
                $SQLPostInstallationScript = "$local_script_location\sddc_sql_Post_Installation.ps1"
                powershell.exe -ExecutionPolicy Bypass $SQLPostInstallationScript $prc $sqlver $instnc $majorversion
                $SQLPostInstallationResult = Get-Content $ResultFilePath
                if($SQLPostInstallationResult -ne "FAILED")
                {
                    "Script sddc_sql_Post_Installation.ps1 : Executed successfully" >> $BatchLog
                    
                    #---------------------Execute Post Verification ----------------------#
                    if($Process -ieq "AWS" -or $Process -ieq "AZR")
                    {
                        $scripttorun = "sddc_sql_Post_Installation_Verification.ps1"
                    }
                    elseif($Process -eq "SDDC")
                    {
                        $scripttorun = "sddc_sql_Post_Installation_Verification_SDDC.ps1"
                    }
                    $SQLPostInstallVerificationScript = "$local_script_location\$scripttorun"
                    powershell.exe -ExecutionPolicy Bypass $SQLPostInstallVerificationScript $sqlver $spver $instnc $majorversion
                    if($SQLInstallationResult -eq "REBOOT")
                    {
                        Write-Host "Please reboot the server"
                    }
                    $SQLPostInstallVerificationResult = Get-Content $ResultFilePath
                    if($SQLPostInstallVerificationResult -ne "FAILED")
                    {
                        "Script $scripttorun : Executed successfully" >> $BatchLog
                    }
                    else
                    {
                        "Script $scripttorun : FAILED. View the log files and address the failed steps" >> $BatchLog
                    }
                }
                else
                {    
                    Write-host "Error during Post Installation script sddc_sql_Post_Installation"
		            "Script sddc_sql_Post_Installation.ps1 : Error during Post Installation script sddc_sql_Post_Installation" >> $BatchLog
                }
            }
            else
            {
                Write-host "Reboot required OR Error during SQL Installation"
                "Script sddc_sql_InstallSQLServer.ps1 : Reboot required OR Error during SQL Installation" >> $BatchLog 
            }
        }
        else
        {
            Write-host "`n Resolve the failed tasks and then run the script.`n"
            "Script sddc_sql_Pre-Req_OS_Verification.ps1 : Resolve the failed tasks and then run the script." >> $BatchLog 
        }
    }
    catch 
    {
        Write-Output "Error Occurred : $_.Message"
    }
}
try
{
    $Process = $args[0]
    $Tier = $args[1]
    $Env = $args[2]
    $SQLVersion = $args[3]
    $SPVersion = $args[4]  
    $Edition = $args[5]
    $strCollation = $args[6]
	#$Process = "SDDC"
    #$Tier = "Small"
    #$Env = "QA"
    #$SQLVersion = "SQL2022"
    #$SPVersion = "16.0.4120.exe"
    #$Edition = "E"
    #$strCollation = "SQL_Latin1_General_CP1_CI_AS"
    $InstanceName = "MSSQLSERVER"	

    $SQLDML= "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\Scripts\Dynamic_Provisioning_Scripts" 
    $build_server_url = "http://buildserver.jnj.com/jnj-opcx-scm/packages/database/mssql" 
    $regexpattern = "SQL20[0-9][0-9]"   
    $htmlContent = Invoke-RestMethod -Uri $build_server_url
    $global:SQLmatches = $htmlContent -split '\n' | Select-String -Pattern $regexpattern | ForEach-Object { $_.Matches.Value }
    $SQLVer_SPVer = @{}
    $rtmregexpattern = "en_sql_server_20[0-9][0-9]_([a-z]+_[a-z]+|[a-z]+)_rtm.ISO"
    $sp_hf_regexpattern = "\d+.\d.\d+.exe"
    foreach($match in $SQLmatches)
    {
        $rtmUrl = "$build_server_url/$match/binaries"
        $rtmHtmlContent = Invoke-RestMethod -Uri $rtmUrl
        $RTMmatches = $rtmHtmlContent -split '\n' | Select-String -Pattern $rtmregexpattern | ForEach-Object { $_.Matches.Value }
        $SQLVer_SPVer[$match] = $RTMmatches
        $sp_hf_url = "$build_server_url/$match/patches"
        $sp_hf_htmlcontent = Invoke-RestMethod -Uri $sp_hf_url
        $sp_hf_matches = $sp_hf_htmlcontent -split '\n' | Select-String -Pattern $sp_hf_regexpattern | ForEach-Object { $_.Matches.Value }
        $SQLVer_SPVer[$match] += $sp_hf_matches
    }

    # $SQLVer_SPVer["SQL2005"] = @("SP3", "SP4")
    # $SQLVer_SPVer["SQL2008"] = @("SP3", "SP4", "SP4_10.00.6556")
    # $SQLVer_SPVer["SQL2012"] = @("SP2", "SP3", "SP3CU11.0.6567", "SP4", "SP4_11.0.7462")
    # $SQLVer_SPVer["SQL2014"] = @("SP2", "SP2_12.0.5557", "SP2_12.0.5589", "SP3_12.0.6329")
    # $SQLVer_SPVer["SQL2016"] = @("SP1", "SP2", "SP2_13.0.5201", "SP2_13.0.5426", "SP2_13.0.5830", "CU17", "SP3", "SP3_13.0.6419")
    # $SQLVer_SPVer["SQL2017"] = @("RTM", "CU16", "CU21", "CU25", "CU29")
    # $SQLVer_SPVer["SQL2019"] = @("RTM", "CU16", "CU17") 

    $arrCollation = @("SQL_Latin1_General_CP1_CI_AS",
                      "Latin1_General_CI_AI",
                      "Latin1_General_CI_AS",
                      "Latin1_General_CI_AS_KS_WS",
                      "SQL_Latin1_General_CP850_CI_AI",
                      "Chinese_PRC_CI_AS",
                      "SQL_Latin1_General_CP1_CI_AI",
                      "SQL_Latin1_General_CP850_BIN2",
                      "Chinese_Taiwan_Stroke_CI_AS",
                      "SQL_Latin1_General_CP1_CS_AS",
                      "Cyrillic_General_CI_AS",
                      "Finnish_Swedish_CI_AS",
                      "Japanese_CI_AS",
                      "SQL_Czech_CP1250_CI_AS",
                      "Arabic_BIN",
                      "Czech_BIN",
                      "French_BIN",
                      "Latin1_General_CS_AS",
                      "SQL_Latin1_General_CP850_BIN",
                      "Thai_CI_AS",
                      "Finnish_Swedish_CS_AI",
                      "Hebrew_CI_AS",
                      "Japanese_CI_AI",
                      "Korean_Wansung_CI_AS",
                      "Latin1_General_CS_AI",
                      "Polish_CI_AS",
                      "SQL_1xCompat_CP850_CI_AS",
                      "SQL_Hungarian_CP1250_CS_AS",
                      "SQL_Slovak_CP1250_CI_AS" )   
    
    #$transcript = "C:\SQLInstall_Logs\TranscriptLog"
    #if(!(Test-Path -path $transcript))
    #{
    #    New-Item -path $transcript -ItemType Directory -Force
    #}
    #$transcriptfile = "$transcript\Transcript.txt"
    #if(!(Test-Path -path $transcriptfile))
    #{
    #    New-Item -path $transcriptfile -ItemType File -force
    #}
    #else
    #{
    #    try
    #    {
    #        Clear-Content -path $transcriptfile -force
    #        Start-Sleep -s 3
    #        Start-Transcript -Path $transcriptfile
    #    }
    #    catch
    #    {
    #        $process_id = (Get-Process | Where-Object {$_.Modules.FileName -contains $transcriptfile}).Id
    #        Stop-Process -Id $process_id
    #        Clear-Content -path $transcriptfile -force
    #        Start-Sleep -s 3
    #        Start-Transcript -Path $transcriptfile
    #    }
    #}

    Write-Host "Validating the passed parameters..."
    CheckParameters -Process $Process -Tier $Tier -Env $Env -SQLVersion $SQLVersion -SPVersion $SPVersion -Edition $Edition -strCollation $strCollation -SQLVer_SPVer $SQLVer_SPVer -arrCollation $arrCollation   
    $SQLServerRegistryPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
    if(Test-Path $SQLServerRegistryPath)
    {
      $instances = (Get-ItemProperty $SQLServerRegistryPath).InstalledInstances
      if($instances -contains $InstanceName)
      {
        Write-host "`nDefault instance $InstanceName already exists.`n"
        Exit 0  
      }
    }

    $regexmatch = "\d+.\d.\d+.exe"
    $majorversion = $SQLVer_SPVer[$SQLVersion] | Select-String -Pattern $regexmatch | ForEach-Object {($_ -Split("\."))[0]} | Sort-Object -Unique
    $destinationpath = "D:\SQLInstall\Download"
	if((Test-Path $destinationpath))
	{
         Remove-Item $destinationpath -force -recurse
         New-Item -path $destinationpath -ItemType Directory		 
	}
    else
    {
        New-Item -path $destinationpath -ItemType Directory
    }
    
    if($Edition -ieq "E")
    {
        $rtm_to_install = $SQLVer_SPVer[$SQLVersion] | Where-Object {$_ -match $rtmregexpattern -and $_ -like "*enterprise*"}
        if($SQLVersion -ieq "SQL2016")
        {
            $rtm_to_install = "en_sql_server_2016_enterprise_with_service_pack_2.ISO"
        }
    }
    elseif($Edition -ieq "S")
    {
        $rtm_to_install = $SQLVer_SPVer[$SQLVersion] | Where-Object {$_ -match $rtmregexpattern -and $_ -like "*standard*"}
        if($SQLVersion -ieq "SQL2016")
        {
            $rtm_to_install = "en_sql_server_2016_standard_with_service_pack_2.ISO"
        }
    }

    Write-Host "Downloading the binaries from the central build server...$build_server_url"
    DownloadFiles $SQLVersion $SPVersion $rtm_to_install $build_server_url $destinationpath
	Write-Host "Downloading executable files is completed......" -f green
    Write-Host "Mounting the iso file to copy the binaries..."
	MountISOandCopy $destinationpath
    Write-Host "ISO file is mounted, binaries are copied and dismounted the iso..." -f Green
    if($Process -ine "SDDC")
    {
        $awsMetadataUrl = "http://169.254.169.254/latest/meta-data"
        $azrMetadataUrl = "http://169.254.169.254/metadata/instance?api-version=2019-03-11"
        $hosted_environment = CheckHostedEnv $awsMetadataUrl $azrMetadataUrl
        Write-Host "hosted_environment : $hosted_environment"
        if($hosted_environment -eq "AWS")
        {
            $Process = "AWS"
        }
        elseif($hosted_environment -eq "AZR")
        {
            $Process = "AZR"
        }
    }
    
    Executeallscripts $SQLDML $Process $Tier $Env $SQLVersion $Edition $InstanceName $SPVersion $strCollation $majorversion $destinationpath
    #Stop-Transcript
}
catch
{
  Write-Output "Error Occured : $_"
}