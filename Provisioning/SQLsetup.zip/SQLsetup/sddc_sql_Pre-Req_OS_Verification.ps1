$global:ScriptName = "sddc_SQL_Pre-Req_OS_Verification.ps1"
$global:Scriptver = "1.0"
###################################################################################################
<#Description 
    The script deals with verification of server configuration compatible for installing SQL instanc.
#>
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			11/08/2024	Pavithra K	New Script
###################################################################################################
function sddc_sql_Pre_Req_OS_Verification ($IDMLLOC)
{
	$Time = get-date -Uformat "%Y%m%d%H%M"
	$pathforLogs = "C:\SQLInstall_Logs"
    if(!(Test-Path $pathforLogs))
    {
        New-Item -path $pathforLogs -ItemType Directory
    }
    $Log = "$pathforLogs\sddc_sql_Pre-Req_OS_Verification_$Time.txt"
	$Exec_Time = Get-Date

	Write-Host "###################################################################################################"
	Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $env:computername"
	Write-Host "###################################################################################################"

	"###################################################################################################" > $Log
	"Script Name: $ScriptName`nScript Version: $Scriptver`nExecute On: $Exec_Time`nServer Host: $env:computername" >> $Log
	"Execution string: $ScriptName $Process $Tier $Env" >> $Log
	"###################################################################################################" >> $Log

	$VM_Size_IAll = "D:\SQLsetup\ConfigFiles\sddc_sql_VM_Size_test_provision.txt" 
	$VM_Size_All = Import-Csv $VM_Size_IAll

	$Disk_Layout_IAll = "D:\SQLsetup\ConfigFiles\sddc_sql_Disk_Layout_provision.txt"
	$Disk_Layout_All = Import-Csv $Disk_Layout_IAll

	$Disk_Sizes_IAll = "D:\SQLsetup\ConfigFiles\sddc_sql_Disk_Sizes_test_provision.txt"
	$Disk_Sizes_All = Import-Csv $Disk_Sizes_IAll

	$pathIQOQLogs = "C:\IQOQ"
	if(!(Test-Path $pathIQOQLogs))
	{
		New-Item -Path $pathIQOQLogs -ItemType Directory
	}
	Set-ItemProperty -Path "$pathIQOQLogs\*.txt" -Name IsReadOnly -Value $False
	Remove-Item $pathIQOQLogs\* -recurse
	$IQOQ_1 = "$pathIQOQLogs\IQOQ_1.txt" #Enable Read-only mode
	$BatchOutput1 = "$pathIQOQLogs\Status.txt"

	function Drive 
	{  
		PARAM($DriveLetter)  
		(New-Object System.IO.DriveInfo($driveletter)).DriveType -ne 'NoRootDirectory'    
	}  

	function Error
	{
		Exit 1
		Break
	}

	#--------------------------------- Verify OS Version ---------------------------------#
	Write-Host "--------------`nVerify Minimum OS Version`nExpected Value : 6.1"
	"--------------`nVerify Minimum OS Version`nExpected Value : 6.1" >> $Log

	$Major = [environment]::OSVersion.Version.Major
	$Minor = [environment]::OSVersion.Version.Minor
	$OS_Version = "$Major.$Minor"
	Write-Host "Current Value : $OS_Version"
	"Current Value : $OS_Version" >> $Log

	$expectedOSVersionValues = @("6.1","6.2","6.3","10.0")
	if($expectedOSVersionValues -notcontains $OS_Version)
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify Processor Type --------------------------------- #
	Write-Host "--------------`nVerify Processor Type`nExpected Value : Different from x86"
	"--------------`nVerify Processor Type`nExpected Value : Different from x86" >> $Log

	$Proc = (Get-Process -Id $PID).StartInfo.EnvironmentVariables["PROCESSOR_ARCHITECTURE"]
	Write-Host "Current Value : $Proc"
	"Current Value : $Proc" >> $Log

	if($Proc -eq "x86")
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify .NET --------------------------------- #
	Write-Host "--------------`nVerify .NET Version`nExpected Value : 4.0*"
	"--------------`nVerify .NET Version`nExpected Value : 4.0*" >> $Log
	$error.clear()

	$NET = Get-ItemProperty 'HKLM:\Software\Microsoft\NET Framework Setup\NDP\v4\Client\1033'
	if($error[0])
	{
		$NET_Version = "N/A"
	}
	else
	{
		$NET_Version = $NET.Version
	}
	Write-Host "Current Value : $Net_Version"
	"Current Value : $Net_Version" >> $Log

	if($NET_Version -eq "N/A")
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify NetBackup Configuration --------------------------------- #
	if($Process -ieq "SDDC")
	{
		Write-Host "--------------`nVerify NetBackup Exclusion List`nExpected Value: *.MDF,*.NDF,*.LDF"
		"--------------`nVerify NetBackup Exclusion List`nExpected Value: *.MDF,*.NDF,*.LDF" >> $Log
	
		$NBU = Get-ItemProperty 'HKLM:\Software\Veritas\NetBackup\CurrentVersion\Config'
		$NBU_EL = $NBU.Exclude
		if($NBU_EL -Contains "*.MDF") {$NBU_Final = "*.MDF"}
		if($NBU_EL -Contains "*.NDF") {$NBU_Final = $NBU_Final + ",*.NDF"}
		if($NBU_EL -Contains "*.LDF") {$NBU_Final = $NBU_Final + ",*.LDF"}
		Write-Host "Current Value : $NBU_Final"
		"Current Value : $NBU_Final" >> $Log
	
		if($NBU_Final -ne "*.MDF,*.NDF,*.LDF")
		{
			Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
			"Verification : FAIL" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
			"Verification : OK" >> $Log
		}
	
		Write-Host "--------------"
		"--------------" >> $Log
	}
	#--------------------------------- Verify Pagefile Size --------------------------------- #
	Write-Host "--------------`nVerify Pagefile Size`nExpected Value : Bigger than 8G"
	"--------------`nVerify Pagefile Size`nExpected Value : Bigger than 8G" >> $Log

	$PageFile_All = Get-WmiObject -class Win32_PageFileUsage
	$PageFile = $PageFile_All.AllocatedBaseSize / 1024
	Write-Host "Current Value : $Pagefile GB"
	"Current Value : $Pagefile GB" >> $Log
	if($PageFile -lt 8)
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify VM Size - CPU --------------------------------- #
	Write-Host "--------------`nVerify # of CPUs"
	"--------------`nVerify # of CPUs" >> $Log

	$Tmp_Exp_CPU = $VM_Size_All | Select-Object Process,Tier,CPU | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
	$Exp_CPU = $Tmp_Exp_CPU.CPU
	$property = "numberOfCores"
	$Tmp_Curr_CPU = Get-WmiObject -class win32_processor -Property $property -ErrorAction Stop | Select-Object -Property $property
	if($Tmp_Curr_CPU -is [system.array])
	{
		$Curr_CPU = 0
		#$Curr_CPU_Count = $Tmp_Curr_CPU.Count
		foreach($CPU in $Tmp_Curr_CPU) 
		{
			$Curr_CPU += $CPU.numberOfCores
		}
		if ($Curr_CPU -eq 0)
		{
			$Curr_CPU = $Tmp_Curr_CPU.Count
		}
	}
	else
	{
		$Curr_CPU = $Tmp_Curr_CPU.numberOfCores
	}

	[int]$Min_CPU = 2

	Write-Host "Expected # of CPUs : 2`nCurrent # of CPUs : $Curr_CPU"
	"Expected # of CPUs : $EXp_CPU`nCurrent # of CPUs : $Curr_CPU" >> $Log

	if($Curr_CPU -lt $Min_CPU)
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify VM Size - Memory --------------------------------- #
	Write-Host "--------------`nVerify Memory"
	"--------------`nVerify Memory" >> $Log

	$Tmp_Exp_Mem = $VM_Size_All | Select-Object Process,Tier,Memory | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
	$Exp_Mem = $Tmp_Exp_Mem.Memory
	$Tmp_Curr_Mem = Get-WmiObject Win32_ComputerSystem
	$Curr_Mem = [decimal]::round((($Tmp_Curr_Mem.TotalPhysicalMemory/1024)/1024)/1024)

	[decimal]$Min_Mem = 4
	Write-Host "Expected Memory (GB) : $Min_Mem`nCurrent Memory (GB) : $Curr_Mem"
	"Expected Memory (GB): $EXp_Mem`nCurrent Memory (GB) : $Curr_Mem" >> $Log
	if($Curr_Mem -lt $Min_Mem)
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify WinAdmin group exists --------------------------------- #

	Write-Host "--------------"
	"--------------" >> $Log

	$group =[ADSI]"WinNT://./Administrators,group" 
	$members = @($group.psbase.Invoke("Members"))
	if(($members | ForEach-Object {$_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}) -contains "ITS-EP-APP-DBServers-WinAdmin")
	{
	    if($IPIdentifier2 -eq 0)
	    {
			Write-Host "DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "OK" -f green
			"DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: OK" >> $Log
	    }
		else
	    {
			Write-Host "JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "OK" -f green
			"JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: OK" >> $Log
	    }
	}
	else
	{
		if($IPIdentifier2 -eq 0)
	    {
			Write-Host "DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "FAIL" -f red
			"DFDEV\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: FAIL" >> $Log
			$Final_Status_Error = 1
	    }
	    else
	    {
			Write-Host "JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: " -f white -nonewline; Write-Host "FAIL" -f red
			"JNJ\ITS-EP-APP-DBServers-WinAdmin is member of Local Admins: FAIL" >> $Log
			$Final_Status_Error = 1
	    }
	}

	Write-Host "--------------"
	"--------------" >> $Log

	#--------------------------------- Verify Disk Configuration Layout --------------------------------- #
	Write-Host "--------------`nDisk Layout Configuration"
	"--------------`nDisk Layout Configuration" >> $Log

	$Tmp_Exp_Disk_Layout = $Disk_Layout_All | Select-Object Process,Drive | Where-Object {$_.Process -eq $Process}
	foreach($item in $Tmp_Exp_Disk_Layout) 
	{
		$Tmp_Exp_Disk_Layout_2 = $item.Drive
		$Exp_Disk_Layout = $Exp_Disk_Layout + $Tmp_Exp_Disk_Layout_2 + ","
		$Tmp_Curr_Disk_Layout = $item.Drive
		$Tmp_Curr_Disk_Layout_2 = Drive $Tmp_Curr_Disk_Layout
		if($Tmp_Curr_Disk_Layout_2 -eq "True")
		{
			$Curr_Disk_Layout = $Curr_Disk_Layout + $Tmp_Curr_Disk_Layout + ","
		}
	}

	Write-Host "Expected Disk Layout : $Exp_Disk_Layout`nCurrent Disk Layout : $Curr_Disk_Layout"
	"Expected Disk Layout : $Exp_Disk_Layout`nCurrent Disk Layout : $Curr_Disk_Layout" >> $Log

	if($Exp_Disk_Layout -ne $Curr_Disk_Layout)
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
		"Verification : FAIL" >> $Log
		$Final_Status_Error = 1
	}
	else
	{
		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
		"Verification : OK" >> $Log
	}

	Write-Host "--------------"
	"--------------" >> $Log

#--------------------------------- Verify Disk Size Configuration --------------------------------- #
	Write-Host "--------------`nDisk Size Configuration"
	"--------------`nDisk Size Configuration" >> $Log
	"" >> $Log

	# Enable native auditing on all environments (DEV, QA and PROD)
	"Native Auditing:Enable" > $IQOQ_1
	if($Env -ieq "DEV")
	{
		"DEV" >> $IQOQ_1
	}
	else
	{
		"PROD" >> $IQOQ_1
	}
	
	Set-ItemProperty -Path $IQOQ_1 -Name IsReadOnly -Value $True
	
	if($Env -ine "DEV")
	{
		$Env = "NON_DEV"
	}
	if($Process -ieq "AWS" -or $Process -ieq "AZR")
	{
		$i=0
		$Tmp_Exp_Disk_Size = $Disk_Sizes_All | Select-Object Process,Drive,Env,Tier,Size | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier -and $_.Env -eq $Env}
		foreach($item in $Tmp_Exp_Disk_Size) 
		{
			$Tmp_Exp_Disk_Size_2 = $item.Drive
	  		[decimal]$Exp_Disk_Size = $item.Size
	  		[decimal]$tolerance = ($Exp_Disk_Size)*0.05
	  		[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance

	 		Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less"
	  		"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less" >> $Log

	  		$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID,Size | Where-Object {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
	  		$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)

	  		Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size"
	  		"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size" >> $Log

	  		Write-Host "--"
	  		"--" >> $Log

	  		if($Curr_Disk_Size -lt $Exp_Disk_Size_less)
	   		{
	     		$i = 1
	   		}
		}
		if($i -eq 1)
	 	{
	   		Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
	   		"Verification : FAIL" >> $Log
	   		$Final_Status_Error = 1
	 	}
		else
	 	{
	   		Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
	   		"Verification : OK" >> $Log
	 	}
	}
	if($Process -eq "SDDC")
	{
		$i=0
		$Tmp_Exp_Disk_Size = $Disk_Sizes_All | Select-Object Process,Drive,Tier,Size,UsedFor | Where-Object {$_.Process -eq $Process -and $_.Tier -eq $Tier}
		foreach($item in $Tmp_Exp_Disk_Size) 
		{
			$Tmp_Exp_Disk_Size_2 = $item.Drive
			$Tmp_Exp_Disk_Size_3 = $item.UsedFor
			if(($Tmp_Exp_Disk_Size_3 -eq "Binary") -or ($Tmp_Exp_Disk_Size_3 -eq "Sysdb"))
			{
				[decimal]$Exp_Disk_Size = $item.Size
				[decimal]$tolerance = ($Exp_Disk_Size)*0.05
				[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance

				Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less"
				"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less" >> $Log

				$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID,Size | Where-Object {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
				$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)

				Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size"
				"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size" >> $Log

				Write-Host "--"
				"--" >> $Log

				if($Curr_Disk_Size -lt $Exp_Disk_Size_less)
				{
					$i = 1
				}
			}
			if(($Tmp_Exp_Disk_Size_3 -eq "Data1") -or ($Tmp_Exp_Disk_Size_3 -eq "Data2"))
			{ 
				[decimal]$Exp_Disk_Size = $item.Size
				[decimal]$tolerance = ($Exp_Disk_Size)*0.05
				[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance

				Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less"
				"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less" >> $Log

				$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID,Size | Where-Object {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
				$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)

				Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size"
				"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size" >> $Log

				if($Tmp_Exp_Disk_Size_3 -eq "Data1")
				{
					$Data1 = $Curr_Disk_Size
				}
				Write-Host "--"
				"--" >> $Log

				if($Curr_Disk_Size -lt $Exp_Disk_Size_less)
				{
					$i = 1
				}
			}
			if(($Tmp_Exp_Disk_Size_3 -eq "Log") -or ($Tmp_Exp_Disk_Size_3 -eq "TempDB"))
			{
				if($Data1 + $Data2 -gt 100)
				{
					[decimal]$Exp_Disk_Size = $item.Size
					[decimal]$tolerance = ($Exp_Disk_Size)*0.05
					[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance		
				}
				else
				{
					[decimal]$Exp_Disk_Size = $item.Size
					[decimal]$tolerance = ($Exp_Disk_Size)*0.05
					[decimal]$Exp_Disk_Size_less = $Exp_Disk_Size-$tolerance
				}
				Write-Host "Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less"
				"Expected minimum size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Exp_Disk_Size_less" >> $Log

				$Tmp_Curr_Disk_Size = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID,Size | Where-Object {$_.DeviceID -eq $Tmp_Exp_Disk_Size_2}
				$Curr_Disk_size = [decimal]::round((($Tmp_Curr_Disk_Size.Size/1024)/1024)/1024)

				Write-Host "Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size"
				"Current size (GB) for Drive $Tmp_Exp_Disk_Size_2 : $Curr_Disk_Size" >> $Log

				Write-Host "--"
				"--" >> $Log
				if($Curr_Disk_Size -lt $Exp_Disk_Size_less)
				{
					$i = 1
				}
			}
		}
		if($i -eq 1)
		{
			Write-Host "Verification : " -f white -nonewline; Write-Host "FAIL" -f red
			"Verification : FAIL" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Verification : " -f white -nonewline; Write-Host "OK" -f green
			"Verification : OK" >> $Log
		}
	}
	Write-Host "--------------"
	"--------------" >> $Log
	#-----------------------------------------------------------------------------------------#

	Write-Host "###################################################################################################"
	"###################################################################################################" >> $Log

	if($Final_Status_Error -eq 1)
	{
		Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
		"FINAL STATUS = FAILED" >> $Log
		"FAILED" > $BatchOutput1
		Write-Host "Please review the verification steps and address the failed step"
		"Please review the verification steps and address the failed step" >> $Log
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log
		Exit 1  
	}
	else
	{
		Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
		"FINAL STATUS = SUCCESS" >> $Log
		"SUCCESS" > $BatchOutput1
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log
		Exit 0
	}
}
try
{
	$SQLDML= '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML' 
	$ErrorActionPreference = "SilentlyContinue"
	$error.clear()
	$Final_Status_Error = 0
	$global:Process = $args[0]
	$global:Tier = $args[1]
	$global:Env = $args[2]
	#$global:Process = "SDDC"
	#$global:Tier = "Small"
	#$global:Env = "QA"
	sddc_sql_Pre_Req_OS_Verification $SQLDML
}
catch
{
	Write-Host "Error Occurred : $_"
}
