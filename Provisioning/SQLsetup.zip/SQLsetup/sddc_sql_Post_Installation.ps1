###################################################################################################
$global:ScriptName = "sddc_sql_Post_Installation.PS1"
$global:Scriptver = "1.0"
###################################################################################################
<#Description 
    The script carries out the activities like backup jobs deployment, baseline db configuration, tempdb configuration, enabling nativeaudit, etc 
#>
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			11/08/2024	Pavithra K	New Script
###################################################################################################
function Post_Installation($IDMLLOC, $Process, $sqlversion, $iName, $majorversion)
{
	#try
	#{
		Write-Host "Here"
		$Time = get-date -Uformat "%Y%m%d%H%M"
		$Log = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_$Time.txt"
		#$LogFilePath = "C:\SQLInstall_Logs\sddc_sql_Post_Installation_SQLLog_$Time.txt"
		$E_NativeAuditLog = "C:\SQLInstall_Logs\sddc_sql_ENT_NativeAudit_Log_$Time.txt"
		$S_NativeAuditLog = "C:\SQLInstall_Logs\sddc_sql_STD_NativeAudit_Log_$Time.txt"
		$S_StartAuditJob = "C:\SQLInstall_Logs\sddc_sql_STD_StartAuditJob_Log_$Time.txt"
		#$M_Plans_sql = $IDMLLOC + "\Scripts"
        $Hostname = Hostname
		$Exec_Time = Get-Date
        
		Write-Host "###################################################################################################"
		"###################################################################################################" > $Log
		Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname"
		"Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname" >> $Log
		"Execution String: $ScriptName $Process $sqlversion $iName" >> $Log
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log

		$ErrorActionPreference = "SilentlyContinue"
		$error.clear()
		[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.ConnectionInfo')
		[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Sdk.Sfc')
		[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO')
		[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMOExtended')
		
		if($iName -eq "MSSQLSERVER")
		{
			#Write-Host "inside if"
		 	$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
		 	$Inst_Name = $svr.name
		 	$Inst_Name
		 	$Final_Status_Error = 0
		}
		else
		{
			$svr = new-object ('Microsoft.SqlServer.Management.Smo.Server') localhost
			$Inst_Name = $svr.name + "\" + $iName
			$Final_Status_Error = 0
		}
		#Write-Host "after if-else"
		$filesystemobject = New-Object -ComObject Scripting.FileSystemObject
		#Write-Host "before array"
		$nonODBCVersions = @("SQL2005","SQL2008","SQL2012")
		$SSIS_versionfolder = "$majorversion" + "0"
		Write-Host $SSIS_versionfolder
		if($nonODBCVersions -notcontains $sqlversion)
		{
			$M_Plans = $IDMLLOC + "\ConfigFiles"
			$DTSFolder=$filesystemobject.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${SSIS_versionfolder}\DTS\Setup").SQLPath).ShortPath
			$ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${SSIS_versionfolder}\Tools\ClientSetup").ODBCToolsPath
			$ToolsFolder='"' + $ClientTool + 'SQLCMD.EXE"'
		}
		else 
		{
			$M_Plans = $IDMLLOC + "\ConfigFiles"
			$DTSFolder=$filesystemobject.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$($SSIS_versionfolder)\DTS\Setup").SQLPath).ShortPath
			$ToolsFolder=$filesystemobject.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$($SSIS_versionfolder)\Tools\Setup").SQLPath).ShortPath	  
		}

		#--------------------------------- Backup Jobs Deployment ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		$SSISPackages = "C:\SSISPackages"
		$BackUpconfigLogs = "C:\SQLInstall_Logs\BackupConfigLogs"
		$path_array = @($SSISPackages, $BackUpconfigLogs)
		foreach($path in $path_array)
		{
			if(Test-Path $path)
			{
				Remove-Item "$path\*" -recurse
			}
			else 
			{
				New-Item -path $path -ItemType Directory
			}
		}
		
		$BKScriptsPath = $IDMLLOC + '\Scripts\BackupConfigScripts'	
		$ScriptsPath = $IDMLLOC + '\Scripts'
		$LogPath = 'C:\SQLInstall_Logs\BackupConfigLogs'

		#------------------------------------------------------------------------------------------#

		$Env_txt = (Get-Content "C:\IQOQ\IQOQ_1.txt")[1]
		if($Process -eq "SDDC")
		{
			if($Env_txt -eq "DEV")
			{
				Write-Host "Backup Jobs Deployment - For DEV environment"
				Write-Host ""
			    "Backup Jobs Deployment" >> $Log
			    "" >> $Log
				if($nonODBCVersions -notcontains $sqlversion)
				{		
					$bkp_1 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo_meta.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
					$bkp_2 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
					$bkp_3 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
					$bkp_sp = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITSSQL_DB_FULL_BACKUP_DEV.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
					$bkp_dev = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
					$bkp_10 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
					$bkp_11 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
					$bkp_12 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"		
				}
				else 
				{
					$bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo_meta.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
					$bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
					$bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
					$bkp_sp = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_DB_FULL_BACKUP_DEV.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
					if($sqlversion -eq "SQL2005")
					{
						$bkp_dev = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData_SQL2005.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
					}
					else 
					{
						$bkp_dev = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITSSQL_MetaData.sql -o $LogPath\MetaDataJob.txt -x && exit 0 || exit 1"
					}
					$bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
					$bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
					$bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
				}
		
				$backuphashtable = [ordered]@{}
				$backuphashtable[$bkp_1] = "Table ITS_MASTER_BACKUPINFO"
				$backuphashtable[$bkp_2] = "Table ITS_CFG_BLACKOUT"
				$backuphashtable[$bkp_3] = "Table ITS_BACKUP_JOB"
				$backuphashtable[$bkp_sp] = "Table ITSSQL_DB_FULL_BACKUP_DEV"
				$backuphashtable[$bkp_dev] = "Table ITSSQL_MetaData job"
				$backuphashtable[$bkp_10] = "Stored Procedure usp_blackout"
				$backuphashtable[$bkp_11] = "Stored Procedure usp_masterbackup_entry"
				$backuphashtable[$bkp_12] = "Trigger ITS_Audit_Trigger"
				foreach($key in $backuphashtable.keys)
				{
					& cmd.exe /c $key | out-null
					if($lastexitcode -eq 1)
					{
						Write-Host "ITS Backup process - Create $($backuphashtable[$key]) : " -f white -nonewline; Write-Host "Failed" -f red
						"ITS Backup process - Create $($backuphashtable[$key]) : FAILED" >> $Log
						$Final_Status_Error = 1
					}
					else
					{
						Write-Host "ITS Backup process - Create $($backuphashtable[$key]) : " -f white -nonewline; Write-Host "Success" -f green
						"ITS Backup process - Create $($backuphashtable[$key]) : SUCCESS" >> $Log
					}
				}
			}
			else 
			{
				Write-Host "Backup Jobs Deployment - For PROD/QA environment"
				"Backup Jobs Deployment" >> $Log
				if($nonODBCVersions -notcontains $sqlversion)
				{
					$bkp_1 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
 					$bkp_2 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
 					$bkp_3 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
					$bkp_6 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Full_Backup.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
					$bkp_7 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Diff_Backup.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
					$bkp_8 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Log_Backup_2014.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
					$bkp_adhoc_full = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Adhoc_FULL_Backup.sql -o $LogPath\AdhocFullBkpJob.txt -x && exit 0 || exit 1"
					$bkp_adhoc_diff = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\Adhoc_DIFF_Backup.sql -o $LogPath\AdhocDiffBkpJob.txt -x && exit 0 || exit 1"
					$bkp_10 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
   					$bkp_11 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
   					$bkp_12 = $ToolsFolder + " -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"
 
				}
				else 
				{				
					$bkp_1 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_master_backupinfo.sql -o $LogPath\MasterBkpInfo.txt -x && exit 0 || exit 1"
					$bkp_2 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_CFG_BLACKOUT.sql -o $LogPath\CfgBlackout.txt -x && exit 0 || exit 1"
					$bkp_3 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_BACKUP_JOB.sql -o $LogPath\BkpJob.txt -x && exit 0 || exit 1"
					if($sqlversion -eq "SQL2005")
					{
						$bkp_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Full_Backup_SQL2005.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
						$bkp_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Diff_Backup_SQL2005.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
						$bkp_8 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Log_Backup_SQL2005.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
					}
					else
					{
						$bkp_6 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Full_Backup.sql -o $LogPath\FullBkpJob.txt -x && exit 0 || exit 1"
						$bkp_7 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Diff_Backup.sql -o $LogPath\DiffBkpJob.txt -x && exit 0 || exit 1"
						$bkp_8 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\Log_Backup.sql -o $LogPath\LogBkpJob.txt -x && exit 0 || exit 1"
					}
					$bkp_10 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_blackout.sql -o $LogPath\uspBlackoutScript.txt -x && exit 0 || exit 1"
   					$bkp_11 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\usp_masterbackup_entry.sql -o $LogPath\uspmasterBkpEntry.txt -x && exit 0 || exit 1"
   					$bkp_12 = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $BKScriptsPath\ITS_Audit_Trigger.sql -o $LogPath\AuditTrigger.txt -x && exit 0 || exit 1"

				}

				$backuphashtable = [ordered]@{}
				$backuphashtable[$bkp_1] = "Table ITS_MASTER_BACKUPINFO"
				$backuphashtable[$bkp_2] = "Table ITS_CFG_BLACKOUT"
				$backuphashtable[$bkp_3] = "Table ITS_BACKUP_JOB"
				$backuphashtable[$bkp_6] = "Full BackUp Job"
				$backuphashtable[$bkp_7] = "Differential BackUp Job"
				$backuphashtable[$bkp_8] = "Transaction Log BackUp Job"
				$backuphashtable[$bkp_adhoc_full] = "Adhoc Full BackUp Job"
				$backuphashtable[$bkp_adhoc_diff] = "Adhoc Differential BackUp Job"
				$backuphashtable[$bkp_10] = "Stored Procedure usp_blackout"
				$backuphashtable[$bkp_11] = "Stored Procedure usp_masterbackup_entry"
				$backuphashtable[$bkp_12] = "Trigger ITS_Audit_Trigger"
				foreach($key in $backuphashtable.keys)
				{
					& cmd.exe /c $key | out-null
					if($lastexitcode -eq 1)
					{
						Write-Host "ITS Backup process - Create $($backuphashtable[$key]) : " -f white -nonewline; Write-Host "Failed" -f red
						"ITS Backup process - Create $($backuphashtable[$key]) : FAILED" >> $Log
						$Final_Status_Error = 1
					}
					else
					{
						Write-Host "ITS Backup process - Create $($backuphashtable[$key]) : " -f white -nonewline; Write-Host "Success" -f green
						"ITS Backup process - Create $($backuphashtable[$key]) : SUCCESS" >> $Log
					}
				}
			}
		}
        elseif($Process -ieq "AWS")
        {
            $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${SSIS_versionfolder}\Tools\ClientSetup").ODBCToolsPath
            $ClientTool
            $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
            $ToolsFolder
            $AWSBackupScript = "$SQLDML\Scripts\AWS_Modified_Backups_V2.sql"
            $result = $ToolsFolder + " -S $Inst_Name -i $AWSBackupScript -x && exit 0 || exit 1"
            $result
            & cmd.exe /c $result | Out-Null

        }
        elseif($Process -ieq "AZR")
        {
            $ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${SSIS_versionfolder}\Tools\ClientSetup").ODBCToolsPath
            $ClientTool
            $ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
            $ToolsFolder
            $AZRBackupScript = "$SQLDML\Scripts\Azure_Modified_Backups_V1.sql"
            $result = $ToolsFolder + " -S $Inst_Name -i $AZRBackupScript -x && exit 0 || exit 1"
            $result
            & cmd.exe /c $result | Out-Null

        }
		#---------------------------------- End of Backup Jobs Deployment --------------------------------

		#--------------------------------Baseline Database Creation for SQL Performance Montioring ------------------------------# 
		#----------------baseline database creation for SQL performance monitoring and integrity & optimization check ---------------------
        try 
		{
			$BaselineScript = "$SQLDML\Scripts\Baseline_DB_Framework.sql"
			$DiScript = "$SQLDML\ConfigFiles\Databasemaintenance.sql"
			$sqlpath_hash = @{}
			$sqlpath_hash[$BaselineScript] = "Baseline Database Creation for SQL Performance Monitoring"
			$sqlpath_hash[$DiScript] = "Integrity & Optimization Jobs Creation for SQL Server"
			foreach($sqlpath in $sqlpath_hash.Keys)
			{
				$sqlpath
				Write-Host "$($sqlpath_hash[$sqlpath]) " -f white -NoNewline; Write-Host "Started" -f Green
				"$($sqlpath_hash[$sqlpath]) : Started" >> $Log
				$ClientTool = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${SSIS_versionfolder}\Tools\ClientSetup").ODBCToolsPath
				$ClientTool
				$ToolsFolder = '"' + $ClientTool + 'SQLCMD.EXE"'
				$ToolsFolder
				$result = $ToolsFolder + " -S $Inst_Name -i $sqlpath -x && exit 0 || exit 1"
				$result
				& cmd.exe /c $result | Out-Null
				Write-Host "$($sqlpath_hash[$sqlpath]) Completed : " -f white -NoNewline; Write-Host "Success" -f Green
				"$($sqlpath_hash[$sqlpath]) : Success" >> $Log
			}
		}
		catch 
		{
			Write-Host "Error occured in baseline db and basetabasemaintanence creation : $_"
		}


		#-------------------------------- Move TempDB files to H drive if SQL2005 ------------------------------------------#
		if($sqlversion -eq "SQL2005")
		{
			$MoveTempDB = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\SQL2005_MoveTempDB.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005_MoveTempDB.txt -x && exit 0 || exit 1"
			& cmd.exe /c $MoveTempDB | out-null
		}

		#--------------------------------- Script Execution for Post Installation Configuration ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		Write-Host "Script Execution for Post Installation Configuration"
		"Script Execution of Post Installation Configuration" >> $Log

		if($sqlversion -eq "SQL2008")
		{
			Copy-Item $ScriptsPath\sddc_sql2008_TempDBDiskSpace.ps1 C:\IQOQ
		}
		if($sqlversion -eq "SQL2005")
		{
			Copy-Item $ScriptsPath\sddc_sql2005_TempDBDiskSpace.ps1 C:\IQOQ
		}

		if($Process -eq "SDDC")
		{
			$scripttorun = "$ScriptsPath\sddc_sql_Post_Installation_sddc.sql"
		}
		elseif($Process -eq "AWS" -or $Process -eq "AZR")
		{
			$scripttorun = "$ScriptsPath\sddc_sql_Post_Installation_nonsddc.sql"
		}

		if($nonODBCVersions -notcontains $sqlversion)
		{
			$postinstallation_cmd = $ToolsFolder + " -S $Inst_Name -i $scripttorun -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
		}
		else 
		{
			if($sqlversion -eq "SQL2012")
			{
				$postinstallation_cmd = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $scripttorun -o C:\SQLInstall_Logs\BackupConfigLogs\PostInstallSQL.txt -x && exit 0 || exit 1"
			}
			elseif($sqlversion -eq "SQL2008")
			{
				$postinstallation_cmd = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $scripttorun -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2008_SDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
			}
			elseif($sqlversion -eq "SQL2005")
			{
				$postinstallation_cmd = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $scripttorun -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005_SDDC_PostInstallSQL.txt -x && exit 0 || exit 1"
			}
		}
		& cmd.exe /c $postinstallation_cmd | out-null
		if($lastexitcode -eq 1)
		{
			Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Failed" -f red
			"Script Execution of Post Installation Configuration: Failed" >> $Log
			$Final_Status_Error = 1
		}
		else
		{
			Write-Host "Script Execution of Post Installation Configuration: " -f white -nonewline; Write-Host "Success" -f green
			"Script Execution of Post Installation Configuration: Success" >> $Log
		}
		Write-Host "-------"
		"-------" >> $Log

		#---------------------------------------- TempDB Startup Parameters ----------------------------------------#
		if(($nonODBCVersions -contains $sqlversion) -or ($sqlversion -eq "SQL2014"))
		{
			Write-Host "-------"
			"-------" >> $Log
			Write-Host "TempDB Startup Parameters"
			"TempDB Startup Parameters" >> $Log

			$i = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
			$error.clear()
			$regKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$i\MSSQLServer\Parameters"
			$newRegProp = "SQLArg3"
			$StartupParameter = "-T1118"
			Set-ItemProperty -Path $RegKey -Name $newRegProp -Value $StartupParameter
			$newRegProp = "SQLArg4"
			$StartupParameter = "-T1117"
			Set-ItemProperty -Path $RegKey -Name $newRegProp -Value $StartupParameter
			if($error[0])
			{
				$S_Param = 1
			}
			else
			{
				$S_Param = 0
			}
			$error.clear()
			if($S_Param -eq 0)
			{
				Write-Host "TempDB Configuration: " -f white -nonewline; Write-Host "Success" -f green
				"TempDB Configuration: Success" >> $Log
				$Final_Status_Error = 0
			}
			else
			{
				Write-Host "TempDB Configuration: " -f white -nonewline; Write-Host "Failed" -f red
				"TempDB Configuration: Failed" >> $Log
				$Final_Status_Error = 1
			}
			Write-Host "-------"
			"-------" >> $Log
		}
		#--------------------------------- Script Execution for enabling Native Auditing ---------------------------------#

		Write-Host "-------"
		"-------" >> $Log

		New-Item -Path HKLM:\SYSTEM\ControlSet001\Services\EventLog -Name SQLAudit -Force
		if (!(Test-Path -Path 'D:\SQLNativeAudit' -PathType Container ))
		{
			New-Item -Path "D:\" -Name "SQLNativeAudit" -ItemType "directory"
		}
		Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\SQLAudit" -Name "File" -Value "D:\SQLNativeAudit\SQLAudit.evtx"
		New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\SQLAudit" -Name "Flags" -Value "1" -PropertyType DWORD
		Limit-EventLog -LogName "SQLAudit" -MaximumSize 200MB
		New-EventLog -source MSSQL -LogName SQLAudit

		$NativeAudit = (Get-Content "C:\IQOQ\IQOQ_1.txt")
		$i = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
		$Edition=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$i\Setup").Edition

		if(Test-Path "C:\IQOQ\IQOQ_2.txt")
		{
			Remove-Item "C:\IQOQ\IQOQ_2.txt"
		}
		$IQOQ_2 = "C:\IQOQ\IQOQ_2.txt" #Make it read-only

		if($NativeAudit -eq "Native Auditing:Enable")
		{
			if($sqlversion -eq "SQL2005")
			{
				Write-Host "Script Execution for enabling Native Auditing"
				"Script Execution for enabling Native Auditing" >> $Log
				$cmd_audit = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_2005_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
				& cmd.exe /c $cmd_audit | out-null
				if($lastexitcode -eq 1)
				{
				   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
				   "Script Execution for enabling Native Auditing: Failed" >> $Log
				   "Native Auditing:1" >> $IQOQ_2
				   $Final_Status_Error = 1
				}
				else
				{
				   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
				   "Native Auditing:0" >> $IQOQ_2
				   "Script Execution for enabling Native Auditing: Success" >> $Log
				}
			}
			elseif(($Edition -eq "Enterprise Edition: Core-based Licensing") -or ($Edition -eq "Enterprise Edition"))
			{
				Write-Host "Script Execution for enabling Native Auditing"
				"Script Execution for enabling Native Auditing" >> $Log
				if($nonODBCVersions -notcontains $sqlversion) 
				{
					$cmd_audit = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\SQLAudit_ENT_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
				}
				else
				{
					$cmd_audit = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_ENT_Script.sql -x -o $E_NativeAuditLog && exit 0 || exit 1"
				}
			   	& cmd.exe /c $cmd_audit | out-null
				if($lastexitcode -eq 1)
				{
				   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
				   "Script Execution for enabling Native Auditing: Failed" >> $Log
				   "Native Auditing:1" >> $IQOQ_2
				   $Final_Status_Error = 1
				}
				else
				{
				   Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
				   "Native Auditing:0" >> $IQOQ_2
				   "Script Execution for enabling Native Auditing: Success" >> $Log
				}
			}
			elseif($Edition -eq "Standard Edition")
			{
				Write-Host "Script Execution for enabling Native Auditing"
				"Script Execution for enabling Native Auditing" >> $Log
				if($nonODBCVersions -notcontains $sqlversion)
				{
					$cmd_audit = $ToolsFolder + " -S $Inst_Name -i $ScriptsPath\SQLAudit_STD_Script.sql -x -o $S_NativeAuditLog && exit 0 || exit 1"
				}
				else 
				{
					$cmd_audit = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\SQLAudit_STD_Script.sql -x -o $S_NativeAuditLog && exit 0 || exit 1"
				}
				& cmd.exe /c $cmd_audit | out-null
				if($lastexitcode -eq 1)
				{
					Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Failed" -f red
					"Script Execution for enabling Native Auditing: Failed" >> $Log
					"Native Auditing:1" >> $IQOQ_2
					$Final_Status_Error = 1
				}
				else
				{
					Write-Host "Script Execution for enabling Native Auditing: " -f white -nonewline; Write-Host "Success" -f green
					"Native Auditing:0" >> $IQOQ_2
					"Script Execution for enabling Native Auditing: Success" >> $Log
				}
			}
		}
		else
		{
			Write-host "Native Auditing disabled on NON-PROD environment: " -f white -nonewline; Write-Host "Success" -f green
			"Native Auditing:D" >> $IQOQ_2
			"Native Auditing disabled on NON-PROD environment: Success" >> $Log
		}

		Write-Host "-------"
		"-------" >> $Log

		#--------------------------------- Change to Mixed mode authentication ---------------------------------#
		$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
		$registryPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${p}\MSSQLServer"
		$Name = "LoginMode"
		$value = "2"
		Set-ItemProperty -Path $registryPath -Name $name -Value $value
		
		#--------------------------------- Restart SQL Services ---------------------------------#
		Write-Host "-------"
		"-------" >> $Log
		$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
		$BackupDir=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${p}\MSSQLServer").BackupDirectory
		$SysBkpFolder = "$BackupDir\SystemBackup"
        Write-Host "here"
		if($iName -eq "MSSQLSERVER")
		{
			$SQLSvcAcct = 'MSSQLSERVER'
			$SQLAgtAcct = 'SQLSERVERAGENT'
			Stop-Service -Name $SQLAgtAcct -force
			Stop-Service -Name $SQLSvcAcct -force
		}
		else
		{
			$SQLSvcAcct = 'MSSQL$' + $iName
			$SQLAgtAcct = 'SQLAgent$' + $iName
            Stop-Service -Name $SQLSvcAcct -force
            Write-Host "Here "
			Stop-Service -Name $SQLAgtAcct -force
			
		}
		if($error[0])
		{
            $error[0]
            $error
			Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Failed" -f red
			"Stop SQL Server Services $SQLSvcAcct : Failed" >> $Log
			$Final_Status_Error = 1
			$error.clear()
		}
		else
		{
			Write-Host "Stop SQL Server Service $SQLSvcAcct : " -f white -nonewline; Write-Host "Success" -f green
			"Stop SQL Server Service $SQLSvcAcct : Success" >> $Log
			$ArchiveFolder = "$BackupDir\SystemBackup\ArchiveAfter_$Time"
			if(Test-Path $SysBkpFolder)
			{
				Remove-Item $SysBkpFolder\* -recurse
			}
			if(!(Test-Path $ArchiveFolder))
			{
				New-Item -Path $ArchiveFolder -ItemType Directory
				Start-Sleep -s 5
			}
			$sourcefiles_array = @("master.mdf", "model.mdf", "MSDBData.mdf", "mastlog.ldf", "modellog.ldf", "MSDBLog.ldf", "mssqlsystemresource.mdf", "mssqlsystemresource.ldf")
			if($sqlversion)
			{
				foreach($file in $sourcefiles_array)
				{
                    $file
					if($sqlversion -ne "SQL2005")
					{
						if($file -like "*mssqlsystemresource*")
						{
							Copy-Item "D:\MS$($sqlversion)\MSSQL$($majorversion).$iName\MSSQL\Binn\$file" $ArchiveFolder 
						}  
						else
						{
                            Copy-Item "E:\MS$($sqlversion)\MSSQL$($majorversion).$iName\MSSQL\DATA\$file" $ArchiveFolder
						}
					}
					else 
					{
						Copy-Item "E:\MS$($sqlversion)\MSSQL.1\MSSQL\DATA\$file" $ArchiveFolder
					}
					if($file -like "*.mdf")
					{
						Rename-Item $ArchiveFolder\$file $($file.replace(".mdf",".mmm"))
					}
					elseif($file -like "*.ldf")
					{
						Rename-Item $ArchiveFolder\$file $($file.replace(".ldf",".lll"))
					}
				
				}
			}
			if ($error[0])
			{
				Write-Host "Error : $error[0]"
				Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Failed" -f red
				"Cold backup of system databases to $ArchiveFolder : Failed" >> $Log
				"Cold Backup:1" >> $IQOQ_2
				$Final_Status_Error = 1
				#$error.clear()
			}
			else
			{
				Write-Host "Cold backup of system databases to $ArchiveFolder : " -f white -nonewline; Write-Host "Success" -f green
				"Cold backup of system databases to $ArchiveFolder : Success" >> $Log
				"Cold Backup:0" >> $IQOQ_2
			}
		}
        Write-Host "after cold backup"
		Write-Host "-------"
		"-------" >> $Log
		$error.clear()
		if($iName -eq "MSSQLSERVER")
		{
			$SQLSvcAcct = 'MSSQLSERVER'
		 	$SQLAgtAcct = 'SQLSERVERAGENT'
		 	$ASSVCAcct = 'MSSQLServerOLAPService'
		 	$RSSVCAcct = 'ReportServer'
		}
		else
		{
			$SQLSvcAcct = 'MSSQL$' + $iName
			$SQLAgtAcct = 'SQLAgent$' + $iName
			$ASSVCAcct = 'MSOLAP$' + $iName
			$RSSVCAcct = 'ReportServer$' + $iName
		}

		#------------ Set authentication mode to Mixed mode --------------------
		$Mode = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer").LoginMode
		$value = "2"
		$Name = "LoginMode"
		$registryPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\MSSQLServer"
		if($Mode -eq "1")
		{
			New-ItemProperty -Path $registryPath -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		}		
		#---------------------------------------------------------------------
		Start-Service -Name $SQLAgtAcct -ErrorAction Stop
		Start-Service -Name $SQLSvcAcct 
		Set-service $SQLAgtAcct -startup automatic
		Set-service SQLBrowser -startup automatic
		Set-service $ASSVCAcct -startup Manual
		Start-Service -Name SQLBrowser
		Stop-Service -Name $ASSVCAcct -force
		if(($nonODBCVersions -notcontains $sqlversion) -and ($sqlversion -ne "SQL2014") -and ($sqlversion -ne "SQL2016"))
		{			
			$RSSVCAcct = 'SQLServerReportingServices'		
			Set-service $RSSVCAcct -startup Manual			
			Stop-Service -Name $RSSVCAcct -force
		}
		else 
		{			
			Set-service $RSSVCAcct -startup Manual			
			Stop-Service -Name $RSSVCAcct -force
		}		
		if($error[0])
		{
            Write-Host "here in error"
            $error
            $error[0]
			Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Failed" -f red
			"Start SQL Server Services: Failed" >> $Log
			$Final_Status_Error = 1
			$error.clear()
		}
		else
		{
			Write-Host "Start SQL Server Services: " -f white -nonewline; Write-Host "Success" -f green
			"Start SQL Server Services: Success" >> $Log
		}

		Write-Host "-------"
		"-------" >> $Log

		#--------------------------------- Resize TempB -----------------------------------------#
		if($sqlversion -eq "SQL2005")
		{
    		$ResizeTempDB = $ToolsFolder + "\Binn\SQLCMD.exe -S $Inst_Name -i $ScriptsPath\SQL2005_TempDBResizing.sql -o C:\SQLInstall_Logs\BackupConfigLogs\SQL2005TempDBResizing.txt -x && exit 0 || exit 1"
 	   		& cmd.exe /c $ResizeTempDB | out-null
		}
		#--------------------------------- Start Native Audit job -----------------------------------------#
		if($NativeAudit -eq "Native Auditing:Enable")
		{
			if($Edition -eq "Standard Edition")
			{
				$cmd_nativeaudit = $ToolsFolder + "\Binn\sqlcmd -S $Inst_Name -i $ScriptsPath\StartNativeAuditJob.sql -x -o $S_StartAuditJob && exit 0 || exit 1"
				& cmd.exe /c $cmd_nativeaudit | out-null
			}
		}
		#--------------------------------- Deactivate CEIP -----------------------------------------#
		Get-Service | Where-Object { $_.Name -like '*telemetry*' -or $_.DisplayName -like '*CEIP*' } | ForEach-Object { 
			$servicename = $_.Name; 
			$displayname = $_.DisplayName; 
			Set-Service -Name $servicename  -StartupType Disabled 
			$serviceinfo = Get-Service -Name $servicename 
			$startup = $serviceinfo.StartType
			Write-Host "$servicename : $startup : $displayname"
		}
		$Key = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server'
		$FoundKeys = Get-ChildItem $Key -Recurse | Where-Object -Property Property -eq 'EnableErrorReporting'
		foreach ($Sqlfoundkey in $FoundKeys)
		{
			$SqlFoundkey | Set-ItemProperty -Name EnableErrorReporting -Value 0
			$SqlFoundkey | Set-ItemProperty -Name CustomerFeedback -Value 0
		}
		##################################################
		# Set HKEY_LOCAL_MACHINE\Software\Wow6432Node\Microsoft\Microsoft SQL Server\***\CustomerFeedback=0
		# Set HKEY_LOCAL_MACHINE\Software\Wow6432Node\Microsoft\Microsoft SQL Server\***\EnableErrorReporting=0
		# *** --> Version of SQL Server(100,110,120,130,140,...)
		##################################################
		$WowKey = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Microsoft SQL Server"
		$FoundWowKeys = Get-ChildItem $WowKey | Where-Object -Property Property -eq 'EnableErrorReporting'
		foreach($SqlFoundWowKey in $FoundWowKeys)
		{
			$SqlFoundWowKey | Set-ItemProperty -Name EnableErrorReporting -Value 0
			$SqlFoundWowKey | Set-ItemProperty -Name CustomerFeedback -Value 0
		}
		C:
		Write-Host "###################################################################################################"
		"###################################################################################################" >> $Log
		if($Final_Status_Error -eq 1)
		{
			Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "FAILED" -f red
			"FINAL STATUS = FAILED" >> $Log
			Write-Host "Please review the verification steps and address the failed step"
			"Please review the verification steps and address the failed step" >> $Log
			"FAILED" > $BatchOutput3
			Write-Host "###################################################################################################"
			"###################################################################################################" >> $Log
			Exit 1
		}
		else
		{
			Write-Host "FINAL STATUS = " -f white -nonewline; Write-Host "SUCCESS" -f green
			"FINAL STATUS = SUCCESS" >> $Log
			"SUCCESS" > $BatchOutput3
			Write-Host "###################################################################################################"
			"###################################################################################################" >> $Log
			Exit 0
		}
	#}
	#catch
	#{
	#	Write-Host "***********Error Occurred during the execution of the function sddc_sql_Post_Installation : $_**************"
	#}
}

#try
#{
	#$global:SQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'	
	$global:SQLDML = 'D:\SQLsetup'
	$global:Proc = $args[0]
	$global:sqlv = $args[1]
	$global:InstName = $args[2]
	$global:majorversion = $args[3]
	#$global:Proc = "AZR"
	#$global:sqlv = "SQL2022"
	#$global:InstName = "MSSQLSERVER"
	#$global:majorversion = "16"
	#$global:InstName = "MSSQLSERVER"
	$BatchOutput3 = "C:\IQOQ\Status.txt"

	$path = "D:\MS${sqlv}\MSSQL${majorversion}.MSSQLSERVER\MSSQL\Log\"
	if(!(Test-Path -path $path))
	{
		New-Item -path $path -ItemType Directory
	}

	#------------------------ Check if valid instance name is being passed --------------------------------------
	$instances = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
	if($instances -notcontains $InstName)
	{
		Write-Host "`nInstance $InstName not found.`n" -f red		#Delete this line later for named instance installs.
		Exit 0
	}

	#------------------- Check if instance name really belongs to the SQLVersion passed as parameter ---------------------------
	$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$InstName
	$ver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${p}\Setup").Version
	$build = $ver.SubString(0,2)
	if($build -ne $majorversion)
	{
		Write-Host "`nInstance $InstName doesn't belong to $sqlv. Check again and pass correct parameters." -f red
		EXIT 0
	}
	Post_Installation $SQLDML $Proc $sqlv $InstName $majorversion
#}
##catch
##{
##	Write-Host "Error Occurred in the post installation : $_"
#}


