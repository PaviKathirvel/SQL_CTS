
$PrimaryReplica1 = $args[0]
$SecondaryReplica1 = $args[1]
$AGGroupName = $args[2]

IF (!($PrimaryReplica1) -or !($SecondaryReplica1) -or !($AGGroupName))
{
  Write-Host ""
  Write-Host "Enter Primary node name as 1st parameter, Secondary node name as 2nd parameter and Availability group name as 3rd parameter" -f red
  Write-Host ""
  EXIT 0
}

If (Test-Path C:\ReDeployJobs) { Remove-Item C:\ReDeployJobs\* -recurse } else { mkdir "C:\ReDeployJobs" }


        $Domain = (gwmi WIN32_ComputerSystem).Domain

	$PrimaryRoutingUrl = "N'" + "TCP://" + ($PrimaryReplica1) + "." + $Domain + ":1433'"
	$SecondaryRoutingUrl = "N'" + "TCP://" + ($SecondaryReplica1) + "." + $Domain + ":1433'"


	$RO_Query1 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL));
	GO"

	$RO_Query2 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL));
	GO"

	$sqlquery4 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (SECONDARY_ROLE (READ_ONLY_ROUTING_URL = $PrimaryRoutingUrl));
	GO"

	$sqlquery5 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (SECONDARY_ROLE (READ_ONLY_ROUTING_URL = $SecondaryRoutingUrl));
	GO"

	$sqlquery6 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=('$SecondaryReplica1')));
	GO"

	$sqlquery7 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=('$PrimaryReplica1')));
	GO"


	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $RO_Query1 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\RO_Query1_Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $RO_Query2 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\RO_Query2_Log.txt

	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery4 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ4Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery5 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ5Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery6 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ6Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery7 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\ReDeployJobs\SQLQ7Log.txt
