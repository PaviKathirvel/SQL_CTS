#----------------------------------------------------------------------------------------
# File             :  AlwaysON_Remediation.ps1
# Description      :  This script will insert a couple of extra steps to the existing FULL, DIFF and LOG jobs to check if the node is Primary or Secondary.
# LastModified     :  10-Mar-2017
# Authors          :  Jay Sangam
#----------------------------------------------------------------------------------------


$PrimaryReplica1 = $args[0]
$SecondaryReplica1 = $args[1]
$AGGroupName = $args[2]

IF (!($PrimaryReplica1) -or !($SecondaryReplica1) -or !($AGGroupName))
{
  Write-Host ""
  Write-Host "Enter Primary node name as 1st parameter, Secondary node name as 2nd parameter and Availability group name as 3rd parameter" -f red
  Write-Host ""
  EXIT 0
}

########################### Modify maintenance jobs on both nodes ###########################

If (Test-Path C:\ReDeployJobs) { Remove-Item C:\ReDeployJobs\* -recurse } else { mkdir "C:\ReDeployJobs" }
Invoke-Command -ComputerName $SecondaryReplica1 -ScriptBlock { If (Test-Path C:\ReDeployJobs) { Remove-Item C:\ReDeployJobs\* -recurse } else { mkdir C:\ReDeployJobs } }

$Time = get-date -Uformat "%Y%m%d%H%M"
$LogPath = "C:\ReDeployJobs\DBIntegrityJobsDeployment_$Time.txt"

Write-Host ""
Write-Host "=========== PRIMARY REPLICA : $PrimaryReplica1 ==========="
Write-Host ""

"" > $LogPath
"=========== PRIMARY REPLICA : $PrimaryReplica1 ===========" >> $LogPath
""  >> $LogPath

$iName = "MSSQLSERVER"

Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\Update_LOG_job_And_DataIntegrity_job.sql" "C:\ReDeployJobs" -force
Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" "C:\ReDeployJobs" -force
Copy-Item "\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML\ConfigFiles\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" "C:\ReDeployJobs" -force

Copy-Item "C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force
Copy-Item "C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force
Copy-Item "C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" "\\$SecondaryReplica1\C$\ReDeployJobs" -force

$p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$iName
$sqlver = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version
$sqlbuild = $sqlver.substring(0,2)

  $fso = New-Object -ComObject Scripting.FileSystemObject

  IF ($sqlbuild -eq "12")
  {
   $ToolsFolder = '"D:\MSSQL2014\Client SDK\ODBC\110\Tools\Binn\SQLCMD.EXE"'
  }
  
  ELSEIF ($sqlbuild -eq "11")
  {
   $TF=$fso.GetFolder((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\Setup").SQLPath).ShortPath
   $ToolsFolder=$TF + "\Binn\sqlcmd"
  }

################# Updating of existing jobs on PRIMARY replica ##################

 $Final_Status_Error = 0

 $cmd_1 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql -o C:\ReDeployJobs\QueryOutput3.txt -x && exit 0 || exit 1"
 $cmd_2 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql -o C:\ReDeployJobs\QueryOutput4.txt -x && exit 0 || exit 1"
 $cmd_3 = $ToolsFolder + " -S $PrimaryReplica1 -i C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql -o C:\ReDeployJobs\QueryOutput5.txt -x && exit 0 || exit 1"

& cmd.exe /c $cmd_1 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Failed" -f red
	"Update DB Integrity and optimization maintenance plan : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Success" -f green
	"Update DB Integrity and optimization maintenance plan : Success" >> $LogPath
}


& cmd.exe /c $cmd_2 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy FULL backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy FULL backup job : Success" >> $LogPath
}


& cmd.exe /c $cmd_3 | out-null

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy DIFF backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy DIFF backup job : Success" >> $LogPath
}


################# Updating existing jobs on SECONDARY replica ##################

Write-Host ""
Write-Host "=========== SECONDARY REPLICA : $SecondaryReplica1 ==========="
Write-Host ""

"" > $LogPath
"=========== SECONDARY REPLICA : $SecondaryReplica1 ===========" >> $LogPath
""  >> $LogPath


Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\Update_LOG_job_And_DataIntegrity_job.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\DBIntegrityJobUpdateOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Failed" -f red
	"Update DB Integrity and optimization maintenance plan : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Update DB Integrity and optimization maintenance plan : " -f white -nonewline; Write-Host "Success" -f green
	"Update DB Integrity and optimization maintenance plan : Success" >> $LogPath
}	     

Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\ReDeploy_FULL_BackupJob_ForAlwaysON.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\UpdateFULLBkpOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy FULL backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy FULL backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy FULL backup job : Success" >> $LogPath
}

Invoke-Sqlcmd -InputFile "C:\ReDeployJobs\ReDeploy_DIFF_BackupJob_ForAlwaysON.sql" -ServerInstance "$SecondaryReplica1" -DisableVariables | Out-File -filePath "C:\ReDeployJobs\UpdateDIFFBkpOnSecondary.txt"

IF ($lastexitcode -eq 1)
{
	Write-Host "Re-deploy DIFF backup job: " -f white -nonewline; Write-Host "Failed" -f red
	"Re-deploy DIFF backup job : Failed" >> $LogPath
	$Final_Status_Error = 1
}
ELSE
{
	Write-Host "Re-deploy DIFF backup job : " -f white -nonewline; Write-Host "Success" -f green
	"Re-deploy DIFF backup job : Success" >> $LogPath
}


If ($Final_Status_Error -eq 1)
{
 Write-Host ""
 Write-Host "Modifying of FULL, DIFF and DB Integrity and optimization jobs on primary and secondary replicas : " -f white -nonewline; Write-Host "Failed" -f red
 Write-Host ""
}
ELSE
{
  Write-Host ""
  Write-Host "Modifying of FULL, DIFF and DB Integrity and optimization jobs on primary and secondary replicas : " -f white -nonewline; Write-Host "Success" -f green
  Write-Host ""
}


