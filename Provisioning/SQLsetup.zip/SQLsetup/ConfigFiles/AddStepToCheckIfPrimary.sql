

USE [msdb]
GO


/* --------------------- Add step 'Check if Primary' to FULL backup job --------------------- */

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'ITSSQL_DirectTape_FULL' and b.step_name = 'Check if Primary' )
BEGIN

EXEC msdb.dbo.sp_add_jobstep @job_name = 'ITSSQL_DirectTape_FULL', @step_name=N'Check if Primary', 
 		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
       @command=N'IF EXISTS(SELECT primary_replica FROM sys.dm_hadr_availability_group_states WHERE primary_replica = @@servername)
PRINT ''About to execute FULL backup job on primary node '' + @@servername + '' at : ''  + CONVERT(CHAR(20),  GETDATE(), 120)
ELSE
RAISERROR(''This is secondary node. Cannot execute backups on Secondary node'',16,1)', 
        @database_name=N'master', 
        @flags=0

END


/* --------------------- Add step 'Check if Primary' to DIFF backup job --------------------- */

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'ITSSQL_DirectTape_DIFF' and b.step_name = 'Check if Primary' )
BEGIN

EXEC msdb.dbo.sp_add_jobstep @job_name = 'ITSSQL_DirectTape_DIFF', @step_name=N'Check if Primary', 
 		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
       @command=N'IF EXISTS(SELECT primary_replica FROM sys.dm_hadr_availability_group_states WHERE primary_replica = @@servername)
PRINT ''About to execute DIFF backup job on primary node '' + @@servername + '' at : ''  + CONVERT(CHAR(20),  GETDATE(), 120)
ELSE
RAISERROR(''This is secondary node. Cannot execute backups on Secondary node'',16,1)', 
        @database_name=N'master', 
        @flags=0

END

/* --------------------- Add step 'Check if Primary' to LOG backup job --------------------- */

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'ITSSQL_DirectTape_LOG' and b.step_name = 'Check if Primary' )
BEGIN

EXEC msdb.dbo.sp_add_jobstep @job_name = 'ITSSQL_DirectTape_LOG', @step_name=N'Check if Primary', 
 		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
       @command=N'IF EXISTS(SELECT primary_replica FROM sys.dm_hadr_availability_group_states WHERE primary_replica = @@servername)
PRINT ''About to execute LOG backup job on primary node '' + @@servername + '' at : ''  + CONVERT(CHAR(20),  GETDATE(), 120)
ELSE
RAISERROR(''This is secondary node. Cannot execute backups on Secondary node'',16,1)', 
        @database_name=N'master', 
        @flags=0

END

/* --------------------- Disable job 'DataIntegrityAndOptimizationMaintenance.Subplan_1' if it exists --------------------- */

DECLARE @jobId binary(16)
SELECT @jobId = job_id FROM msdb.dbo.sysjobs WHERE (name = N'DataIntegrityAndOptimizationMaintenance.Subplan_1')
IF (@jobId IS NOT NULL)
BEGIN
	EXEC dbo.sp_update_job
    	@job_name = N'DataIntegrityAndOptimizationMaintenance.Subplan_1',
   	@enabled = 0
END
