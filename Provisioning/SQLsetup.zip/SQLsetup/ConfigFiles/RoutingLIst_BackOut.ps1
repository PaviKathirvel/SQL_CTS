

$PrimaryReplica1 = $args[0]
$SecondaryReplica1 = $args[1]
$AGGroupName = $args[2]

IF (!($PrimaryReplica1) -or !($SecondaryReplica1) -or !($AGGroupName))
{
  Write-Host ""
  Write-Host "Enter Primary node name as 1st parameter, Secondary node name as 2nd parameter and Availability group name as 3rd parameter" -f red
  Write-Host ""
  EXIT 0
}

If (Test-Path C:\RoutingList) { Remove-Item C:\RoutingList\* -recurse } else { mkdir "C:\RoutingList" }

	$sqlquery6 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$PrimaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=NONE));
	GO"

	$sqlquery7 = "ALTER AVAILABILITY GROUP [$AGGroupName] MODIFY REPLICA ON N'$SecondaryReplica1' WITH (PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=NONE));
	GO"

	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery6 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\RoutingList\SQLQ6Log.txt
	Invoke-Sqlcmd -ServerInstance $PrimaryReplica1 -Query $sqlquery7 -QueryTimeout 200 -ea 'Stop' -verbose  > C:\RoutingList\SQLQ7Log.txt

