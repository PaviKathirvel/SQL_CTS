/**********************************************************************************************
Script Name: IQ/OQ Execution
Description: IQ/OQ Execution for SDDC
Date: 06/02/2014
Version: 1.0
Author: 
Reason for Change: New Script
**********************************************************************************************/
Print '/**********************************************************************************************'
Print 'Script Name: IQ/OQ Execution'
Print 'Description: IQ/OQ Execution for SDDC'
Print 'Date: 06/02/2014'
Print 'Version: 1.0'
Print 'Author: '
Print 'Reason for Change: New Script'
Print '**********************************************************************************************/'

SET NOCOUNT ON
Print '========================== SQL Server Software Installation Verification Result ==============  '
declare @svrName varchar(255)
if serverproperty('IsClustered') =1
	set @svrName = cast(serverproperty('computernamephysicalnetbios') as varchar)
else	
    set @svrName = cast(serverproperty('machinename') as varchar)
    
print 'Windows Server Name : ' + @svrName   
print 'SQL Instance Name : ' + @@SERVERNAME
print 'User Name :' + suser_name()
print 'Date :' + cast(getdate() as varchar)



Print ' ========================= Test 1 - Step 1 SQL Server Version Details ========================= '
SELECT @@VERSION
Go


Print ' ========================= Test 1 - Step 2 SYSTEM DB location details ========================= '
select distinct db_name(dbid) as systemDBName,substring(filename,1,3) as drivename from master..sysaltfiles where dbid <= 4
Go

Print ' ========================= Test 1 - Step 3 SQL Server Services & their status ========================= '
set nocount on
CREATE TABLE #ServicesStatus
( 
myid int identity(1,1),
serverName nvarchar(100) default @@serverName,
serviceName varchar(100),
Status varchar(50),
checkdatetime datetime default (getdate())
)
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'MSSQLServer'
update #ServicesStatus set serviceName = 'MSSQLServer' where myid = @@identity
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'SQLServerAGENT'
update #ServicesStatus set serviceName = 'SQLServerAGENT' where myid = @@identity
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'sqlbrowser'
update #ServicesStatus set serviceName = 'sqlbrowser' where myid = @@identity
select serverName,ServiceName,status,cast(checkdatetime as varchar) as CheckDateTime from #ServicesStatus 
select char(13)
select char(13)
drop table #ServicesStatus
Go


Print ' ========================= Test 2 - Step 1 Configuration details ========================= '
select name,value from sys.configurations where name in ('backup compression default','remote access')
Go

Print ' ========================= Test 2 - Step 2 Job details ========================= '
Select name,cast(date_created as varchar) as created from msdb..sysjobs where name like '%backup%' or name like '%Optimization%'
Go


Print ' ========================= Test 2 - Step 3 Password complexity check  ========================= '
-- For SQL Server 2005/2008
-- This query MUST not return any rows
USE [master]
GO
SELECT name,
case is_policy_checked 
when '0' then 'Password Policy Not Checked'
when '1' then 'Password Policy Checked'
end  as 'is_policy_checked'
FROM sys.sql_logins where name not like '%#%'


Print ' ========================= Test 2 - Step 4  Login Auditing ========================= '
-- Get Audit Level set for sql 2000,2005 & 2008

declare @SQLServerAuditLevel int
exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE'
                                    ,N'Software\Microsoft\MSSQLServer\MSSQLServer'
                                    ,N'AuditLevel', 
                            @SQLServerAuditLevel OUTPUT
select (CASE 
        WHEN @SQLServerAuditLevel = 0 THEN 'None.'
        WHEN @SQLServerAuditLevel = 1 THEN 'Successful Logins Only'
        WHEN @SQLServerAuditLevel = 2 THEN 'Failed Logins Only'
        WHEN @SQLServerAuditLevel = 3 THEN 'Both Failed and Successful Logins Only'
        ELSE 'N/A' END) AS [AuditLevel]
Go

Go




