

USE [msdb]
GO

/* --------------------- Add step 'Check if Primary' to LOG backup job --------------------- */

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'ITSSQL_DirectTape_LOG' and b.step_name = 'Check if Primary' )
BEGIN

EXEC msdb.dbo.sp_add_jobstep @job_name = 'ITSSQL_DirectTape_LOG', @step_name=N'Check if Primary', 
 		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
       @command=N'IF EXISTS(SELECT primary_replica FROM sys.dm_hadr_availability_group_states WHERE primary_replica = @@servername)
PRINT ''About to execute LOG backup job on primary node '' + @@servername + '' at : ''  + CONVERT(CHAR(20),  GETDATE(), 120)
ELSE
RAISERROR(''This is secondary node. Cannot execute backups on Secondary node'',16,1)', 
        @database_name=N'master', 
        @flags=0

END



/****************** Add 'Check if primary' step to 'DataIntegrityAndOptimizationMaintenance.Subplan_1' job*******************/

BEGIN TRANSACTION
DECLARE @ReturnCode INT
DECLARE @jobId BINARY(16)

SELECT @ReturnCode = 0

SELECT @jobId = job_id FROM msdb.dbo.sysjobs WHERE (name = N'DataIntegrityAndOptimizationMaintenance.Subplan_1')
IF (@jobId IS NOT NULL)

BEGIN

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'DataIntegrityAndOptimizationMaintenance.Subplan_1' and b.step_name = 'Check if Primary' )
BEGIN

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check if Primary', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=3, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF EXISTS(SELECT primary_replica FROM sys.dm_hadr_availability_group_states WHERE primary_replica = @@servername)
PRINT ''Executing DB integrity and Rebuild index of all DBs on primary '' + @@servername + '' at : ''  + CONVERT(CHAR(20),  GETDATE(), 120)
ELSE
RAISERROR(''This is secondary node. Cannot execute Rebuild index of all DBs on Secondary node'',16,1)
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

IF NOT EXISTS(SELECT b.step_name FROM [msdb].[dbo].[sysjobs] a WITH(NOLOCK) 
            INNER JOIN [msdb].[dbo].[sysjobsteps] b WITH(NOLOCK) ON a.job_id = b.job_id 
            WHERE a.Name = 'DataIntegrityAndOptimizationMaintenance.Subplan_1' and b.step_name = 'DBIntegrity' )
BEGIN

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBIntegrity', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
DECLARE @databaseList as CURSOR;
DECLARE @databaseName as NVARCHAR(500);
DECLARE @tsql AS NVARCHAR(500);
 
SET @databaseList = CURSOR  LOCAL FORWARD_ONLY STATIC READ_ONLY 
FOR
        SELECT QUOTENAME([name])
       FROM sys.databases
       WHERE [state] = 0
       AND [is_read_only] = 0;
OPEN @databaseList;
FETCH NEXT FROM @databaseList into @databaseName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @tsql = N''DBCC CheckDB('' + @databaseName + '') WITH NO_INFOMSGS;'';
    EXECUTE (@tsql);
    FETCH NEXT FROM @databaseList into @databaseName;
END
CLOSE @databaseList;
DEALLOCATE @databaseList
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END



EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DataIntegrityAndOptimizationMaintenance', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140514, 
		@active_end_date=99991231, 
		@active_start_time=120000, 
		@active_end_time=235959, 
		@schedule_uid=N'8e230b2c-f3f0-49bb-b17d-dac479f08b19'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO