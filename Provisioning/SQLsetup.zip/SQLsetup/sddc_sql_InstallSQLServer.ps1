$global:ScriptName = "SQL_InstallSQLServer.ps1"
$global:Scriptver = "1.0"
###################################################################################################
<#Description 
    The script deals with RTM and applies the mentioned patch. It also installs SSRS, SSMS and SQLServer PS module.
#>
###################################################################################################
#Version		Date		Author		Reason for Change
###################################################################################################
#1.0			11/08/2024	Pavithra K	New Script
###################################################################################################
function InstallSQLInstance
{
        param(
            $setp
        )
        try
        {
            if($version)
            {
                Write-Host "Installing $version instance $InstName..."
                & $setp $Config $Action $ConfigFile $InstParam $InstParamID $Collation $DataDir $BkpDir $UserDBDir $UserDBLogDir $TempDBDir $ASConfigDir $ASDataDir $ASLogDir $ASBackupDir $ASTempDir $SqlSvcAcct $AgtSvcAcct $Updates $PatchSource
            }
        }
        catch
        {
            Write-Host "Error occurred while setting up the RTM : $_"
            Exit 1
        }

}

function ApplyPatch
{
    param(
        $setupfilepath
    )
	try
	{
		$SPpath = "$setupfilepath\setup.exe"
		$SPpath
		& $SPpath /quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=mssqlserver | Out-Null 
		#$patchApplicationArgs = "/quiet /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceID=mssqlserver"
		#Start-Process -FilePath "$setupfilepath\setup.exe" -ArgumentList $patchApplicationArgs -Wait
		#$apply_patch = "'$setupfilepath\setup.exe' /allinstances /quiet /IAcceptSQLServerLicenseTerms"
		#Invoke-Expression -command $apply_patch | out-null;
		#Start-Sleep -s 600
	}
	catch
	{
		Write-Host "Error occurred in the patch application : $_"
        Exit 1
	}

}
function VerifySQLInstall
{
        $ssisfolder =  "$majorversion"+"0"
		$LatestFolder = Get-ChildItem "C:\Program Files\Microsoft SQL Server\${ssisfolder}\Setup Bootstrap\Log" | Where-Object { $_.PSIsContainer } | Sort-Object CreationTime -desc | Select-Object -f 1
		$Path = 'C:\Program Files\Microsoft SQL Server\' + $($ssisfolder) + '\Setup Bootstrap\Log\' + $LatestFolder
		$file_txt = 'C:\Program Files\Microsoft SQL Server\' + $($ssisfolder) + '\Setup Bootstrap\Log\Summary.txt'	
        $SummaryFile = Get-ChildItem $Path -Filter "Summary*.txt"
        Write-Host "Inside SQL_Installation_Verification file creation 1" 
        $ResultFile = $Path + "\" + $SummaryFile
	    $exitmsg = (Get-Content $ResultFile)[2].Trim()
        if($exitmsg -eq "Exit code (Decimal):           -2067919934")
	    {
    	    Write-Host "`nA Computer restart is required. Installation of $version instance $($InstName) : " -f white -nonewline; Write-Host "FAILED" -f red
    	    "" >> $Log
    	    "A Computer restart is required. Installation of $version instance $InstName : FAILED" >> $Log
	        "FAILED" > $BatchOutput
	        EXIT 0
	    }

        $Time = get-date -Uformat "%Y%m%d%H%M"
        $s1 = (Get-Content $file_txt)[1]
        $s2 = (Get-Content $file_txt)[3]
        $s3 = (Get-Content $file_txt)[4]
        $s4 = (Get-Content $file_txt)[2].Trim()
        $exitPass  = "Exit code (Decimal):           0"
        $exitPassReboot  = "Exit code (Decimal):           3010"

        Write-Host "Inside SQL_Installation_Verification file creation 2" 
        $Log = "C:\SQLInstall_Logs\sddc_sql_Installation_Verification_$Time.txt"

        Write-host ""
        Write-Host "#######################################################################"
        "#######################################################################" >> $Log
	    write-host "SQL_Installation_Verification log file created" 
        $Hostname = Hostname
        $Exec_Time = Get-Date
        Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname"
        "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $Hostname" >> $Log
        "Execution string: $ScriptName $Process $version $spversion $Edition $InstName" >> $Log
        Write-Host "#######################################################################"
        "#######################################################################" >> $Log
        if($s4 -eq $exitPass)  
        {
        	Write-Host "`nInstallation of $version instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL" -f green
        	"" >> $Log
        	"Installation of $version instance $InstName : SUCCESSFUL" >> $Log
	        "SUCCESS" > $BatchOutput
        }
        elseif($s4 -eq $exitPassReboot)
        {
        	Write-Host ""
        	Write-Host "Installation of $version instance $InstName : " -f white -nonewline; Write-Host "SUCCESSFUL, but reboot the server before proceeding to next step" -f red
        	Write-Host ""
        	"" >> $Log
        	"SUCCESSFUL, but reboot the server before proceeding to next step" >> $Log
	        "REBOOT" > $BatchOutput
        }
        else
        {
        	Write-Host ""
        	Write-Host "Installation of $version instance $InstName : " -f white -nonewline; Write-Host "FAILED" -f red
        	Write-Host ""
        	"" >> $Log
        	"Installation of $version instance $InstName : FAILED" >> $Log
	        "FAILED" > $BatchOutput
        }

            Write-Host ""
            Write-Host "------------------------ Installation Summary -------------------------"  
            Write-Host ""
            Write-Host "$s1"
            Write-Host "$s2"
            Write-Host "$s3"
            Write-Host ""

            "" >> $Log
            "------------------------ Installation Summary -------------------------"  >> $log
            "" >> $Log
            "$s1" >> $log
            "$s2" >> $log
            "$s3" >> $log

            $installed_instances = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
            foreach($inst in $installed_instances)
            {
                $instance = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$inst
		        $Cluster = (Test-Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Cluster")
		        if($Cluster)
                {
                    $ClusterName = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Cluster").ClusterName
                } 
                else
                {
                    $ClusterName = "Null"
                }
		        $CurrentVersion = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\MSSQLServer\CurrentVersion").CurrentVersion
		        $SP = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").SP
		        $Language = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\MSSQLServer\CurrentVersion").Language
		        $Edition = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").Edition
		        $PatchLevel = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").PatchLevel
		        $Collation = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").Collation
		        $SQLPath = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").SQLPath
		        $SQLDataDir = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\Setup").SQLDataRoot
		        $TCPPort = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TCPPort
		        $BackupDir = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\MSSQLServer").BackupDirectory
		        $NumErrorLogs = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\${instance}\MSSQLServer").NumErrorLogs
		
                "  ClusterName    : $ClusterName" >> $Log
	            "  Instance Name  : $inst" >> $Log
	            "  CurrentVersion : $CurrentVersion" >> $Log
	            "  SP             : $SP" >> $Log
	            "  Language       : $Language" >> $Log
	            "  Edition        : $Edition" >> $Log
	            "  PatchLevel     :	$PatchLevel" >> $Log
	            "  Collation      :	$Collation" >> $Log
	            "  SQLPath        :	$SQLPath" >> $Log
	            "  DataDirectory  : $SQLDataDir" >> $Log
	            "  BackupDirectory: $BackupDir" >> $Log
                "  TCPPort        : $TCPPort" >> $Log
                "  NumErrorLogs   : $NumErrorLogs" >> $Log
	            "" >> $Log
	            "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\${ssisfolder}\Setup Bootstrap\Log. " >> $Log
	            "" >> $Log
	            "-----------------------------------------------------------------------" >> $Log
	            
                Write-Host "  ClusterName    :  $ClusterName"
                Write-Host "  Instance Name  :  $inst" 
	            Write-Host "  CurrentVersion : 	$CurrentVersion" 
	            Write-Host "  SP             : 	$SP" 
	            Write-Host "  Language       : 	$Language" 
	            Write-Host "  Edition        : 	$Edition" 
	            Write-Host "  PatchLevel     :	$PatchLevel" 
	            Write-Host "  Collation      :	$Collation" 
	            Write-Host "  SQLPath        :	$SQLPath" 
	            Write-Host "  DataDirectory  : 	$SQLDataDir" 
	            Write-Host "  BackupDirectory:	$BackupDir"
                Write-Host "  TCPPort        :  $TCPPort" 
                Write-Host "  NumErrorLogs   :  $NumErrorLogs" 
	            Write-Host ""
	            Write-Host "Detailed log files are available inside -- C:\Program Files\Microsoft SQL Server\${ssisfolder}\Setup Bootstrap\Log. "
	            Write-Host ""
	            Write-Host "#######################################################################"
            }
}
function Install_SSRS_SSMS
{
    param
    (
        $setupfilepath
    )
    try
    {
        Write-host "Installing SSRS" -f green
        $SPpath = "$setupfilepath\sqlserverreportingservices.exe"
        & $SPpath /quiet /norestart /InstallFolder="D:\SSRS" /IAcceptLicenseTerms | Out-Null 
        Write-host "SSRS Installation complete " -f green
    }
    catch
    {
        Write-Host "Error occurred while installation SSRS.. : $_" -f Red
        "Error occurred while installation SSRS.. : $_" >> $Log
        Exit 1
    }
    try 
    {
        Write-host "Installing SSMS" -f green
        $SPpath = "$setupfilepath\ssms-setup-enu.exe"
        & $SPpath /install /quiet /norestart  | Out-Null
    }
    catch 
    {
        Write-Host "Error occurred while installation SSMS.. : $_" -f Red
        "Error occurred while installation SSMS.. : $_" >> $Log
        Exit 1
    }

}
function Install_PS_Module
{
    param($setupfilepath)
	$local_location = "D:\SQLsetup"
    Write-host "Installing Powershell Module" -f green
    #Expand-Archive "C:\SQLInstall\SQL2019_SSMS\sqlserver_PS_module.zip" "C:\temp"

    if(Test-Path "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080\") 
    { 
        Remove-Item "C:\Program Files\WindowsPowerShell\Modules\sqlserver" -Force -recurse 
	} 
    else 
    { 
        New-Item -path "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080\" -ItemType Directory
    }

	Xcopy /S /I /E /H "$local_location\PS\sqlserver_PS_module\21.1.18080" "C:\Program Files\WindowsPowerShell\Modules\sqlserver\21.1.18080"
	Import-Module SqlServer -Version 21.1.18080 
	Write-host "Installation of Powershell Module for $version Completed" -f green
}

try
{
    $Process = $args[0]
    $global:version = $args[1]
    $Edition = $args[2]
    $spversion = $args[3]
    $CollationSet = $args[4]
    $InstName = $args[5]
    $majorversion = $args[6]
    $setupfilepath = $args[7]
    $setupfile = "$setupfilepath\Binaries\setup.exe" 
    #$Process = "AZR"
    #$version = "SQL2022"
    #$Edition = "E"
    #$spversion = "16.0.4120.exe"
    #$CollationSet = "SQL_Latin1_General_CP1_CI_AS"
    #$InstName = "MSSQLSERVER"
    #$majorversion = "16"
    #$setupfilepath = "D:\SQLInstall\Download"
    #$setupfile = "$setupfilepath\Binaries\setup.exe" 
    $InstName = "MSSQLSERVER"	
    
    $BatchOutput = "C:\IQOQ\Status.txt"
    $SQLDML = '\\na.jnj.com\ncsusdfsroot\NCSUSGRPDATA\sqlsrvr\MSSQLDML'
    $SQLDML = "D:\SQLsetup"
    if(($version) -and $Process -ieq "SDDC")
    {
        $global:updates ='/UpdateEnabled=TRUE'
        $global:Action ='/Action=Install'
        $global:InstParam = '/INSTANCENAME=' + $InstName
        $global:InstParamID = '/INSTANCEID=' + $InstName
        $global:DataDir = '/INSTALLSQLDATADIR=E:\MS' + ${version}
        $global:ASConfigDir = '/ASCONFIGDIR=D:\MS' + ${version} + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Config'
        $global:Collation = '/SQLCOLLATION=' + $CollationSet
        $global:cnfgfl = '\ConfigFiles\' + $($version) + '_ConfigurationFile.ini"'
        $global:BkpDir = '/SQLBACKUPDIR=F:\MS' + $($version) +'\MSSQL' + $($majorversion) + '.' + $InstName + '\MSSQL\Backup'
        $global:UserDBDir = '/SQLUSERDBDIR=F:\MS' + $($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\Data'
        $global:UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MS'  +$($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\Log'
        $global:TempDBDir = '/SQLTEMPDBDIR=H:\MS' + $($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\Tempdb'
        $global:ASDataDir = '/ASDATADIR=F:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Data'
        $global:ASLogDir = '/ASLOGDIR=G:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Log'
        $global:ASBackupDir = '/ASBACKUPDIR=F:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Backup'
        $global:ASTempDir = '/ASTEMPDIR=H:\MS' + $($version) + '\MSAS' + $($majorversion)+ '.' + $InstName + '\OLAP\Temp'
        $global:Setup = '/C:\SQLInstall\Download\Binaries\setup.exe'
        $global:Config = "/configurationfile=""" + $SQLDML + $cnfgfl
        if($InstName -eq 'MSSQLSERVER')
        {
            $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
            $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
        }
        else
        {
            $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
            $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
        }
    }
        
    elseif(($version) -and ($Process -ieq "AWS" -or $Process -ieq "AZR"))
    {
        $global:updates ='/UpdateEnabled=TRUE'
        $global:Action ='/Action=Install'
        $global:InstParam = '/INSTANCENAME=' + $InstName
        $global:InstParamID = '/INSTANCEID=' + $InstName
        $global:DataDir = '/INSTALLSQLDATADIR=E:\MS' + ${version}
        $global:ASConfigDir = '/ASCONFIGDIR=D:\MS' + ${version} + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Config'
        $global:Collation = '/SQLCOLLATION=' + $CollationSet
        $global:cnfgfl = '\ConfigFiles\' + $($version) + '_ConfigurationFile.ini"'
        $global:BkpDir = '/SQLBACKUPDIR=I:\SQLBackup'
        $global:UserDBDir = '/SQLUSERDBDIR=F:\MS' + $($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\MSSQL\Data'
        $global:UserDBLogDir = '/SQLUSERDBLOGDIR=G:\MS'  +$($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\MSSQL\Log'
        $global:TempDBDir = '/SQLTEMPDBDIR=H:\MS' + $($version) + '\MSSQL' + $($majorversion) + '.' + $InstName + '\Tempdb'
        $global:ASDataDir = '/ASDATADIR=F:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Data'
        $global:ASLogDir = '/ASLOGDIR=G:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Log'
        $global:ASBackupDir = '/ASBACKUPDIR=F:\MS' + $($version) + '\MSAS' + $($majorversion) + '.' + $InstName + '\OLAP\Backup'
        $global:ASTempDir = '/ASTEMPDIR=H:\MS' + $($version) + '\MSAS' + $($majorversion)+ '.' + $InstName + '\OLAP\Temp'
        $global:Setup = '/C:\SQLInstall\Download\Binaries\setup.exe'
        $global:Config = "/configurationfile=""" + $SQLDML + $cnfgfl
        if($InstName -eq 'MSSQLSERVER')
        {
            $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQLSERVER'
            $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLSERVERAGENT'
        }
        else
        {
            $SqlSvcAcct = '/SQLSVCACCOUNT=NT Service\MSSQL$' + $InstName
            $AgtSvcAcct = '/AGTSVCACCOUNT=NT Service\SQLAgent$' + $InstName
        }
    }
    
    if(Test-Path -path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')
    {
       $installed_instances = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server").InstalledInstances
       if($installed_instances -contains "MSSQLSERVER")
       {
           Write-Host "A default SQL instance MSSQLSERVER already exists..."
           "FAILED" > $BatchOutput
           Exit 0
       }
    }

    $Time = get-date -Uformat "%Y%m%d%H%M"
	$pathforLogs = "C:\SQLInstall_Logs"
    if(!(Test-Path $pathforLogs))
    {
        New-Item -path $pathforLogs -ItemType Directory
    }
    $global:Log = "$pathforLogs\SQL_InstallSQLServer_$Time.txt"
	$Exec_Time = Get-Date

	Write-Host "###################################################################################################"
	Write-Host "Script Name: $ScriptName`nScript Version: $Scriptver`nExecuted On: $Exec_Time`nServer Host: $env:computername"
	Write-Host "###################################################################################################"

	"###################################################################################################" > $Log
	"Script Name: $ScriptName`nScript Version: $Scriptver`nExecute On: $Exec_Time`nServer Host: $env:computername" >> $Log
	"Execution string: $ScriptName $Process $Tier $Env" >> $Log
	"###################################################################################################" >> $Log

    Write-Host "Installing the RTM.."
    "Installing the RTM.." >> $Log
    InstallSQLInstance $setupfile
	Write-Host "Installation of RTM is done successfully.." -f Green
    "Installation of RTM is done successfully.." >> $Log
    Write-Host "`n****************Sleeping for 100 seconds..******************"
	start-sleep -s 100
    Write-Host "Applying the given patch.."
    ApplyPatch $setupfilepath
    "Applying the given patch.." >> $Log
    Write-Host "Apllication of patch is done successfully.." -f Green
    "Application of patch is done successfully.." >> $Log
    Write-Host "`n****************Sleeping for 50 seconds..******************"
	start-sleep -s 50
    Write-Host "Verifying the correctness of the SQL installation..."
    "Verifying the correctness of the SQL installation..." >> $Log
    VerifySQLInstall
    Write-Host "Verification is done successfully"
    "Verification is done successfully" >> $Log
    Write-Host "`n****************Sleeping for 50 seconds..******************"
    start-sleep -s 50
    Write-Host "Installing the SSRS and SSMS.. "
    "Installing the SSRS and SSMS.." >> $Log
    Install_SSRS_SSMS $setupfilepath
    Write-Host "Installation of SSRS and SSMS ia completed"
    "Installing the SSRS and SSMS ia completed" >> $Log
    Write-Host "`n****************Sleeping for 50 seconds..******************"
    start-sleep -s 50
    #Write-Host "Installing the sqlserver powershell module"
    Install_PS_Module $setupfilepath
    Write-Host "Installing the sqlserver ps module is completed successfully"

    if((Get-Content $BatchOutput) -ine "FAILED")
    {
        Write-Host "`n***************Installation of RTM, patch apply, Installation os SSRS, SSMS, PS module are done successfully...`n" -f Green
        "SUCCESS" > $BatchOutput
    }

}
catch
{
    Write-Host "Error Occurred in installation :  $_"
}

